# Final Audit — Accounting / CurrencyController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/CurrencyController.php` (299 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/currency` (redirects to the Configurations page) · `/accounting/configurations?tab=currencies` (the live list, rendered by `AccDashboardController`) · `/accounting/currency/create` · `/accounting/currency/{id}` (view) · `/accounting/currency/{id}/edit` · `/accounting/currency/trash/view` · `POST /accounting/currency` · `PUT /accounting/currency/{id}` · `DELETE /accounting/currency/{id}` · `POST /accounting/currency/{id}/toggle-status` · `POST /accounting/currency/{id}/make-base` · `GET /accounting/currency/{id}/restore` · `DELETE /accounting/currency/{id}/force-delete` |
| Menu path | Accounting → Configurations → Currencies tab (the Setup & Masters page redirects this tab to Configurations — `AccDashboardController::setupMasters` line 100-101). |
| Who uses it | Five seeded roles hold all seven `tenant.accounting.currency.*` permissions: **Account Manager, Account Staff, Management, School Admin, Super Admin** (exact-name query on `sys_role_has_permissions_jnt`, output in §6-CRNC-08). |
| What a user does here | A currency master. The user adds a currency (ISO code, name, symbol, decimal places), edits it, marks exactly one currency as the reporting "base", toggles it active/inactive, and moves it to the trash where it can be restored or permanently deleted. Exactly one row may have `is_base = 1`; the database enforces that with a unique index on the generated `base_flag` column. |
| Tables written | `acc_currencies` (insert / update / soft-delete / force-delete) and the tenant activity log `sys_activity_logs` (written by the common `activityLog()` helper). |
| Tables read | `acc_currencies`. The live list is read by `AccDashboardController@configurations` (another controller). Permanently deleting a currency is also constrained by five `RESTRICT` foreign keys: `acc_bill_references`, `acc_exchange_rates`, `acc_ledgers`, `acc_opening_balances`, `acc_vouchers`. |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: `acc_currencies` = **5 total, 0 trashed, 5 active, 1 base**; `acc_exchange_rates` = 4 rows, referencing currency ids 2, 3, 4 and 5. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready as it stands. The single worst finding is **CRNC-01 (B)**: all seven write paths catch `\Throwable` and print `$e->getMessage()` to the user, so a failed save shows raw SQL, table names and column names; because `forceDelete()` is also the only guard against a `RESTRICT` foreign key, a perfectly ordinary "permanently delete a used currency" attempt triggers exactly that leak. The second systemic issue is D1: every mutation uses `try/catch` plus manual `DB::beginTransaction()/commit()/rollBack()`, and `forceDelete()` returns from inside an open transaction. The controller is small (299 lines, 12 methods — not a god controller) and its authorization names are correct and seeded. Effort to fix the plan: **M** (roughly half a day: one transaction/error rewrite of seven methods, a base-currency guard, a route verb change, pagination, style, and three decisions — permission constants, a duplicate create UI, and the permanent-delete reference policy).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 7 | 8 | 3 | 20 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CRNC-01, CRNC-02, CRNC-03, CRNC-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CRNC-05, CRNC-06 | F9 Queries/Perf | CRNC-17 |
| F3 Authorization | CRNC-07, CRNC-08 | F10 Views | clean |
| F4 Validation | CRNC-09 | F11 Security/Tenancy | clean |
| F5 Routes | CRNC-10 | F12 Style | CRNC-18 |
| F6 Controller shape | CRNC-11, CRNC-12, CRNC-13, CRNC-14, CRNC-15, CRNC-16 | F13 Deep read | CRNC-19, CRNC-20 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/CurrencyController.php` | controller | 299 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/Currency.php` | model | 74 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/CurrencyRequest.php` | FormRequest | 52 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/resources/views/currency/create.blade.php` | blade | 120 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/currency/edit.blade.php` | blade | 123 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/currency/show.blade.php` | blade | 131 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/currency/trash.blade.php` | blade | 69 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/currency/index.blade.php` | blade | 100 | this report | ✅ (dead — CRNC-16) |
| 9 | `database/migrations/tenant/2026_09_16_100004_create_acc_currencies_table.php` | migration | 48 | this report | ✅ (structure checked; never edited) |
| 10 | `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php` | migration | 153 | shared migration | checked only — confirms `acc_currencies.deleted_at` exists |
| 11 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 12 | `Modules/Accounting/app/Services/AccountingContext.php` | service | — | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 13 | `Modules/Accounting/app/Models/ExchangeRate.php` | related model | 58 | ↗ [gaurav/Accounting/ExchangeRateController](../ExchangeRateController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_currencies.blade.php` | blade (live list) | 269 | AccDashboardController report (CLAIMED 2026-10-19 — report not written yet) | ↗ linked / checked only |
| 15 | `Modules/Accounting/routes/web.php` | route file | 536 | not owned by this report — ⚠ SHARED | checked only |
| 16 | `config/permissionslist.php` | config | — | common/shared | checked only |
| 17 | `app/Helpers/activityLog.php` | helper | — | common | checked only |

No pre-applied files (`PRE-APPLIED-*.md`) apply to the Accounting module.

`BaseAccountingModel` and `AccountingContext` are already owned by other Accounting reports (`_Info/00-CLASS-OWNERS.md`), so they are **linked, not re-audited**. Any defect noticed in them is recorded as a cross-cutting note in §7.

## 4. Routes

```
GET|HEAD  accounting/currency                       accounting.currency.index        CurrencyController@index
POST      accounting/currency                       accounting.currency.store        CurrencyController@store
GET|HEAD  accounting/currency/create                accounting.currency.create       CurrencyController@create
GET|HEAD  accounting/currency/trash/view            accounting.currency.trashed      CurrencyController@trashed
GET|HEAD  accounting/currency/{currency}            accounting.currency.show         CurrencyController@show
PUT|PATCH accounting/currency/{currency}            accounting.currency.update       CurrencyController@update
DELETE    accounting/currency/{currency}            accounting.currency.destroy      CurrencyController@destroy
GET|HEAD  accounting/currency/{currency}/edit       accounting.currency.edit         CurrencyController@edit
POST      accounting/currency/{currency}/make-base  accounting.currency.makeBase     CurrencyController@makeBase
POST      accounting/currency/{currency}/toggle-status accounting.currency.toggleStatus CurrencyController@toggleStatus
DELETE    accounting/currency/{id}/force-delete     accounting.currency.forceDelete  CurrencyController@forceDelete
GET|HEAD  accounting/currency/{id}/restore          accounting.currency.restore      CurrencyController@restore
```

Every route carries the tenant middleware chain `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Accounting, Authenticate, EnsureEmailIsVerified` — RTE-05 clean (output from the uncached `route:list` probe).

Unrouted public methods: **none** — all 12 public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET accounting/currency | `tenant.accounting.currency.viewAny` | — | — | — | CRNC-12 |
| `create` | 24 | GET accounting/currency/create | `tenant.accounting.currency.create` | — | — | — | CRNC-12, CRNC-15 |
| `store` | 31 | POST accounting/currency | `tenant.accounting.currency.create` | controller | 'Created' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-03, CRNC-04, CRNC-05, CRNC-07, CRNC-14, CRNC-19 |
| `show` | 68 | GET accounting/currency/{currency} | `tenant.accounting.currency.view` | — | — | — | CRNC-12 |
| `edit` | 75 | GET accounting/currency/{currency}/edit | `tenant.accounting.currency.update` | — | — | — | CRNC-12 |
| `update` | 82 | PUT accounting/currency/{currency} | `tenant.accounting.currency.update` | controller | 'Updated' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-03, CRNC-04, CRNC-05, CRNC-07, CRNC-14, CRNC-19 |
| `makeBase` | 123 | POST accounting/currency/{currency}/make-base | `tenant.accounting.currency.update` | controller | 'MadeBase' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-03, CRNC-04, CRNC-05, CRNC-13, CRNC-14 |
| `destroy` | 165 | DELETE accounting/currency/{currency} | `tenant.accounting.currency.delete` | controller | 'Trashed' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-03, CRNC-04, CRNC-05, CRNC-06 |
| `toggleStatus` | 199 | POST accounting/currency/{currency}/toggle-status | `tenant.accounting.currency.update` | controller | 'Toggled' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-03, CRNC-04, CRNC-05 |
| `trashed` | 234 | GET accounting/currency/trash/view | `tenant.accounting.currency.restore` | — | — | — | CRNC-17 |
| `restore` | 243 | GET accounting/currency/{id}/restore | `tenant.accounting.currency.restore` | controller | 'Restored' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-02, CRNC-03, CRNC-04, CRNC-05, CRNC-11 |
| `forceDelete` | 270 | DELETE accounting/currency/{id}/force-delete | `tenant.accounting.currency.forceDelete` | controller | 'Deleted' | acc_currencies, sys_activity_logs | CRNC-01, CRNC-02, CRNC-03, CRNC-04, CRNC-05, CRNC-11, CRNC-20 |

## 6. Findings

### F1 — Errors

#### CRNC-01 · B · ERR-01 — Raw exception text is shown to the user on every failed write

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:60,64,116,119,155,158,161,193,195,228,230,264,266,294,296` — methods `store()`, `update()`, `makeBase()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every `catch (\Throwable $e)` builds the flash or JSON message by concatenating `$e->getMessage()`. A `QueryException` message contains the SQL statement, the table name and the column name; a `ModelNotFoundException` message contains the model class and id. |
| **Consequence** | Any failed save — for example permanently deleting a currency that a voucher or ledger still references — shows the user raw SQL such as `SQLSTATE[23000]: Integrity constraint violation: 1451 Cannot delete or update a parent row...` instead of a friendly message. |
| **Reproduce** | Trash a currency that has an exchange rate or ledger row, then press "Permanent Delete": the `fk_acc_*` RESTRICT key fires and the red flash prints the SQL text. |
| **Fix approach** | Remove the `catch` blocks entirely (D1). Let the central handler in `bootstrap/app.php` render the failure; no message is composed from the exception. |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (also resolves CRNC-02/03/04/05/06/12/13/14/19) |

```php
// CurrencyController.php:57-65 — CURRENT (representative; the same shape repeats 7x)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Currency', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Currency: ' . $e->getMessage());
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "getMessage"
60:'error' => $e->getMessage(),
64:return back()->withInput()->with('error', 'Failed to create Currency: ' . $e->getMessage());
116:'error' => $e->getMessage(),
119:return back()->withInput()->with('error', 'Failed to update Currency: ' . $e->getMessage());
155:Log::error('Failed to set base currency', ['id' => $currency->id, 'error' => $e->getMessage()]);
158:return response()->json(['success' => false, 'message' => 'Failed to set base currency: ' . $e->getMessage()], 500);
161:return back()->with('error', 'Failed to set base currency: ' . $e->getMessage());
193:Log::error('Failed to trash Currency', ['id' => $currency->id, 'error' => $e->getMessage()]);
195:return back()->with('error', 'Failed to trash Currency: ' . $e->getMessage());
228:Log::error('Failed to toggle Currency status', ['id' => $currency->id, 'error' => $e->getMessage()]);
230:return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
264:Log::error('Failed to restore Currency', ['id' => $id, 'error' => $e->getMessage()]);
266:return back()->with('error', 'Failed to restore Currency: ' . $e->getMessage());
294:Log::error('Failed to force delete Currency', ['id' => $id, 'error' => $e->getMessage()]);
296:return back()->with('error', 'Failed to delete Currency: ' . $e->getMessage());
```

#### CRNC-02 · H · ERR-02 — A missing record gives a redirect instead of a 404 (`findOrFail()` inside `try`)

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:249` (`restore()`), `:276` (`forceDelete()`) |
| **Root cause** | `Currency::onlyTrashed()->findOrFail($id)` and `Currency::withTrashed()->findOrFail($id)` sit inside the `try`. The `ModelNotFoundException` that should be a 404 is caught by the generic `catch (\Throwable $e)` and converted to `back()->with('error', …)`. |
| **Consequence** | Opening a restore or force-delete link for an id that no longer exists shows a red flash plus the raw exception text, instead of a clean 404. |
| **Reproduce** | While logged in, open `/accounting/currency/999999/restore`. Expected 404; actual: redirect back with "Failed to restore Currency: …". |
| **Fix approach** | Move `findOrFail()` above the transaction and remove the `try` (D1). |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CurrencyController.php:247-251 — CURRENT
        DB::beginTransaction();
        try {
            $model = Currency::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "findOrFail"
249:$model = Currency::onlyTrashed()->findOrFail($id);
276:$model = Currency::withTrashed()->findOrFail($id);
```

#### CRNC-03 · M · ERR-05 — `Log::error()` logs the message string, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:59-62,114-117,155,193,228,264,294` |
| **Root cause** | The catch blocks pass `['error' => $e->getMessage()]` (and in `store()` a separately formatted trace string) to `Log::error()` instead of the exception object. |
| **Consequence** | When a save fails in production the log holds only a bare message, so the failure cannot be located from the stack. |
| **Reproduce** | static only — requires a failing write and inspection of `storage/logs`. |
| **Fix approach** | Remove the catches (D1). Where a service must log, use `report($e)`. |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CurrencyController.php:59-62 — CURRENT
            Log::error('Failed to create Currency', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "Log::error"
59:Log::error('Failed to create Currency', [
114:Log::error('Failed to update Currency', [
155:Log::error('Failed to set base currency', ['id' => $currency->id, 'error' => $e->getMessage()]);
193:Log::error('Failed to trash Currency', ['id' => $currency->id, 'error' => $e->getMessage()]);
228:Log::error('Failed to toggle Currency status', ['id' => $currency->id, 'error' => $e->getMessage()]);
264:Log::error('Failed to restore Currency', ['id' => $id, 'error' => $e->getMessage()]);
294:Log::error('Failed to force delete Currency', ['id' => $id, 'error' => $e->getMessage()]);
```

#### CRNC-04 · M · ERR-00 — Controller `try/catch` blocks violate the D1 idiom

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, D1) — *no `try/catch` in a controller unless a D2 shape; `DB::transaction()` rolls back and rethrows by itself* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:37-38/57-58, 92-93/112-113, 127-128/153-154, 173-174/191-192, 212-213/226-227, 247-248/262-263, 274-275/292-293` |
| **Root cause** | All seven mutating methods wrap the write in `try { … } catch (\Throwable $e) { … }`, the Variant H house style that D1 replaced with the Laravel idiom. None of the catches is a D2 shape. |
| **Consequence** | Every catch is a place to get ERR-01/02/05 wrong (as they are, above), and the friendly message is hand-composed instead of rendered by the central handler. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Delete the `try/catch` and the manual transaction; use one `DB::transaction(fn () => …)`. |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CurrencyController.php:37-38 and 57-58 — CURRENT (open and close of one of the 7 blocks)
        DB::beginTransaction();
        try {
            …
        } catch (\Throwable $e) {
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "\btry \{|\} catch"
38:try {        57:} catch (\Throwable $e) {
93:try {       112:} catch (\Throwable $e) {
128:try {      153:} catch (\Throwable $e) {
174:try {      191:} catch (\Throwable $e) {
213:try {      226:} catch (\Throwable $e) {
248:try {      262:} catch (\Throwable $e) {
275:try {      292:} catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### CRNC-05 · M · TXN-02 — Manual `beginTransaction()/commit()/rollBack()`; `forceDelete()` returns inside an open transaction

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, never manual `beginTransaction`/`commit`/`rollBack`; never `return` between them* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:37/53/58, 92/108/113, 127/142/154, 173/187/192, 212/223/227, 247/259/263, 274/289/293`; the early return is at `277-279` |
| **Root cause** | Each method opens the transaction by hand. In `forceDelete()` the base-currency guard returns `back()` **after** `DB::beginTransaction()` (line 274) and before any `commit()`/`rollBack()`, leaving the transaction open on the connection. |
| **Consequence** | An early return during force-delete leaves an uncommitted transaction open for the rest of the request; a later write on the same connection can be rolled back or locked. |
| **Reproduce** | static only — the guard path at `forceDelete()` for a base currency. |
| **Fix approach** | Replace manual transactions with `DB::transaction(fn () => …)` and move the guard above it. |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CurrencyController.php:274-279 — CURRENT (return between begin and commit)
        DB::beginTransaction();
        try {
            $model = Currency::withTrashed()->findOrFail($id);
            if ($model->isBase()) {
                return back()->with('error', 'The base currency cannot be deleted.');
            }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "beginTransaction|DB::commit|DB::rollBack"
37:DB::beginTransaction();   53:DB::commit();   58:DB::rollBack();
92:DB::beginTransaction();  108:DB::commit();  113:DB::rollBack();
127:DB::beginTransaction(); 142:DB::commit();  154:DB::rollBack();
173:DB::beginTransaction(); 187:DB::commit();  192:DB::rollBack();
212:DB::beginTransaction(); 223:DB::commit();  227:DB::rollBack();
247:DB::beginTransaction(); 259:DB::commit();  263:DB::rollBack();
274:DB::beginTransaction(); 289:DB::commit();  293:DB::rollBack();
```

#### CRNC-06 · M · TXN-06 — `destroy()` checks "is base?" outside the transaction (check-then-act race)

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M) — *check-then-act needs a lock or a unique index (`count()` then insert, `exists()` then `create()`)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:169` (the `isBase()` check) compared with `:173` (`DB::beginTransaction()`) and `:179` (`$currency->delete()`) |
| **Root cause** | The "base currency cannot be deleted" guard reads `is_base` before the transaction starts. A concurrent `makeBase()` for the same row can set it to base between the check and the soft delete. The unique index on `base_flag` does not prevent this: it only prevents a second base row; the soft-deleted row keeps `base_flag = 1`. |
| **Consequence** | Two concurrent requests can leave the tenant with its only base currency in the trash; because the trashed row still holds the unique `base_flag`, a new base cannot be designated until the row is restored. |
| **Reproduce** | static only — needs two concurrent requests (`DELETE /accounting/currency/{id}` and `POST /accounting/currency/{id}/make-base`). |
| **Fix approach** | Re-fetch the row with `lockForUpdate()` inside the transaction and re-check `is_base` before deleting (see the CRNC-01 `destroy()` After block). |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (the `destroy()` rewrite adds the lock) |

```php
// CurrencyController.php:169-179 — CURRENT
        if ($currency->isBase()) {
            return back()->with('error', 'The base currency cannot be deleted because all accounts and reports depend on it.');
        }

        DB::beginTransaction();
        try {
            $name = $currency->name;
            $code = $currency->code;
            $currency->is_active = false;
            $currency->save();
            $currency->delete();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "isBase\(\)|beginTransaction|->delete\(\)"
88:if ($currency->isBase() && empty($validated['is_base'])) {
169:if ($currency->isBase()) {
173:DB::beginTransaction();
179:$currency->delete();
205:if ($currency->isBase() && !$request->boolean('is_active')) {
277:if ($model->isBase()) {
```

### F3 — Authorization

#### CRNC-07 · L · AUTH-04 — The same permission is authorized twice (FormRequest + Gate)

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Requests/CurrencyRequest.php:17` and `Modules/Accounting/app/Http/Controllers/CurrencyController.php:33` (`store`), `:84` (`update`) |
| **Root cause** | `CurrencyRequest::authorize()` maps POST→`create` and PUT→`update` on `tenant.accounting.currency` (via `AuthorizesTenantFeature`), and the controller then calls `Gate::authorize()` for the same permission. |
| **Consequence** | Two identical checks run per store/update request; a future change to one silently diverges from the other. Harmless today, hence L. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first) and drop the redundant `Gate::authorize()` in `store()`/`update()`. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted: belt-and-braces duplicate) |

```php
// CurrencyRequest.php:15-18 (FIRST check) and CurrencyController.php:33 (SECOND check)
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.currency');
    }
```
```php
        Gate::authorize('tenant.accounting.currency.create');   // store()
        Gate::authorize('tenant.accounting.currency.update');   // update()
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Requests\CurrencyRequest.php -Pattern "authorizeByCrudPermission"
17:return $this->authorizeByCrudPermission('tenant.accounting.currency');
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "currency.create'|currency.update'"
33:Gate::authorize('tenant.accounting.currency.create');
84:Gate::authorize('tenant.accounting.currency.update');
```

#### CRNC-08 · M · AUTH-06 — Permission strings are repeated as literals in 12 controller places

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place (a Policy or constants), not repeated as literals in every method* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:19,26,33,70,77,84,125,167,201,236,245,272` (plus `CurrencyRequest.php:17` and four blades) |
| **Root cause** | The seven `tenant.accounting.currency.*` names are hard-coded in every method, in the request, and in the views. |
| **Consequence** | A rename or typo in one place produces a permission check that silently never matches; `Gate::before()` hides the mistake from Super Admin. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Introduce constants (or a Policy) and reference them from controller/request/views. Cross-file refactor → DECISION. |
| **Plan item** | CRNC-08 in `02-fix-plan.md` §9 |

```php
// CurrencyController.php:19 — CURRENT (representative)
        Gate::authorize('tenant.accounting.currency.viewAny');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "Gate::authorize"
19:tenant.accounting.currency.viewAny   26:tenant.accounting.currency.create
33:tenant.accounting.currency.create    70:tenant.accounting.currency.view
77:tenant.accounting.currency.update    84:tenant.accounting.currency.update
125:tenant.accounting.currency.update   167:tenant.accounting.currency.delete
201:tenant.accounting.currency.update   236:tenant.accounting.currency.restore
245:tenant.accounting.currency.restore  272:tenant.accounting.currency.forceDelete
$ Select-String -Path config\permissionslist.php -Pattern "'accounting.currency'"
623:'accounting.currency' => $crud,
```

The seven names are seeded exactly once each (exact-name query, not `LIKE`):

```
tenant.accounting.currency.create       1
tenant.accounting.currency.delete       1
tenant.accounting.currency.forceDelete  1
tenant.accounting.currency.restore      1
tenant.accounting.currency.update       1
tenant.accounting.currency.view         1
tenant.accounting.currency.viewAny      1
```

Five roles hold all seven: Account Manager, Account Staff, Management, School Admin, Super Admin.

### F4 — Validation and input

#### CRNC-09 · L · VAL-05 — The create form posts a `base_flag` field that is never validated or stored

| Field | Value |
|---|---|
| **Rule** | VAL-05 (L) — *every field is typed; a field that is neither validated nor accepted is silently dropped* |
| **Where** | `Modules/Accounting/resources/views/currency/create.blade.php:79-89` vs `Modules/Accounting/app/Http/Requests/CurrencyRequest.php:24-31` |
| **Root cause** | The form renders a text input named `base_flag`, but `CurrencyRequest::rules()` does not declare `base_flag`, so `validated()` never contains it. `base_flag` is also a **generated** column in MySQL (`storedAs('(case when (is_base = 1) then 1 else NULL end)')`), so it cannot be written directly. |
| **Consequence** | A user types a value into "Base Flag", saves, and the value disappears with no error; the stored flag is derived only from the "Is Base Currency" switch. |
| **Reproduce** | Open `/accounting/currency/create`, type `1` in "Base Flag", fill the rest, Save; re-open the row — the Base Flag shown is whatever `is_base` produced. |
| **Fix approach** | Remove the dead `base_flag` control from `create.blade.php`. |
| **Plan item** | CRNC-09 in `02-fix-plan.md` §7 |

```php
// create.blade.php:79-89 — CURRENT
                                    <div class="col-md-6 col-lg-4">
                                        <x-backend.form.input-text
                                            type="text"
                                            name="base_flag"
                                            id="base_flag"
                                            label="Base Flag"
                                            placeholder="Enter base flag"
                                            required="false"
                                            value="{{ old('base_flag') }}"
                                        />
                                    </div>
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\currency\create.blade.php -Pattern "base_flag"
82:name="base_flag"
83:id="base_flag"
87:value="{{ old('base_flag') }}"
$ Select-String -Path Modules\Accounting\app\Http\Requests\CurrencyRequest.php -Pattern "base_flag"
(no output — not in rules())
```

### F5 — Routes

#### CRNC-10 · H · RTE-01 — A restore (state change) is performed over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:374` → `CurrencyController@restore` |
| **Root cause** | The route is registered as `Route::get('/currency/{id}/restore', …)`, and `restore()` writes to the database. |
| **Consequence** | Any crawl, browser prefetch, or a link shared in chat can silently restore a trashed currency with no CSRF token and no confirmation. |
| **Reproduce** | While logged in, open `/accounting/currency/{trashedId}/restore` directly — the currency is restored. |
| **Fix approach** | Change the verb to POST. The shared `x-backend.table.action-trashed` component already reads `methods()` from the route and renders a POST form with `@csrf` automatically, so no component change is needed. |
| **Plan item** | CRNC-10 in `02-fix-plan.md` §5 — ⚠ SHARED (route file) |

```php
// routes/web.php:374 — CURRENT
Route::get('/currency/{id}/restore', [CurrencyController::class, 'restore'])->name('currency.restore');
```

**Evidence**
```
$ php artisan route:list (uncached, via routesprobe) — verb column
GET|HEAD  accounting/currency/{id}/restore   accounting.currency.restore
```

### F6 — Controller shape

#### CRNC-11 · L · CTL-03 — `restore()`/`forceDelete()` use `$id` + `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (L, lowered from M: no user-visible effect, consistency only) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:243,249,270,276` |
| **Root cause** | Both methods accept a raw `$id` and load the model by hand. |
| **Consequence** | None user-visible; it is a consistency issue and blocks the automatic 404 that binding provides (the controller re-adds a manual 404 through `findOrFail`). |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Bind `Currency $currency` with `->withTrashed()` on the shared route, then use the bound model. Deferred to a route change. |
| **Plan item** | none — see `02-fix-plan.md` §10 (deferred: needs a `⚠ SHARED` route change) |

```php
// CurrencyController.php:243-249 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.currency.restore');

        DB::beginTransaction();
        try {
            $model = Currency::onlyTrashed()->findOrFail($id);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "findOrFail"
249:$model = Currency::onlyTrashed()->findOrFail($id);
276:$model = Currency::withTrashed()->findOrFail($id);
```

#### CRNC-12 · L · CTL-04 — Nine public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:17,24,31,68,75,82,123,165,199` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type; the other nine do not (and use a fully-qualified type where they do). |
| **Consequence** | None user-visible; typing drift makes a wrong return shape a runtime surprise instead of a static error. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Add `: RedirectResponse` / `: View` / `: JsonResponse` and import the three classes (folded into the CRNC-01 rewrite). |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (the rewrite adds the return types) |

```php
// CurrencyController.php:17,24 — CURRENT
    public function index()
    {
    public function create()
    {
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "public function"
17:public function index()
24:public function create()
31:public function store(CurrencyRequest $request)
68:public function show(Currency $currency)
75:public function edit(Currency $currency)
82:public function update(CurrencyRequest $request, Currency $currency)
123:public function makeBase(Currency $currency)
165:public function destroy(Currency $currency)
199:public function toggleStatus(Request $request, Currency $currency)
234:public function trashed(): \Illuminate\View\View
243:public function restore($id): \Illuminate\Http\RedirectResponse
270:public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### CRNC-13 · L · CTL-08 — `makeBase()` uses the `request()` helper instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; do not call the `request()` helper inside controller methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:144,157` |
| **Root cause** | The signature is `makeBase(Currency $currency)`; it reaches for `request()->wantsJson()` / `request()->ajax()` twice. |
| **Consequence** | None user-visible; inconsistent request handling and harder to test. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Change the signature to `makeBase(Request $request, Currency $currency)` and use `$request`. |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (the rewrite injects `Request`) |

```php
// CurrencyController.php:144,157 — CURRENT
            if (request()->wantsJson() || request()->ajax()) {
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "request\(\)"
144:if (request()->wantsJson() || request()->ajax()) {
157:if (request()->wantsJson() || request()->ajax()) {
```

#### CRNC-14 · M · CTL-05 — The "unset every other base" statement is copy-pasted in three methods

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; one implementation of one operation* (also SVC-04) |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:40` (`store`), `:95` (`update`), `:129` (`makeBase`) |
| **Root cause** | The bulk update `Currency::…->update(['is_base' => false])` is written three times, with two different scopes (all rows vs. all but the current id). There is no single owner of the "exactly one base" invariant. |
| **Consequence** | A future change to the rule (e.g. also filtering trash) must be made in three places; the copies already differ in their `where` clause, which is exactly the drift the rule warns about. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Extract one private method `unsetOtherBaseCurrencies(?int $exceptId = null)` and call it from all three (folded into the CRNC-01 rewrite). |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (the rewrite adds the helper) |

```php
// CurrencyController.php:40,95,129 — CURRENT (three copies)
Currency::query()->update(['is_base' => false]);
Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "is_base' => false"
40:Currency::query()->update(['is_base' => false]);
95:Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
129:Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
```

#### CRNC-15 · L · CTL-05 — Two "create currency" UIs exist (modal + full page)

| Field | Value |
|---|---|
| **Rule** | CTL-05 (L) — *no copy-paste; the same form duplicated* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:24-29` (`create()`) and `resources/views/currency/create.blade.php` vs `resources/views/pages/partials/setup-masters/_currencies.blade.php` (`#createCurrencyModal`) |
| **Root cause** | The live Currencies tab creates a currency through the modal (POST `accounting.currency.store`), while the routed `create()` page duplicates the same fields (and adds the dead `base_flag` control, CRNC-09). |
| **Consequence** | Two forms to maintain; only the modal is reachable from the live tab. |
| **Reproduce** | Compare `?tab=currencies` → "Add Currency" (modal) with `/accounting/currency/create` (full page). |
| **Fix approach** | Decide which UI is canonical and remove the other. This changes a routed page → DECISION. |
| **Plan item** | CRNC-15 in `02-fix-plan.md` §9 |

```php
// CurrencyController.php:24-29 — CURRENT
    public function create()
    {
        Gate::authorize('tenant.accounting.currency.create');

        return view('accounting::currency.create');
    }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\pages\partials\setup-masters\_currencies.blade.php -Pattern "createCurrencyModal|currency.store"
140:id="createCurrencyModal"
144::action="route('accounting.currency.store')"
$ Select-String -Path Modules\Accounting\resources\views\currency\create.blade.php -Pattern "currency.store"
25:<form action="{{ route('accounting.currency.store') }}" method="POST">
```

#### CRNC-16 · L · CTL-10 — Dead view `currency/index.blade.php` and dead `Currency::selectable()`

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code: unused methods, unused view files* |
| **Where** | `Modules/Accounting/resources/views/currency/index.blade.php` (100 lines, never rendered) and `Modules/Accounting/app/Models/Currency.php:69-73` (`selectable()`, no caller) |
| **Root cause** | `index()` redirects to the Configurations page, whose Currencies tab is rendered by `_currencies.blade.php`; `currency/index.blade.php` is referenced nowhere except the breadcrumb registry. `Currency::selectable()` is defined but never called (the live code uses `Ledger::selectableCurrencies()`). |
| **Consequence** | None user-visible; the dead view drifts from the real UI and misleads the next developer. |
| **Reproduce** | static only — grep for callers. |
| **Fix approach** | Delete `currency/index.blade.php` and `Currency::selectable()` after confirming no external module calls it. |
| **Plan item** | CRNC-16 in `02-fix-plan.md` §5 |

```php
// Currency.php:69-73 — CURRENT
    /** Active currencies ordered by code — for dropdowns. */
    public static function selectable()
    {
        return static::active()->orderBy('code')->get();
    }
```

**Evidence**
```
$ Get-ChildItem Modules,app,config,resources -Recurse -Include *.php | Select-String "currency\.index"
app\Services\Breadcrumbs\registry.php:174:'accounting.currency.index' => [
config\breadcrumbs.php:1507:'accounting.currency.index' => [
$ Get-ChildItem Modules,app,resources -Recurse -Include *.php | Select-String "Currency::selectable|->selectable\(\)"
(no output)
```

### F7 — Models

clean — `Currency` declares `$fillable` (no sensitive column), casts every boolean/integer (`decimal_places`, `is_base`, `base_flag`, `is_active`), its `$table` `acc_currencies` exists in `2026_09_16_100004_create_acc_currencies_table.php`, `SoftDeletes` matches the `deleted_at` column added by `2026_09_16_130001_…`, and both relationships are return-typed. Proof command:

```
$ Select-String -Path Modules\Accounting\app\Models\Currency.php -Pattern "protected \$table|protected \$fillable|protected \$casts|HasMany|HasOne|is_base|is_active"
13:protected $table = 'acc_currencies';
15:protected $fillable = [
24:protected $casts = [
33:public function exchangeRates(): HasMany
39:public function currentRate(): HasOne
$ mysql -uroot -N -e "SELECT INDEX_NAME, GROUP_CONCAT(COLUMN_NAME) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA='xyz_school_00000000000040008000_202627' AND TABLE_NAME='acc_currencies' GROUP BY INDEX_NAME"
chk_acc_base_currency  base_flag
PRIMARY  id
uq_acc_currency_code  code
```

`currentRate()` uses `latestOfMany('rate_date')`; `acc_exchange_rates` has `rate_date`, `currency_id` and the table exists (checked in §3 row 13). The `ExchangeRate` model itself is owned by the ExchangeRateController report and was not re-audited.

### F8 — Services and jobs

clean — no service, job, event, listener, mail or notification is named by this controller. Proof: `Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern 'Service|Job|Event|Listener|Mail|Notification'` → no output.

### F9 — Queries and performance

#### CRNC-17 · M · QRY-02 — The trash list paginates at 15, not the standard 10, with no distinct page name

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) / C12 — *lists paginate; the standard page size is 10 with a distinct `pageName` per list* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:238` |
| **Root cause** | `paginate(15)` uses a non-standard size and the default page name (`page`), so it can collide with another paginator on the same screen. |
| **Consequence** | The trash list is inconsistent with the rest of the app and can fight a second paginator for the `page` query parameter. |
| **Reproduce** | Open `/accounting/currency/trash/view` — 15 rows per page. |
| **Fix approach** | Use `paginate(10, ['*'], 'currency_page')`. |
| **Plan item** | CRNC-17 in `02-fix-plan.md` §6 |

```php
// CurrencyController.php:238 — CURRENT
        $currencies = Currency::onlyTrashed()->orderBy('code')->paginate(15);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "paginate"
238:$currencies = Currency::onlyTrashed()->orderBy('code')->paginate(15);
```

### F10 — Views

clean — no queries, no `@php`, no `{!! !!}` in the five currency blades. Proof: `Select-String -Path Modules\Accounting\resources\views\currency\*.blade.php -Pattern 'Model::|DB::|->get\(\)|->count\(\)|->where\(|@php|\{!!'` → no output. Row actions use `x-backend.table.action` / `action-trashed`; the status switch uses `x-backend.table.status-switch`. The live list partial `_currencies.blade.php` is owned by the AccDashboardController report (cross-cutting note §7).

### F11 — Security and tenancy

clean — no `env()` call in the controller (`Select-String … -Pattern 'env\('` → no output), no `$request->all()`/`except()`/`fill()` (same check → no output), no hard-coded tenant/user id, no request body logging. The two support classes that this model reaches (`BaseAccountingModel`, `AccountingContext`) contain `?? 1` fallbacks but are owned by other reports, so they are cross-cutting notes (§7), not re-audited here.

### F12 — Style

#### CRNC-18 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php`, `Modules/Accounting/app/Models/Currency.php`, `Modules/Accounting/app/Http/Requests/CurrencyRequest.php` |
| **Root cause** | Import order, binary/not operator spacing, fully-qualified return types, `concat_space` and an unused `App\Models\BaseModel` import in `Currency` are not normalised. |
| **Consequence** | None user-visible; inconsistent style. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\CurrencyController.php Modules\Accounting\app\Models\Currency.php Modules\Accounting\app\Http\Requests\CurrencyRequest.php --format agent` reports `fail`. |
| **Fix approach** | Run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\CurrencyController.php Modules\Accounting\app\Models\Currency.php Modules\Accounting\app\Http\Requests\CurrencyRequest.php --format agent` (never `--dirty`). |
| **Plan item** | CRNC-18 in `02-fix-plan.md` §8 (one item, three files) |

```php
// Currency.php:7 — CURRENT (unused import; Pint no_unused_imports)
use App\Models\BaseModel;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\CurrencyController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\CurrencyController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]}]}
$ vendor\bin\pint --test Modules\Accounting\app\Models\Currency.php Modules\Accounting\app\Http\Requests\CurrencyRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Currency.php","fixers":["no_unused_imports","binary_operator_spaces"]},{"path":"Modules\\Accounting\\app\\Http\\Requests\\CurrencyRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Q1 write-overwrites? · Q2 deleted-before-replaced? · Q3 duplicate impls? · Q4 soft-delete×unique? · Q5 race? · Q6 auth hole? · Q7 lying message? · Q8 dead feature?

| Method | Q1 | Q2 | Q3 | Q4 | Q5 | Q6 | Q7 | Q8 |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | CRNC-14 | ok | ok | ok | CRNC-19 | ok |
| `update` | CRNC-19 | ok | CRNC-14 | ok | ok | ok | CRNC-19 | ok |
| `makeBase` | ok | ok | CRNC-14 | ok | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | CRNC-06 | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | CRNC-20 |

Q4 note: `CurrencyRequest` does **not** add `whereNull('deleted_at')`, so its unique rules see trashed rows exactly as the plain `uq_acc_currency_code` index does. A trashed code is rejected at validation (no DB 500); the user must restore the row. That mirrors the index, so Q4 is `ok`.

#### CRNC-19 · H · CTL-06 / VAL-07 — `update()` and `store()` can save the base currency as inactive, which `toggleStatus()` forbids

| Field | Value |
|---|---|
| **Rule** | CTL-06 (H, raised from M: it breaks the reporting base used by every account and report) — *business rules live in one place; a controller method reads input, calls one owner, returns a response* (also VAL-07, cross-field checks) |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:88-90` and `:94-98` (`update()`), `:35-43` (`store()`), compared with `:205-210` (`toggleStatus()`) |
| **Root cause** | `update()` guards only the *unsetting* of `is_base`; it does not guard `is_active`. The edit form has an "Active" checkbox, so unchecking it while keeping "Is Base Currency" checked saves an inactive base. `store()` likewise accepts `is_base = 1` together with `is_active = 0`. `toggleStatus()` is the only method that enforces "the base cannot be deactivated". |
| **Consequence** | The tenant can end up with an inactive base currency. `Currency::selectable()` and every dropdown scope `is_active = 1`, so the base disappears from pickers while `Currency::base()` still returns it, and reports that rely on an active base become inconsistent. |
| **Reproduce** | Edit the base currency (`/accounting/currency/{baseId}/edit`), leave "Is Base Currency" ticked, untick "Active", Save — it saves. Then try toggling it back on and off from the list: `toggleStatus()` returns 422 "The base currency cannot be deactivated." |
| **Fix approach** | Add the same guard to `update()` (cannot deactivate the base) and to `store()` (a base currency must be active). Folded into the CRNC-01 rewrite. |
| **Plan item** | CRNC-01 in `02-fix-plan.md` §1 (the rewrite adds both guards) |

```php
// CurrencyController.php:88-98 — CURRENT (guards is_base, not is_active)
        if ($currency->isBase() && empty($validated['is_base'])) {
            return back()->withInput()->with('error', 'Cannot unset base currency status. Designate another currency as base instead.');
        }

        DB::beginTransaction();
        try {
            if (!empty($validated['is_base'])) {
                Currency::where('id', '!=', $currency->id)->update(['is_base' => false]);
            }

            $currency->update($validated);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CurrencyController.php -Pattern "isBase\(\)|is_active"
88:if ($currency->isBase() && empty($validated['is_base'])) {
131:'is_base'   => true,
132:'is_active' => true,
169:if ($currency->isBase()) {
205:if ($currency->isBase() && !$request->boolean('is_active')) {
251:$model->update(['is_active' => true]);
277:if ($model->isBase()) {
```

#### CRNC-20 · H · CTL-06 — `forceDelete()` has no reference guard; five `RESTRICT` foreign keys make a used currency a 500

| Field | Value |
|---|---|
| **Rule** | CTL-06 (H, raised from M: a normal permanent-delete path throws) — *business rules live in a service/action; the controller reads input, calls one owner, returns a response* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CurrencyController.php:270-298` (`forceDelete()`); the constraints live in the tenant schema |
| **Root cause** | `forceDelete()` checks only `is_base`. Five tables hold a `RESTRICT` foreign key to `acc_currencies`: `acc_bill_references`, `acc_exchange_rates`, `acc_ledgers`, `acc_opening_balances`, `acc_vouchers`. Any trashed currency still referenced by one of them cannot be deleted, and the controller never checks this before calling `forceDelete()`. |
| **Consequence** | Pressing "Permanent Delete" on a currency used by a ledger/voucher/rate throws a `QueryException`. Today CRNC-01 shows the raw SQL; after CRNC-01 it becomes a generic 500. Either way the user is told nothing useful and the row is not deleted. |
| **Reproduce** | Trash a currency that has a row in `acc_exchange_rates` (live ids 2–5 each have one), open `/accounting/currency/trash/view`, press the eraser icon — the FK rejects the delete. |
| **Fix approach** | Decide the policy: pre-check the five tables and refuse with a friendly message (recommended), or change the FKs to cascade (migration). |
| **Plan item** | CRNC-20 in `02-fix-plan.md` §9 (DECISION) |

```php
// CurrencyController.php:274-281 — CURRENT (only the base check)
        DB::beginTransaction();
        try {
            $model = Currency::withTrashed()->findOrFail($id);
            if ($model->isBase()) {
                return back()->with('error', 'The base currency cannot be deleted.');
            }
            $name = $model->name;
            $model->forceDelete();
```

**Evidence**
```
$ mysql -uroot -N -e "SELECT TABLE_NAME, CONSTRAINT_NAME, DELETE_RULE FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA='xyz_school_00000000000040008000_202627' AND REFERENCED_TABLE_NAME='acc_currencies'"
acc_bill_references  fk_acc_billref_currency  RESTRICT
acc_exchange_rates   fk_acc_fx_currency       RESTRICT
acc_ledgers          fk_acc_ledger_currency   RESTRICT
acc_opening_balances fk_acc_ob_currency       RESTRICT
acc_vouchers         fk_acc_v_currency        RESTRICT
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_currencies.blade.php` | The live list calls `Gate::check(...)` inside Blade and passes `:canView`/`:canEdit`/`:canDelete` to `x-backend.table.action` (the props do nothing — component reads routes, not the props) | VIEW standard / table-action standard | the AccDashboardController report (CLAIMED 2026-10-19, not written yet) |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:445-461` | Builds the Currencies tab with `$currenciesQuery->get()` — **unbounded**, no pagination; the live list grows without limit | QRY-02 | the AccDashboardController report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | `Auth::id() ?? 1` fallback attributes a record to user id 1 when no user is resolved | SEC-03 | [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/app/Services/AccountingContext.php` | `return 1;` and `Auth::id() ?? 1` hard-coded id fallbacks | SEC-03 | [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) |
| `resources/views/components/backend/table/action-trashed.blade.php` | Reads the restore route's `methods()` and renders the matching form — verified it will emit a POST + `@csrf` when CRNC-10 changes the verb; no change needed | — | common (no defect) |
| `app/Helpers/activityLog.php` | Writes to `sys_activity_logs`; tenant-vs-central routing is correct; no defect found | — | common (no defect) |

## 8. Not covered, and why

- **The scanner and the self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are **missing** from the repository (`Test-Path` → `False` for both), and `scan.php` must not be run. Therefore the F1–F13 checklist was worked **manually** with `read`/`grep`, `php -l`, `pint --test`, MySQL queries and the uncached route probe. No scan-JSON evidence is quoted.
- **Routes** came from a freshly generated uncached list (`route:clear` + `APP_ROUTES_CACHE=$env:TEMP\fa-nocache.php`); the raw JSON was piped through the `routesprobe.php` helper only.
- **No tests were run** (D4). Runtime behaviour (the FK rejection, the concurrent race, the actual pagination count) is established from the schema and from static reading, not from a test.
- **The blades were read but not rendered**; no Blade compile check was run. The `x-backend.*` and `x-tenantcore::` components and the shared layout were not opened.
- **Relationships were verified statically** (`ExchangeRate` table and `rate_date`/`currency_id` columns exist) but were not executed in tinker, because running tenant-context queries is outside a read-only audit.
- **`BaseAccountingModel`, `AccountingContext` and `ExchangeRate`** are owned by other reports and were not re-audited; see §7.
- **The live Currencies list** lives in `_currencies.blade.php` and `AccDashboardController@configurations`, both outside this controller's ownership.
