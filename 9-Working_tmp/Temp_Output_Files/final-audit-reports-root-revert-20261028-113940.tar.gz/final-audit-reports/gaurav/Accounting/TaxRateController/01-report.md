# Final Audit — Accounting / TaxRateController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/TaxRateController.php` (227 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/configurations?tab=tax-rates` (list tab), `http://test.localhost:8000/accounting/tax-rate` (redirects to the tab), `/accounting/tax-rate/create`, `/accounting/tax-rate/{id}`, `/accounting/tax-rate/{id}/edit`, `/accounting/tax-rate/trash/view`, `/accounting/tax-rate/{id}/restore`, `/accounting/tax-rate/{id}/force-delete` |
| Menu path | Accounting → Configurations → Tax Rates tab (`glb_menus` id 88, route `accounting.menu.configurations`, permission `tenant.accounting.dashboard.view`) |
| Who uses it | Five roles hold every `tenant.accounting.tax-rate.*` permission: Super Admin, School Admin, Management, Account Staff, Account Manager (exact-name query on `sys_role_has_permissions_jnt`, 5 roles per permission). |
| What a user does here | Maintains the tax-rate master: tax type, name, percentage, HSN/SAC code, interstate flag, posting ledger and validity window. A user creates a rate from the tab's modal, edits one, toggles active/inactive, moves one to the trash, restores it, or permanently deletes it. |
| Tables written | `acc_tax_rates`, `sys_activity_logs` |
| Tables read | `acc_tax_rates`, `acc_tax_types` (tax-type dropdown and `exists` rule), `acc_ledgers` (`exists` rule), `sys_permissions` / `sys_role_has_permissions_jnt` (gates) |
| Live data | `acc_tax_rates` 6 live, 0 trashed; `acc_tax_types` 7; `sys_activity_logs` 433. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready. The single worst finding is TXRT-01: all six write paths hand-roll a transaction inside a `try/catch (\Throwable)` and append `$e->getMessage()` to the flash or JSON response, so a duplicate key or a failed database write shows raw SQL text (table and column names) to the user. The same six methods also turn a missing restore/force-delete id into a redirect instead of a 404 (TXRT-02) and log only the message without the exception (TXRT-03). The authorization model itself is sound — all seven permission names exist and are seeded to five roles — but the registered `TaxRatePolicy` is never consulted (TXRT-07), and the restore action is a state change over GET (TXRT-09). Rough effort is S/M (about one developer-day): the Blocker, the two error follow-ons and the transaction finding collapse into one mechanical rewrite of the six mutation bodies, plus one FormRequest default, one route verb, two Blade query fixes and three Pint runs.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 7 | 6 | 3 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TXRT-01, TXRT-02, TXRT-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | TXRT-04 | F9 Queries/Perf | TXRT-12 |
| F3 Authorization | TXRT-05, TXRT-06, TXRT-07 | F10 Views | TXRT-13, TXRT-14 |
| F4 Validation | TXRT-08 | F11 Security/Tenancy | clean |
| F5 Routes | TXRT-09 | F12 Style | TXRT-15, TXRT-16, TXRT-17 |
| F6 Controller shape | TXRT-10, TXRT-11 | F13 Deep read | TXRT-18 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/TaxRateController.php` | controller | 227 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/TaxRate.php` | model | 104 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/TaxRateRequest.php` | FormRequest | 64 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Policies/TaxRatePolicy.php` | policy | 36 | this report (unclaimed; not yet in `_Info/00-CLASS-OWNERS.md`) | ✅ |
| 5 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model base | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 6 | `Modules/Accounting/app/Services/AccountingContext.php` | service (reached through the model base) | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 7 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model (reached through `activityLog()`) | 50 | ↗ [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 8 | `app/Helpers/activityLog.php` | app helper (common) | 51 | common/app glue | checked only |
| 9 | `Modules/Accounting/resources/views/tax-rate/create.blade.php` | view | 117 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/tax-rate/edit.blade.php` | view | 154 | this report | ✅ |
| 11 | `Modules/Accounting/resources/views/tax-rate/show.blade.php` | view | 135 | this report | ✅ |
| 12 | `Modules/Accounting/resources/views/tax-rate/trash.blade.php` | view | 70 | this report | ✅ |
| 13 | `Modules/Accounting/resources/views/tax-rate/index.blade.php` | view (never rendered) | 114 | this report | ✅ (dead — TXRT-18) |
| 14 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-rates.blade.php` | list/create modal (rendered by `AccDashboardController`) | 263 | ↗ [gaurav/Accounting/AccDashboardController](../AccDashboardController/01-report.md) (CLAIMED) | ↗ out of scope, see §7 |
| 15 | `config/permissionslist.php` | shared config | 1798 | common/shared | checked only (F3) |
| 16 | `Modules/Accounting/routes/web.php` | shared route file | 536 | common/shared | checked only (F5) |
| 17 | `database/migrations/tenant/2026_09_16_100027_create_acc_tax_rates_table.php` | migration | 59 | DDL — not edited by audits | checked only (F4/F7) |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/tax-rate                                     accounting.tax-rate.index           Modules\Accounting\Http\Controllers\TaxRateController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tax-rate                                     accounting.tax-rate.store           Modules\Accounting\Http\Controllers\TaxRateController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-rate/create                              accounting.tax-rate.create          Modules\Accounting\Http\Controllers\TaxRateController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-rate/trash/view                          accounting.tax-rate.trashed         Modules\Accounting\Http\Controllers\TaxRateController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tax-rate/{id}/force-delete                   accounting.tax-rate.forceDelete     Modules\Accounting\Http\Controllers\TaxRateController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-rate/{id}/restore                        accounting.tax-rate.restore         Modules\Accounting\Http\Controllers\TaxRateController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-rate/{tax_rate}                          accounting.tax-rate.show            Modules\Accounting\Http\Controllers\TaxRateController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/tax-rate/{tax_rate}                          accounting.tax-rate.update          Modules\Accounting\Http\Controllers\TaxRateController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/tax-rate/{tax_rate}                          accounting.tax-rate.destroy         Modules\Accounting\Http\Controllers\TaxRateController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/tax-rate/{tax_rate}/edit                     accounting.tax-rate.edit            Modules\Accounting\Http\Controllers\TaxRateController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/tax-rate/{tax_rate}/toggle-status            accounting.tax-rate.toggleStatus    Modules\Accounting\Http\Controllers\TaxRateController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 11 public methods have a route (see the list above).

Route notes: `restore` is a `GET` route at `Modules/Accounting/routes/web.php:191` even though it writes (`TXRT-09`). Custom routes sit before `Route::resource` (`web.php:190-192`); `toggle-status` is registered after the resource (`web.php:194`) but does not collide — it is a POST with three URI segments while the resource POST is `/tax-rate` and the show route is two segments. The `{id}` routes (`restore`, `forceDelete`) pass `$id`; the resource `{tax_rate}` routes bind implicitly to `$taxRate`. Tenant middleware (`InitializeTenancyByDomain`, `EnsureTenantHasModule:Accounting`) is present on every route.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /accounting/tax-rate | `tenant.accounting.tax-rate.viewAny` | none | none | none | TXRT-11, TXRT-18 |
| `create` | 24 | GET /accounting/tax-rate/create | `tenant.accounting.tax-rate.create` | none | none | none | TXRT-11, TXRT-13, TXRT-18 |
| `store` | 31 | POST /accounting/tax-rate | `tenant.accounting.tax-rate.create` (also `TaxRateRequest::authorize()`) | controller, manual (38-48) | `Created` | acc_tax_rates, sys_activity_logs | TXRT-01, TXRT-03, TXRT-04, TXRT-06 |
| `show` | 63 | GET /accounting/tax-rate/{tax_rate} | `tenant.accounting.tax-rate.view` | none | none | none | TXRT-05, TXRT-11 |
| `edit` | 70 | GET /accounting/tax-rate/{tax_rate}/edit | `tenant.accounting.tax-rate.update` | none | none | none | TXRT-05, TXRT-11, TXRT-13 |
| `update` | 77 | PUT/PATCH /accounting/tax-rate/{tax_rate} | `tenant.accounting.tax-rate.update` (also `TaxRateRequest::authorize()`) | controller, manual (81-91) | `Updated` | acc_tax_rates, sys_activity_logs | TXRT-01, TXRT-03, TXRT-04, TXRT-05, TXRT-06 |
| `destroy` | 106 | DELETE /accounting/tax-rate/{tax_rate} | `tenant.accounting.tax-rate.delete` | controller, manual (110-122) | `Trashed` | acc_tax_rates, sys_activity_logs | TXRT-01, TXRT-03, TXRT-04, TXRT-05 |
| `toggleStatus` | 137 | POST /accounting/tax-rate/{tax_rate}/toggle-status | `tenant.accounting.tax-rate.update` | controller, manual (143-154) | `Toggled` | acc_tax_rates, sys_activity_logs | TXRT-01, TXRT-03, TXRT-04, TXRT-05, TXRT-11 |
| `trashed` | 165 | GET /accounting/tax-rate/trash/view | `tenant.accounting.tax-rate.restore` | none | none | reads acc_tax_rates | TXRT-12, TXRT-14 |
| `restore` | 174 | GET /accounting/tax-rate/{id}/restore | `tenant.accounting.tax-rate.restore` | controller, manual (178-190) | `Restored` | acc_tax_rates, sys_activity_logs | TXRT-01, TXRT-02, TXRT-03, TXRT-04, TXRT-09, TXRT-10 |
| `forceDelete` | 201 | DELETE /accounting/tax-rate/{id}/force-delete | `tenant.accounting.tax-rate.forceDelete` | controller, manual (205-217) | `Deleted` | acc_tax_rates, sys_activity_logs | TXRT-01, TXRT-02, TXRT-03, TXRT-04, TXRT-09, TXRT-10 |

## 6. Findings

### F1 — Errors

#### TXRT-01 · B · ERR-01 — Raw exception text is shown to the user in all six write paths

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:59, 102, 133, 161, 197, 224`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Every mutation wraps its work in `try { ... } catch (\Throwable $e)` and appends `$e->getMessage()` to the flash message or JSON body. `QueryException` extends `RuntimeException`, so a duplicate key, a trigger error or a missing column reaches the browser as SQL text. D1 forbids a controller `try/catch` unless a D2 shape applies, and none of these is a truncate-then-rebuild or a snapshot-protection method. |
| **Consequence** | A user who saves a tax rate after a database error sees the database message (for example a duplicate-key or foreign-key error) instead of a friendly page, and table/column names are exposed. |
| **Reproduce** | Log in as School Admin, open Accounting → Configurations → Tax Rates, submit the create modal twice with the same name (duplicates are allowed by validation), and the second save is accepted; force a database error (for example by deleting a referenced tax type in another tab) and the red flash contains the SQL error. |
| **Fix approach** | Remove the hand-rolled `try/catch` and `beginTransaction`/`commit`/`rollBack` from all six methods and use one `DB::transaction()` closure per mutation; let the central handler in `bootstrap/app.php` render failures (D1). Plan item TXRT-01 rewrites all six bodies. |
| **Plan item** | TXRT-01 in `02-fix-plan.md` §1 |

```php
// TaxRateController.php:52-60 — CURRENT (store; the same shape is in five other methods)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Tax Rate', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Tax Rate: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "getMessage\("
55:'error' => $e->getMessage(),
59:return back()->withInput()->with('error', 'Failed to create Tax Rate: ' . $e->getMessage());
99:'error' => $e->getMessage(),
102:return back()->withInput()->with('error', 'Failed to update Tax Rate: ' . $e->getMessage());
130:'error' => $e->getMessage(),
133:return back()->with('error', 'Failed to delete Tax Rate: ' . $e->getMessage());
159:Log::error('Failed to toggle Tax Rate status', ['id' => $taxRate->id, 'error' => $e->getMessage()]);
161:return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
195:Log::error('Failed to restore Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);
197:return back()->with('error', 'Failed to restore Tax Rate: ' . $e->getMessage());
222:Log::error('Failed to force delete Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);
224:return back()->with('error', 'Failed to delete Tax Rate: ' . $e->getMessage());
```

#### TXRT-02 · H · ERR-02 — A missing restore/force-delete id becomes a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:178-198` (`restore()`), `:205-225` (`forceDelete()`) |
| **Root cause** | `TaxRate::onlyTrashed()->findOrFail($id)` (line 180) and `TaxRate::withTrashed()->findOrFail($id)` (line 207) sit inside the `try`, and the generic `catch (\Throwable $e)` swallows `ModelNotFoundException` and redirects with a flash. |
| **Consequence** | A user who opens a restore/force-delete link for an id that no longer exists is redirected back with a red "Failed …" flash (and the raw exception text from TXRT-01), instead of receiving a 404. |
| **Reproduce** | Open `/accounting/tax-rate/999999/restore` as an authorized user. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Removing the catch (TXRT-01) lets `ModelNotFoundException` reach the central handler as a 404. |
| **Plan item** | none — fixed by TXRT-01; see `02-fix-plan.md` §10 |

```php
// TaxRateController.php:178-198 — CURRENT (restore)
        DB::beginTransaction();
        try {
            $model = TaxRate::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Tax Rate restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.tax-rate.trashed')->with('success', 'Tax Rate restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Tax Rate: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "findOrFail|catch \("
52:} catch (\Throwable $e) {
95:} catch (\Throwable $e) {
126:} catch (\Throwable $e) {
157:} catch (\Throwable $e) {
180:$model = TaxRate::onlyTrashed()->findOrFail($id);
193:} catch (\Throwable $e) {
207:$model = TaxRate::withTrashed()->findOrFail($id);
220:} catch (\Throwable $e) {
```

#### TXRT-03 · M · ERR-05 — Catches log only the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:54-57, 97-100, 128-131, 159, 195, 222`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Five of the six catches call `Log::error('…', ['error' => $e->getMessage()])`; only `store()` also records `getTraceAsString()`. The exception object (class, file, line, previous) is discarded. |
| **Consequence** | When a save fails in production, the log has the message but not the stack, so the failing query or line cannot be reconstructed from the log. |
| **Reproduce** | Static only — the six `Log::error` calls are quoted by the evidence command. |
| **Fix approach** | Removing the catches (TXRT-01) makes this moot because the central handler logs the exception object; no controller-level logging remains. |
| **Plan item** | none — fixed by TXRT-01; see `02-fix-plan.md` §10 |

```php
// TaxRateController.php:97-100 — CURRENT (update; four others are identical in shape)
            Log::error('Failed to update Tax Rate', [
                'id'    => $taxRate->id,
                'error' => $e->getMessage(),
            ]);
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "Log::error"
54:Log::error('Failed to create Tax Rate', [
97:Log::error('Failed to update Tax Rate', [
128:Log::error('Failed to delete Tax Rate', [
159:Log::error('Failed to toggle Tax Rate status', ['id' => $taxRate->id, 'error' => $e->getMessage()]);
195:Log::error('Failed to restore Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);
222:Log::error('Failed to force delete Tax Rate', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### TXRT-04 · M · TXN-02 — Six mutations hand-roll transactions instead of `DB::transaction()`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:38, 48, 53` (`store`), `:81, 91, 96` (`update`), `:110, 122, 127` (`destroy`), `:143, 154, 158` (`toggleStatus`), `:178, 190, 194` (`restore`), `:205, 217, 221` (`forceDelete`) |
| **Root cause** | Each mutation opens a transaction by hand, commits inside the `try`, and rolls back in the catch. A `return` or an exception between `beginTransaction()` and `commit()` leaves the transaction to be unwound by the catch, and the `activityLog()` write is only protected because it happens to sit before `commit()` in each method. |
| **Consequence** | The multi-table write (rate row + `sys_activity_logs`) is atomic today, but the pattern is fragile: one early return or a new side effect added before `commit()` silently changes the unit of work. |
| **Reproduce** | Static only — the pairs are listed by the evidence command. |
| **Fix approach** | Replace each open/try/commit/rollback with one `DB::transaction(function () { … })` closure and keep `activityLog()` after the write, inside the closure (TXN-04 is already satisfied). |
| **Plan item** | none — fixed by TXRT-01; see `02-fix-plan.md` §10 |

```php
// TaxRateController.php:38-48 — CURRENT (store)
        DB::beginTransaction();
        try {
            $taxRate = TaxRate::create($validated);

            activityLog($taxRate, 'Created', [
                'message'      => 'Tax Rate created: ' . $taxRate->name,
                'name'         => $taxRate->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "beginTransaction|DB::commit|DB::rollBack"
38:DB::beginTransaction();
48:DB::commit();
53:DB::rollBack();
81:DB::beginTransaction();
91:DB::commit();
96:DB::rollBack();
110:DB::beginTransaction();
122:DB::commit();
127:DB::rollBack();
143:DB::beginTransaction();
154:DB::commit();
158:DB::rollBack();
178:DB::beginTransaction();
190:DB::commit();
194:DB::rollBack();
205:DB::beginTransaction();
217:DB::commit();
221:DB::rollBack();
```

### F3 — Authorization

#### TXRT-05 · M · AUTH-02 — Route-model binding loads the record before the in-method Gate runs

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H) — *authorize first, before loading records; loading first leaks whether an id exists (404 vs 403)*. Lowered to M: the leak is only the existence of a numeric id to an already-authenticated user who lacks the permission; no data is returned. |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:63-65` (`show`), `:70-72` (`edit`), `:77-79` (`update`), `:106-108` (`destroy`), `:137-139` (`toggleStatus`) |
| **Root cause** | Laravel's `SubstituteBindings` middleware resolves the `TaxRate` route parameter before the controller method runs; the method's `Gate::authorize` therefore runs after the row has been fetched. A missing id returns 404 before the gate, an existing id returns 403 after it. |
| **Consequence** | An authenticated user who lacks the permission can distinguish an existing id from a missing one by the status code (403 vs 404). |
| **Reproduce** | Static only — the middleware order is framework-level; the route list in §4 shows `SubstituteBindings` is in the `web` group, which runs before the controller. |
| **Fix approach** | Decide: (a) accept the framework order (it is the same in every controller in the module), or (b) move the authorization into a middleware that runs before `SubstituteBindings` (a global priority change). This is a DECISION, not a mechanical fix. |
| **Plan item** | TXRT-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// TaxRateController.php:63-67 — CURRENT (show; edit/update/destroy/toggleStatus follow the same shape)
    public function show(TaxRate $taxRate)
    {
        Gate::authorize('tenant.accounting.tax-rate.view');

        return view('accounting::tax-rate.show', compact('taxRate'));
    }
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "public function (show|edit|update|destroy|toggleStatus)|Gate::authorize"
63:public function show(TaxRate $taxRate)
65:Gate::authorize('tenant.accounting.tax-rate.view');
70:public function edit(TaxRate $taxRate)
72:Gate::authorize('tenant.accounting.tax-rate.update');
77:public function update(TaxRateRequest $request, TaxRate $taxRate)
79:Gate::authorize('tenant.accounting.tax-rate.update');
106:public function destroy(TaxRate $taxRate)
108:Gate::authorize('tenant.accounting.tax-rate.delete');
137:public function toggleStatus(Request $request, TaxRate $taxRate)
139:Gate::authorize('tenant.accounting.tax-rate.update');
```

#### TXRT-06 · L · AUTH-04 — `store`/`update` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:33` (`store`), `:79` (`update`); `Modules/Accounting/app/Http/Requests/TaxRateRequest.php:16` |
| **Root cause** | `TaxRateRequest::authorize()` calls `authorizeByCrudPermission('tenant.accounting.tax-rate')`, which maps POST to `create` and PUT/PATCH to `update`; the controller then runs `Gate::authorize` with the same string. |
| **Consequence** | No runtime difference; a future permission rename must be made in two places and one copy can drift. |
| **Reproduce** | Static only — two authorization calls run on every store and update. |
| **Fix approach** | Remove the two controller `Gate::authorize` lines; the FormRequest already authorizes and runs first. TXRT-01 does this. |
| **Plan item** | none — fixed by TXRT-01; see `02-fix-plan.md` §10 |

```php
// TaxRateController.php:31-35 — CURRENT
    public function store(TaxRateRequest $request)
    {
        Gate::authorize('tenant.accounting.tax-rate.create');

        $validated = $request->validated();
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Requests\TaxRateRequest.php","Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "authorizeByCrudPermission|Gate::authorize\('tenant.accounting.tax-rate.create'\)|Gate::authorize\('tenant.accounting.tax-rate.update'\)"
TaxRateRequest.php:16:return $this->authorizeByCrudPermission('tenant.accounting.tax-rate');
TaxRateController.php:33:Gate::authorize('tenant.accounting.tax-rate.create');
TaxRateController.php:79:Gate::authorize('tenant.accounting.tax-rate.update');
```

#### TXRT-07 · M · AUTH-05 — `TaxRatePolicy` is registered but no gate ever consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic; a policy that nothing consults is dead logic* |
| **Where** | `Modules/Accounting/app/Policies/TaxRatePolicy.php:10-36`; registration at `Modules/Accounting/app/Providers/AccountingServiceProvider.php:142` |
| **Root cause** | Every check passes a string ability (`Gate::authorize('tenant.accounting.tax-rate.viewAny')`). The Gate resolves a string through Spatie's permission check, never through `TaxRatePolicy`; the policy is registered with `Gate::policy(TaxRate::class, TaxRatePolicy::class)` but never called with a model ability. |
| **Consequence** | The policy methods `viewAny`, `view`, `create`, `update`, `delete` are inert; a reader believes the policy guards this resource, but only the literal permission strings do. The policy also has no `restore`/`forceDelete` methods, so switching to model abilities would need those added. |
| **Reproduce** | Static only — `Gate::authorize('viewAny', TaxRate::class)` does not appear anywhere in the controller. |
| **Fix approach** | Decide: delete the policy and its provider registration (dead code), extend it with `restore`/`forceDelete` and switch the 11 gates to model abilities, or accept it as inert for this pass. |
| **Plan item** | TXRT-07 in `02-fix-plan.md` §9 (DECISION) |

```php
// TaxRatePolicy.php:10-36 — CURRENT
class TaxRatePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.tax-rate.viewAny');
    }

    public function view(User $user, TaxRate $taxRate): bool
    {
        return $user->can('tenant.accounting.tax-rate.view');
    }

    public function create(User $user): bool
    {
        return $user->can('tenant.accounting.tax-rate.create');
    }

    public function update(User $user, TaxRate $taxRate): bool
    {
        return $user->can('tenant.accounting.tax-rate.update');
    }

    public function delete(User $user, TaxRate $taxRate): bool
    {
        return $user->can('tenant.accounting.tax-rate.delete');
    }
}
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Providers\AccountingServiceProvider.php" -Pattern "TaxRate"
42:use Modules\Accounting\Policies\TaxRatePolicy;
142:Gate::policy(TaxRate::class, TaxRatePolicy::class);
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "Gate::authorize\('viewAny', TaxRate::class\)"
(no output)
```

**F3 clean (permission existence):** all seven names are declared by `config/permissionslist.php:614` (`'accounting.tax-rate' => $crud`) and seeded, exact-name query:
```
EXACT_FOUND=["tenant.accounting.tax-rate.create","tenant.accounting.tax-rate.delete","tenant.accounting.tax-rate.forceDelete","tenant.accounting.tax-rate.restore","tenant.accounting.tax-rate.update","tenant.accounting.tax-rate.view","tenant.accounting.tax-rate.viewAny"]
PERM tenant.accounting.tax-rate.create ROLES=5
PERM tenant.accounting.tax-rate.view ROLES=5
PERM tenant.accounting.tax-rate.viewAny ROLES=5
PERM tenant.accounting.tax-rate.update ROLES=5
PERM tenant.accounting.tax-rate.delete ROLES=5
PERM tenant.accounting.tax-rate.restore ROLES=5
PERM tenant.accounting.tax-rate.forceDelete ROLES=5
```
Roles: Super Admin, School Admin, Management, Account Staff, Account Manager (role ids 1, 2, 3, 8, 9).

### F4 — Validation and input

#### TXRT-08 · H · VAL-03 — An unchecked Active box is forced back to true, so a rate cannot be deactivated from the edit form

| Field | Value |
|---|---|
| **Rule** | VAL-03 (H) — *optional fields are read safely; an absent boolean must not silently take the wrong default* |
| **Where** | `Modules/Accounting/app/Http/Requests/TaxRateRequest.php:52` (`prepareForValidation()`), used by `store()` and `update()` |
| **Root cause** | The edit form renders `is_active` as a plain checkbox (`edit.blade.php:129-131`); an unchecked checkbox is not submitted, so `$this->boolean('is_active', true)` returns the default `true`. The request therefore sends `is_active = 1` on every edit save, even when the user cleared the box. |
| **Consequence** | A user who unchecks Active on the edit form and saves sees the record stay active. The only way to deactivate is the list-page toggle switch, and the edit form's checkbox is a lie. |
| **Reproduce** | Open `/accounting/tax-rate/{id}/edit`, clear the Active checkbox, save. The record is still active in the list. |
| **Fix approach** | Default the absent checkbox to `false` (the form submits `1` when checked and sends nothing when unchecked). The create form's `old('is_active', true)` keeps new records active by default, because it submits the checked value. |
| **Plan item** | TXRT-08 in `02-fix-plan.md` §5 |

```php
// TaxRateRequest.php:49-55 — CURRENT
    protected function prepareForValidation(): void
    {
        $effectiveFrom = $this->input('effective_from') ?: now()->toDateString();
        $mergeData = [
            'is_active'      => $this->boolean('is_active', true),
            'is_interstate'  => $this->boolean('is_interstate', false),
            'effective_from' => $effectiveFrom,
        ];
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Requests\TaxRateRequest.php" -Pattern "boolean\('is_active'|boolean\('is_interstate'"
52:'is_active'      => $this->boolean('is_active', true),
53:'is_interstate'  => $this->boolean('is_interstate', false),
$ Select-String -Path "Modules\Accounting\resources\views\tax-rate\edit.blade.php" -Pattern "name=\"is_active\""
129:<input type="checkbox" name="is_active" id="is_active"
```

### F5 — Routes

#### TXRT-09 · H · RTE-01 — Restore changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`)* |
| **Where** | `Modules/Accounting/routes/web.php:191`; handler `Modules/Accounting/app/Http/Controllers/TaxRateController.php:174-199` (`restore`) |
| **Root cause** | The route is `Route::get('/tax-rate/{id}/restore', …)`, but `restore()` writes `deleted_at`, `is_active` and an activity-log row. GET has no CSRF token, so a link prefetch, a crawler or a cross-site image can trigger the restore. |
| **Consequence** | A trashed tax rate can be restored by a GET request the user did not confirm, and the action is not CSRF-protected. |
| **Reproduce** | While logged in, open `/accounting/tax-rate/{trashed_id}/restore` directly in the address bar; the record is restored. |
| **Fix approach** | Change the route to `DELETE` (the `x-backend.table.action-trashed` component already reads the route's verb and emits a CSRF-protected form, so no component edit is needed). This is a route change: a DECISION, `⚠ SHARED`. |
| **Plan item** | TXRT-09 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// web.php:190-194 — CURRENT
Route::get('/tax-rate/trash/view', [TaxRateController::class, 'trashed'])->name('tax-rate.trashed');
Route::get('/tax-rate/{id}/restore', [TaxRateController::class, 'restore'])->name('tax-rate.restore');
Route::delete('/tax-rate/{id}/force-delete', [TaxRateController::class, 'forceDelete'])->name('tax-rate.forceDelete');
Route::resource('tax-rate', TaxRateController::class);
Route::post('/tax-rate/{tax_rate}/toggle-status', [TaxRateController::class, 'toggleStatus'])->name('tax-rate.toggleStatus');
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "tax-rate"
190:Route::get('/tax-rate/trash/view', [TaxRateController::class, 'trashed'])->name('tax-rate.trashed');
191:Route::get('/tax-rate/{id}/restore', [TaxRateController::class, 'restore'])->name('tax-rate.restore');
192:Route::delete('/tax-rate/{id}/force-delete', [TaxRateController::class, 'forceDelete'])->name('tax-rate.forceDelete');
193:Route::resource('tax-rate', TaxRateController::class);
194:Route::post('/tax-rate/{tax_rate}/toggle-status', [TaxRateController::class, 'toggleStatus'])->name('tax-rate.toggleStatus');
```

### F6 — Controller shape

#### TXRT-10 · M · CTL-03 — Restore/force-delete use `$id` + `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:174, 180` (`restore`), `:201, 207` (`forceDelete`) |
| **Root cause** | The two custom routes take `{id}` and the methods take `$id`, then run a manual `onlyTrashed()` / `withTrashed()` query. The six resource methods already use implicit binding, so the controller is inconsistent. |
| **Consequence** | The trashed-scope rule is repeated in the controller instead of being declared on the route; a future route change can forget the `withTrashed()` scope and 404 every restore. |
| **Reproduce** | Static only — the signatures and queries are quoted below. |
| **Fix approach** | Add `->withTrashed()` to the two routes, rename the parameter to `{tax_rate}`, and take `TaxRate $taxRate` in both methods. Deferred: it overlaps TXRT-01's rewrite of the same methods and TXRT-09's route change, so it is not a separate item in this pass. |
| **Plan item** | none — deferred; see `02-fix-plan.md` §10 |

```php
// TaxRateController.php:174-181 — CURRENT (restore)
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tax-rate.restore');

        DB::beginTransaction();
        try {
            $model = TaxRate::onlyTrashed()->findOrFail($id);
            $model->restore();
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "public function (restore|forceDelete)|findOrFail"
174:public function restore($id): \Illuminate\Http\RedirectResponse
180:$model = TaxRate::onlyTrashed()->findOrFail($id);
201:public function forceDelete($id): \Illuminate\Http\RedirectResponse
207:$model = TaxRate::withTrashed()->findOrFail($id);
```

#### TXRT-11 · L · CTL-04 — Eight public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:17, 24, 31, 63, 70, 77, 106, 137` |
| **Root cause** | `index`, `create`, `store`, `show`, `edit`, `update`, `destroy` and `toggleStatus` declare no return type; only `trashed`, `restore` and `forceDelete` do. |
| **Consequence** | The controller's contract is invisible to static analysis, and a wrong return in a branch becomes a runtime `TypeError` instead of a compile-time signal. |
| **Reproduce** | Static only — the signatures are listed by the evidence command. |
| **Fix approach** | Add `RedirectResponse`, `View` and `JsonResponse` return types; TXRT-01 adds them to the six mutators, TXRT-11 adds them to the four read methods. |
| **Plan item** | TXRT-11 in `02-fix-plan.md` §5 |

```php
// TaxRateController.php:17-137 — CURRENT
    public function index()
    public function create()
    public function store(TaxRateRequest $request)
    public function show(TaxRate $taxRate)
    public function edit(TaxRate $taxRate)
    public function update(TaxRateRequest $request, TaxRate $taxRate)
    public function destroy(TaxRate $taxRate)
    public function toggleStatus(Request $request, TaxRate $taxRate)
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "public function" | ForEach-Object { "$($_.LineNumber): $($_.Line.Trim())" }
17: public function index()
24: public function create()
31: public function store(TaxRateRequest $request)
63: public function show(TaxRate $taxRate)
70: public function edit(TaxRate $taxRate)
77: public function update(TaxRateRequest $request, TaxRate $taxRate)
106: public function destroy(TaxRate $taxRate)
137: public function toggleStatus(Request $request, TaxRate $taxRate)
165: public function trashed(): \Illuminate\View\View
174: public function restore($id): \Illuminate\Http\RedirectResponse
201: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

### F7 — Models

clean — `php -l` passes and the model declares `$fillable`, `$casts` for `rate`/`is_interstate`/`effective_from`/`effective_to`/`is_active`, `SoftDeletes`, and a `$table` (`acc_tax_rates`) that exists in `database/migrations/tenant/2026_09_16_100027_create_acc_tax_rates_table.php`. The live column list includes `deleted_at`, so `SoftDeletes` is correct. Evidence:

```
$ php -l Modules\Accounting\app\Models\TaxRate.php
No syntax errors detected in Modules\Accounting\app\Models\TaxRate.php
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php"; $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); var_dump(class_exists(Modules\Accounting\Models\TaxRate::class));'
true
COLUMNS=["id","tax_type_id","name","rate","hsn_sac_code","is_interstate","tax_ledger_id","effective_from","effective_to","is_active","created_by","created_at","updated_at","deleted_at"]
```

### F8 — Services and jobs

clean — the controller uses no service, job, event, mail or notification. Evidence: `Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "Service|Job|Event|Mail|Notification"` → no output.

### F9 — Queries and performance

#### TXRT-12 · M · QRY-02 — The trash list paginates 15 rows, not 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *lists are paginated; use `paginate()`* — lowered to M: the list is paginated, only the page size (15) and the missing eager load are wrong. |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php:169` |
| **Root cause** | `TaxRate::onlyTrashed()->orderBy('name')->paginate(15)` uses a bespoke page size; the project standard is 10. The query also loads every column and does not eager-load `taxType`, which the trash view needs (TXRT-14). |
| **Consequence** | The trash page shows 15 rows instead of the standard 10 and issues one extra query per row once the view displays the tax-type name. |
| **Reproduce** | Open `/accounting/tax-rate/trash/view` with more than 15 trashed rows; the page shows 15. |
| **Fix approach** | `paginate(10)` and add `with('taxType')`. |
| **Plan item** | TXRT-12 in `02-fix-plan.md` §6 |

```php
// TaxRateController.php:165-171 — CURRENT
    public function trashed(): \Illuminate\View\View
    {
        Gate::authorize('tenant.accounting.tax-rate.restore');

        $taxRates = TaxRate::onlyTrashed()->orderBy('name')->paginate(15);

        return view('accounting::tax-rate.trash', compact('taxRates'));
    }
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "paginate\("
169:$taxRates = TaxRate::onlyTrashed()->orderBy('name')->paginate(15);
```

### F10 — Views

#### TXRT-13 · H · VIEW-01 — The create/edit blades query `TaxType` directly

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no queries in Blade; pass data from the controller* |
| **Where** | `Modules/Accounting/resources/views/tax-rate/create.blade.php:63`, `Modules/Accounting/resources/views/tax-rate/edit.blade.php:72` |
| **Root cause** | Both templates run `\Modules\Accounting\Models\TaxType::orderBy('name')->get()` inside a `@foreach` instead of receiving a `$taxTypes` collection from `create()`/`edit()`. The query also selects every column (`get()` with no column list). |
| **Consequence** | The view layer owns a database query, so the dropdown cannot be cached or reused, and the template fails outside a database-backed request. |
| **Reproduce** | Static only — the two `@foreach` lines are quoted below. |
| **Fix approach** | Load `TaxType::query()->orderBy('name')->get(['id', 'name'])` in `create()`/`edit()`, pass it with `compact()`, and loop over `$taxTypes` in both templates. |
| **Plan item** | TXRT-13 in `02-fix-plan.md` §7 |

```php
// create.blade.php:63 — CURRENT
                                                @foreach (\Modules\Accounting\Models\TaxType::orderBy('name')->get() as $taxType)
// edit.blade.php:72 — CURRENT
                                            @foreach (\Modules\Accounting\Models\TaxType::orderBy('name')->get() as $taxType)
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\resources\views\tax-rate\create.blade.php","Modules\Accounting\resources\views\tax-rate\edit.blade.php" -Pattern "TaxType::"
create.blade.php:63:@foreach (\Modules\Accounting\Models\TaxType::orderBy('name')->get() as $taxType)
edit.blade.php:72:@foreach (\Modules\Accounting\Models\TaxType::orderBy('name')->get() as $taxType)
```

#### TXRT-14 · M · VIEW-02 — The trash list reads `$taxRate->tax_type`, a column that does not exist

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations and attributes used in Blade must exist on the model; a property that does not exist is silent forever* |
| **Where** | `Modules/Accounting/resources/views/tax-rate/trash.blade.php:32` |
| **Root cause** | The `acc_tax_rates` table has `tax_type_id`, not `tax_type` (confirmed by the live column list), and `TaxRate` has no `tax_type` accessor. The Blade therefore reads an undefined attribute. |
| **Consequence** | The Tax Type column on the trash page is always blank, so a user cannot tell two trashed rates of different types apart. |
| **Reproduce** | Open `/accounting/tax-rate/trash/view`; the Tax Type column is empty for every row. |
| **Fix approach** | Display `$taxRate->taxType?->name ?? '-'` and eager-load `taxType` in `trashed()` (TXRT-12). |
| **Plan item** | TXRT-14 in `02-fix-plan.md` §7 |

```php
// trash.blade.php:29-34 — CURRENT
                                        <tr>
                                            <td class="fw-semibold">{{ $taxRate->name }}</td>

                                            <td>{{ $taxRate->tax_type }}</td>

                                            <td>{{ $taxRate->rate . '%' }}</td>
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\resources\views\tax-rate\trash.blade.php" -Pattern "tax_type"
32:<td>{{ $taxRate->tax_type }}</td>
$ php "/tmp/opencode\txrt_probe.php"
COLUMNS=["id","tax_type_id","name","rate","hsn_sac_code","is_interstate","tax_ledger_id","effective_from","effective_to","is_active","created_by","created_at","updated_at","deleted_at"]
```

### F11 — Security and tenancy

clean — no `env()` in the controller, model or request; no request body or secret is logged; no hard-coded tenant/user/status id; the helper `activityLog()` routes to the tenant log when `tenancy()->initialized` (`app/Helpers/activityLog.php:45-49`); cache is not used. Evidence: `Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php","Modules\Accounting\app\Models\TaxRate.php","Modules\Accounting\app\Http\Requests\TaxRateRequest.php" -Pattern "env\("` → no output.

### F12 — Style

#### TXRT-15 · L · STY-02 — The controller is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/TaxRateController.php` |
| **Root cause** | Pint reports `fully_qualified_strict_types`, `concat_space`, `ordered_imports` and `binary_operator_spaces`: the file uses spaced concatenation, aligned `=>`, and fully-qualified return types. |
| **Consequence** | A future `pint --dirty` pass reformats this file in the middle of an unrelated change, adding noise to the diff. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TaxRateController.php --format agent` → `fail`. |
| **Fix approach** | Run Pint on the controller after TXRT-01/TXRT-11/TXRT-13; it adds the `RedirectResponse`/`JsonResponse`/`View` imports, removes the then-unused `Log` import and normalises operators. |
| **Plan item** | TXRT-15 in `02-fix-plan.md` §8 |

```php
// TaxRateController.php:7-13 — CURRENT imports
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\TaxRateRequest;
use Modules\Accounting\Models\TaxRate;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TaxRateController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\TaxRateController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]}]}
```

#### TXRT-16 · L · STY-02 — The `TaxRate` model is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Models/TaxRate.php` |
| **Root cause** | Pint reports `fully_qualified_strict_types`, `method_chaining_indentation`, `no_unused_imports`, `ordered_imports` and `binary_operator_spaces`: `use App\Models\BaseModel;` is unused, `\Modules\SchoolSetup\Models\User` is inline, the `scopeEffective` chain is over-indented and the `$casts` arrows are aligned. |
| **Consequence** | The unused import and formatting drift make the model inconsistent with the rest of the module. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Models\TaxRate.php --format agent` → `fail`. |
| **Fix approach** | Run Pint on the model. |
| **Plan item** | TXRT-16 in `02-fix-plan.md` §8 |

```php
// TaxRate.php:7-9 — CURRENT imports
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Models\TaxRate.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\TaxRate.php","fixers":["fully_qualified_strict_types","method_chaining_indentation","no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
```

#### TXRT-17 · L · STY-02 — `TaxRateRequest` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Requests/TaxRateRequest.php` |
| **Root cause** | Pint reports `ordered_imports` and `binary_operator_spaces`: the `App\Traits` import follows the `Illuminate` import, and the `rules()`/`attributes()` arrows are aligned. |
| **Consequence** | Style drift only. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\TaxRateRequest.php --format agent` → `fail`. |
| **Fix approach** | Run Pint on the request. |
| **Plan item** | TXRT-17 in `02-fix-plan.md` §8 |

```php
// TaxRateRequest.php:7-8 — CURRENT imports
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Requests\TaxRateRequest.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\TaxRateRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data? | 2 Delete before store? | 3 Duplicate operation? | 4 Soft-delete × unique index? | 5 Race? | 6 Auth hole? | 7 Message lies? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | ok (no unique index on `acc_tax_rates`) | ok | TXRT-05/TXRT-06 | ok | ok |
| `update` | TXRT-08 | ok | ok | ok | ok | TXRT-05/TXRT-06 | ok | ok |
| `destroy` | ok (sets `is_active=false` then soft-deletes) | ok | ok | ok | ok | TXRT-05 | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | TXRT-05 | ok | ok |
| `restore` | ok (sets `is_active=true` deliberately) | ok | ok | ok | ok | TXRT-09 | ok | ok |
| `forceDelete` | ok (captures `$name` before delete) | ok | ok | ok | ok | ok | ok | ok |

Notes: (1) the only wrong-data case is TXRT-08 (the edit form forces `is_active` back to true). (2) `forceDelete` captures the name before deleting and writes the log inside the same transaction, so nothing is lost. (3) No service duplicates a mutation. (4) `acc_tax_rates` has no unique index, only non-unique indexes, so there is no soft-delete × unique-index trap. (5) No count-then-insert or exists-then-create; the six methods are single-row updates. (6) Every method is gated; the only ordering nuance is TXRT-05 and the duplicate in TXRT-06. (7) The event literals (`Created`, `Updated`, `Trashed`, `Toggled`, `Restored`, `Deleted`) and the flash text match the action. (8) `index()` redirects and never renders `index.blade.php`; see TXRT-18.

#### TXRT-18 · L · CTL-10 — `index.blade.php` is never rendered and the standalone create form duplicates the modal

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code: unused files and duplicate implementations* |
| **Where** | `Modules/Accounting/resources/views/tax-rate/index.blade.php:1-114`; `Modules/Accounting/app/Http/Controllers/TaxRateController.php:17-22`; `Modules/Accounting/resources/views/tax-rate/create.blade.php:1-117` vs `_tax-rates.blade.php:195-263` |
| **Root cause** | `index()` redirects to `accounting.menu.configurations` and never returns a view, so `index.blade.php` has no renderer (grep finds it only in the breadcrumb registry and the tests). The real create form is the modal in `_tax-rates.blade.php`; `create.blade.php` is the superseded standalone form. |
| **Consequence** | Two create forms and a dead list view must be maintained; a change to one silently diverges from the other. |
| **Reproduce** | Static only — `Select-String -Pattern "tax-rate.index"` finds no `view('accounting::tax-rate.index')` call. |
| **Fix approach** | Delete `index.blade.php` in a separate cleanup; keep `create.blade.php` only until the route/link is reviewed (it is still reachable by URL). No code change in this pass. |
| **Plan item** | none — cleanup deferred; see `02-fix-plan.md` §10 |

```php
// TaxRateController.php:17-22 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.accounting.tax-rate.viewAny');

        return redirect()->route('accounting.menu.configurations', ['tab' => 'tax-rates']);
    }
```

**Evidence**
```
$ Select-String -Path "Modules\Accounting\app\Http\Controllers\TaxRateController.php" -Pattern "tax-rate.index|view\('accounting::tax-rate"
(no output)
$ Get-ChildItem -Recurse -Path "Modules","resources" -Include "*.blade.php","*.php" | Select-String -Pattern "tax-rate\.index" | ForEach-Object { "$($_.Path):$($_.LineNumber)" }
/Users/bkwork/Herd/prime_ai_dev\app\Services\Breadcrumbs\registry.php:204
/Users/bkwork/Herd/prime_ai_dev\config\breadcrumbs.php:1537
/Users/bkwork/Herd/prime_ai_dev\Modules\Accounting\tests\Feature\TaxRateCrudTest.php:21
/Users/bkwork/Herd/prime_ai_dev\Modules\Accounting\tests\Feature\TaxRateCrudTest.php:33
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-rates.blade.php` | The real create modal repeats the same inline `TaxType::orderBy('name')->get()` query as `create.blade.php`, and the list loops `$taxRate->taxType` without a visible eager load in the controller. Rendered by `AccDashboardController::configurations()`, not by this controller. | VIEW-01 / VIEW-02 | `gaurav/Accounting/AccDashboardController` (CLAIMED) |
| `_tax-rates.blade.php:141-148` | `x-backend.table.action` receives each permission twice (`:view-permission` and `viewPermission`, etc.). The camelCase props are ignored; only the kebab-case ones are used. | STY-04 / CTL-05 | `gaurav/Accounting/AccDashboardController` (CLAIMED) |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_tax-rates.blade.php:44` | The toolbar writes the pagination page into `tr_page`, but `{{ $taxRates->links() }}` uses the default `page` query key, so the hidden field is never read. | QRY-13 | `gaurav/Accounting/AccDashboardController` (CLAIMED) |
| `Modules/Accounting/app/Models/BaseAccountingModel.php:28` | `Auth::id() ?? 1` hard-codes a fallback user id for `updated_by`. | SEC-03 | owner report (AccountingStatusMasterController) |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` are missing and `scan.php` must not be run per the binding tooling override. F1–F13 were worked manually with `read`, `Select-String` and the commands quoted above. The §15 self-check could not run.
- **`TaxRule` (`Modules/Accounting/app/Models/TaxRule.php`, 104 lines) is not reached by this controller.** `TaxRate` is the parent of `TaxRule` (`tax_rate_id`), but no method here loads or writes a `TaxRule`. It is unclaimed in `_Info/00-CLASS-OWNERS.md`; it is listed in the hand-back for the main session to assign. It was not audited because it is outside this controller's scope (§4.2).
- **The list tab (`_tax-rates.blade.php`) is rendered by `AccDashboardController::configurations()`, not by this controller.** Its queries and N+1 risks are recorded as cross-cutting notes and belong to the AccDashboard report.
- **No browser was run and no tests were executed (D4).** Behaviour findings (TXRT-07, TXRT-08) are proven from the request/view code, not from a live submission.
- **No queue, job or external service is involved**, so F8 has nothing to run.
- **`TaxRateRequest` cross-field rule was not executed against a payload (D4).** The rules are static; `effective_to >= effective_from` and the `exists` rules were read, not run.
