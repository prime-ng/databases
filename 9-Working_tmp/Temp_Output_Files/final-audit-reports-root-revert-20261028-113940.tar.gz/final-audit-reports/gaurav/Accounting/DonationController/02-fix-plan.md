# Fix Plan — Accounting / DonationController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/DonationController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file — only DNAT-14 (DECISION) edits it, and only when ticked |
| `config/permissionslist.php` | shared config — only DNAT-07 (DECISION) edits it, and only when ticked |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md` | registry — not edited by this plan |
| `final-audit-reports/gaurav/Accounting/00-INDEX.md` | index — not edited by this plan |
| `database/migrations/**` | never edit an existing migration |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | shared page controller; owns the donations list query (cross-cutting note) |
| `Modules/Accounting/app/Models/FinancialYear.php`, `Fund.php`, `Ledger.php`, `VoucherType.php` | owned by another report (scope table, links 4–7) |
| `Modules/Accounting/app/Services/VoucherService.php` | owned by the VoucherController report (scope table, link 8) |
| `resources/views/components/**`, the layouts | shared components |
| `Modules/Accounting/resources/views/pages/partials/school-specific/_donations.blade.php` | shared partial — only DNAT-12 (⚠ SHARED) edits it, and only when ticked |

## 1. Blockers reachable today

- [ ] **DNAT-01** · B · ERR-01 · `DonationController.php:39-78` — rewrite `store()`: no catch, one transaction, FY from the donation date, sequence inside the lock, prefix from the year's dates.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:9-13`):
    ```php
    use DomainException;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After:**
    ```php
    use DomainException;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\ValidationException;
    ```
  - **Before** (`DonationController.php:39-78`):
    ```php
            $fyId = $validated['financial_year_id'] ?? null;
            if (!$fyId) {
                $activeFy = FinancialYear::where('is_active', true)->orderByDesc('start_date')->first();
                $fyId = $activeFy?->id;
                $validated['financial_year_id'] = $fyId;
            }

            $amount = (float) $validated['amount'];
            $mode = $validated['mode'];

            // Cash donations > 2000 are not 80G eligible
            if ($mode === 'Cash' && $amount > 2000.0) {
                $validated['is_80g_eligible'] = false;
            }

            // Sequential 80G numbering per FY under row lock
            if (empty($validated['receipt_no']) || empty($validated['receipt_sequence'])) {
                $maxSeq = (int) Donation::where('financial_year_id', $fyId)->lockForUpdate()->max('receipt_sequence');
                $nextSeq = $maxSeq + 1;
                $validated['receipt_sequence'] = $nextSeq;

                $fy = FinancialYear::find($fyId);
                $fyCode = $fy?->code ?? Carbon::now()->format('Y');
                $validated['receipt_no'] = sprintf('80G/%s/%04d', $fyCode, $nextSeq);
            }

            $validated['created_by'] = auth()->id();
            $validated['status']     = 'Draft';

            DB::beginTransaction();
            try {
                $donation = Donation::create($validated);
                DB::commit();

                return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                    ->with('success', "Donation receipt {$donation->receipt_no} created successfully.");
            } catch (\Throwable $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->with('error', 'Failed to create donation: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            $amount = (float) $validated['amount'];
            $mode = $validated['mode'];

            // Cash donations > 2000 are not 80G eligible
            if ($mode === 'Cash' && $amount > 2000.0) {
                $validated['is_80g_eligible'] = false;
            }

            $validated['created_by'] = auth()->id();
            $validated['status']     = 'Draft';

            $donation = DB::transaction(function () use ($validated) {
                $donationDate = Carbon::parse($validated['donation_date']);

                $financialYear = FinancialYear::where('start_date', '<=', $donationDate)
                    ->where('end_date', '>=', $donationDate)
                    ->first();

                if (!$financialYear) {
                    throw ValidationException::withMessages([
                        'donation_date' => 'No financial year covers the selected donation date.',
                    ]);
                }

                FinancialYear::whereKey($financialYear->id)->lockForUpdate()->first();

                $validated['financial_year_id'] = $financialYear->id;
                $validated['receipt_sequence'] = ((int) Donation::withTrashed()
                    ->where('financial_year_id', $financialYear->id)
                    ->max('receipt_sequence')) + 1;
                $validated['receipt_no'] = sprintf(
                    '80G/%s-%s/%04d',
                    $financialYear->start_date->format('Y'),
                    $financialYear->end_date->format('y'),
                    $validated['receipt_sequence'],
                );

                $donation = Donation::create($validated);

                activityLog($donation, 'Created', [
                    'message' => "Donation receipt {$donation->receipt_no} created",
                ]);

                return $donation;
            });

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                ->with('success', "Donation receipt {$donation->receipt_no} created successfully.");
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'getMessage|beginTransaction'`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **DNAT-13** · B · RTE-02 · `DonationController.php:30-33` — add the missing `create()` method so the routed URL stops throwing a 500.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:30-33`):
    ```php
            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations']);
        }

        public function store(DonationRequest $request): RedirectResponse
    ```
  - **After:**
    ```php
            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations']);
        }

        public function create(): RedirectResponse
        {
            Gate::authorize('tenant.accounting.donation.create');

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                ->with('info', 'Use the "Record Donation" button to create a receipt.');
        }

        public function store(DonationRequest $request): RedirectResponse
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'function create'`
  - **Expect:** one line, `public function create(): RedirectResponse`.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **DNAT-12** · H · VAL-07 · ⚠ SHARED — `_donations.blade.php:361-367,423-427` — send `is_in_kind` from the create modal, so the valuation rule and the DDL check run.
  - **Touches:** `Modules/Accounting/resources/views/pages/partials/school-specific/_donations.blade.php`
  - **Before** (`_donations.blade.php:361-367`):
    ```php
                            <select name="mode" id="don_mode" class="form-select form-select-sm" required>
                                @foreach(\Modules\Accounting\Models\Donation::modes() as $mode)
                                    <option value="{{ $mode }}" {{ old('mode', 'Cheque') === $mode ? 'selected' : '' }}>{{ str_replace('_', ' ', $mode) }}</option>
                                @endforeach
                            </select>
    ```
  - **After:**
    ```php
                            <select name="mode" id="don_mode" class="form-select form-select-sm" required>
                                @foreach(\Modules\Accounting\Models\Donation::modes() as $mode)
                                    <option value="{{ $mode }}" {{ old('mode', 'Cheque') === $mode ? 'selected' : '' }}>{{ str_replace('_', ' ', $mode) }}</option>
                                @endforeach
                            </select>
                            <input type="hidden" name="is_in_kind" id="don_is_in_kind" value="{{ old('is_in_kind') ? '1' : '0' }}">
    ```
  - **Before** (`_donations.blade.php:423-427`):
    ```php
                function toggleInKind() {
                    if (inKindSection) {
                        inKindSection.style.display = modeSelect?.value === 'In_Kind' ? 'block' : 'none';
                    }
                }
    ```
  - **After:**
    ```php
                function toggleInKind() {
                    if (inKindSection) {
                        inKindSection.style.display = modeSelect?.value === 'In_Kind' ? 'block' : 'none';
                    }
                    const inKindInput = document.getElementById('don_is_in_kind');
                    if (inKindInput) {
                        inKindInput.value = modeSelect?.value === 'In_Kind' ? '1' : '0';
                    }
                }
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\resources\views\pages\partials\school-specific\_donations.blade.php -Pattern 'name="is_in_kind"'`
  - **Expect:** one line containing `name="is_in_kind" id="don_is_in_kind"`.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **DNAT-03** · H · ERR-06 · `DonationController.php:143-225` — rewrite `post()`: refuse to post when the voucher cannot be created, one transaction, no catch.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:143-225`):
    ```php
            DB::beginTransaction();
            try {
                // Find cash/bank receiving ledger
                $debitLedgerId = null;
                if ($donation->mode === 'Cash') {
                    $debitLedgerId = Ledger::where('is_active', true)->where('ledger_type', 'Cash')->value('id');
                } elseif ($donation->mode !== 'In_Kind') {
                    $debitLedgerId = Ledger::where('is_active', true)->where('ledger_type', 'Bank')->value('id');
                }

                // Find credit head (Donation Income / Fund / Corpus)
                $creditLedgerId = $donation->donor_ledger_id;
                if (!$creditLedgerId) {
                    if ($donation->donation_nature === 'Corpus') {
                        $creditLedgerId = Ledger::where('is_active', true)
                            ->where(function ($q) {
                                $q->where('name', 'like', '%Corpus%')
                                  ->orWhere('name', 'like', '%Capital Fund%');
                            })->value('id');
                    } else {
                        $creditLedgerId = Ledger::where('is_active', true)
                            ->where(function ($q) {
                                $q->where('name', 'like', '%Donation%')
                                  ->orWhere('name', 'like', '%Contribution%');
                            })
                            ->whereHas('accountGroup', fn($q) => $q->where('nature', 'Income'))
                            ->value('id');
                    }
                }

                if ($debitLedgerId && $creditLedgerId) {
                    $rcpType = VoucherType::where('base_type', 'Receipt')->where('is_active', true)->first()
                        ?? VoucherType::where('base_type', 'Receipt')->first()
                        ?? VoucherType::where(function ($q) {
                            $q->whereIn('code', ['RECEIPT', 'RCP', 'RCT'])
                              ->orWhere('code', 'like', 'RCP%')
                              ->orWhere('code', 'like', 'RCT%')
                              ->orWhere('name', 'like', '%Receipt%');
                        })->first()
                        ?? VoucherType::where('is_active', true)->first();

                    if ($rcpType) {
                        $voucher = $this->voucherService->create([
                            'voucher_type_id'   => $rcpType->id,
                            'financial_year_id' => $donation->financial_year_id,
                            'period_id'         => $donation->period_id,
                            'campus_id'         => $donation->campus_id,
                            'voucher_date'      => $donation->donation_date->format('Y-m-d'),
                            'narration'         => "Donation receipt {$donation->receipt_no} ({$donation->donation_nature}) from " . ($donation->donor_name ?? 'Donor'),
                            'party_ledger_id'   => $donation->donor_ledger_id,
                            'status'            => 'draft',
                        ], [
                            [
                                'ledger_id'  => $debitLedgerId,
                                'entry_type' => 'Dr',
                                'amount'     => (float) $donation->amount,
                                'narration'  => "Received via {$donation->mode}" . ($donation->instrument_no ? " #{$donation->instrument_no}" : ''),
                            ],
                            [
                                'ledger_id'  => $creditLedgerId,
                                'entry_type' => 'Cr',
                                'amount'     => (float) $donation->amount,
                                'narration'  => "Donation income/corpus: {$donation->purpose}",
                            ],
                        ]);

                        $this->voucherService->post($voucher->fresh());
                        $donation->voucher_id = $voucher->id;
                    }
                }

                $donation->status = 'Posted';
                $donation->updated_by = auth()->id();
                $donation->save();

                DB::commit();

                return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                    ->with('success', "Donation {$donation->receipt_no} posted successfully.");
            } catch (\Throwable $e) {
                DB::rollBack();
                return redirect()->back()->with('error', 'Failed to post donation: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            $donation = DB::transaction(function () use ($donation) {
                $debitLedgerId = match (true) {
                    $donation->mode === 'Cash' => Ledger::where('is_active', true)->where('ledger_type', 'Cash')->value('id'),
                    $donation->mode === 'In_Kind' => null,
                    default => Ledger::where('is_active', true)->where('ledger_type', 'Bank')->value('id'),
                };

                $creditLedgerId = $donation->donor_ledger_id;
                if (!$creditLedgerId) {
                    if ($donation->donation_nature === 'Corpus') {
                        $creditLedgerId = Ledger::where('is_active', true)
                            ->where(function ($query) {
                                $query->where('name', 'like', '%Corpus%')
                                    ->orWhere('name', 'like', '%Capital Fund%');
                            })->value('id');
                    } else {
                        $creditLedgerId = Ledger::where('is_active', true)
                            ->where(function ($query) {
                                $query->where('name', 'like', '%Donation%')
                                    ->orWhere('name', 'like', '%Contribution%');
                            })
                            ->whereHas('accountGroup', fn ($query) => $query->where('nature', 'Income'))
                            ->value('id');
                    }
                }

                $receiptType = VoucherType::where('base_type', 'Receipt')->where('is_active', true)->first()
                    ?? VoucherType::where('base_type', 'Receipt')->first()
                    ?? VoucherType::where(function ($query) {
                        $query->whereIn('code', ['RECEIPT', 'RCP', 'RCT'])
                            ->orWhere('code', 'like', 'RCP%')
                            ->orWhere('code', 'like', 'RCT%')
                            ->orWhere('name', 'like', '%Receipt%');
                    })->first()
                    ?? VoucherType::where('is_active', true)->first();

                if (!$debitLedgerId || !$creditLedgerId || !$receiptType) {
                    throw new DomainException('The donation cannot be posted: a receiving ledger, an income ledger or a receipt voucher type is missing.');
                }

                $voucher = $this->voucherService->create([
                    'voucher_type_id'   => $receiptType->id,
                    'financial_year_id' => $donation->financial_year_id,
                    'period_id'         => $donation->period_id,
                    'campus_id'         => $donation->campus_id,
                    'voucher_date'      => $donation->donation_date->format('Y-m-d'),
                    'narration'         => "Donation receipt {$donation->receipt_no} ({$donation->donation_nature}) from " . ($donation->donor_name ?? 'Donor'),
                    'party_ledger_id'   => $donation->donor_ledger_id,
                    'status'            => 'draft',
                ], [
                    [
                        'ledger_id'  => $debitLedgerId,
                        'entry_type' => 'Dr',
                        'amount'     => (float) $donation->amount,
                        'narration'  => "Received via {$donation->mode}" . ($donation->instrument_no ? " #{$donation->instrument_no}" : ''),
                    ],
                    [
                        'ledger_id'  => $creditLedgerId,
                        'entry_type' => 'Cr',
                        'amount'     => (float) $donation->amount,
                        'narration'  => "Donation income/corpus: {$donation->purpose}",
                    ],
                ]);

                $this->voucherService->post($voucher->fresh());

                $donation->voucher_id = $voucher->id;
                $donation->status = 'Posted';
                $donation->updated_by = auth()->id();
                $donation->save();

                activityLog($donation, 'Posted', [
                    'message' => "Donation receipt {$donation->receipt_no} posted",
                ]);

                return $donation;
            });

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                ->with('success', "Donation {$donation->receipt_no} posted successfully.");
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'Failed to post donation'`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **DNAT-04** · M · TXN-02 · `DonationController.php:118-128` — rewrite `update()` as one `DB::transaction` closure, no catch.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:118-128`):
    ```php
            DB::beginTransaction();
            try {
                $donation->update($validated);
                DB::commit();

                return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                    ->with('success', "Donation receipt {$donation->receipt_no} updated successfully.");
            } catch (\Throwable $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->with('error', 'Failed to update donation: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($donation, $validated) {
                $donation->update($validated);

                activityLog($donation, 'Updated', [
                    'message' => "Donation receipt {$donation->receipt_no} updated",
                ]);
            });

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'donations'])
                ->with('success', "Donation receipt {$donation->receipt_no} updated successfully.");
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'Failed to update donation'`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **DNAT-05** · M · TXN-04 · `DonationController.php:294,313-314,323-324` — log the trash, restore and permanent delete. The other six mutations are logged by DNAT-01 (store), DNAT-03 (post), DNAT-04 (update), DNAT-21 (toggle), DNAT-34 (cancel) and DNAT-35 (certificate).
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:294`):
    ```php
            $donation->delete();
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($donation) {
                $donation->delete();

                activityLog($donation, 'Trashed', [
                    'message' => "Donation receipt {$donation->receipt_no} trashed",
                ]);
            });
    ```
  - **Before** (`DonationController.php:313-314`):
    ```php
            $donation = Donation::onlyTrashed()->findOrFail($id);
            $donation->restore();
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($id) {
                $donation = Donation::onlyTrashed()->findOrFail($id);
                $donation->restore();

                activityLog($donation, 'Restored', [
                    'message' => "Donation receipt {$donation->receipt_no} restored",
                ]);
            });
    ```
  - **Before** (`DonationController.php:323-324`):
    ```php
            $donation = Donation::onlyTrashed()->findOrFail($id);
            $donation->forceDelete();
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($id) {
                $donation = Donation::onlyTrashed()->findOrFail($id);
                $donation->forceDelete();

                activityLog($donation, 'Deleted', [
                    'message' => "Donation receipt {$donation->receipt_no} permanently deleted",
                ]);
            });
    ```
  - **Verify:** `(Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'activityLog').Count`
  - **Expect:** `9` or more.
  - **Effort:** S

## 4. Authorization (F3)

No mechanical item. Both authorization findings are DECISION items (DNAT-07 and DNAT-08) because one needs a new permission key in a shared config file and the other needs a new policy class. See §9.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **DNAT-10** · M · VAL-05 · `DonationRequest.php:21-22` — stop accepting the statutory receipt number and sequence from the browser.
  - **Touches:** `Modules/Accounting/app/Http/Requests/DonationRequest.php`
  - **Before** (`DonationRequest.php:21-23`):
    ```php
                'receipt_no'            => ['nullable', 'string', 'max:50'],
                'receipt_sequence'      => ['nullable', 'integer', 'min:1'],
                'financial_year_id'     => ['nullable', 'integer', 'exists:acc_financial_years,id'],
    ```
  - **After:**
    ```php
                'financial_year_id'     => ['nullable', 'integer', 'exists:acc_financial_years,id'],
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Requests\DonationRequest.php -Pattern 'receipt_no|receipt_sequence'`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **DNAT-11** · M · VAL-02 · `DonationController.php:254-260` — move the cancel-reason rule into `DonationCancelRequest`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`, `Modules/Accounting/app/Http/Requests/DonationCancelRequest.php` (new file)
  - **Before** (`DonationController.php:254-260`):
    ```php
        public function cancel(Request $request, Donation $donation): RedirectResponse
        {
            Gate::authorize('tenant.accounting.donation.cancel');

            $request->validate([
                'cancelled_reason' => 'required|string|max:500',
            ]);
    ```
  - **After:**
    ```php
        public function cancel(DonationCancelRequest $request, Donation $donation): RedirectResponse
        {
            Gate::authorize('tenant.accounting.donation.cancel');
    ```
  - **Before** (`DonationController.php:14`):
    ```php
    use Modules\Accounting\Http\Requests\DonationRequest;
    ```
  - **After:**
    ```php
    use Modules\Accounting\Http\Requests\DonationCancelRequest;
    use Modules\Accounting\Http\Requests\DonationRequest;
    ```
  - **New file** `Modules/Accounting/app/Http/Requests/DonationCancelRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class DonationCancelRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        public function rules(): array
        {
            return [
                'cancelled_reason' => ['required', 'string', 'max:500'],
            ];
        }
    }
    ```
  - **Verify:** `Test-Path Modules\Accounting\app\Http\Requests\DonationCancelRequest.php`
  - **Expect:** `True`.
  - **Effort:** S

- [ ] **DNAT-21** · M · MDL-01 · `Donation.php:18-60` and `DonationController.php:281` — make `is_active` fillable and cast it, and log the toggle it performs.
  - **Touches:** `Modules/Accounting/app/Models/Donation.php`, `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`Donation.php:46-50`):
    ```php
            'remarks',
            'created_by',
            'updated_by',
        ];
    ```
  - **After:**
    ```php
            'remarks',
            'is_active',
            'created_by',
            'updated_by',
        ];
    ```
  - **Before** (`Donation.php:56-58`):
    ```php
            'is_80g_eligible'      => 'boolean',
            'certificate_issued_at'=> 'datetime',
            'receipt_sequence'     => 'integer',
    ```
  - **After:**
    ```php
            'is_80g_eligible'      => 'boolean',
            'is_active'            => 'boolean',
            'certificate_issued_at'=> 'datetime',
            'receipt_sequence'     => 'integer',
    ```
  - **Before** (`DonationController.php:281`):
    ```php
            $donation->update(['is_active' => !$donation->is_active]);
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($donation) {
                $donation->update(['is_active' => !$donation->is_active]);

                activityLog($donation, 'Toggled', [
                    'message' => "Donation receipt {$donation->receipt_no} active flag set to " . ($donation->is_active ? 'active' : 'inactive'),
                ]);
            });
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Models\Donation.php -Pattern "'is_active'"`
  - **Expect:** three lines — `$fillable` entry, the cast, and the `scopeActive` where clause.
  - **Effort:** S

- [ ] **DNAT-23** · L · MDL-04 · `Donation.php:106-144` — add `Builder` parameter and return types to the eight scopes.
  - **Touches:** `Modules/Accounting/app/Models/Donation.php`
  - **Before** (`Donation.php:106-144`):
    ```php
        public function scopeDraft($query)
        {
            return $query->where('status', 'Draft');
        }

        public function scopePosted($query)
        {
            return $query->where('status', 'Posted');
        }

        public function scopeCancelled($query)
        {
            return $query->where('status', 'Cancelled');
        }

        public function scopeByNature($query, string $nature)
        {
            return $query->where('donation_nature', $nature);
        }

        public function scopeByFund($query, int $fundId)
        {
            return $query->where('fund_id', $fundId);
        }

        public function scopeForFinancialYear($query, int $fyId)
        {
            return $query->where('financial_year_id', $fyId);
        }

        public function scopeEligibleFor80g($query)
        {
            return $query->where('is_80g_eligible', true);
        }

        public function scopeActive($query)
        {
            return $query->where('is_active', true);
        }
    ```
  - **After:**
    ```php
        public function scopeDraft(Builder $query): Builder
        {
            return $query->where('status', 'Draft');
        }

        public function scopePosted(Builder $query): Builder
        {
            return $query->where('status', 'Posted');
        }

        public function scopeCancelled(Builder $query): Builder
        {
            return $query->where('status', 'Cancelled');
        }

        public function scopeByNature(Builder $query, string $nature): Builder
        {
            return $query->where('donation_nature', $nature);
        }

        public function scopeByFund(Builder $query, int $fundId): Builder
        {
            return $query->where('fund_id', $fundId);
        }

        public function scopeForFinancialYear(Builder $query, int $fyId): Builder
        {
            return $query->where('financial_year_id', $fyId);
        }

        public function scopeEligibleFor80g(Builder $query): Builder
        {
            return $query->where('is_80g_eligible', true);
        }

        public function scopeActive(Builder $query): Builder
        {
            return $query->where('is_active', true);
        }
    ```
  - **Before** (`Donation.php:8-10`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Verify:** `(Select-String -Path Modules\Accounting\app\Models\Donation.php -Pattern 'public function scope\w+\(Builder \$query').Count`
  - **Expect:** `8`.
  - **Effort:** S

- [ ] **DNAT-35** · M · F13-Q1 · `DonationController.php:232-239` — refuse a certificate for a donation that is not Posted.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:232-239`):
    ```php
            if (!$donation->is_80g_eligible) {
                return redirect()->back()->with('error', 'This donation is not eligible for an 80G certificate.');
            }

            $donation->update([
                'certificate_issued_at' => now(),
                'updated_by'            => auth()->id(),
            ]);
    ```
  - **After:**
    ```php
            if (!$donation->is_80g_eligible) {
                return redirect()->back()->with('error', 'This donation is not eligible for an 80G certificate.');
            }

            if ($donation->status !== 'Posted') {
                return redirect()->back()->with('error', 'Only a posted donation can receive an 80G certificate.');
            }

            DB::transaction(function () use ($donation) {
                $donation->update([
                    'certificate_issued_at' => now(),
                    'updated_by'            => auth()->id(),
                ]);

                activityLog($donation, 'Certificate Issued', [
                    'message' => "80G certificate issued for receipt {$donation->receipt_no}",
                ]);
            });
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern "status !== 'Posted'"`
  - **Expect:** one line in `issueCertificate()`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **DNAT-26** · M · QRY-15 · `DonationController.php:94-95` — select only the two columns the edit form reads.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:94-95`):
    ```php
            $donorLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
            $funds = Fund::where('is_active', true)->orderBy('name')->get();
    ```
  - **After:**
    ```php
            $donorLedgers = Ledger::where('is_active', true)->orderBy('name')->get(['id', 'name']);
            $funds = Fund::where('is_active', true)->orderBy('name')->get(['id', 'name']);
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern "orderBy\('name'\)->get\(\['id', 'name'\]\)"`
  - **Expect:** two lines (94 and 95).
  - **Effort:** S

- [ ] **DNAT-27** · M · QRY-02 · `DonationController.php:304` — paginate the trash list at 10 with its own page name.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:304`):
    ```php
            $donations = Donation::onlyTrashed()->with(['donorLedger', 'financialYear'])->paginate(25);
    ```
  - **After:**
    ```php
            $donations = Donation::onlyTrashed()->with(['donorLedger', 'financialYear'])->paginate(10, ['*'], 'donation_trash_page');
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\app\Http\Controllers\DonationController.php -Pattern 'paginate\('`
  - **Expect:** one line containing `paginate(10, ['*'], 'donation_trash_page')`.
  - **Effort:** S

## 7. Views (F10)

- [ ] **DNAT-28** · H · VIEW-02 · `certificate.blade.php:47-48` — print the stored `donor_pan`, not the non-existent `pan`.
  - **Touches:** `Modules/Accounting/resources/views/donation/certificate.blade.php`
  - **Before** (`certificate.blade.php:47-48`):
    ```php
                            @if($donation->pan || $donation->donorLedger?->pan)
                                (PAN: <span class="font-monospace fw-bold">{{ $donation->pan ?: $donation->donorLedger?->pan }}</span>)
                            @endif
    ```
  - **After:**
    ```php
                            @if($donation->donor_pan || $donation->donorLedger?->pan)
                                (PAN: <span class="font-monospace fw-bold">{{ $donation->donor_pan ?: $donation->donorLedger?->pan }}</span>)
                            @endif
    ```
  - **Verify:** `Select-String -Path Modules\Accounting\resources\views\donation\certificate.blade.php -Pattern '\$donation->pan'`
  - **Expect:** no output.
  - **Effort:** S

## 8. Style (F12) - one item per file

- [ ] **DNAT-29** · L · STY-02 · `DonationController.php:26,81,90,245,300` — add the five return types, drop the unused `index()` parameter, then run Pint on this file.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DonationController.php`
  - **Before** (`DonationController.php:26`):
    ```php
        public function index(Request $request)
    ```
  - **After:**
    ```php
        public function index(): RedirectResponse
    ```
  - **Before** (`DonationController.php:81`):
    ```php
        public function show(Donation $donation)
    ```
  - **After:**
    ```php
        public function show(Donation $donation): View
    ```
  - **Before** (`DonationController.php:90`):
    ```php
        public function edit(Donation $donation)
    ```
  - **After:**
    ```php
        public function edit(Donation $donation): View
    ```
  - **Before** (`DonationController.php:245`):
    ```php
        public function certificate(Donation $donation)
    ```
  - **After:**
    ```php
        public function certificate(Donation $donation): View
    ```
  - **Before** (`DonationController.php:300`):
    ```php
        public function trashed()
    ```
  - **After:**
    ```php
        public function trashed(): View
    ```
  - **Before** (`DonationController.php:7-8`):
    ```php
    use App\Http\Controllers\Controller;
    use Carbon\Carbon;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Carbon\Carbon;
    use Illuminate\Contracts\View\View;
    ```
  - **Then run:** `vendor\bin\pint Modules\Accounting\app\Http\Controllers\DonationController.php --format agent`
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\DonationController.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

- [ ] **DNAT-30** · L · STY-02 · `Modules/Accounting/app/Http/Requests/DonationRequest.php` — make the file Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Requests/DonationRequest.php`
  - **Before** (`DonationRequest.php:57`):
    ```php
                if (!$isAnonymous && empty($donorLedgerId) && empty($donorName)) {
    ```
  - **After:**
    ```php
                if (! $isAnonymous && empty($donorLedgerId) && empty($donorName)) {
    ```
  - **Then run:** `vendor\bin\pint Modules\Accounting\app\Http\Requests\DonationRequest.php --format agent`
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Requests\DonationRequest.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

- [ ] **DNAT-31** · L · STY-02 · `Donation.php:14` — remove the redundant `SoftDeletes`, run Pint (which also drops the unused `BaseModel` import).
  - **Touches:** `Modules/Accounting/app/Models/Donation.php`
  - **Before** (`Donation.php:12-16`):
    ```php
    class Donation extends BaseAccountingModel
    {
        use SoftDeletes;

        protected $table = 'acc_donations';
    ```
  - **After:**
    ```php
    class Donation extends BaseAccountingModel
    {
        protected $table = 'acc_donations';
    ```
  - **Before** (`Donation.php:7-10`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Modules\SchoolSetup\Models\User;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Modules\SchoolSetup\Models\User;
    ```
  - **Then run:** `vendor\bin\pint Modules\Accounting\app\Models\Donation.php --format agent`
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Models\Donation.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **DNAT-07** · B · DECISION · AUTH-01 — add the missing donation permission family.
  - **Why it is a decision:** a new permission key in a shared config file, plus `/system-config/sync-permissions` in Tarun's hand.
  - (a) ⭐ Add `'accounting.donation' => array_merge($crud, ['post', 'cancel', 'issueCertificate'])` to the Accounting block of `config/permissionslist.php`, then run `/system-config/sync-permissions` and grant the family to the five roles that hold `accounting.dashboard.view`. Apply this **after** §1–§3, so the repaired create/post paths are what the new roles reach.
  - (b) Leave the screen Super-Admin-only and record it as accepted.
  - (c) Reuse an existing family (for example `accounting.fund`) — not recommended: the audit trail would name the wrong resource.
  - ➜ Choice: ____

- [ ] **DNAT-08** · M · DECISION · AUTH-06 — one home for the fourteen permission strings.
  - **Why it is a decision:** introduces a new `DonationPolicy` class and a registration, which reaches outside this controller.
  - (a) ⭐ Defer to the policy pass (D3); keep the literals until then.
  - (b) Add `Modules/Accounting/app/Policies/DonationPolicy.php`, register it, and replace the fourteen `Gate::authorize()` calls with policy abilities.
  - (c) Extract the strings to class constants in the controller and leave the gates as strings.
  - ➜ Choice: ____

- [ ] **DNAT-14** · H · DECISION · RTE-01 — the restore action is a GET. ⚠ SHARED (route file).
  - **Why it is a decision:** changes a route verb and the trash view's action markup.
  - (a) ⭐ Change the route to `Route::post('/donation/{id}/restore', ...)` and replace the trash link with a CSRF form, matching `forceDelete`.
  - (b) Leave it as an accepted risk.
  - (c) Keep GET and add a signed URL plus a confirmation page.
  - ➜ Choice: ____

- [ ] **DNAT-16** · M · DECISION · CTL-06 — ledger resolution and posting live in `post()`.
  - **Why it is a decision:** a service extraction changes the class structure and is the D3 split/refactor question.
  - (a) ⭐ Defer to the split pass (D3); keep the logic in `post()` for now.
  - (b) Extract `DonationPostingService` with one `post(Donation): Voucher` method and make `post()` a three-line caller. This also resolves DNAT-15, DNAT-17 and the duplicated cash rule in `store()`/`update()`.
  - (c) Leave as is and record as accepted debt.
  - ➜ Choice: ____

- [ ] **DNAT-34** · H · DECISION · F13-Q1 — cancelling a posted donation leaves its voucher Posted.
  - **Why it is a decision:** the business answer (cancel vs reverse vs block) is not in the DDL or the screen.
  - (a) ⭐ Cancel the linked voucher in the same transaction: read `Voucher::find($donation->voucher_id)`, and when its status is `Posted`, call `$this->voucherService->cancel($voucher, $validated['cancelled_reason'])` before saving the donation. Add `use Modules\Accounting\Models\Voucher;` and the `Cancelled` activity log.
  - (b) Keep the voucher posted and surface a warning on the donation that a manual voucher cancellation is required.
  - (c) Block cancelling a donation that has a posted voucher.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| DNAT-15 | The 96-line `post()` is the same problem as DNAT-16; a mechanical split would only move lines, and the extraction is the DNAT-16 DECISION. |
| DNAT-17 | The duplicated cash-over-2000 rule is resolved by the DNAT-16 extraction (option b). Until then the two copies are four lines each and identical. |
| DNAT-18 | Route-model binding for `restore`/`forceDelete` needs the route parameters renamed from `{id}` to `{donation}`, which edits the shared route file; folded into the DNAT-14 route change when it is ticked. |
| DNAT-24 | Replacing the `Draft` / `Posted` / `Cancelled` literals with an enum touches the controller, the model and the three views; deferred to the enum/status pass, which is module-wide. |
