# Fix Plan — Accounting / GrantController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/GrantController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | ⚠ SHARED — written only by GRNT-06, and only if that decision is ticked |
| `Modules/Accounting/routes/web.php` | ⚠ SHARED — written only by GRNT-11, and only if that item is ticked |
| `Modules/Accounting/resources/views/pages/partials/school-specific/_grants.blade.php` | Owned by AccDashboardController; cross-cutting note only |
| `Modules/Accounting/app/Services/VoucherService.php` | Owned by VoucherController |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Owned by AccountingStatusMasterController |
| `app/Traits/AuthorizesTenantFeature.php` | Shared trait — read only |
| `resources/views/components/backend/table/action-trashed.blade.php` | Shared component — read only |
| `app/Providers/AppServiceProvider.php` | Shared Gate::before bypass — read only |
| `database/migrations/**` | Schema changes are out of scope for this fix |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Accounting/00-INDEX.md` | Registry/index — never edited by the fixer |

## 1. Blockers reachable today

- [ ] **GRNT-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/GrantController.php:42-67,93-141,143-203` — remove the raw `$e->getMessage()` flashes and the manual transactions; make recognition report success.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Before** (`GrantController.php:42-67`):
    ```php
    public function store(GrantRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
        $validated['status']     = 'Sanctioned';

        DB::beginTransaction();
        try {
            $grant = Grant::create($validated);

            // If recognition basis is On_Sanction, generate receivable voucher automatically
            if ($grant->recognition_basis === 'On_Sanction') {
                $this->recogniseReceivableInternal($grant);
            }

            DB::commit();

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
                ->with('success', "Grant {$grant->grant_code} created successfully.");
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->withInput()->with('error', 'Failed to create grant: ' . $e->getMessage());
        }
    }
    ```
  - **Before** (`GrantController.php:93-120`):
    ```php
    public function update(GrantRequest $request, Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        if (in_array($grant->status, ['Closed', 'Cancelled'], true)) {
            return redirect()->back()->with('error', "Cannot modify a grant with status [{$grant->status}].");
        }

        $validated = $request->validated();
        $validated['updated_by'] = auth()->id();

        DB::beginTransaction();
        try {
            $grant->update($validated);

            if ($grant->recognition_basis === 'On_Sanction' && !$grant->receivable_voucher_id) {
                $this->recogniseReceivableInternal($grant);
            }

            DB::commit();

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
                ->with('success', "Grant {$grant->grant_code} updated successfully.");
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->withInput()->with('error', 'Failed to update grant: ' . $e->getMessage());
        }
    }
    ```
  - **Before** (`GrantController.php:122-141`):
    ```php
    public function recogniseReceivable(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        if ($grant->receivable_voucher_id) {
            return redirect()->back()->with('warning', 'Receivable voucher already exists for this grant.');
        }

        DB::beginTransaction();
        try {
            $this->recogniseReceivableInternal($grant);
            DB::commit();

            return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
                ->with('success', "Grant receivable recognised for {$grant->grant_code}.");
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to recognise grant receivable: ' . $e->getMessage());
        }
    }
    ```
  - **Before** (`GrantController.php:143-203`, first lines, guards and save):
    ```php
    private function recogniseReceivableInternal(Grant $grant): void
    {
        $grantorLedgerId = $grant->grantor_ledger_id;
        $liabilityLedgerId = $grant->unutilised_liability_ledger_id;
    ```
    ```php
        if ($grantorLedgerId && $liabilityLedgerId && (float) $grant->sanctioned_amount > 0) {
            $jnlType = VoucherType::where('base_type', 'Journal')->where('is_active', true)->first()
    ```
    ```php
            if ($jnlType) {
                $activeFy = FinancialYear::where('is_active', true)->orderByDesc('start_date')->first();
    ```
    ```php
                $this->voucherService->post($voucher->fresh());
                $grant->receivable_voucher_id = $voucher->id;
                $grant->save();
            }
        }
    }
    ```
  - **After** (replace the whole of `store()`):
    ```php
    public function store(GrantRequest $request): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();
        $validated['status'] = 'Sanctioned';

        [$grant, $recognised] = DB::transaction(function () use ($validated): array {
            $grant = Grant::create($validated);

            activityLog($grant, 'Created', ['message' => 'Grant created']);

            $recognised = true;
            if ($grant->recognition_basis === 'On_Sanction') {
                $recognised = $this->recogniseReceivableInternal($grant);
            }

            return [$grant, $recognised];
        });

        $redirect = redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Grant {$grant->grant_code} created successfully.");

        if (! $recognised) {
            $redirect->with('warning', 'The grant was saved, but no receivable voucher was created: set the grantor ledger, the unutilised-liability ledger and a sanctioned amount above zero.');
        }

        return $redirect;
    }
    ```
  - **After** (replace the whole of `update()`):
    ```php
    public function update(GrantRequest $request, Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        if (in_array($grant->status, ['Closed', 'Cancelled'], true)) {
            return redirect()->back()->with('error', "Cannot modify a grant with status [{$grant->status}].");
        }

        $validated = $request->validated();
        $validated['updated_by'] = auth()->id();

        [$grant, $recognised] = DB::transaction(function () use ($grant, $validated): array {
            $locked = Grant::whereKey($grant->getKey())->lockForUpdate()->firstOrFail();

            $locked->update($validated);

            activityLog($locked, 'Updated', ['message' => 'Grant updated']);

            $recognised = true;
            if ($locked->recognition_basis === 'On_Sanction' && ! $locked->receivable_voucher_id) {
                $recognised = $this->recogniseReceivableInternal($locked);
            }

            return [$locked, $recognised];
        });

        $redirect = redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Grant {$grant->grant_code} updated successfully.");

        if (! $recognised) {
            $redirect->with('warning', 'The grant was saved, but no receivable voucher was created: set the grantor ledger, the unutilised-liability ledger and a sanctioned amount above zero.');
        }

        return $redirect;
    }
    ```
  - **After** (replace the whole of `recogniseReceivable()`):
    ```php
    public function recogniseReceivable(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        [$grant, $recognised, $alreadyExists] = DB::transaction(function () use ($grant): array {
            $locked = Grant::whereKey($grant->getKey())->lockForUpdate()->firstOrFail();

            if ($locked->receivable_voucher_id) {
                return [$locked, true, true];
            }

            $recognised = $this->recogniseReceivableInternal($locked);

            if ($recognised) {
                activityLog($locked, 'Receivable Recognised', ['message' => 'Grant receivable voucher created']);
            }

            return [$locked, $recognised, false];
        });

        if ($alreadyExists) {
            return redirect()->back()->with('warning', 'Receivable voucher already exists for this grant.');
        }

        if (! $recognised) {
            return redirect()->back()->with('error', 'Receivable voucher could not be created: set the grantor ledger, the unutilised-liability ledger and a sanctioned amount above zero.');
        }

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Grant receivable recognised for {$grant->grant_code}.");
    }
    ```
  - **After** (replace the whole of `recogniseReceivableInternal()`):
    ```php
    private function recogniseReceivableInternal(Grant $grant): bool
    {
        $grantorLedgerId = $grant->grantor_ledger_id;
        $liabilityLedgerId = $grant->unutilised_liability_ledger_id;

        if (! $grantorLedgerId) {
            $grantorLedgerId = Ledger::where('is_active', true)
                ->where('name', 'like', "%{$grant->grantor_name}%")
                ->value('id');
        }

        if (! $liabilityLedgerId) {
            $liabilityLedgerId = Ledger::where('is_active', true)
                ->where(function ($q) {
                    $q->where('name', 'like', '%Unutilised Grant%')
                        ->orWhere('name', 'like', '%Grant Liability%');
                })->value('id');
        }

        if (! $grantorLedgerId || ! $liabilityLedgerId || (float) $grant->sanctioned_amount <= 0) {
            return false;
        }

        $jnlType = VoucherType::where('base_type', 'Journal')->where('is_active', true)->first()
            ?? VoucherType::where('base_type', 'Journal')->first()
            ?? VoucherType::where(function ($q) {
                $q->whereIn('code', ['JOURNAL', 'JNL', 'JRN'])
                    ->orWhere('code', 'like', 'JRN%')
                    ->orWhere('code', 'like', 'JNL%');
            })->first()
            ?? VoucherType::where('is_active', true)->first();

        if (! $jnlType) {
            return false;
        }

        $activeFy = FinancialYear::where('is_active', true)->orderByDesc('start_date')->first();

        $voucher = $this->voucherService->create([
            'voucher_type_id' => $jnlType->id,
            'financial_year_id' => $activeFy?->id,
            'campus_id' => $grant->campus_id,
            'voucher_date' => ($grant->sanction_date ? $grant->sanction_date->format('Y-m-d') : now()->format('Y-m-d')),
            'narration' => "Grant sanctioned: {$grant->grant_code} - {$grant->name}",
            'party_ledger_id' => $grantorLedgerId,
            'status' => 'draft',
        ], [
            [
                'ledger_id' => $grantorLedgerId,
                'entry_type' => 'Dr',
                'amount' => (float) $grant->sanctioned_amount,
                'narration' => "Grant receivable from {$grant->grantor_name}",
            ],
            [
                'ledger_id' => $liabilityLedgerId,
                'entry_type' => 'Cr',
                'amount' => (float) $grant->sanctioned_amount,
                'narration' => "Unutilised grant liability ({$grant->grant_code})",
            ],
        ]);

        $this->voucherService->post($voucher->fresh());

        $grant->receivable_voucher_id = $voucher->id;
        $grant->save();

        return true;
    }
    ```
  - **Verify:** `grep -nE "beginTransaction|rollBack|getMessage|recogniseReceivableInternal\(Grant \\\$grant\): void" Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **GRNT-14** · H · MDL-01 · `Modules/Accounting/app/Models/Grant.php:18-55` — add `is_active` to `$fillable` and `$casts` so `toggleStatus()` can write it.
  - **Touches:** `Modules/Accounting/app/Models/Grant.php`
  - **Before** (`Grant.php:42-55`):
    ```php
            'notes',
            'created_by',
            'updated_by',
        ];

        protected $casts = [
            'sanction_date'             => 'date',
            'sanctioned_amount'         => 'decimal:2',
            'utilisation_from'          => 'date',
            'utilisation_to'            => 'date',
            'refundable_if_unutilised'  => 'boolean',
            'utilisation_cert_due_on'   => 'date',
            'utilisation_cert_filed_on' => 'date',
        ];
    ```
  - **After:**
    ```php
            'notes',
            'created_by',
            'updated_by',
            'is_active',
        ];

        protected $casts = [
            'sanction_date'             => 'date',
            'sanctioned_amount'         => 'decimal:2',
            'utilisation_from'          => 'date',
            'utilisation_to'            => 'date',
            'refundable_if_unutilised'  => 'boolean',
            'utilisation_cert_due_on'   => 'date',
            'utilisation_cert_filed_on' => 'date',
            'is_active'                 => 'boolean',
        ];
    ```
  - **Verify:** `grep -n "'is_active'" Modules/Accounting/app/Models/Grant.php`
  - **Expect:** two matches inside `$fillable` and `$casts` (plus the scope match at the old line 128).
  - **Effort:** S

- [ ] **GRNT-07** · M · AUTH-02 · `Modules/Accounting/app/Http/Requests/GrantRequest.php:7-16` — authorize through the shared tenant-feature trait instead of `return true`.
  - **Touches:** `Modules/Accounting/app/Http/Requests/GrantRequest.php`
  - **Before** (`GrantRequest.php:7-16`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\Accounting\Models\Grant;

    class GrantRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }
    ```
  - **After:**
    ```php
    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\Accounting\Models\Grant;

    class GrantRequest extends FormRequest
    {
        use AuthorizesTenantFeature;

        public function authorize(): bool
        {
            return $this->authorizeByCrudPermission('tenant.accounting.grant');
        }
    ```
  - **Verify:** `grep -n "authorizeByCrudPermission" Modules/Accounting/app/Http/Requests/GrantRequest.php`
  - **Expect:** `return $this->authorizeByCrudPermission('tenant.accounting.grant');` (1 match) and no `return true;`.
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [ ] **GRNT-05** · M · TXN-04 · `Modules/Accounting/app/Http/Controllers/GrantController.php:227-265` — write an audit entry for the remaining mutations and apply the closed-grant guard to `changeStatus()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Before** (`GrantController.php:227-265`):
    ```php
    public function changeStatus(Request $request, Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        $request->validate([
            'status' => 'required|in:Sanctioned,Active,Fully_Utilised,Closed,Cancelled,Lapsed',
        ]);

        $grant->update([
            'status'     => $request->input('status'),
            'updated_by' => auth()->id(),
        ]);

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Grant status changed to {$grant->status}.");
    }

    public function toggleStatus(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        $grant->update(['is_active' => !$grant->is_active]);

        return redirect()->back()->with('success', 'Grant status updated.');
    }

    public function destroy(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.delete');

        if ($grant->receivable_voucher_id) {
            return redirect()->back()->with('error', 'Cannot delete a grant with a posted receivable voucher.');
        }

        $grant->delete();

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', 'Grant deleted successfully.');
    }
    ```
  - **After:**
    ```php
    public function changeStatus(Request $request, Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        if (in_array($grant->status, ['Closed', 'Cancelled'], true)) {
            return redirect()->back()->with('error', "Cannot modify a grant with status [{$grant->status}].");
        }

        $request->validate([
            'status' => 'required|in:Sanctioned,Active,Fully_Utilised,Closed,Cancelled,Lapsed',
        ]);

        DB::transaction(function () use ($request, $grant): void {
            $grant->update([
                'status' => $request->input('status'),
                'updated_by' => auth()->id(),
            ]);

            activityLog($grant, 'Status Changed', ['message' => "Grant status changed to {$grant->status}"]);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Grant status changed to {$grant->status}.");
    }

    public function toggleStatus(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        DB::transaction(function () use ($grant): void {
            $grant->update(['is_active' => ! $grant->is_active]);
            activityLog($grant, 'Active Toggled', ['message' => 'Grant active flag toggled']);
        });

        return redirect()->back()->with('success', 'Grant status updated.');
    }

    public function destroy(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.delete');

        $blocked = DB::transaction(function () use ($grant): bool {
            $locked = Grant::whereKey($grant->getKey())->lockForUpdate()->firstOrFail();

            if ($locked->receivable_voucher_id) {
                return true;
            }

            $locked->delete();
            activityLog($locked, 'Deleted', ['message' => 'Grant deleted']);

            return false;
        });

        if ($blocked) {
            return redirect()->back()->with('error', 'Cannot delete a grant with a posted receivable voucher.');
        }

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', 'Grant deleted successfully.');
    }
    ```
  - **Verify:** `grep -n "activityLog" Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Expect:** at least six matches (Created, Updated, Receivable Recognised, Status Changed, Active Toggled, Deleted).
  - **Effort:** M

## 4. Authorization (F3)

No item here. GRNT-06 is a DECISION (§9) because it adds a permission key; GRNT-07 is sequenced in §2 because it must land before the permission key can be exercised.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **GRNT-09** · M · VAL-02 · `Modules/Accounting/app/Http/Controllers/GrantController.php:205-225` — move certificate validation into a FormRequest and check the media id exists.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/GrantController.php`, `Modules/Accounting/app/Http/Requests/FileCertificateRequest.php` (new)
  - **Before** (`GrantController.php:13`):
    ```php
    use Modules\Accounting\Http\Requests\GrantRequest;
    ```
  - **Before** (`GrantController.php:205-225`):
    ```php
    public function fileCertificate(Request $request, Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        $request->validate([
            'utilisation_cert_filed_on' => 'required|date',
            'utilisation_cert_media_id' => 'nullable|integer',
            'notes'                     => 'nullable|string|max:1000',
        ]);

        $grant->update([
            'utilisation_cert_filed_on' => $request->input('utilisation_cert_filed_on'),
            'utilisation_cert_media_id' => $request->input('utilisation_cert_media_id'),
            'notes'                     => $request->input('notes') ?? $grant->notes,
            'status'                    => 'Fully_Utilised',
            'updated_by'                => auth()->id(),
        ]);

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Utilisation certificate recorded for grant {$grant->grant_code}.");
    }
    ```
  - **After** — new file `Modules/Accounting/app/Http/Requests/FileCertificateRequest.php`:
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Requests;

    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;

    class FileCertificateRequest extends FormRequest
    {
        use AuthorizesTenantFeature;

        public function authorize(): bool
        {
            return $this->authorizeByCrudPermission('tenant.accounting.grant', 'update');
        }

        public function rules(): array
        {
            return [
                'utilisation_cert_filed_on' => ['required', 'date'],
                'utilisation_cert_media_id' => ['nullable', 'integer', 'exists:sys_media,id'],
                'notes' => ['nullable', 'string', 'max:1000'],
            ];
        }
    }
    ```
  - **After** (controller import):
    ```php
    use Modules\Accounting\Http\Requests\FileCertificateRequest;
    use Modules\Accounting\Http\Requests\GrantRequest;
    ```
  - **After** (controller method):
    ```php
    public function fileCertificate(FileCertificateRequest $request, Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.update');

        if (in_array($grant->status, ['Closed', 'Cancelled'], true)) {
            return redirect()->back()->with('error', "Cannot modify a grant with status [{$grant->status}].");
        }

        $validated = $request->validated();

        DB::transaction(function () use ($validated, $grant): void {
            $grant->update([
                'utilisation_cert_filed_on' => $validated['utilisation_cert_filed_on'],
                'utilisation_cert_media_id' => $validated['utilisation_cert_media_id'] ?? null,
                'notes' => $validated['notes'] ?? $grant->notes,
                'status' => 'Fully_Utilised',
                'updated_by' => auth()->id(),
            ]);

            activityLog($grant, 'Certificate Filed', ['message' => 'Utilisation certificate filed']);
        });

        return redirect()->route('accounting.menu.schoolSpecific', ['tab' => 'grants'])
            ->with('success', "Utilisation certificate recorded for grant {$grant->grant_code}.");
    }
    ```
  - **Verify:** `grep -n "FileCertificateRequest" Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Expect:** the import and `fileCertificate(FileCertificateRequest $request, ...)`; and `php -l` passes on both files.
  - **Effort:** M

- [ ] **GRNT-11** · H · RTE-01 · ⚠ SHARED — `Modules/Accounting/routes/web.php:521-523`, `GrantController.php:267-294`, `grant/trash.blade.php:38-50` — restore over POST with route-model binding, correct trash permissions, and the shared row-action component.
  - **Touches:** `Modules/Accounting/routes/web.php` (⚠ SHARED, explicit tick required), `Modules/Accounting/app/Http/Controllers/GrantController.php`, `Modules/Accounting/resources/views/grant/trash.blade.php`
  - **Before** (`routes/web.php:521-523`):
    ```php
    Route::get('/grant/trash/view', [GrantController::class, 'trashed'])->name('grant.trashed');
    Route::get('/grant/{id}/restore', [GrantController::class, 'restore'])->name('grant.restore');
    Route::delete('/grant/{id}/force-delete', [GrantController::class, 'forceDelete'])->name('grant.forceDelete');
    ```
  - **Before** (`GrantController.php:9-10`):
    ```php
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    ```
  - **Before** (`GrantController.php:267-294`):
    ```php
    public function trashed()
    {
        Gate::authorize('tenant.accounting.grant.delete');

        $grants = Grant::onlyTrashed()->with(['fund', 'grantorLedger'])->paginate(25);

        return view('accounting::grant.trash', compact('grants'));
    }

    public function restore(int $id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.delete');

        $grant = Grant::onlyTrashed()->findOrFail($id);
        $grant->restore();

        return redirect()->route('accounting.grant.trashed')->with('success', 'Grant restored successfully.');
    }

    public function forceDelete(int $id): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.delete');

        $grant = Grant::onlyTrashed()->findOrFail($id);
        $grant->forceDelete();

        return redirect()->route('accounting.grant.trashed')->with('success', 'Grant permanently deleted.');
    }
    ```
  - **Before** (`trash.blade.php:38-50`):
    ```blade
                                        <td class="text-end pe-3">
                                            <div class="d-flex justify-content-end gap-1">
                                                <a href="{{ route('accounting.grant.restore', $item->id) }}" class="btn btn-xs btn-outline-success" title="Restore">
                                                    <i class="bi bi-arrow-counterclockwise"></i> Restore
                                                </a>
                                                <form action="{{ route('accounting.grant.forceDelete', $item->id) }}" method="POST" onsubmit="return confirm('Permanently delete this grant record?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-xs btn-outline-danger" title="Force Delete">
                                                        <i class="bi bi-trash"></i> Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
    ```
  - **After** (`routes/web.php`):
    ```php
    Route::get('/grant/trash/view', [GrantController::class, 'trashed'])->name('grant.trashed');
    Route::post('/grant/{grant}/restore', [GrantController::class, 'restore'])->name('grant.restore')->withTrashed();
    Route::delete('/grant/{grant}/force-delete', [GrantController::class, 'forceDelete'])->name('grant.forceDelete')->withTrashed();
    ```
  - **After** (`GrantController.php` import):
    ```php
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\View\View;
    ```
  - **After** (`GrantController.php` methods):
    ```php
    public function trashed(): View
    {
        Gate::authorize('tenant.accounting.grant.restore');

        $grants = Grant::onlyTrashed()->with(['fund', 'grantorLedger'])->paginate(10, ['*'], 'trashed_page');

        return view('accounting::grant.trash', compact('grants'));
    }

    public function restore(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.restore');

        if (! $grant->trashed()) {
            return redirect()->back()->with('warning', 'This grant is not deleted.');
        }

        DB::transaction(function () use ($grant): void {
            $grant->restore();
            activityLog($grant, 'Restored', ['message' => 'Grant restored']);
        });

        return redirect()->route('accounting.grant.trashed')->with('success', 'Grant restored successfully.');
    }

    public function forceDelete(Grant $grant): RedirectResponse
    {
        Gate::authorize('tenant.accounting.grant.forceDelete');

        if (! $grant->trashed()) {
            return redirect()->back()->with('error', 'Only trashed grants can be permanently deleted.');
        }

        DB::transaction(function () use ($grant): void {
            $grant->forceDelete();
            activityLog($grant, 'Force Deleted', ['message' => 'Grant permanently deleted']);
        });

        return redirect()->route('accounting.grant.trashed')->with('success', 'Grant permanently deleted.');
    }
    ```
  - **After** (`trash.blade.php`):
    ```blade
                                        <td class="text-end pe-3">
                                            <x-backend.table.action-trashed :id="$item->id" url="accounting.grant" tab="grants"
                                                restorePermission="tenant.accounting.grant.restore"
                                                forceDeletePermission="tenant.accounting.grant.forceDelete" />
                                        </td>
    ```
  - **Verify:** `php artisan route:list --name=accounting.grant.restore`
  - **Expect:** one line starting `POST` for `accounting/grant/{grant}/restore`.
  - **Effort:** M

## 6. Queries & performance (F9)

No separate item. GRNT-16 is applied by GRNT-11 (`paginate(10, ['*'], 'trashed_page')`).

## 7. Views (F10)

No separate item. GRNT-17 is applied by GRNT-11 (the shared `x-backend.table.action-trashed` component).

## 8. Style (F12) — one item per file

- [ ] **GRNT-18** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/GrantController.php:7-9` — drop the unused import, then run Pint on the file.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Before** (`GrantController.php:7-9`):
    ```php
    use App\Http\Controllers\Controller;
    use DomainException;
    use Illuminate\Http\RedirectResponse;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    ```
    Then run: `php vendor\bin\pint Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Verify:** `php vendor\bin\pint --test Modules/Accounting/app/Http/Controllers/GrantController.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **GRNT-19** · L · STY-02 · `Modules/Accounting/app/Http/Requests/GrantRequest.php:26-48` — use a single space around `=>`, then run Pint.
  - **Touches:** `Modules/Accounting/app/Http/Requests/GrantRequest.php`
  - **Before** (`GrantRequest.php:26-31`):
    ```php
                'grant_code'                     => ['required', 'string', 'max:30', Rule::unique('acc_grants', 'grant_code')->ignore($grantId)],
                'name'                           => ['required', 'string', 'max:200'],
                'grantor_ledger_id'              => ['nullable', 'integer', 'exists:acc_ledgers,id'],
                'grantor_name'                   => ['required', 'string', 'max:200'],
                'grantor_type'                   => ['required', Rule::in(Grant::grantorTypes())],
                'fund_id'                        => ['required', 'integer', 'exists:acc_funds,id'],
    ```
  - **After:**
    ```php
                'grant_code' => ['required', 'string', 'max:30', Rule::unique('acc_grants', 'grant_code')->ignore($grantId)],
                'name' => ['required', 'string', 'max:200'],
                'grantor_ledger_id' => ['nullable', 'integer', 'exists:acc_ledgers,id'],
                'grantor_name' => ['required', 'string', 'max:200'],
                'grantor_type' => ['required', Rule::in(Grant::grantorTypes())],
                'fund_id' => ['required', 'integer', 'exists:acc_funds,id'],
    ```
    Apply the same single-space form to every `=>` in `rules()` (lines 26-48), then run: `php vendor\bin\pint Modules/Accounting/app/Http/Requests/GrantRequest.php`
  - **Verify:** `php vendor\bin\pint --test Modules/Accounting/app/Http/Requests/GrantRequest.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **GRNT-20** · L · STY-02 · `Modules/Accounting/app/Models/Grant.php:7-8` — drop the unused `BaseModel` import, then run Pint on the file.
  - **Touches:** `Modules/Accounting/app/Models/Grant.php`
  - **Before** (`Grant.php:7-8`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    ```
    Then run: `php vendor\bin\pint Modules/Accounting/app/Models/Grant.php`
  - **Verify:** `php vendor\bin\pint --test Modules/Accounting/app/Models/Grant.php`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **GRNT-06** · H · DECISION · AUTH-01 — create the missing `accounting.grant` permission key so the feature can be given to real roles?
  - **Why it is a decision:** new permission key plus a ⚠ SHARED config file (`config/permissionslist.php`), and a per-tenant sync.
  - (a) ⭐ Add `'accounting.grant' => array_merge($crud, ['recogniseReceivable', 'fileCertificate'])` after `'accounting.fund' => $crud,` at `config/permissionslist.php:633`; then run the permission sync for each tenant. This makes the Grants tab and every controller gate reachable for any role granted the abilities.
  - (b) Reuse `'accounting.fund'` for the grant gates (wrong: grants and funds are separate rights and would over-grant).
  - (c) Leave as is and document that Grants is Super-Admin-only.
  - ➜ Choice: ____

- [ ] **GRNT-22** · H · DECISION · TXN-01 — what should happen when a grant with a posted receivable voucher is edited?
  - **Why it is a decision:** behaviour change on financial data (block vs reverse/repost), and option (b) adds a reversal convention this module does not have.
  - (a) ⭐ In `update()`, when `$grant->receivable_voucher_id` is set, reject changes to `sanctioned_amount`, `recognition_basis`, `fund_id` and `campus_id` with a flash telling the user to reverse the voucher first.
  - (b) Reverse the posted voucher and post a new one on every such edit (needs a reversal method on `VoucherService`, owned by VoucherController).
  - (c) Leave as is and accept that the grant and the ledger can disagree.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| GRNT-02 | Applied by GRNT-01 (helper returns `bool`; callers warn). |
| GRNT-03 | Applied by GRNT-01 (manual transactions replaced). |
| GRNT-04 | Applied by GRNT-01 and GRNT-05 (`lockForUpdate()`). |
| GRNT-08 | Applied by GRNT-11 (`.restore` / `.forceDelete` gates). |
| GRNT-10 | Applied by GRNT-09 (`exists:sys_media,id`). |
| GRNT-12 | Applied by GRNT-11 (route-model binding + `withTrashed()`). |
| GRNT-13 | `trashed(): View` applied by GRNT-11; the other four return types are informational and would only add noise to this pass. |
| GRNT-15 | Informational: status literals → enums/constants is a refactor with no behaviour change; not recommended in this pass. |
| GRNT-16 | Applied by GRNT-11 (`paginate(10, ['*'], 'trashed_page')`). |
| GRNT-17 | Applied by GRNT-11 (shared row-action component). |
| GRNT-21 | Applied by GRNT-05 (`changeStatus`) and GRNT-09 (`fileCertificate`). |
