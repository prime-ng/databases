# Final Audit — Accounting / CostCategoryController

**Audited:** 2026-10-22 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/CostCategoryController.php` (254 lines, 12 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/setup-masters?tab=cost-categories` (list tab), `/accounting/cost-category/create`, `/accounting/cost-category/{id}`, `/accounting/cost-category/{id}/edit`, `/accounting/cost-category/trash/view` |
| Menu path | Accounting → Setup & Masters → Cost Categories (tab) |
| Who uses it | Five roles hold `tenant.accounting.cost-category.viewAny` on `xyz_school_00000000000040008000_202627`: Account Manager, Account Staff, Management, School Admin and Super Admin (exact-name query against `sys_roles`, `sys_role_has_permissions_jnt`, `sys_permissions`) |
| What a user does here | Maintains the cost-category master used to classify expenses: create a category with a code, name, description, mandatory flag, multiple-allocation flag and active flag; edit it; toggle it active/inactive; drag rows to reorder them; move it to the trash; restore it; or permanently delete it. |
| Tables written | `acc_cost_categories`, `sys_activity_logs` |
| Tables read | `acc_cost_categories`; reference checks read `acc_cost_centers`, `acc_voucher_item_cost_centers` and `acc_expense_claim_lines` |
| Live data | `acc_cost_categories` 6 live, 0 trashed; `acc_cost_centers` 12 (5 + 7 reference two categories); `acc_voucher_item_cost_centers` 91; `acc_expense_claim_lines` 7; `sys_activity_logs` 407 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No. The controller is not production-ready until the blocker and the five high findings are fixed. The single worst finding is CSCA-01: all seven write paths catch every throwable and send `$e->getMessage()` to the browser, so SQL and column names leak; CSCA-08 and CSCA-19 make that leak reachable from ordinary screens (re-creating a trashed code, or clearing Display Order on edit). CSCA-09 silently saves `Allow Multiple` and `Active` as `true` when the user unchecks them. The fix is one controller rewrite plus two FormRequest edits; rough effort **S–M**, about one developer-day including the trash-route decision and the Pint pass.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 5 | 9 | 4 | 2 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CSCA-01, CSCA-02, CSCA-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CSCA-04, CSCA-05, CSCA-06 | F9 Queries/Perf | CSCA-14 |
| F3 Authorization | CSCA-07 | F10 Views | CSCA-15 |
| F4 Validation | CSCA-08, CSCA-09, CSCA-10, CSCA-19 | F11 Security/Tenancy | clean |
| F5 Routes | CSCA-11 | F12 Style | CSCA-16 |
| F6 Controller shape | CSCA-12, CSCA-13 | F13 Deep read | CSCA-17, CSCA-18 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php` | controller | 254 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/CostCategory.php` | model | 64 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php` | FormRequest | 65 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model base | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 5 | `Modules/Accounting/app/Services/AccountingContext.php` | service reached through the model base | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked (not exercised: `CostCategory::$fillable` has no context columns) |
| 6 | `Modules/Accounting/resources/views/cost-category/create.blade.php` | view | 109 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/cost-category/edit.blade.php` | view | 148 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/cost-category/show.blade.php` | view | 140 | this report | ✅ |
| 9 | `Modules/Accounting/resources/views/cost-category/trash.blade.php` | view | 69 | this report | ✅ |
| 10 | `Modules/Accounting/resources/views/cost-category/index.blade.php` | view (orphaned) | 104 | this report | ✅ (dead — CSCA-15) |
| 11 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model reached through `activityLog()` | 50 | unclaimed shared — §7 cross-cutting | ✅ (usage checked) |
| 12 | `Modules/Accounting/routes/web.php` | shared route file | 536 | module-shared | ✅ (routes read; changes are ⚠ SHARED) |
| 13 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_cost-categories.blade.php` | view | 228 | ❌ not this controller — rendered by `AccDashboardController::setupMasters()` | ❌ outside scope |

No pre-applied files.

## 4. Routes

```
GET|HEAD  accounting/cost-category                                accounting.cost-category.index      Modules\Accounting\Http\Controllers\CostCategoryController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cost-category                                accounting.cost-category.store      Modules\Accounting\Http\Controllers\CostCategoryController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-category/create                         accounting.cost-category.create     Modules\Accounting\Http\Controllers\CostCategoryController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cost-category/reorder                        accounting.cost-category.reorder    Modules\Accounting\Http\Controllers\CostCategoryController@reorder  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-category/trash/view                     accounting.cost-category.trashed    Modules\Accounting\Http\Controllers\CostCategoryController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-category/{cost_category}                accounting.cost-category.show       Modules\Accounting\Http\Controllers\CostCategoryController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/cost-category/{cost_category}                accounting.cost-category.update     Modules\Accounting\Http\Controllers\CostCategoryController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cost-category/{cost_category}                accounting.cost-category.destroy    Modules\Accounting\Http\Controllers\CostCategoryController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-category/{cost_category}/edit           accounting.cost-category.edit       Modules\Accounting\Http\Controllers\CostCategoryController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cost-category/{cost_category}/toggle-status  accounting.cost-category.toggleStatus Modules\Accounting\Http\Controllers\CostCategoryController@toggleStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cost-category/{id}/force-delete              accounting.cost-category.forceDelete Modules\Accounting\Http\Controllers\CostCategoryController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cost-category/{id}/restore                   accounting.cost-category.restore    Modules\Accounting\Http\Controllers\CostCategoryController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none — all 12 public methods have a route.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET /accounting/cost-category | `tenant.accounting.cost-category.viewAny` | none | none | none | CSCA-13 |
| `create` | 24 | GET /accounting/cost-category/create | `tenant.accounting.cost-category.create` | none | none | none | CSCA-13 |
| `store` | 31 | POST /accounting/cost-category | `tenant.accounting.cost-category.create` | controller (manual) | `Created` | `acc_cost_categories`, `sys_activity_logs` | CSCA-01, CSCA-03, CSCA-04, CSCA-06, CSCA-07, CSCA-08, CSCA-09, CSCA-13, CSCA-17 |
| `show` | 64 | GET /accounting/cost-category/{cost_category} | `tenant.accounting.cost-category.view` | none | none | none | CSCA-13 |
| `edit` | 71 | GET /accounting/cost-category/{cost_category}/edit | `tenant.accounting.cost-category.update` | none | none | none | CSCA-13 |
| `update` | 78 | PUT/PATCH /accounting/cost-category/{cost_category} | `tenant.accounting.cost-category.update` | controller (manual) | `Updated` | `acc_cost_categories`, `sys_activity_logs` | CSCA-01, CSCA-03, CSCA-04, CSCA-07, CSCA-08, CSCA-09, CSCA-13, CSCA-17, CSCA-19 |
| `destroy` | 108 | DELETE /accounting/cost-category/{cost_category} | `tenant.accounting.cost-category.delete` | controller (manual) | `Trashed` | `acc_cost_categories`, `sys_activity_logs` | CSCA-01, CSCA-03, CSCA-04, CSCA-13, CSCA-18 |
| `toggleStatus` | 140 | POST /accounting/cost-category/{cost_category}/toggle-status | `tenant.accounting.cost-category.update` | controller (manual) | `Toggled` | `acc_cost_categories`, `sys_activity_logs` | CSCA-01, CSCA-03, CSCA-04, CSCA-13 |
| `reorder` | 168 | POST /accounting/cost-category/reorder | `tenant.accounting.cost-category.update` | controller (manual) | none | `acc_cost_categories` | CSCA-01, CSCA-03, CSCA-04, CSCA-05, CSCA-10, CSCA-13, CSCA-14, CSCA-17 |
| `trashed` | 192 | GET /accounting/cost-category/trash/view | `tenant.accounting.cost-category.restore` | none | none | none | none |
| `restore` | 201 | GET /accounting/cost-category/{id}/restore | `tenant.accounting.cost-category.restore` | controller (manual) | `Restored` | `acc_cost_categories`, `sys_activity_logs` | CSCA-01, CSCA-02, CSCA-03, CSCA-04, CSCA-11, CSCA-12 |
| `forceDelete` | 228 | DELETE /accounting/cost-category/{id}/force-delete | `tenant.accounting.cost-category.forceDelete` | controller (manual) | `Deleted` | `acc_cost_categories`, `sys_activity_logs` | CSCA-01, CSCA-02, CSCA-03, CSCA-04, CSCA-11, CSCA-12, CSCA-18 |

## 6. Findings

### F1 — Errors

#### CSCA-01 · B · ERR-01 — Every write path sends the raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:53-60, 97-104, 129-136, 160-164, 184-188, 220-224, 247-251`, methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `reorder()`, `restore()`, `forceDelete()` |
| **Root cause** | All seven mutations wrap the write in `try/catch (\Throwable $e)` and either concatenate `$e->getMessage()` into a flash/JSON message or return it in the 500 payload. `QueryException` extends `RuntimeException`, so duplicate-key, NOT NULL and foreign-key failures all reach the browser as SQL text. |
| **Consequence** | A user who clears Display Order on the edit screen (CSCA-19) or re-uses a trashed code (CSCA-08) sees the database error, including table and column names, instead of a field-level message. |
| **Reproduce** | Open `/accounting/cost-category/{id}/edit`, clear Display Order, save. Validation passes, the UPDATE sets `ordinal = NULL`, MySQL rejects it, and the red flash contains `SQLSTATE[23000]`. |
| **Fix approach** | Remove the controller `try/catch` (D1) and let the central handler log and render the failure; wrap each write in `DB::transaction()`. The plan item rewrites all seven methods. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:53-60 — CURRENT
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cost Category', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Cost Category: ' . $e->getMessage());
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "getMessage"
56:                'error' => $e->getMessage(),
60:            return back()->withInput()->with('error', 'Failed to create Cost Category: ' . $e->getMessage());
101:                'error' => $e->getMessage(),
104:            return back()->withInput()->with('error', 'Failed to update Cost Category: ' . $e->getMessage());
133:                'error' => $e->getMessage(),
136:            return back()->with('error', 'Failed to delete Cost Category: ' . $e->getMessage());
162:            Log::error('Failed to toggle Cost Category status', ['id' => $costCategory->id, 'error' => $e->getMessage()]);
164:            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
186:            Log::error('Failed to reorder Cost Categories', ['error' => $e->getMessage()]);
188:            return response()->json(['success' => false, 'message' => 'Failed to reorder: ' . $e->getMessage()], 500);
222:            Log::error('Failed to restore Cost Category', ['id' => $id, 'error' => $e->getMessage()]);
224:            return back()->with('error', 'Failed to restore Cost Category: ' . $e->getMessage());
249:            Log::error('Failed to force delete Cost Category', ['id' => $id, 'error' => $e->getMessage()]);
251:            return back()->with('error', 'Failed to delete Cost Category: ' . $e->getMessage());
```

#### CSCA-02 · H · ERR-02 — A missing trash record becomes a redirect instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:207, 220` (`restore()`), `:234, 247` (`forceDelete()`) |
| **Root cause** | `findOrFail()` sits inside the `try`, and the generic `catch (\Throwable $e)` swallows `ModelNotFoundException` and redirects with a red flash. |
| **Consequence** | A stale restore or force-delete URL shows "Failed to restore Cost Category" instead of a 404, so the operator cannot tell a bad link from a server failure. |
| **Reproduce** | Open `/accounting/cost-category/999999/restore` while logged in as Account Manager; expected 404, actual redirect with the red flash. |
| **Fix approach** | Move the lookup above the transaction; the D1 rewrite in CSCA-01 removes the `try` entirely. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:205-208 and :220 — CURRENT
        DB::beginTransaction();
        try {
            $model = CostCategory::onlyTrashed()->findOrFail($id);
            $model->restore();
        } catch (\Throwable $e) {
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "findOrFail|catch \("
53:        } catch (\Throwable $e) {
97:        } catch (\Throwable $e) {
129:        } catch (\Throwable $e) {
160:        } catch (\Throwable $e) {
184:        } catch (\Throwable $e) {
207:            $model = CostCategory::onlyTrashed()->findOrFail($id);
220:        } catch (\Throwable $e) {
234:            $model = CostCategory::withTrashed()->findOrFail($id);
247:        } catch (\Throwable $e) {
```

#### CSCA-03 · M · ERR-05 — The log stores the message string, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:55-58, 99-102, 131-134, 162, 186, 222, 249` |
| **Root cause** | Each catch calls `Log::error(..., ['error' => $e->getMessage()])`; `store()` also stores `getTraceAsString()` as text. No exception object is passed to the handler, so the log has no class, trace or report grouping. |
| **Consequence** | Production debugging is slower: the central handler never sees the exception, and the log entry cannot be grouped with other failures of the same type. |
| **Reproduce** | Static only — a log inspection after forcing a write failure is required. |
| **Fix approach** | Let the exception escape (D1) so `bootstrap/app.php` logs and renders it. The rewrite removes every `Log::error` call. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:55-58 — CURRENT
            Log::error('Failed to create Cost Category', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "Log::error"
55:            Log::error('Failed to create Cost Category', [
99:            Log::error('Failed to update Cost Category', [
131:            Log::error('Failed to trash Cost Category', [
162:            Log::error('Failed to toggle Cost Category status', ['id' => $costCategory->id, 'error' => $e->getMessage()]);
186:            Log::error('Failed to reorder Cost Categories', ['error' => $e->getMessage()]);
222:            Log::error('Failed to restore Cost Category', ['id' => $id, 'error' => $e->getMessage()]);
249:            Log::error('Failed to force delete Cost Category', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CSCA-04 · M · TXN-02 — Seven methods hand-roll beginTransaction/commit/rollBack

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => ...)`, not manual `beginTransaction`/`commit`/`rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:38-61, 82-105, 112-137, 146-165, 174-189, 205-225, 232-252` |
| **Root cause** | Every mutation opens a transaction by hand and guards it with a controller `try/catch`. A future early return between `beginTransaction()` and `commit()` leaves the connection inside an open transaction. |
| **Consequence** | The write paths are fragile: one added early return or throw can leak a transaction and make later queries in the same request behave unpredictably. |
| **Reproduce** | Static only — the current paths reach commit or rollBack, but the shape is not safe to extend. |
| **Fix approach** | Wrap each mutation in a `DB::transaction()` closure; build the redirect/JSON after the closure. CSCA-01 does this for all seven methods. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:38-40 and :49-54 — CURRENT
        DB::beginTransaction();
        try {
            $costCategory = CostCategory::create($validated);
            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "DB::beginTransaction|DB::commit|DB::rollBack"
38:        DB::beginTransaction();
49:            DB::commit();
54:            DB::rollBack();
82:        DB::beginTransaction();
93:            DB::commit();
98:            DB::rollBack();
112:        DB::beginTransaction();
125:            DB::commit();
130:            DB::rollBack();
146:        DB::beginTransaction();
157:            DB::commit();
161:            DB::rollBack();
174:        DB::beginTransaction();
181:            DB::commit();
185:            DB::rollBack();
205:        DB::beginTransaction();
217:            DB::commit();
221:            DB::rollBack();
232:        DB::beginTransaction();
244:            DB::commit();
248:            DB::rollBack();
```

#### CSCA-05 · M · TXN-04 — Reordering changes data with no audit entry

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:168-190`, method `reorder()` |
| **Root cause** | The other six mutations call `activityLog()` after the write; `reorder()` updates every ordinal and commits without logging anything. |
| **Consequence** | Display-order changes leave no trace in `sys_activity_logs`, so an operator cannot tell who reordered the categories or when. |
| **Reproduce** | Drag a category row on the Cost Categories tab, then query `sys_activity_logs` for a `Reordered` event; no row is written. |
| **Fix approach** | Add one `activityLog($model, 'Reordered', $context)` call inside the transaction after the updates. The rewrite in CSCA-01 includes it. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:174-183 — CURRENT
        DB::beginTransaction();
        try {
            $ids = $request->input('ids');
            foreach ($ids as $ordinal => $id) {
                CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }

            DB::commit();

            return response()->json(['success' => true, 'message' => 'Order updated.']);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "activityLog"
42:            activityLog($costCategory, 'Created', [
86:            activityLog($costCategory, 'Updated', [
118:            activityLog($costCategory, 'Trashed', [
151:            activityLog($costCategory, 'Toggled', [
211:            activityLog($model, 'Restored', [
238:            activityLog($model, 'Deleted', [

> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "foreach"
177:            foreach ($ids as $ordinal => $id) {
```

#### CSCA-06 · M · TXN-06 — The next ordinal is computed outside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M; rulebook default H lowered because duplicate ordinals only affect display order, not data integrity) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:36` (computed before `beginTransaction()` at `:38`) |
| **Root cause** | `CostCategory::max('ordinal') + 1` reads the maximum before the transaction starts and without a lock. Two concurrent creates read the same maximum and both insert the same ordinal. |
| **Consequence** | Two categories created at the same moment share a display order; the list order between them is arbitrary. |
| **Reproduce** | Static only — two parallel POSTs to `/accounting/cost-category` are needed to observe the duplicate. |
| **Fix approach** | Resolve the next ordinal inside the transaction with `lockForUpdate()`, or order by `ordinal` then `id` so duplicates are deterministic. CSCA-01 computes it inside the transaction. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:35-38 — CURRENT
        $validated = $request->validated();
        $validated['ordinal'] = CostCategory::max('ordinal') + 1;

        DB::beginTransaction();
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "ordinal"
36:        $validated['ordinal'] = CostCategory::max('ordinal') + 1;
177:            foreach ($ids as $ordinal => $id) {
178:                CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
```

### F3 — Authorization

#### CSCA-07 · L · AUTH-04 — The create and update permissions are checked twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php:15-18`; `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:33, 80` |
| **Root cause** | `CostCategoryRequest::authorize()` maps POST to `tenant.accounting.cost-category.create` and PUT/PATCH to `tenant.accounting.cost-category.update`; the controller then calls `Gate::authorize()` with the same two names. |
| **Consequence** | No runtime difference; a future permission rename or policy change must be made in two places, and one copy can drift. |
| **Reproduce** | Static only — inspect the FormRequest and the two controller methods. |
| **Fix approach** | Keep the FormRequest check for `store`/`update` and remove the two duplicate `Gate::authorize()` lines (CSCA-01 rewrite). |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php — CURRENT
    // store(), line 33
    Gate::authorize('tenant.accounting.cost-category.create');

    // update(), line 80
    Gate::authorize('tenant.accounting.cost-category.update');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php","Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "authorizeByCrudPermission|Gate::authorize"
CostCategoryRequest.php:17:        return $this->authorizeByCrudPermission('tenant.accounting.cost-category');
CostCategoryController.php:19:        Gate::authorize('tenant.accounting.cost-category.viewAny');
CostCategoryController.php:26:        Gate::authorize('tenant.accounting.cost-category.create');
CostCategoryController.php:33:        Gate::authorize('tenant.accounting.cost-category.create');
CostCategoryController.php:66:        Gate::authorize('tenant.accounting.cost-category.view');
CostCategoryController.php:73:        Gate::authorize('tenant.accounting.cost-category.update');
CostCategoryController.php:80:        Gate::authorize('tenant.accounting.cost-category.update');
CostCategoryController.php:110:        Gate::authorize('tenant.accounting.cost-category.delete');
CostCategoryController.php:142:        Gate::authorize('tenant.accounting.cost-category.update');
CostCategoryController.php:170:        Gate::authorize('tenant.accounting.cost-category.update');
CostCategoryController.php:194:        Gate::authorize('tenant.accounting.cost-category.restore');
CostCategoryController.php:203:        Gate::authorize('tenant.accounting.cost-category.restore');
CostCategoryController.php:230:        Gate::authorize('tenant.accounting.cost-category.forceDelete');
```

### F4 — Validation and input

#### CSCA-08 · H · VAL-04 — Soft-deleted codes and names pass validation but violate the unique index

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules must mirror the database unique index, including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php:25-26`; indexes from `database/migrations/tenant/2026_09_16_100003_create_acc_cost_categories_table.php:33-34` |
| **Root cause** | Both `Rule::unique()` calls add `->whereNull('deleted_at')`, so validation ignores trashed rows, but `uq_acc_cc_cat_code` and `uq_acc_cc_cat_name` cover every row, including trashed ones. |
| **Consequence** | Re-creating a category with the code or name of a trashed category passes validation and then fails the insert; the raw SQL error is shown through CSCA-01. |
| **Reproduce** | Trash category `Wing`, then create a new category with code `Wing`; validation passes, the insert throws a duplicate-key error. |
| **Fix approach** | Remove `->whereNull('deleted_at')` from both rules so validation matches the unique index. |
| **Plan item** | CSCA-08 in `02-fix-plan.md` §5 |

```php
// CostCategoryRequest.php:25-26 — CURRENT
            'code'           => ['required', 'string', 'max:20', Rule::unique('acc_cost_categories', 'code')->ignore($id)->whereNull('deleted_at')],
            'name'           => ['required', 'string', 'max:100', Rule::unique('acc_cost_categories', 'name')->ignore($id)->whereNull('deleted_at')],
```

**Evidence**
```
> mysql -uroot -N -e "SELECT INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX), NON_UNIQUE FROM information_schema.STATISTICS WHERE TABLE_SCHEMA='xyz_school_00000000000040008000_202627' AND TABLE_NAME='acc_cost_categories' GROUP BY INDEX_NAME, NON_UNIQUE;"
PRIMARY	id	0
uq_acc_cc_cat_code	code	0
uq_acc_cc_cat_name	name	0

> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" -Pattern "whereNull"
25:            'code'           => ['required', 'string', 'max:20', Rule::unique('acc_cost_categories', 'code')->ignore($id)->whereNull('deleted_at')],
26:            'name'           => ['required', 'string', 'max:100', Rule::unique('acc_cost_categories', 'name')->ignore($id)->whereNull('deleted_at')],
```

#### CSCA-09 · H · VAL-03 — Unchecked boolean fields are saved as true

| Field | Value |
|---|---|
| **Rule** | VAL-03 (H) — *absent optional fields must not be replaced by a wrong default* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php:50-52`; unchecked boxes in `Modules/Accounting/resources/views/cost-category/edit.blade.php:111, 119` and `Modules/Accounting/resources/views/pages/partials/setup-masters/_cost-categories.blade.php:167, 174` |
| **Root cause** | `prepareForValidation()` merges `$this->boolean('allow_multiple', true)` and `$this->boolean('is_active', true)`. A browser does not submit an unchecked checkbox, so the key is absent and the default `true` wins. The rules then accept `true`. |
| **Consequence** | A user who switches `Allow Multiple` or `Active` off on the edit page (or leaves `Allow Multiple` unchecked on create) sees the category saved with the flag still on; the screen silently ignores the input. |
| **Reproduce** | Open a category's edit page, switch `Allow Multiple` off, save, reopen; the switch is on again. |
| **Fix approach** | Default all three checkbox booleans to `false` so an absent key means "unchecked". The create form's Active switch is checked by default and submits `1`, so it is unaffected. |
| **Plan item** | CSCA-09 in `02-fix-plan.md` §5 |

```php
// CostCategoryRequest.php:49-53 — CURRENT
        $mergeData = [
            'is_mandatory'   => $this->boolean('is_mandatory', false),
            'allow_multiple' => $this->boolean('allow_multiple', true),
            'is_active'      => $this->boolean('is_active', true),
        ];
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" -Pattern "boolean"
50:            'is_mandatory'   => $this->boolean('is_mandatory', false),
51:            'allow_multiple' => $this->boolean('allow_multiple', true),
52:            'is_active'      => $this->boolean('is_active', true),

> Select-String -Path "Modules\Accounting\resources\views\cost-category\edit.blade.php" -Pattern "name=`"is_active`"|name=`"allow_multiple`""
103:                                                <input class="form-check-input" type="checkbox" name="is_mandatory" id="is_mandatory" value="1" {{ old('is_mandatory', $costCategory->is_mandatory) ? 'checked' : '' }}>
111:                                                <input class="form-check-input" type="checkbox" name="allow_multiple" id="allow_multiple" value="1" {{ old('allow_multiple', $costCategory->allow_multiple) ? 'checked' : '' }}>
119:                                                <input type="checkbox" name="is_active" id="is_active"
120:                                                    class="form-check-input" value="1" {{ old('is_active', $costCategory->is_active) ? 'checked' : '' }}>
```

#### CSCA-10 · M · VAL-05 — Reorder accepts array elements that are not ids

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed; the request is the boundary that enforces it* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:172, 176-178` |
| **Root cause** | The inline rule is `['ids' => 'required|array']`. Element values are never validated as integers or as existing category ids; a non-numeric value reaches `where('id', $id)` and an unknown id is silently skipped. |
| **Consequence** | A malformed or stale drag request returns `success: true` while nothing changes, and the UI reports "Order updated." when the order did not update. |
| **Reproduce** | POST `/accounting/cost-category/reorder` with `{"ids":["abc"]}` and a valid CSRF token; the response is `{"success":true,"message":"Order updated."}`. |
| **Fix approach** | Validate `ids.*` as `required|integer|exists:acc_cost_categories,id` before the transaction. CSCA-01 includes the rule. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:172-178 — CURRENT
        $request->validate(['ids' => 'required|array']);

        DB::beginTransaction();
        try {
            $ids = $request->input('ids');
            foreach ($ids as $ordinal => $id) {
                CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "ids"
172:        $request->validate(['ids' => 'required|array']);
176:            $ids = $request->input('ids');
177:            foreach ($ids as $ordinal => $id) {
```

#### CSCA-19 · H · VAL-04 — Validation allows a NULL ordinal, but the column is NOT NULL

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *validation must mirror the database constraints, here the NOT NULL ordinal column* |
| **Where** | `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php:30, 55-56`; `database/migrations/tenant/2026_09_16_100003_create_acc_cost_categories_table.php:26`; `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:84` |
| **Root cause** | The rule is `nullable|integer|min:0`, and `prepareForValidation()` converts an empty `ordinal` to `null`. `update()` passes `validated()` straight to `$costCategory->update()`, but the column is `unsignedSmallInteger(...)->default(0)` with no `NULL` allowance. |
| **Consequence** | Clearing Display Order on the edit page produces a database error instead of saving; because of CSCA-01 the raw SQL text is shown to the user. |
| **Reproduce** | Open a category's edit page, clear Display Order, save; the request fails with `Column 'ordinal' cannot be null`. |
| **Fix approach** | Keep the existing ordinal when the field is cleared, or reject the null in the FormRequest. CSCA-01's `update()` substitutes the current value. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryRequest.php:30 — CURRENT
            'ordinal'        => 'nullable|integer|min:0',
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" -Pattern "ordinal"
30:            'ordinal'        => 'nullable|integer|min:0',
43:            'ordinal'        => 'Display Order',
55:        $this->has('ordinal') && $this->input('ordinal') === ''
56:            $mergeData['ordinal'] = null;

> Select-String -Path "database\migrations\tenant\2026_09_16_100003_create_acc_cost_categories_table.php" -Pattern "ordinal"
26:            $table->unsignedSmallInteger('ordinal')->default(0);
```

### F5 — Routes

#### CSCA-11 · H · RTE-01 — Restoring a category changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:389`; `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:201-226` |
| **Root cause** | The restore route is `Route::get`, and the trash view's action is a link. Any prefetch, crawler or authenticated GET restores the record. |
| **Consequence** | A browser prefetch or a pasted URL can restore a trashed cost category without an explicit confirmation or CSRF token. |
| **Reproduce** | Open `/accounting/cost-category/{id}/restore` directly for a trashed category; it is restored with a success flash. |
| **Fix approach** | Move the action to POST/DELETE. The route file is shared and the `x-backend.table.action-trashed` component has 475 call sites, so this is a module-wide decision. |
| **Plan item** | CSCA-11 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// Modules/Accounting/routes/web.php:389 — CURRENT
Route::get('/cost-category/{id}/restore', [CostCategoryController::class, 'restore'])->name('cost-category.restore');
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "cost-category.*restore"
389:Route::get('/cost-category/{id}/restore', [CostCategoryController::class, 'restore'])->name('cost-category.restore');

> $files = Get-ChildItem -Recurse -Path "resources\views","Modules" -Filter *.blade.php; ($files | Select-String -Pattern "x-backend.table.action-trashed" -AllMatches | ForEach-Object { $_.Matches.Count } | Measure-Object -Sum).Sum
475
```

### F6 — Controller shape

#### CSCA-12 · M · CTL-03 — The two trash actions bypass route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` plus `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:201, 207, 228, 234`; `Modules/Accounting/routes/web.php:389-390` |
| **Root cause** | `restore($id)` and `forceDelete($id)` use an unbound `{id}` parameter and run their own `findOrFail` queries; the other six record actions use `{cost_category}` and implicit binding. |
| **Consequence** | The two trash actions use a different lookup shape from the rest of the controller; a future change to the model's route key or to trashed-row lookup rules will silently miss these two actions. |
| **Reproduce** | Static only — compare the route parameters and method signatures. |
| **Fix approach** | Rename the parameters to `{cost_category}` and bind `CostCategory` in the same pass as CSCA-11. The binding must include trashed rows for these actions. |
| **Plan item** | CSCA-11 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
// CostCategoryController.php:201-207 and :228-234 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cost-category.restore');

        DB::beginTransaction();
        try {
            $model = CostCategory::onlyTrashed()->findOrFail($id);
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cost-category.forceDelete');

        DB::beginTransaction();
        try {
            $model = CostCategory::withTrashed()->findOrFail($id);
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "cost-category.*(restore|force-delete)"
389:Route::get('/cost-category/{id}/restore', [CostCategoryController::class, 'restore'])->name('cost-category.restore');
390:Route::delete('/cost-category/{id}/force-delete', [CostCategoryController::class, 'forceDelete'])->name('cost-category.forceDelete');

> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "public function (restore|forceDelete)|findOrFail"
201:    public function restore($id): \Illuminate\Http\RedirectResponse
207:            $model = CostCategory::onlyTrashed()->findOrFail($id);
228:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
234:            $model = CostCategory::withTrashed()->findOrFail($id);
```

#### CSCA-13 · L · CTL-04 — Nine public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:17, 24, 31, 64, 71, 78, 108, 140, 168` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type; the other nine signatures declare none. |
| **Consequence** | No runtime effect; the response contract is invisible to static analysis and to the next developer. |
| **Reproduce** | Static only — inspect the signatures. |
| **Fix approach** | Add `RedirectResponse`, `View` and `JsonResponse` return types to the nine signatures. CSCA-01 includes them. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php — CURRENT signatures
    public function index()
    public function create()
    public function store(CostCategoryRequest $request)
    public function show(CostCategory $costCategory)
    public function edit(CostCategory $costCategory)
    public function update(CostCategoryRequest $request, CostCategory $costCategory)
    public function destroy(CostCategory $costCategory)
    public function toggleStatus(Request $request, CostCategory $costCategory)
    public function reorder(Request $request)
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "public function"
17:    public function index()
24:    public function create()
31:    public function store(CostCategoryRequest $request)
64:    public function show(CostCategory $costCategory)
71:    public function edit(CostCategory $costCategory)
78:    public function update(CostCategoryRequest $request, CostCategory $costCategory)
108:    public function destroy(CostCategory $costCategory)
140:    public function toggleStatus(Request $request, CostCategory $costCategory)
168:    public function reorder(Request $request)
192:    public function trashed(): \Illuminate\View\View
201:    public function restore($id): \Illuminate\Http\RedirectResponse
228:    public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

### F7 — Models

clean — `php -l Modules/Accounting/app/Models/CostCategory.php` → `No syntax errors detected`; `$table = 'acc_cost_categories'` exists in `database/migrations/tenant/2026_09_16_100003_create_acc_cost_categories_table.php:19`; `$fillable` lists the seven writable columns (no sensitive column); `$casts` covers `is_mandatory`, `allow_multiple` and `is_active` (boolean); `SoftDeletes` is present and the table has `deleted_at`; both relationships are return-typed `HasMany` and their targets exist (`CostCenter.php`, `VoucherItemCostCenter.php`). The only model defect is the unused `App\Models\BaseModel` import, reported under STY-02 (CSCA-16).

### F8 — Services and jobs

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "Service|Job|dispatch|queue"` → no output. The controller calls no service and dispatches no job.

### F9 — Queries and performance

#### CSCA-14 · M · QRY-01 — Reorder runs one UPDATE per row

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M; rulebook default H lowered because the live table has 6 rows and each row needs a distinct ordinal) — *no queries inside loops* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:177-178` |
| **Root cause** | The `foreach` issues one `UPDATE` per id; the number of round-trips equals the number of dragged rows. |
| **Consequence** | At 6 rows the cost is negligible; as the master list grows, one drag becomes N update statements inside one transaction. |
| **Reproduce** | Static only — the loop is the query. |
| **Fix approach** | A single CASE update or a full-column upsert would reduce it to one statement; at the current volume the loop is accepted (see plan §10). |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted at 6 rows; revisit when the list grows) |

```php
// CostCategoryController.php:177-179 — CURRENT
            foreach ($ids as $ordinal => $id) {
                CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }
```

**Evidence**
```
> mysql -uroot -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_cost_categories;"
6

> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "foreach" -Context 0,1
177:            foreach ($ids as $ordinal => $id) {
178:                CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);
```

### F10 — Views

#### CSCA-15 · L · CTL-10 — The index view is orphaned

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code; a view no route renders is dead code* |
| **Where** | `Modules/Accounting/resources/views/cost-category/index.blade.php` (104 lines); `CostCategoryController.php:17-22` |
| **Root cause** | `index()` redirects to the setup-masters tab. No controller returns `accounting::cost-category.index`, and the route name `accounting.cost-category.index` is not referenced by any Blade or controller. |
| **Consequence** | No user sees the file today; a future change that points `index()` at it without passing `$costCategories` fails with an undefined-variable error. |
| **Reproduce** | Static only — grep the route name and the view name; both return no reference. |
| **Fix approach** | Delete the orphan in a cleanup pass. The real list is the setup-masters tab partial rendered by `AccDashboardController`. |
| **Plan item** | none — see `02-fix-plan.md` §10 (dead file; cleanup pass) |

```php
// CostCategoryController.php:17-22 — CURRENT
    public function index()
    {
        Gate::authorize('tenant.accounting.cost-category.viewAny');

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-categories']);
    }
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\*.php","Modules\Accounting\resources\views\**\*.blade.php" -Pattern "cost-category\.index"
no output

> Select-String -Path "Modules\Accounting\app\Http\Controllers\*.php" -Pattern "cost-category\.index"
no output
```

### F11 — Security and tenancy

clean — `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "env\(|DB::raw|whereRaw|orderByRaw|\?\? 1|Log::.*request"` → no output. All routes carry the tenant middleware group (see §4); the model is tenant-scoped through `BaseAccountingModel`; no raw SQL, hard-coded ids or request-body logging is present.

### F12 — Style

#### CSCA-16 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 plus the Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php`; `Modules/Accounting/app/Http/Requests/CostCategoryRequest.php`; `Modules/Accounting/app/Models/CostCategory.php` |
| **Root cause** | The controller fails `fully_qualified_strict_types`, `concat_space`, `ordered_imports` and `binary_operator_spaces`; the request fails `ordered_imports` and `binary_operator_spaces`; the model fails `no_unused_imports`, `ordered_imports` and `binary_operator_spaces`. |
| **Consequence** | The style gate fails, and the next Pint run rewrites large parts of the files, creating review noise. |
| **Reproduce** | `vendor\bin\pint --test <file> --format agent` on each of the three files. |
| **Fix approach** | Run Pint on the three files after the functional edits. The controller After in CSCA-01 is already Pint-clean. |
| **Plan item** | CSCA-16 in `02-fix-plan.md` §8 |

```php
// CostCategory.php:7-9 — CURRENT imports
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
```

**Evidence**
```
> vendor\bin\pint --test "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\CostCategoryController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]}]}

> vendor\bin\pint --test "Modules\Accounting\app\Http\Requests\CostCategoryRequest.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\CostCategoryRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}

> vendor\bin\pint --test "Modules\Accounting\app\Models\CostCategory.php" --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\CostCategory.php","fixers":["no_unused_imports","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 Wrong data? | Q2 Delete before replacement? | Q3 Duplicate implementation? | Q4 Soft-delete × unique? | Q5 Race? | Q6 Auth hole? | Q7 Message lies? | Q8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | CSCA-17 | ok | ok | CSCA-08 | CSCA-06 | CSCA-07 | CSCA-17 | CSCA-17 |
| `update` | CSCA-09, CSCA-19 | ok | CSCA-17 | CSCA-08 | ok | CSCA-07 | ok | CSCA-17 |
| `destroy` | CSCA-18 | ok | ok | ok | ok | ok | ok | CSCA-18 |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `reorder` | ok | ok | CSCA-17 | ok | CSCA-06 | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | CSCA-18 | ok | ok | ok | ok | ok | ok | CSCA-18 |

#### CSCA-17 · M · F13-Q8 — The create form's Display Order is ignored, while edit and reorder both write it

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q8 (M) — *dead feature: a saved control that no consumer honours*; Q3 duplicate implementation |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:35-36, 84, 177-178`; `Modules/Accounting/resources/views/cost-category/create.blade.php:55-64` |
| **Root cause** | `store()` always overwrites the submitted value with `max('ordinal') + 1`, so the create form's Ordinal control is discarded. `update()` honours the same field, and `reorder()` overwrites it again, so three code paths disagree about who owns the value. |
| **Consequence** | A user who sets Display Order to 1 on the create page gets a category appended at the end; the value they typed is not what is saved. |
| **Reproduce** | Create a category with Ordinal `1` while six categories exist; reopen it and the saved ordinal is `7`. |
| **Fix approach** | In `store()`, keep a supplied, non-null ordinal and only compute `max + 1` when the field is absent or empty. CSCA-01 includes the change. |
| **Plan item** | CSCA-01 in `02-fix-plan.md` §1 |

```php
// CostCategoryController.php:35-36 — CURRENT
        $validated = $request->validated();
        $validated['ordinal'] = CostCategory::max('ordinal') + 1;
```

**Evidence**
```
> Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCategoryController.php" -Pattern "ordinal"
36:        $validated['ordinal'] = CostCategory::max('ordinal') + 1;
177:            foreach ($ids as $ordinal => $id) {
178:                CostCategory::where('id', $id)->update(['ordinal' => $ordinal + 1]);

> Select-String -Path "Modules\Accounting\resources\views\cost-category\create.blade.php" -Pattern "ordinal"
56:                                        <x-backend.form.input-text
57:                                            type="number"
58:                                            name="ordinal"
59:                                            id="ordinal"
60:                                            label="Ordinal"
61:                                            placeholder="e.g. 1"
62:                                            required="false"
63:                                            value="{{ old('ordinal') }}"
64:                                        />
```

#### CSCA-18 · M · F13-Q1 — A referenced category can be trashed or force-deleted without a usage check

| Field | Value |
|---|---|
| **Rule** | F13 deep-read Q1 (M) — *a write must not orphan data it should not* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CostCategoryController.php:114-116` (`destroy()`), `:234-236` (`forceDelete()`); references from `acc_cost_centers`, `acc_voucher_item_cost_centers`, `acc_expense_claim_lines` |
| **Root cause** | `destroy()` soft-deletes the category without checking references; `forceDelete()` relies on the database `RESTRICT` constraints and therefore fails with a `QueryException` instead of a business message. `CostCategory::selectable()` (`:60-63`) excludes trashed rows, so a trashed category disappears from every picker. |
| **Consequence** | Trashing `Operations & Support Services` (id 2) hides it from the Cost Center category picker while 7 cost centers, 91 voucher allocations and 7 expense-claim lines still point at it; force-deleting that category returns a raw foreign-key error. |
| **Reproduce** | Trash category id 2 from the Cost Categories tab, then open any of its 7 cost centers for edit; the category is missing from the picker although the row still references it. |
| **Fix approach** | Decide whether to block the trash when references exist (safest) or cascade the soft delete; for force-delete, check with `withTrashed()` references first so the user gets a message, not a 500. |
| **Plan item** | CSCA-18 in `02-fix-plan.md` §9 (DECISION) |

```php
// CostCategoryController.php:114-116 — CURRENT
            $costCategory->is_active = false;
            $costCategory->save();
            $costCategory->delete();
```

**Evidence**
```
> mysql -uroot -e "SELECT c.id, c.name, (SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_cost_centers cc WHERE cc.cost_category_id=c.id) AS cost_centers, (SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_voucher_item_cost_centers v WHERE v.cost_category_id=c.id) AS voucher_items, (SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.acc_expense_claim_lines e WHERE e.cost_category_id=c.id) AS claim_lines FROM xyz_school_00000000000040008000_202627.acc_cost_categories c ORDER BY c.ordinal;"
1	Academic Wings & Sections	5	0	0
2	Operations & Support Services	7	91	7
3	Wing	0	0	0
4	Department	0	0	0
5	Activity	0	0	0
6	Project	0	0	0

> mysql -uroot -N -e "SELECT TABLE_NAME, CONSTRAINT_NAME, DELETE_RULE FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA='xyz_school_00000000000040008000_202627' AND REFERENCED_TABLE_NAME='acc_cost_categories';"
acc_cost_centers	fk_acc_cc_category	RESTRICT
acc_expense_claim_lines	fk_acc_ecl_cat	RESTRICT
acc_recurring_template_lines	fk_acc_rtl_cat	SET NULL
acc_voucher_item_cost_centers	fk_fk_acc_vicc_category	RESTRICT
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/GlobalMaster/app/Models/ActivityLog.php:9, 35-47` | The `subject()` and `user()` relationship methods have no return types, and a commented-out factory import remains on line 9. The controller reaches this model through `activityLog()`. | MDL-04, STY-04 | GlobalMaster owner — unclaimed shared model; needs a row in `_Info/00-CLASS-OWNERS.md` |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `final-audit-reports/_tools/selfcheck.py` are missing, and `scan.php` must not be run under the tooling override. F1–F13 were checked manually with `read`, `Select-String`, `php -l`, `route:list` and Pint.
- **No tests run** (D4). No browser render was performed; the five in-scope blades were read, not compiled in a browser.
- **The actual list pane is not in this controller.** `AccDashboardController::setupMasters()` (`Modules/Accounting/app/Http/Controllers/AccDashboardController.php:178-196`) and `pages/partials/setup-masters/_cost-categories.blade.php` render the Cost Categories tab, its filters and its create modal. That is the `AccDashboardController` report's scope. The list there uses `->get()` with no pagination, which is a QRY-02 risk at scale; it is recorded here as context only, not counted in this report.
- **Linked classes were not re-audited.** `BaseAccountingModel` and `AccountingContext` are owned elsewhere; this report checked only how this controller reaches them. `AccountingContext` is not exercised by this model because `CostCategory::$fillable` contains no context columns.
- **No access to a second browser session.** The race in CSCA-06 and the audit gap in CSCA-05 are proven statically (the code shape) rather than by two concurrent requests.
