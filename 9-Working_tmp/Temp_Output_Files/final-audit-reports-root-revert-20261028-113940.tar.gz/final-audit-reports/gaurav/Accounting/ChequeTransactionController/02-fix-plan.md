# Fix Plan — Accounting / ChequeTransactionController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `↳ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file; only the CHQT-09 decision may touch line 153 |
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php` | owns the actual list page; not this report |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-transactions.blade.php` | owned by `AccDashboardController`; the list/modal is not audited here |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared table component; it already supports method detection |
| `config/permissionslist.php` | permission definitions; no new key is proposed |
| `app/Helpers/activityLog.php` | common helper; no change needed |
| `Modules/Accounting/app/Models/Ledger.php` | owned by `LedgerController` |
| `Modules/Accounting/app/Models/Voucher.php` | owned by `VoucherController` |
| `Modules/Accounting/app/Models/ChequeLeaf.php` | owned by `ChequeLeafController` |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by `AccountingStatusMasterController` |
| `Modules/Accounting/app/Models/VoucherBankDetail.php` | unclaimed in `_Info/00-CLASS-OWNERS.md`; read-only usage |
| `Modules/SchoolSetup/app/Models/User.php` | unclaimed; only the `actionedBy` relation reads it |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md` and `final-audit-reports/gaurav/Accounting/00-INDEX.md` | registry/index; never edited by the fixer |

## 1. Blockers reachable today

- [ ] **CHQT-14** · B · MDL-07 · `Modules/Accounting/app/Models/ChequeTransaction.php:8-10` — stop Eloquent writing the missing `updated_at` column.
  - **Touches:** `Modules/Accounting/app/Models/ChequeTransaction.php`
  - **Before** (`ChequeTransaction.php:8-10`):
    ```php
    class ChequeTransaction extends BaseAccountingModel
    {
        protected $table = 'acc_cheque_transactions';
    ```
  - **After:**
    ```php
    class ChequeTransaction extends BaseAccountingModel
    {
        public const UPDATED_AT = null;

        protected $table = 'acc_cheque_transactions';
    ```
  - **Verify:** `php artisan tinker --execute="echo (new Modules\Accounting\Models\ChequeTransaction())->getUpdatedAtColumn() ?? 'null';"`
  - **Expect:** `null`.
  - **Effort:** S

- [ ] **CHQT-01** · B · ERR-01/TXN-02 · `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:45-291` — replace all six manual transaction/catch blocks with `DB::transaction`, drop the raw exception text, and keep the cheque leaf in sync. Also clears CHQT-02, CHQT-03, CHQT-04 and CHQT-20.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Before** (`ChequeTransactionController.php:7-16`, imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Modules\Accounting\Http\Requests\ChequeTransactionRequest;
    use Modules\Accounting\Models\ChequeLeaf;
    use Modules\Accounting\Models\ChequeTransaction;
    use Modules\Accounting\Models\Ledger;
    use Modules\Accounting\Models\Voucher;
    ```
  - **After** (imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\ValidationException;
    use Modules\Accounting\Http\Requests\ChequeTransactionRequest;
    use Modules\Accounting\Models\ChequeLeaf;
    use Modules\Accounting\Models\ChequeTransaction;
    use Modules\Accounting\Models\Ledger;
    use Modules\Accounting\Models\Voucher;
    ```
  - **Before** (`ChequeTransactionController.php:39-80`, `store`):
    ```php
    public function store(ChequeTransactionRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            if (empty($validated['stale_on']) && !empty($validated['instrument_date'])) {
                $validated['stale_on'] = date('Y-m-d', strtotime($validated['instrument_date'] . ' +3 months'));
            }
            $validated['actioned_by'] = auth()->id();

            $txn = ChequeTransaction::create($validated);

            // If leaf is assigned, update leaf status to Issued
            if (!empty($validated['cheque_leaf_id'])) {
                ChequeLeaf::where('id', $validated['cheque_leaf_id'])->update([
                    'status'      => 'Issued',
                    'voucher_id'  => $validated['voucher_id'],
                    'issued_date' => $validated['instrument_date'],
                ]);
            }

            activityLog($txn, 'Created', [
                'message'       => 'Cheque transaction recorded: ' . $txn->instrument_no . ' (' . $txn->status . ')',
                'instrument_no' => $txn->instrument_no,
                'status'        => $txn->status,
                'performed_by'  => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
                ->with('success', 'Cheque transaction recorded successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cheque Transaction', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to record Cheque Transaction: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`store`):
    ```php
    public function store(ChequeTransactionRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.create');

        $validated = $request->validated();

        DB::transaction(function () use ($validated) {
            if (empty($validated['stale_on']) && ! empty($validated['instrument_date'])) {
                $validated['stale_on'] = date('Y-m-d', strtotime($validated['instrument_date'] . ' +3 months'));
            }
            $validated['actioned_by'] = auth()->id();

            $txn = ChequeTransaction::create($validated);

            if (! empty($validated['cheque_leaf_id']) && $txn->direction === 'Issued') {
                ChequeLeaf::where('id', $validated['cheque_leaf_id'])->update([
                    'status'      => 'Issued',
                    'voucher_id'  => $validated['voucher_id'],
                    'issued_date' => $validated['instrument_date'],
                ]);
            }

            activityLog($txn, 'Created', [
                'message'       => 'Cheque transaction recorded: ' . $txn->instrument_no . ' (' . $txn->status . ')',
                'instrument_no' => $txn->instrument_no,
                'status'        => $txn->status,
                'performed_by'  => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
            ->with('success', 'Cheque transaction recorded successfully.');
    }
    ```
  - **Before** (`ChequeTransactionController.php:127-153`, `update`):
    ```php
    public function update(ChequeTransactionRequest $request, ChequeTransaction $chequeTransaction)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.update');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $chequeTransaction->update($validated);

            activityLog($chequeTransaction, 'Updated', [
                'message'       => 'Cheque transaction updated: ' . $chequeTransaction->instrument_no,
                'instrument_no' => $chequeTransaction->instrument_no,
                'performed_by'  => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
                ->with('success', 'Cheque transaction updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to update Cheque Transaction: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`update`):
    ```php
    public function update(ChequeTransactionRequest $request, ChequeTransaction $chequeTransaction)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.update');

        $validated = $request->validated();
        $oldLeafId = $chequeTransaction->cheque_leaf_id;

        DB::transaction(function () use ($chequeTransaction, $validated, $oldLeafId) {
            $chequeTransaction->update($validated);

            $newLeafId = $chequeTransaction->cheque_leaf_id;

            if ($oldLeafId && (int) $oldLeafId !== (int) $newLeafId) {
                ChequeLeaf::where('id', $oldLeafId)->update([
                    'status'      => 'Unused',
                    'voucher_id'  => null,
                    'issued_date' => null,
                ]);
            }

            if ($newLeafId && (int) $newLeafId !== (int) $oldLeafId && $chequeTransaction->direction === 'Issued') {
                ChequeLeaf::where('id', $newLeafId)->update([
                    'status'      => 'Issued',
                    'voucher_id'  => $chequeTransaction->voucher_id,
                    'issued_date' => $chequeTransaction->instrument_date?->toDateString(),
                ]);
            }

            activityLog($chequeTransaction, 'Updated', [
                'message'       => 'Cheque transaction updated: ' . $chequeTransaction->instrument_no,
                'instrument_no' => $chequeTransaction->instrument_no,
                'performed_by'  => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
            ->with('success', 'Cheque transaction updated successfully.');
    }
    ```
  - **Before** (`ChequeTransactionController.php:155-180`, `destroy`):
    ```php
    public function destroy(ChequeTransaction $chequeTransaction)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.delete');

        DB::beginTransaction();
        try {
            $instNo = $chequeTransaction->instrument_no;
            $chequeTransaction->delete();

            activityLog($chequeTransaction, 'Deleted', [
                'message'       => 'Cheque transaction deleted: ' . $instNo,
                'instrument_no' => $instNo,
                'performed_by'  => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
                ->with('success', 'Cheque transaction deleted successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cheque Transaction: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`destroy`):
    ```php
    public function destroy(ChequeTransaction $chequeTransaction)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.delete');

        $instNo = $chequeTransaction->instrument_no;

        DB::transaction(function () use ($chequeTransaction, $instNo) {
            $chequeTransaction->delete();

            activityLog($chequeTransaction, 'Deleted', [
                'message'       => 'Cheque transaction deleted: ' . $instNo,
                'instrument_no' => $instNo,
                'performed_by'  => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
            ->with('success', 'Cheque transaction deleted successfully.');
    }
    ```
  - **Before** (`ChequeTransactionController.php:182-230`, `transition`):
    ```php
    public function transition(Request $request, ChequeTransaction $chequeTransaction)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.update');

        $request->validate([
            'status'                 => 'required|in:Issued,Presented,Cleared,Bounced,Stopped,Cancelled,Stale',
            'status_date'            => 'required|date',
            'status_note'            => 'nullable|string|max:500',
            'bounce_reason'          => 'required_if:status,Bounced|nullable|string|max:255',
            'bounce_charge_amount'   => 'nullable|numeric|min:0',
            'reversal_voucher_id'    => 'nullable|exists:acc_vouchers,id',
            'charge_voucher_id'      => 'nullable|exists:acc_vouchers,id',
            'replacement_voucher_id' => 'nullable|exists:acc_vouchers,id',
        ]);

        DB::beginTransaction();
        try {
            // Append a new status history record as per append-only lifecycle design (BR-CHEQUE-06)
            $newTxn = $chequeTransaction->replicate();
            $newTxn->status                 = $request->input('status');
            $newTxn->status_date            = $request->input('status_date');
            $newTxn->status_note            = $request->input('status_note');
            $newTxn->bounce_reason          = $request->input('bounce_reason');
            $newTxn->bounce_charge_amount   = $request->input('bounce_charge_amount');
            $newTxn->reversal_voucher_id    = $request->input('reversal_voucher_id');
            $newTxn->charge_voucher_id      = $request->input('charge_voucher_id');
            $newTxn->replacement_voucher_id = $request->input('replacement_voucher_id');
            $newTxn->actioned_by            = auth()->id();
            $newTxn->created_at             = now();
            $newTxn->save();

            activityLog($newTxn, 'StatusTransition', [
                'message'       => 'Cheque status transitioned to ' . $newTxn->status . ' for instrument ' . $newTxn->instrument_no,
                'instrument_no' => $newTxn->instrument_no,
                'status'        => $newTxn->status,
                'performed_by'  => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
                ->with('success', 'Cheque status transitioned to ' . $newTxn->status . ' successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to transition Cheque Transaction', ['id' => $chequeTransaction->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to transition Cheque status: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`transition`):
    ```php
    public function transition(Request $request, ChequeTransaction $chequeTransaction)
    {
        Gate::authorize('tenant.accounting.cheque-transaction.update');

        $validated = $request->validate([
            'status'                 => 'required|in:Issued,Presented,Cleared,Bounced,Stopped,Cancelled,Stale',
            'status_date'            => 'required|date',
            'status_note'            => 'nullable|string|max:500',
            'bounce_reason'          => 'required_if:status,Bounced|nullable|string|max:255',
            'bounce_charge_amount'   => 'nullable|numeric|min:0',
            'reversal_voucher_id'    => 'nullable|exists:acc_vouchers,id',
            'charge_voucher_id'      => 'nullable|exists:acc_vouchers,id',
            'replacement_voucher_id' => 'nullable|exists:acc_vouchers,id',
        ]);

        DB::transaction(function () use ($chequeTransaction, $validated) {
            $alreadyRecorded = ChequeTransaction::withTrashed()
                ->where('voucher_id', $chequeTransaction->voucher_id)
                ->where('instrument_no', $chequeTransaction->instrument_no)
                ->where('status', $validated['status'])
                ->where('status_date', $validated['status_date'])
                ->exists();

            if ($alreadyRecorded) {
                throw ValidationException::withMessages([
                    'status' => 'This status is already recorded for this cheque on that date.',
                ]);
            }

            // Append a new status history record as per append-only lifecycle design (BR-CHEQUE-06)
            $newTxn = $chequeTransaction->replicate();
            $newTxn->status                 = $validated['status'];
            $newTxn->status_date            = $validated['status_date'];
            $newTxn->status_note            = $validated['status_note'] ?? null;
            $newTxn->bounce_reason          = $validated['bounce_reason'] ?? null;
            $newTxn->bounce_charge_amount   = $validated['bounce_charge_amount'] ?? null;
            $newTxn->reversal_voucher_id    = $validated['reversal_voucher_id'] ?? null;
            $newTxn->charge_voucher_id      = $validated['charge_voucher_id'] ?? null;
            $newTxn->replacement_voucher_id = $validated['replacement_voucher_id'] ?? null;
            $newTxn->actioned_by            = auth()->id();
            $newTxn->created_at             = now();
            $newTxn->save();

            activityLog($newTxn, 'StatusTransition', [
                'message'       => 'Cheque status transitioned to ' . $newTxn->status . ' for instrument ' . $newTxn->instrument_no,
                'instrument_no' => $newTxn->instrument_no,
                'status'        => $newTxn->status,
                'performed_by'  => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.chequesReconciliation', ['tab' => 'cheque-transactions'])
            ->with('success', 'Cheque status transitioned to ' . $validated['status'] . ' successfully.');
    }
    ```
  - **Before** (`ChequeTransactionController.php:241-265`, `restore`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-transaction.restore');

        DB::beginTransaction();
        try {
            $model = ChequeTransaction::onlyTrashed()->findOrFail($id);
            $model->restore();

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Transaction restored: ' . $model->instrument_no,
                'instrument_no'=> $model->instrument_no,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-transaction.trashed')->with('success', 'Cheque Transaction restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Cheque Transaction: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`restore`):
    ```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-transaction.restore');

        $model = ChequeTransaction::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();

            activityLog($model, 'Restored', [
                'message'       => 'Cheque Transaction restored: ' . $model->instrument_no,
                'instrument_no' => $model->instrument_no,
                'performed_by'  => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cheque-transaction.trashed')->with('success', 'Cheque Transaction restored successfully.');
    }
    ```
  - **Before** (`ChequeTransactionController.php:267-292`, `forceDelete`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-transaction.forceDelete');

        DB::beginTransaction();
        try {
            $model = ChequeTransaction::withTrashed()->findOrFail($id);
            $instNo = $model->instrument_no;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Transaction permanently deleted: ' . $instNo,
                'instrument_no'=> $instNo,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cheque-transaction.trashed')->with('success', 'Cheque Transaction permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Cheque Transaction', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cheque Transaction: ' . $e->getMessage());
        }
    }
    ```
  - **After** (`forceDelete`):
    ```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-transaction.forceDelete');

        $model = ChequeTransaction::withTrashed()->findOrFail($id);
        $instNo = $model->instrument_no;

        DB::transaction(function () use ($model, $instNo) {
            if ($model->cheque_leaf_id) {
                ChequeLeaf::where('id', $model->cheque_leaf_id)->update([
                    'status'      => 'Unused',
                    'voucher_id'  => null,
                    'issued_date' => null,
                ]);
            }

            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'       => 'Cheque Transaction permanently deleted: ' . $instNo,
                'instrument_no' => $instNo,
                'performed_by'  => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cheque-transaction.trashed')->with('success', 'Cheque Transaction permanently deleted.');
    }
    ```
  - **Verify:** `grep -n "DB::beginTransaction\|DB::commit\|DB::rollBack\|getMessage()\|Log::error" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Expect:** no output.
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

- [ ] **CHQT-07** · H · VAL-04/VAL-07 · `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php:39-66` — reject a duplicate append-only state and validate the leaf/date cross-field rules. Also clears CHQT-08 for store and update.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php`
  - **Before** (`ChequeTransactionRequest.php:7-8`, imports):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After** (imports):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Validation\Rule;
    use Illuminate\Validation\Validator;
    use Modules\Accounting\Models\ChequeLeaf;
    ```
  - **Before** (`ChequeTransactionRequest.php:39-66`, rules):
    ```php
    public function rules(): array
    {
        return [
            'voucher_id'             => 'required|exists:acc_vouchers,id',
            'voucher_bank_detail_id' => 'nullable|exists:acc_voucher_bank_details,id',
            'bank_ledger_id'         => 'required|exists:acc_ledgers,id',
            'party_ledger_id'        => 'nullable|exists:acc_ledgers,id',
            'direction'              => 'required|in:Issued,Received,Outward,Inward',
            'cheque_leaf_id'         => 'nullable|exists:acc_cheque_leaves,id',
            'instrument_no'          => 'required|string|max:50',
            'instrument_date'        => 'required|date',
            'amount'                 => 'required|numeric|min:0.01',
            'favouring_name'         => 'nullable|string|max:200',
            'counterparty_bank'      => 'nullable|string|max:150',
            'status'                 => 'required|in:Issued,Presented,Cleared,Bounced,Stopped,Cancelled,Stale',
            'status_date'            => 'required|date',
            'status_note'            => 'nullable|string|max:500',
            'is_post_dated'          => 'nullable|boolean',
            'stale_on'               => 'nullable|date',
            'bounce_reason'          => 'required_if:status,Bounced|nullable|string|max:255',
            'bounce_charge_amount'   => 'nullable|numeric|min:0',
            'reversal_voucher_id'    => 'nullable|exists:acc_vouchers,id',
            'charge_voucher_id'      => 'nullable|exists:acc_vouchers,id',
            'replacement_voucher_id' => 'nullable|exists:acc_vouchers,id',
            'actioned_by'            => 'nullable|exists:sys_users,id',
            'is_active'              => 'nullable|boolean',
        ];
    }
    ```
  - **After** (rules plus `after()`):
    ```php
    public function rules(): array
    {
        return [
            'voucher_id'             => 'required|exists:acc_vouchers,id',
            'voucher_bank_detail_id' => 'nullable|exists:acc_voucher_bank_details,id',
            'bank_ledger_id'         => 'required|exists:acc_ledgers,id',
            'party_ledger_id'        => 'nullable|exists:acc_ledgers,id',
            'direction'              => 'required|in:Issued,Received,Outward,Inward',
            'cheque_leaf_id'         => 'nullable|exists:acc_cheque_leaves,id',
            'instrument_no'          => [
                'required',
                'string',
                'max:50',
                Rule::unique('acc_cheque_transactions', 'instrument_no')
                    ->where(fn ($query) => $query
                        ->where('voucher_id', $this->input('voucher_id'))
                        ->where('status', $this->input('status'))
                        ->where('status_date', $this->input('status_date')))
                    ->ignore($this->route('cheque_transaction')?->getKey()),
            ],
            'instrument_date'        => 'required|date',
            'amount'                 => 'required|numeric|min:0.01',
            'favouring_name'         => 'nullable|string|max:200',
            'counterparty_bank'      => 'nullable|string|max:150',
            'status'                 => 'required|in:Issued,Presented,Cleared,Bounced,Stopped,Cancelled,Stale',
            'status_date'            => 'required|date',
            'status_note'            => 'nullable|string|max:500',
            'is_post_dated'          => 'nullable|boolean',
            'stale_on'               => 'nullable|date',
            'bounce_reason'          => 'required_if:status,Bounced|nullable|string|max:255',
            'bounce_charge_amount'   => 'nullable|numeric|min:0',
            'reversal_voucher_id'    => 'nullable|exists:acc_vouchers,id',
            'charge_voucher_id'      => 'nullable|exists:acc_vouchers,id',
            'replacement_voucher_id' => 'nullable|exists:acc_vouchers,id',
            'actioned_by'            => 'nullable|exists:sys_users,id',
            'is_active'              => 'nullable|boolean',
        ];
    }

    public function after(): array
    {
        return [
            function (Validator $validator): void {
                $leafId = $this->input('cheque_leaf_id');

                if ($leafId !== null && $leafId !== '') {
                    $leaf = ChequeLeaf::find($leafId);

                    if ($leaf !== null) {
                        if ((int) $leaf->bank_ledger_id !== (int) $this->input('bank_ledger_id')) {
                            $validator->errors()->add('cheque_leaf_id', 'The cheque leaf does not belong to the selected bank ledger.');
                        }

                        $currentLeafId = $this->route('cheque_transaction')?->cheque_leaf_id;
                        if ($leaf->status !== 'Unused' && (int) $leaf->id !== (int) $currentLeafId) {
                            $validator->errors()->add('cheque_leaf_id', 'The selected cheque leaf is not available.');
                        }
                    }

                    if ($this->input('direction') === 'Received') {
                        $validator->errors()->add('cheque_leaf_id', 'A received cheque cannot use one of your cheque leaves.');
                    }
                }

                if ($this->filled('stale_on') && $this->filled('instrument_date')
                    && $this->input('stale_on') < $this->input('instrument_date')) {
                    $validator->errors()->add('stale_on', 'The stale date cannot be before the instrument date.');
                }
            },
        ];
    }
    ```
  - **Verify:** `php -l Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php`
  - **Expect:** `No syntax errors detected`.
  - **Effort:** M

## 3. Errors & transactions (F1/F2)

None. CHQT-01 in §1 rewrites all six writers and clears CHQT-02, CHQT-03 and CHQT-04 (no try/catch, no manual transaction, no `getMessage()`, handler logs the exception).

## 4. Authorization (F3)

- [ ] **CHQT-05** · L · AUTH-04 · `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:41,129` — remove the controller Gate calls that duplicate `ChequeTransactionRequest::authorize()`.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Before** (`ChequeTransactionController.php:41` and `:129`):
    ```php
    Gate::authorize('tenant.accounting.cheque-transaction.create');
    ```
    ```php
    Gate::authorize('tenant.accounting.cheque-transaction.update');
    ```
  - **After:** delete both lines. `store()` and `update()` start directly with `$validated = $request->validated();` (the request already authorizes and runs before the controller).
  - **Verify:** `grep -n "Gate::authorize" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Expect:** 9 lines (index, create, show, edit, destroy, transition, trashed, restore, forceDelete); no `create`/`update` line inside store/update.
  - **Effort:** S

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **CHQT-11** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:20-267` — add return types and import the two response classes.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Before** (`ChequeTransactionController.php:7-10`, imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After** (imports):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    ```
  - **Before** (`ChequeTransactionController.php:20,27,39,82,101,127,155,182`):
    ```php
    public function index()
    public function create()
    public function store(ChequeTransactionRequest $request)
    public function show(ChequeTransaction $chequeTransaction)
    public function edit(ChequeTransaction $chequeTransaction)
    public function update(ChequeTransactionRequest $request, ChequeTransaction $chequeTransaction)
    public function destroy(ChequeTransaction $chequeTransaction)
    public function transition(Request $request, ChequeTransaction $chequeTransaction)
    ```
  - **After:**
    ```php
    public function index(): RedirectResponse
    public function create(): View
    public function store(ChequeTransactionRequest $request): RedirectResponse
    public function show(ChequeTransaction $chequeTransaction): View
    public function edit(ChequeTransaction $chequeTransaction): View
    public function update(ChequeTransactionRequest $request, ChequeTransaction $chequeTransaction): RedirectResponse
    public function destroy(ChequeTransaction $chequeTransaction): RedirectResponse
    public function transition(Request $request, ChequeTransaction $chequeTransaction): RedirectResponse
    ```
  - **Before** (`ChequeTransactionController.php:232,241,267`):
    ```php
    public function trashed(): \Illuminate\View\View
    public function restore($id): \Illuminate\Http\RedirectResponse
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    ```
  - **After:**
    ```php
    public function trashed(): View
    public function restore($id): RedirectResponse
    public function forceDelete($id): RedirectResponse
    ```
  - **Verify:** `grep -n "public function" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Expect:** every public method line ends with a return type.
  - **Effort:** S

- [ ] **CHQT-15** · L · MDL-04 · `Modules/Accounting/app/Models/ChequeTransaction.php:48-91` — add `: BelongsTo` to the nine relations.
  - **Touches:** `Modules/Accounting/app/Models/ChequeTransaction.php`
  - **Before** (`ChequeTransaction.php:5-9`, imports/class):
    ```php
    namespace Modules\Accounting\Models;

    use App\Models\BaseModel;
    class ChequeTransaction extends BaseAccountingModel
    {
    ```
  - **After** (imports/class):
    ```php
    namespace Modules\Accounting\Models;

    use Illuminate\Database\Eloquent\Relations\BelongsTo;

    class ChequeTransaction extends BaseAccountingModel
    {
    ```
  - **Before** (`ChequeTransaction.php:48,53,58,63,68,73,78,83,88`):
    ```php
    public function voucher()
    public function voucherBankDetail()
    public function bankLedger()
    public function partyLedger()
    public function chequeLeaf()
    public function reversalVoucher()
    public function chargeVoucher()
    public function replacementVoucher()
    public function actionedBy()
    ```
  - **After:**
    ```php
    public function voucher(): BelongsTo
    public function voucherBankDetail(): BelongsTo
    public function bankLedger(): BelongsTo
    public function partyLedger(): BelongsTo
    public function chequeLeaf(): BelongsTo
    public function reversalVoucher(): BelongsTo
    public function chargeVoucher(): BelongsTo
    public function replacementVoucher(): BelongsTo
    public function actionedBy(): BelongsTo
    ```
  - **Verify:** `grep -n "public function .*BelongsTo" Modules/Accounting/app/Models/ChequeTransaction.php`
  - **Expect:** 9 lines.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **CHQT-12** · M · CTL-05/QRY-15/VIEW-02 · `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:31-36,116-124` — one bounded, eager-loaded form loader for create and edit. Also clears CHQT-16 and CHQT-18.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Before** (`ChequeTransactionController.php:31-36`, `create` body):
    ```php
            $bankLedgers  = Ledger::selectableBankAccounts();
            $partyLedgers = Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get();
            $vouchers     = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
            $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orderBy('leaf_no')->get();

            return view('accounting::cheque-transaction.create', compact('bankLedgers', 'partyLedgers', 'vouchers', 'unusedLeaves'));
    ```
  - **After** (`create` body):
    ```php
            return view('accounting::cheque-transaction.create', $this->formData());
    ```
  - **Before** (`ChequeTransactionController.php:116-124`, `edit` body):
    ```php
            $bankLedgers  = Ledger::selectableBankAccounts();
            $partyLedgers = Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get();
            $vouchers     = Voucher::where('status', 'Posted')->orderByDesc('voucher_date')->take(100)->get();
            $unusedLeaves = ChequeLeaf::where('status', 'Unused')->orWhere('id', $chequeTransaction->cheque_leaf_id)->orderBy('leaf_no')->get();
            $voucherBankDetails = \Modules\Accounting\Models\VoucherBankDetail::where('bank_ledger_id', $chequeTransaction->bank_ledger_id)
                ->orWhere('id', $chequeTransaction->voucher_bank_detail_id)
                ->take(100)->get();

            return view('accounting::cheque-transaction.edit', compact('chequeTransaction', 'bankLedgers', 'partyLedgers', 'vouchers', 'unusedLeaves', 'voucherBankDetails'));
    ```
  - **After** (`edit` body):
    ```php
            $data = $this->formData($chequeTransaction);
            $data['chequeTransaction'] = $chequeTransaction;

            return view('accounting::cheque-transaction.edit', $data);
    ```
  - **After** (new private method, add before `trashed()`):
    ```php
    private function formData(?ChequeTransaction $chequeTransaction = null): array
    {
        return [
            'bankLedgers'  => Ledger::selectableBankAccounts(),
            'partyLedgers' => Ledger::where('ledger_type', 'Party')->orWhereNotNull('party_type')->orderBy('name')->get(['id', 'name']),
            'vouchers'     => Voucher::with('voucherType:id,name')
                ->where('status', 'Posted')
                ->orderByDesc('voucher_date')
                ->take(100)
                ->get(['id', 'voucher_number', 'voucher_type_id', 'total_amount']),
            'unusedLeaves' => ChequeLeaf::with('bankLedger:id,name')
                ->where('status', 'Unused')
                ->when($chequeTransaction?->cheque_leaf_id, fn ($query, $leafId) => $query->orWhere('id', $leafId))
                ->orderBy('leaf_no')
                ->get(['id', 'leaf_no', 'bank_ledger_id']),
            'voucherBankDetails' => $chequeTransaction
                ? \Modules\Accounting\Models\VoucherBankDetail::with('voucher:id,voucher_number')
                    ->where('bank_ledger_id', $chequeTransaction->bank_ledger_id)
                    ->orWhere('id', $chequeTransaction->voucher_bank_detail_id)
                    ->take(100)
                    ->get(['id', 'voucher_id', 'transaction_type', 'instrument_no', 'bank_ledger_id'])
                : collect(),
        ];
    }
    ```
  - **Verify:** `grep -n "formData\|ChequeLeaf::with\|Voucher::with" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Expect:** `formData` defined once and called twice; both eager-load calls present.
  - **Effort:** M

- [ ] **CHQT-17** · L · QRY-02 · `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php:236` — paginate the trash at the house size of 10.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Before** (`ChequeTransactionController.php:236`):
    ```php
            $transactions = ChequeTransaction::onlyTrashed()->with(['bankLedger', 'partyLedger'])->orderByDesc('instrument_date')->paginate(15);
    ```
  - **After:**
    ```php
            $transactions = ChequeTransaction::onlyTrashed()->with(['bankLedger', 'partyLedger'])->orderByDesc('instrument_date')->paginate(10);
    ```
  - **Verify:** `grep -n "paginate(10)" Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Expect:** one match on the trash query.
  - **Effort:** S

## 7. Views (F10)

- [ ] **CHQT-21** · M · F13 #7 · `Modules/Accounting/resources/views/cheque-transaction/show.blade.php:15-19` — compare against the stored `Issued` value, not the discarded `Outward` value.
  - **Touches:** `Modules/Accounting/resources/views/cheque-transaction/show.blade.php`
  - **Before** (`show.blade.php:15-19`):
    ```blade
                                @if($chequeTransaction->direction === 'Outward')
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Outward</span>
                                @else
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">Inward</span>
                                @endif
    ```
  - **After:**
    ```blade
                                @if($chequeTransaction->direction === 'Issued')
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Issued</span>
                                @else
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">Received</span>
                                @endif
    ```
  - **Verify:** `grep -n "direction ===" Modules/Accounting/resources/views/cheque-transaction/show.blade.php`
  - **Expect:** `direction === 'Issued'`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **CHQT-19a** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php` — run Pint on the controller.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php`
  - **Before:**
    ```bash
    vendor/bin/pint --test Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php --format agent
    ```
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ChequeTransactionController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]}]}
    ```
  - **After:**
    ```bash
    vendor/bin/pint Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php --format agent
    ```
    ```json
    {"tool":"pint","result":"pass","files":[]}
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Accounting/app/Http/Controllers/ChequeTransactionController.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **CHQT-19b** · L · STY-02 · `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php` — run Pint on the request.
  - **Touches:** `Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php`
  - **Before:**
    ```bash
    vendor/bin/pint --test Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php --format agent
    ```
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\ChequeTransactionRequest.php","fixers":["binary_operator_spaces"]}]}
    ```
  - **After:**
    ```bash
    vendor/bin/pint Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php --format agent
    ```
    ```json
    {"tool":"pint","result":"pass","files":[]}
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Accounting/app/Http/Requests/ChequeTransactionRequest.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

- [ ] **CHQT-19c** · L · STY-02 · `Modules/Accounting/app/Models/ChequeTransaction.php` — run Pint on the model.
  - **Touches:** `Modules/Accounting/app/Models/ChequeTransaction.php`
  - **Before:**
    ```bash
    vendor/bin/pint --test Modules/Accounting/app/Models/ChequeTransaction.php --format agent
    ```
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\ChequeTransaction.php","fixers":["fully_qualified_strict_types","no_unused_imports","not_operator_with_successor_space","single_line_after_imports","binary_operator_spaces"]}]}
    ```
  - **After:**
    ```bash
    vendor/bin/pint Modules/Accounting/app/Models/ChequeTransaction.php --format agent
    ```
    ```json
    {"tool":"pint","result":"pass","files":[]}
    ```
  - **Verify:** `vendor/bin/pint --test Modules/Accounting/app/Models/ChequeTransaction.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CHQT-06** · M · DECISION · VAL-02 — move the eight transition fields out of `$request->validate()` in the controller?
  - **Why it is a decision:** it adds a class and changes the controller signature, and it overlaps the transition workflow in CHQT-13.
  - (a) ✅ Recommended: add `Modules/Accounting/app/Http/Requests/ChequeTransactionTransitionRequest.php` with `authorize()` returning the `update` gate and the eight rules, then type-hint it in `transition()`.
  - (b) Defer until CHQT-13 extracts a transition service; keep the inline rules meanwhile.
  - (c) Keep the inline rules permanently and document why transition is the exception.
  - ↳ Choice: ____

- [ ] **CHQT-09** · H · DECISION · RTE-01 — change the restore route from GET to DELETE?
  - **Why it is a decision:** it changes a shared route file and the shared trash component's link/form.
  - (a) ✅ Recommended: `Route::delete('/cheque-transaction/{id}/restore', [ChequeTransactionController::class, 'restore'])->name('cheque-transaction.restore');` in `Modules/Accounting/routes/web.php:153` and submit the trash action as DELETE (the shared component already detects the method).
  - (b) Keep GET and accept that prefetch/crawlers can restore a row.
  - (c) Use POST with a CSRF form in `trash.blade.php`.
  - ↳ Choice: ____

- [ ] **CHQT-10** · H · DECISION · RTE-02 — provide the missing create view, or remove the create route?
  - **Why it is a decision:** it adds a Blade file or removes a permission-backed route; either changes what the menu/list modal can do.
  - (a) ✅ Recommended: add `Modules/Accounting/resources/views/cheque-transaction/create.blade.php`, copied from `edit.blade.php` with empty defaults and the same field names.
  - (b) Remove the `create` route and the `create` permission from this controller's flow.
  - (c) Redirect `create()` to the reconciliation tab until the modal form is ready.
  - ↳ Choice: ____

- [ ] **CHQT-13** · M · DECISION · CTL-06 — extract the cheque lifecycle rules into a service?
  - **Why it is a decision:** it is a behavioural refactor of three rules (stale date, leaf issue/release, append-only transition) with no user-visible change.
  - (a) ✅ Recommended: add `Modules/Accounting/app/Services/ChequeTransactionService.php` and move create/transition/leaf sync there; controller keeps HTTP only.
  - (b) Defer until a second caller (import/API) needs the same rules.
  - (c) Keep the rules in the controller and add a comment pointing at `BR-CHEQUE-01` and `BR-CHEQUE-06`.
  - ↳ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CHQT-02 | Fixed by CHQT-01: the model is resolved before `DB::transaction`, and the catch that converted 404 into a redirect is removed. |
| CHQT-03 | Fixed by CHQT-01: all six writers use `DB::transaction`. |
| CHQT-04 | Fixed by CHQT-01: no catch means the framework handler records the exception with its trace. |
| CHQT-08 | Fixed for store/update by CHQT-07's `Rule::unique`; fixed for transition by CHQT-01's `withTrashed()` duplicate guard. If CHQT-06 later creates a transition request, copy the same rule there. |
| CHQT-16 | Fixed by CHQT-12's bounded, selected-column loader. |
| CHQT-18 | Fixed by CHQT-12's `with('voucherType')`, `with('bankLedger')`, and `with('voucher')` eager loads. |
| CHQT-20 | Fixed by CHQT-01: leaves are claimed only for `Issued`, released on update/force-delete, and never claimed for `Received`. |
