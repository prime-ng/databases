# Fix Plan — Accounting / DepreciationEntryController

**From:** `01-report.md` (2026-10-24) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

**Suggested order:** §1 → §3 → §5 → §6 → §7 → §8, then the ticked §9 decisions (they sit last because DPRE-09 edits code introduced by DPRE-03, DPRE-10 edits code introduced by DPRE-05, DPRE-15 edits code introduced by DPRE-06/08, and DPRE-17 edits code introduced by DPRE-05/07). §2 and §4 are empty on purpose.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/app/Models/FixedAsset.php` | Owned by `gaurav/Accounting/FixedAssetController`; its `SUM` accessors are recorded there. DPRE-23 avoids them from the controller instead of editing the model. |
| `Modules/Accounting/app/Models/AssetCategory.php` | Owned by `gaurav/Accounting/AssetCategoryController`. |
| `Modules/Accounting/app/Models/FinancialYear.php` | Owned by `gaurav/Accounting/FinancialYearController`. |
| `Modules/Accounting/app/Models/AccountingPeriod.php` | Owned by `gaurav/Accounting/AccountingPeriodController`. |
| `Modules/Accounting/app/Models/Voucher.php`, `VoucherType.php`, `Services/VoucherService.php` | Owned by `gaurav/Accounting/VoucherController` (CLAIMED). Only their public call shape is used here. |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | Owned by `gaurav/Accounting/AccountingStatusMasterController`. |
| `Modules/Accounting/app/Services/AccountingContext.php` | Owned by `gaurav/Accounting/AccountGroupController`. |
| `Modules/Accounting/resources/views/pages/partials/assets-integration/_depreciation-entries.blade.php` | Owned by `gaurav/Accounting/AccDashboardController` (CLAIMED, no report yet). Its `tenant.accounting.depreciation-entry.*` checks depend on DPRE-02 but are not edited here. |
| `Modules/Accounting/resources/views/depreciation-entry/create.blade.php` and `edit.blade.php` | No item edits them except **DPRE-09 option (b)**, which only deletes the amount prefill in `create.blade.php`. |
| Database migrations, `resources/views/components/**`, layouts, `activityLog()` | App-wide common code; no reported defect belongs here. |
| `final-audit-reports/_Info/00-CLASS-OWNERS.md`, `final-audit-reports/gaurav/Accounting/00-INDEX.md` | Registry files. Never edited by a fix run. |
| `Modules/Accounting/routes/web.php`, `config/permissionslist.php`, `Modules/Accounting/app/Providers/AccountingServiceProvider.php` | ⚠ SHARED — each is edited only by its own ticked `⚠ SHARED` item (DPRE-07, DPRE-02, DPRE-13 respectively). |

## 1. Blockers reachable today

- [ ] **DPRE-01** · B · ERR-01 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:19-21, 44-109, 134-156, 158-181` — delete the three `try/catch` blocks, move the `findOrFail()` and the audit row into the right places, and inject `VoucherService`. Closes DPRE-04, DPRE-11, DPRE-12 and DPRE-16.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (`DepreciationEntryController.php:19-21`):
    ```php
    class DepreciationEntryController extends Controller
    {
        public function index(Request $request)
    ```
  - **After** (`DepreciationEntryController.php:19-25`):
    ```php
    class DepreciationEntryController extends Controller
    {
        public function __construct(
            private readonly VoucherService $voucherService,
        ) {}

        public function index(Request $request)
    ```
  - **Before** (`DepreciationEntryController.php:44-109`):
    ```php
        public function store(DepreciationEntryRequest $request)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.create');

            $validated = $request->validated();
            $validated['computed_by'] = auth()->id();
            $validated['is_active'] = $request->boolean('is_active', true);

            try {
                $fixedAsset = FixedAsset::with('assetCategory')->findOrFail($validated['fixed_asset_id']);
                $depreciationAmount = (float) $validated['depreciation_amount'];

                $entry = DB::transaction(function () use ($validated, $fixedAsset, $depreciationAmount, $request) {
                    // Optional: auto-generate voucher if requested and no voucher_id given
                    if (empty($validated['voucher_id']) && $request->boolean('auto_post_voucher')) {
                        $cat = $fixedAsset->assetCategory;
                        if ($cat && $cat->depreciation_expense_ledger_id && ($cat->accum_dep_ledger_id ?? $cat->accumulated_depreciation_ledger_id)) {
                            $accumLedgerId = $cat->accum_dep_ledger_id ?? $cat->accumulated_depreciation_ledger_id;
                            $jrn = VoucherType::where('base_type', 'Journal')->where('is_active', true)->first()
                                ?? VoucherType::where('base_type', 'Journal')->first()
                                ?? VoucherType::where(function ($q) {
                                    $q->whereIn('code', ['JOURNAL', 'JNL', 'JRN'])
                                      ->orWhere('code', 'like', 'JRN%')
                                      ->orWhere('code', 'like', 'JNL%');
                                })->first()
                                ?? VoucherType::where('is_active', true)->first();
                            if ($jrn) {
                                /** @var VoucherService $voucherService */
                                $voucherService = app(VoucherService::class);
                                $voucher = $voucherService->create([
                                    'voucher_type_id'   => $jrn->id,
                                    'financial_year_id' => (int) $validated['financial_year_id'],
                                    'period_id'         => (int) ($validated['period_id'] ?? null),
                                    'voucher_date'      => $validated['depreciation_date'],
                                    'narration'         => "Depreciation for {$fixedAsset->name} [{$fixedAsset->asset_code}]",
                                    'status'            => 'posted',
                                    'is_active'         => true,
                                ], [
                                    ['ledger_id' => $cat->depreciation_expense_ledger_id, 'entry_type' => 'Dr', 'amount' => $depreciationAmount, 'narration' => $fixedAsset->asset_code],
                                    ['ledger_id' => $accumLedgerId,                        'entry_type' => 'Cr', 'amount' => $depreciationAmount, 'narration' => $fixedAsset->asset_code],
                                ]);
                                $validated['voucher_id'] = $voucher->id;
                                $validated['is_posted'] = true;
                            }
                        }
                    }

                    $entry = DepreciationEntry::create($validated);

                    return $entry;
                });

                activityLog($entry, 'Created', [
                    'message'             => 'Depreciation Entry created.',
                    'fixed_asset_id'      => $entry->fixed_asset_id,
                    'depreciation_amount' => $entry->depreciation_amount,
                    'depreciation_date'   => $entry->depreciation_date?->format('Y-m-d'),
                ]);

                return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'depreciation-entries'])
                    ->with('success', "Depreciation Entry for ₹" . number_format((float) $entry->depreciation_amount, 2) . " created successfully.");
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::error('DepreciationEntry create failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
                return back()->with('error', 'Failed to record depreciation entry: ' . $e->getMessage())->withInput();
            }
        }
    ```
  - **After** (`DepreciationEntryController.php:44-101`):
    ```php
        public function store(DepreciationEntryRequest $request)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.create');

            $validated = $request->validated();
            $validated['computed_by'] = auth()->id();

            $fixedAsset = FixedAsset::with('assetCategory')->findOrFail($validated['fixed_asset_id']);
            $depreciationAmount = (float) $validated['depreciation_amount'];

            $entry = DB::transaction(function () use ($validated, $fixedAsset, $depreciationAmount, $request) {
                // Optional: auto-generate voucher if requested and no voucher_id given
                if (empty($validated['voucher_id']) && $request->boolean('auto_post_voucher')) {
                    $cat = $fixedAsset->assetCategory;
                    if ($cat && $cat->depreciation_expense_ledger_id && ($cat->accum_dep_ledger_id ?? $cat->accumulated_depreciation_ledger_id)) {
                        $accumLedgerId = $cat->accum_dep_ledger_id ?? $cat->accumulated_depreciation_ledger_id;
                        $jrn = VoucherType::where('base_type', 'Journal')->where('is_active', true)->first()
                            ?? VoucherType::where('base_type', 'Journal')->first()
                            ?? VoucherType::where(function ($q) {
                                $q->whereIn('code', ['JOURNAL', 'JNL', 'JRN'])
                                  ->orWhere('code', 'like', 'JRN%')
                                  ->orWhere('code', 'like', 'JNL%');
                            })->first()
                            ?? VoucherType::where('is_active', true)->first();
                        if ($jrn) {
                            $voucher = $this->voucherService->create([
                                'voucher_type_id'   => $jrn->id,
                                'financial_year_id' => (int) $validated['financial_year_id'],
                                'period_id'         => (int) ($validated['period_id'] ?? null),
                                'voucher_date'      => $validated['depreciation_date'],
                                'narration'         => "Depreciation for {$fixedAsset->name} [{$fixedAsset->asset_code}]",
                                'status'            => 'posted',
                                'is_active'         => true,
                            ], [
                                ['ledger_id' => $cat->depreciation_expense_ledger_id, 'entry_type' => 'Dr', 'amount' => $depreciationAmount, 'narration' => $fixedAsset->asset_code],
                                ['ledger_id' => $accumLedgerId,                        'entry_type' => 'Cr', 'amount' => $depreciationAmount, 'narration' => $fixedAsset->asset_code],
                            ]);
                            $validated['voucher_id'] = $voucher->id;
                            $validated['is_posted'] = true;
                        }
                    }
                }

                $entry = DepreciationEntry::create($validated);

                activityLog($entry, 'Created', [
                    'message'             => 'Depreciation Entry created.',
                    'fixed_asset_id'      => $entry->fixed_asset_id,
                    'depreciation_amount' => $entry->depreciation_amount,
                    'depreciation_date'   => $entry->depreciation_date?->format('Y-m-d'),
                ]);

                return $entry;
            });

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'depreciation-entries'])
                ->with('success', "Depreciation Entry for ₹" . number_format((float) $entry->depreciation_amount, 2) . " created successfully.");
        }
    ```
  - **Before** (`DepreciationEntryController.php:134-156`):
    ```php
        public function update(DepreciationEntryRequest $request, DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.update');

            $validated = $request->validated();
            $validated['is_active'] = $request->boolean('is_active', true);

            try {
                $depreciationEntry->update($validated);

                activityLog($depreciationEntry, 'Updated', [
                    'message'             => 'Depreciation Entry updated.',
                    'fixed_asset_id'      => $depreciationEntry->fixed_asset_id,
                    'depreciation_amount' => $depreciationEntry->depreciation_amount,
                ]);

                return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'depreciation-entries'])
                    ->with('success', 'Depreciation Entry updated successfully.');
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::error('DepreciationEntry update failed: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
                return back()->with('error', 'Failed to update depreciation entry: ' . $e->getMessage())->withInput();
            }
        }
    ```
  - **After** (`DepreciationEntryController.php:134-152`):
    ```php
        public function update(DepreciationEntryRequest $request, DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.update');

            $validated = $request->validated();

            DB::transaction(function () use ($validated, $depreciationEntry) {
                $depreciationEntry->update($validated);

                activityLog($depreciationEntry, 'Updated', [
                    'message'             => 'Depreciation Entry updated.',
                    'fixed_asset_id'      => $depreciationEntry->fixed_asset_id,
                    'depreciation_amount' => $depreciationEntry->depreciation_amount,
                ]);
            });

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'depreciation-entries'])
                ->with('success', 'Depreciation Entry updated successfully.');
        }
    ```
  - **Before** (`DepreciationEntryController.php:158-181`):
    ```php
        public function destroy(DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.delete');

            $assetId = $depreciationEntry->fixed_asset_id;

            try {
                $depreciationEntry->is_active = false;
                $depreciationEntry->save();
                $depreciationEntry->delete();

                activityLog($depreciationEntry, 'Trashed', [
                    'message'        => 'Depreciation Entry trashed.',
                    'id'             => $depreciationEntry->id,
                    'fixed_asset_id' => $assetId,
                ]);

                return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'depreciation-entries'])
                    ->with('success', 'Depreciation Entry moved to trash.');
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::error('DepreciationEntry delete failed: ' . $e->getMessage());
                return back()->with('error', 'Failed to delete depreciation entry: ' . $e->getMessage());
            }
        }
    ```
  - **After** (`DepreciationEntryController.php:158-178`):
    ```php
        public function destroy(DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.delete');

            $assetId = $depreciationEntry->fixed_asset_id;

            DB::transaction(function () use ($depreciationEntry, $assetId) {
                $depreciationEntry->is_active = false;
                $depreciationEntry->save();
                $depreciationEntry->delete();

                activityLog($depreciationEntry, 'Trashed', [
                    'message'        => 'Depreciation Entry trashed.',
                    'id'             => $depreciationEntry->id,
                    'fixed_asset_id' => $assetId,
                ]);
            });

            return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'depreciation-entries'])
                ->with('success', 'Depreciation Entry moved to trash.');
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "catch \(|getMessage|Log::|app\(VoucherService"`
  - **Expect:** no output (all three catches, all `getMessage()` calls and the `app(VoucherService::class)` call are gone); `php -l` on the file passes.
  - **Effort:** M

- [ ] **DPRE-02** · B · AUTH-01 · `config/permissionslist.php:600-616` — declare the missing `accounting.depreciation-entry` permission key so the screen is more than Super-Admin-only. ⚠ SHARED (permission config)
  - **Touches:** `config/permissionslist.php` (⚠ SHARED), plus the external sync step below. No controller edit.
  - **Why it is a decision:** adding a permission key changes the tenant ACL, needs a sync against every tenant DB, and the grant targets are a policy choice. `_tools/00-RULEBOOK.md` forbids the audit from inventing permission grants.
  - **Before** (`config/permissionslist.php:604-605`):
    ```php
            'accounting.cost-center' => $crud,
            'accounting.event-voucher-config' => $crud,
    ```
  - (a) ⭐ **Recommended — add the key and grant it to the accounting roles.** Insert the key, then run the additive sync and grant the seven new permissions to the roles that already hold `tenant.accounting.fixed-asset.viewAny` (School Admin synced automatically; assign Management, Account Staff, Account Manager in System Config → Roles).
    ```php
            'accounting.cost-center' => $crud,
            'accounting.depreciation-entry' => $crud,
            'accounting.event-voucher-config' => $crud,
    ```
    Then, on the **central** domain as Super Admin, open `http://localhost/system-config/sync-permissions?apply=1` (the route is GET, dry-run without `?apply=1`, and grants only Super Admin + School Admin automatically). Then assign the keys in System Config → Roles for the other three roles.
  - (b) Reuse the existing `tenant.accounting.fixed-asset.*` keys: replace the 11 `Gate::authorize` strings and the `@can` checks in `trash.blade.php`, `show.blade.php` and the claimed dashboard partial. No new key and no sync, but it edits the claimed partial and blurs two resources — **do not tick without a separate written mapping**.
  - (c) Record as accepted: the tab stays Super-Admin-only. No code change.
  - ➜ Choice: ____
  - **Verify:** `mysql -u root -N -e "SELECT COUNT(*) FROM xyz_school_00000000000040008000_202627.sys_permissions WHERE name LIKE 'tenant.accounting.depreciation-entry%';"`
  - **Expect:** `7` after option (a) — `create`, `view`, `viewAny`, `update`, `delete`, `restore`, `forceDelete`. `0` before.
  - **Effort:** M

- [ ] **DPRE-03** · B · AUTH-01 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:244-249` — authorize and validate the preview endpoint. Closes DPRE-14.
  - **Touches:** new `Modules/Accounting/app/Http/Requests/DepreciationPreviewRequest.php`; `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (`DepreciationEntryController.php:244-249`):
    ```php
        public function calculatePreview(Request $request)
        {
            $assetId = (int) $request->input('fixed_asset_id');
            $date = $request->input('date', now()->format('Y-m-d'));

            $asset = FixedAsset::with('assetCategory')->find($assetId);
    ```
  - **Before** (`DepreciationEntryController.php:7-12`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\DepreciationEntryRequest;
    use Modules\Accounting\Models\DepreciationEntry;
    ```
  - **After — new file `Modules/Accounting/app/Http/Requests/DepreciationPreviewRequest.php`:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Accounting\Http\Requests;

    use App\Traits\AuthorizesTenantFeature;
    use Illuminate\Foundation\Http\FormRequest;

    class DepreciationPreviewRequest extends FormRequest
    {
        use AuthorizesTenantFeature;

        public function authorize(): bool
        {
            return $this->authorizeByCrudPermission('tenant.accounting.depreciation-entry', 'view');
        }

        public function rules(): array
        {
            return [
                'fixed_asset_id' => 'required|integer|exists:acc_fixed_assets,id',
                'date'           => 'nullable|date_format:Y-m-d',
            ];
        }

        public function attributes(): array
        {
            return [
                'fixed_asset_id' => 'Fixed Asset',
                'date'           => 'Depreciation Date',
            ];
        }
    }
    ```
  - **After** (`DepreciationEntryController.php:7-13`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Modules\Accounting\Http\Requests\DepreciationEntryRequest;
    use Modules\Accounting\Http\Requests\DepreciationPreviewRequest;
    use Modules\Accounting\Models\DepreciationEntry;
    ```
  - **After** (`DepreciationEntryController.php:244-250`):
    ```php
        public function calculatePreview(DepreciationPreviewRequest $request)
        {
            $validated = $request->validated();
            $assetId = (int) $validated['fixed_asset_id'];
            $date = $validated['date'] ?? now()->format('Y-m-d');

            $asset = FixedAsset::with('assetCategory')->find($assetId);
    ```
  - **Verify:** `Test-Path "Modules\Accounting\app\Http\Requests\DepreciationPreviewRequest.php"; Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "DepreciationPreviewRequest"`
  - **Expect:** `True`, then exactly 2 matches (the `use` line and the `calculatePreview` signature). A tenant user without `tenant.accounting.depreciation-entry.view` now gets 403; `{"fixed_asset_id":1,"date":"not-a-date"}` now gets 422.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None. Every defect in §1 is reachable today by the Super Admin (live data: 5 posted entries, 5 fixed assets), so no fix unmasks a second one, and each item leaves the file valid when applied alone. The only hard dependency is **DPRE-08 → DPRE-01**: DPRE-08's "absent `is_active` means false" only takes effect once DPRE-01 removes the controller's `$request->boolean('is_active', true)` override. §1 runs before §5, so the order is automatic — but do not tick DPRE-08 without DPRE-01.

## 3. Errors & transactions (F1/F2)

- [ ] **DPRE-05** · H · TXN-01 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:183-202, 213-227, 229-242` — wrap `toggleStatus`, `restore` and `forceDelete` in one transaction each. `update` and `destroy` are closed by DPRE-01.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (`DepreciationEntryController.php:183-202`):
    ```php
        public function toggleStatus(Request $request, DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.update');

            $request->validate(['is_active' => 'required|boolean']);

            $depreciationEntry->is_active = $request->input('is_active');
            $depreciationEntry->save();

            activityLog($depreciationEntry, 'Toggled', [
                'message' => 'Depreciation Entry status toggled.',
                'id'      => $depreciationEntry->id,
            ]);

            return response()->json([
                'success'   => true,
                'is_active' => $depreciationEntry->is_active,
                'message'   => 'Status updated.',
            ]);
        }
    ```
  - **After** (`DepreciationEntryController.php:183-204`):
    ```php
        public function toggleStatus(Request $request, DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.update');

            $request->validate(['is_active' => 'required|boolean']);

            DB::transaction(function () use ($request, $depreciationEntry) {
                $depreciationEntry->is_active = $request->input('is_active');
                $depreciationEntry->save();

                activityLog($depreciationEntry, 'Toggled', [
                    'message' => 'Depreciation Entry status toggled.',
                    'id'      => $depreciationEntry->id,
                ]);
            });

            return response()->json([
                'success'   => true,
                'is_active' => $depreciationEntry->is_active,
                'message'   => 'Status updated.',
            ]);
        }
    ```
  - **Before** (`DepreciationEntryController.php:213-227`):
    ```php
        public function restore($id)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.restore');

            $entry = DepreciationEntry::onlyTrashed()->findOrFail($id);
            $entry->restore();
            $entry->update(['is_active' => true]);

            activityLog($entry, 'Restored', [
                'message' => 'Depreciation Entry restored.',
                'id'      => $entry->id,
            ]);

            return redirect()->route('accounting.depreciation-entry.trashed')->with('success', 'Depreciation Entry restored successfully.');
        }
    ```
  - **After** (`DepreciationEntryController.php:213-230`):
    ```php
        public function restore($id)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.restore');

            $entry = DepreciationEntry::onlyTrashed()->findOrFail($id);

            DB::transaction(function () use ($entry) {
                $entry->restore();
                $entry->update(['is_active' => true]);

                activityLog($entry, 'Restored', [
                    'message' => 'Depreciation Entry restored.',
                    'id'      => $entry->id,
                ]);
            });

            return redirect()->route('accounting.depreciation-entry.trashed')->with('success', 'Depreciation Entry restored successfully.');
        }
    ```
  - **Before** (`DepreciationEntryController.php:229-242`):
    ```php
        public function forceDelete($id)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.forceDelete');

            $entry = DepreciationEntry::withTrashed()->findOrFail($id);
            $entry->forceDelete();

            activityLog($entry, 'Deleted', [
                'message' => 'Depreciation Entry permanently deleted.',
                'id'      => $entry->id,
            ]);

            return redirect()->route('accounting.depreciation-entry.trashed')->with('success', 'Depreciation Entry permanently deleted.');
        }
    ```
  - **After** (`DepreciationEntryController.php:229-245`):
    ```php
        public function forceDelete($id)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.forceDelete');

            $entry = DepreciationEntry::withTrashed()->findOrFail($id);

            DB::transaction(function () use ($entry) {
                $entry->forceDelete();

                activityLog($entry, 'Deleted', [
                    'message' => 'Depreciation Entry permanently deleted.',
                    'id'      => $entry->id,
                ]);
            });

            return redirect()->route('accounting.depreciation-entry.trashed')->with('success', 'Depreciation Entry permanently deleted.');
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "DB::transaction" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `6` when DPRE-01 and DPRE-05 are both ticked (store, update, destroy, toggleStatus, restore, forceDelete); `3` when only DPRE-05 is ticked.
  - **Effort:** M

## 4. Authorization (F3)

None of its own. DPRE-02 (the missing permission key) and DPRE-03 (the unguarded preview) are both blockers and live in §1. DPRE-13 (the inert policy) is a decision in §9.

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **DPRE-06** · H · VAL-04 · `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php:20-34` — add the uniqueness rule that mirrors `uq_acc_de_asset_period`, including trashed rows.
  - **Touches:** `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php`
  - **Before** (`DepreciationEntryRequest.php:7-9`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Modules\Accounting\Models\AccountingPeriod;
    use Modules\Accounting\Models\FixedAsset;
    ```
  - **After** (`DepreciationEntryRequest.php:7-10`):
    ```php
    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\Accounting\Models\AccountingPeriod;
    use Modules\Accounting\Models\FixedAsset;
    ```
  - **Before** (`DepreciationEntryRequest.php:20-34`):
    ```php
            return [
                'fixed_asset_id'      => 'required|exists:acc_fixed_assets,id',
                'financial_year_id'   => 'required|exists:acc_financial_years,id',
                'period_id'           => 'required|exists:acc_accounting_periods,id',
                'depreciation_date'   => 'required|date',
                'method'              => 'required|in:SLM,WDV',
                'rate_applied'        => 'required|numeric|min:0|max:100',
                'opening_wdv'         => 'required|numeric|min:0',
                'depreciation_amount' => 'required|numeric|min:0.01',
                'closing_wdv'         => 'required|numeric|min:0',
                'days_in_use'         => 'nullable|integer|min:0|max:366',
                'voucher_id'          => 'nullable|exists:acc_vouchers,id',
                'is_posted'           => 'nullable|boolean',
                'is_active'           => 'required|boolean',
            ];
    ```
  - **After** (`DepreciationEntryRequest.php:20-41`):
    ```php
            return [
                'fixed_asset_id' => [
                    'required',
                    'integer',
                    'exists:acc_fixed_assets,id',
                    Rule::unique('acc_depreciation_entries', 'fixed_asset_id')
                        ->where(fn ($query) => $query->where('period_id', $this->input('period_id')))
                        ->ignore($this->route('depreciation_entry')?->id),
                ],
                'financial_year_id'   => 'required|exists:acc_financial_years,id',
                'period_id'           => 'required|exists:acc_accounting_periods,id',
                'depreciation_date'   => 'required|date',
                'method'              => 'required|in:SLM,WDV',
                'rate_applied'        => 'required|numeric|min:0|max:100',
                'opening_wdv'         => 'required|numeric|min:0',
                'depreciation_amount' => 'required|numeric|min:0.01',
                'closing_wdv'         => 'required|numeric|min:0',
                'days_in_use'         => 'nullable|integer|min:0|max:366',
                'voucher_id'          => 'nullable|exists:acc_vouchers,id',
                'is_posted'           => 'nullable|boolean',
                'is_active'           => 'required|boolean',
            ];
    ```
  - **After — new method, insert between `rules()` and `attributes()`:**
    ```php
        public function messages(): array
        {
            return [
                'fixed_asset_id.unique' => 'A depreciation entry already exists for this asset and accounting period (including trashed entries).',
            ];
        }
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\DepreciationEntryRequest.php" -Pattern "Rule::unique|fixed_asset_id.unique"`
  - **Expect:** 2 matches (the `Rule::unique(...)` call and the `'fixed_asset_id.unique'` message key). Duplicate create now returns 422 instead of a duplicate-key error.
  - **Effort:** S

- [ ] **DPRE-08** · H · VAL-05/VAL-07 · `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php:56-113` — make `prepareForValidation()` update-aware so an edit preserves `method`, `rate_applied`, `opening_wdv`, `days_in_use`, `is_posted` and `voucher_id`. Depends on DPRE-01.
  - **Touches:** `Modules/Accounting/app/Http/Requests/DepreciationEntryRequest.php`
  - **Before** (`DepreciationEntryRequest.php:8-9`):
    ```php
    use Modules\Accounting\Models\AccountingPeriod;
    use Modules\Accounting\Models\FixedAsset;
    ```
  - **After** (`DepreciationEntryRequest.php:8-10`):
    ```php
    use Modules\Accounting\Models\AccountingPeriod;
    use Modules\Accounting\Models\DepreciationEntry;
    use Modules\Accounting\Models\FixedAsset;
    ```
  - **Before** (`DepreciationEntryRequest.php:56-113`):
    ```php
        protected function prepareForValidation(): void
        {
            $fixedAssetId = $this->input('fixed_asset_id');
            $asset = $fixedAssetId ? FixedAsset::with('assetCategory')->find($fixedAssetId) : null;

            $fyId = $this->input('financial_year_id');
            $date = $this->input('depreciation_date') ?: now()->format('Y-m-d');

            $periodId = $this->input('period_id');
            if (!$periodId && $fyId) {
                $matchedPeriod = AccountingPeriod::where('financial_year_id', $fyId)
                    ->where('start_date', '<=', $date)
                    ->where('end_date', '>=', $date)
                    ->first()
                    ?? AccountingPeriod::where('financial_year_id', $fyId)->orderBy('period_number')->first();
                $periodId = $matchedPeriod?->id;
            }

            $method = $this->input('method') ?: ($asset ? ($asset->depreciation_method ?: ($asset->assetCategory?->depreciation_method ?: 'SLM')) : 'SLM');
            if (!in_array($method, ['SLM', 'WDV'])) {
                $method = 'SLM';
            }

            $rateApplied = $this->input('rate_applied');
            if ($rateApplied === null || $rateApplied === '') {
                $rateApplied = $asset ? $asset->getEffectiveDepreciationRate() : 0.0;
            }

            $openingWdv = $this->input('opening_wdv');
            if ($openingWdv === null || $openingWdv === '') {
                if ($asset) {
                    $accumulated = (float) $asset->depreciationEntries()->where('is_posted', true)->sum('depreciation_amount');
                    $openingWdv = max(0.0, (float) $asset->purchase_cost - $accumulated);
                } else {
                    $openingWdv = 0.0;
                }
            }

            $depAmount = $this->input('depreciation_amount') !== null ? (float) $this->input('depreciation_amount') : 0.0;

            $closingWdv = $this->input('closing_wdv');
            if ($closingWdv === null || $closingWdv === '') {
                $salvage = $asset ? (float) ($asset->salvage_value ?? 0) : 0.0;
                $closingWdv = max($salvage, round((float) $openingWdv - $depAmount, 2));
            }

            $this->merge([
                'period_id'           => $periodId,
                'method'              => $method,
                'rate_applied'        => (float) $rateApplied,
                'opening_wdv'         => (float) $openingWdv,
                'closing_wdv'         => (float) $closingWdv,
                'days_in_use'         => $this->input('days_in_use') !== '' && $this->input('days_in_use') !== null ? (int) $this->input('days_in_use') : null,
                'voucher_id'          => $this->input('voucher_id') ?: null,
                'is_posted'           => $this->boolean('is_posted', false),
                'is_active'           => $this->boolean('is_active', true),
            ]);
        }
    ```
  - **After** (`DepreciationEntryRequest.php:56-130`):
    ```php
        protected function prepareForValidation(): void
        {
            $existing = $this->route('depreciation_entry');
            $existing = $existing instanceof DepreciationEntry ? $existing : null;

            $fixedAssetId = $this->input('fixed_asset_id', $existing?->fixed_asset_id);
            $asset = $fixedAssetId ? FixedAsset::with('assetCategory')->find($fixedAssetId) : null;
            $assetChanged = $existing !== null && (int) $existing->fixed_asset_id !== (int) $fixedAssetId;

            $fyId = $this->input('financial_year_id', $existing?->financial_year_id);
            $date = $this->input('depreciation_date')
                ?: ($existing?->depreciation_date?->format('Y-m-d') ?: now()->format('Y-m-d'));

            $periodId = $this->input('period_id');
            if (!$periodId && $fyId) {
                $matchedPeriod = AccountingPeriod::where('financial_year_id', $fyId)
                    ->where('start_date', '<=', $date)
                    ->where('end_date', '>=', $date)
                    ->first()
                    ?? AccountingPeriod::where('financial_year_id', $fyId)->orderBy('period_number')->first();
                $periodId = $matchedPeriod?->id;
            }
            $periodId = $periodId ?: $existing?->period_id;

            $method = $this->input('method')
                ?: (($existing && !$assetChanged)
                    ? $existing->method
                    : ($asset ? ($asset->depreciation_method ?: ($asset->assetCategory?->depreciation_method ?: 'SLM')) : 'SLM'));
            if (!in_array($method, ['SLM', 'WDV'])) {
                $method = 'SLM';
            }

            $rateApplied = $this->input('rate_applied');
            if ($rateApplied === null || $rateApplied === '') {
                $rateApplied = ($existing && !$assetChanged)
                    ? $existing->rate_applied
                    : ($asset ? $asset->getEffectiveDepreciationRate() : 0.0);
            }

            $openingWdv = $this->input('opening_wdv');
            if ($openingWdv === null || $openingWdv === '') {
                if ($existing && !$assetChanged) {
                    $openingWdv = $existing->opening_wdv;
                } elseif ($asset) {
                    $accumulated = (float) $asset->depreciationEntries()->where('is_posted', true)->sum('depreciation_amount');
                    $openingWdv = max(0.0, (float) $asset->purchase_cost - $accumulated);
                } else {
                    $openingWdv = 0.0;
                }
            }

            $depAmount = $this->input('depreciation_amount') !== null
                ? (float) $this->input('depreciation_amount')
                : (float) ($existing?->depreciation_amount ?? 0.0);

            $closingWdv = $this->input('closing_wdv');
            if ($closingWdv === null || $closingWdv === '') {
                $salvage = $asset ? (float) ($asset->salvage_value ?? 0) : 0.0;
                $closingWdv = max($salvage, round((float) $openingWdv - $depAmount, 2));
            }

            $this->merge([
                'period_id'           => $periodId,
                'method'              => $method,
                'rate_applied'        => (float) $rateApplied,
                'opening_wdv'         => (float) $openingWdv,
                'closing_wdv'         => (float) $closingWdv,
                'days_in_use'         => $this->input('days_in_use') !== '' && $this->input('days_in_use') !== null
                    ? (int) $this->input('days_in_use')
                    : $existing?->days_in_use,
                'voucher_id'          => $this->has('voucher_id') ? ($this->input('voucher_id') ?: null) : $existing?->voucher_id,
                'is_posted'           => $this->has('is_posted') ? $this->boolean('is_posted') : (bool) ($existing?->is_posted ?? false),
                'is_active'           => $this->boolean('is_active'),
            ]);
        }
    ```
  - **Note:** when `fixed_asset_id` changes on an edit, `method`, `rate_applied` and `opening_wdv` are re-derived from the new asset (`$assetChanged`); `is_posted` and `voucher_id` are still preserved.
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\DepreciationEntryRequest.php" -Pattern "\$existing|is_active' => \$this->boolean\('is_active'\)"`
  - **Expect:** matches on `$existing` (the update-aware branches) and an `is_active` merge with **no** second `true` argument. Editing only the amount of a posted entry keeps `is_posted = 1`, the stored `method`/`rate_applied`/`opening_wdv`, and the linked `voucher_id`.
  - **Effort:** M

- [ ] **DPRE-07** · H · RTE-01 · `Modules/Accounting/routes/web.php:279; Modules/Accounting/resources/views/depreciation-entry/trash.blade.php:41-45` — make restore a POST. ⚠ SHARED (route file)
  - **Touches:** `Modules/Accounting/routes/web.php` (⚠ SHARED), `Modules/Accounting/resources/views/depreciation-entry/trash.blade.php`
  - **Before** (`routes/web.php:279`):
    ```php
    Route::get('/depreciation-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'restore'])->name('depreciation-entry.restore');
    ```
  - **After** (`routes/web.php:279`):
    ```php
    Route::post('/depreciation-entry/{id}/restore', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'restore'])->name('depreciation-entry.restore');
    ```
  - **Before** (`trash.blade.php:41-45`):
    ```blade
                                                    @can('tenant.accounting.depreciation-entry.restore')
                                                        <a href="{{ route('accounting.depreciation-entry.restore', $entry->id) }}" class="btn btn-sm btn-outline-success" title="Restore">
                                                            <i class="fa-solid fa-rotate-left"></i>
                                                        </a>
                                                    @endcan
    ```
  - **After** (`trash.blade.php:41-48`):
    ```blade
                                                    @can('tenant.accounting.depreciation-entry.restore')
                                                        <form method="POST" action="{{ route('accounting.depreciation-entry.restore', $entry->id) }}" class="d-inline" onsubmit="return confirm('Restore this entry?');">
                                                            @csrf
                                                            <button type="submit" class="btn btn-sm btn-outline-success" title="Restore">
                                                                <i class="fa-solid fa-rotate-left"></i>
                                                            </button>
                                                        </form>
                                                    @endcan
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\routes\web.php" -Pattern "depreciation-entry/.*restore"; Select-String -Path "Modules\Accounting\resources\views\depreciation-entry\trash.blade.php" -Pattern "restore|@csrf"`
  - **Expect:** the route line starts with `Route::post(`; the trash view has the restore `route(...)` inside `<form method="POST"` with `@csrf`.
  - **Effort:** S

- [ ] **DPRE-19** · L · CTL-04 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:21-244` — declare the return type of all 12 public methods.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (`DepreciationEntryController.php:7-10`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    ```
  - **After** (`DepreciationEntryController.php:7-13`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    ```
    The complete import block after this edit (and DPRE-03, if ticked):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\View\View;
    use Modules\Accounting\Http\Requests\DepreciationEntryRequest;
    use Modules\Accounting\Http\Requests\DepreciationPreviewRequest;
    use Modules\Accounting\Models\DepreciationEntry;
    use Modules\Accounting\Models\FinancialYear;
    use Modules\Accounting\Models\FixedAsset;
    use Modules\Accounting\Models\Voucher;
    use Modules\Accounting\Models\VoucherType;
    use Modules\Accounting\Services\VoucherService;
    ```
  - **Before** (signatures, lines 21, 32, 44, 111, 120, 134, 158, 183, 204, 213, 229, 244):
    ```php
        public function index(Request $request)
        public function create()
        public function store(DepreciationEntryRequest $request)
        public function show(DepreciationEntry $depreciationEntry)
        public function edit(DepreciationEntry $depreciationEntry)
        public function update(DepreciationEntryRequest $request, DepreciationEntry $depreciationEntry)
        public function destroy(DepreciationEntry $depreciationEntry)
        public function toggleStatus(Request $request, DepreciationEntry $depreciationEntry)
        public function trashed()
        public function restore($id)
        public function forceDelete($id)
        public function calculatePreview(Request $request)
    ```
  - **After:**
    ```php
        public function index(Request $request): RedirectResponse
        public function create(): View
        public function store(DepreciationEntryRequest $request): RedirectResponse
        public function show(DepreciationEntry $depreciationEntry): View
        public function edit(DepreciationEntry $depreciationEntry): View
        public function update(DepreciationEntryRequest $request, DepreciationEntry $depreciationEntry): RedirectResponse
        public function destroy(DepreciationEntry $depreciationEntry): RedirectResponse
        public function toggleStatus(Request $request, DepreciationEntry $depreciationEntry): JsonResponse
        public function trashed(): View
        public function restore($id): RedirectResponse
        public function forceDelete($id): RedirectResponse
        public function calculatePreview(DepreciationPreviewRequest $request): JsonResponse
    ```
    If DPRE-03 is not ticked, keep `Request $request` on `calculatePreview`. If DPRE-17 option (b) is chosen, the last two signatures are `restore(DepreciationEntry $depreciationEntry): RedirectResponse` and `forceDelete(DepreciationEntry $depreciationEntry): RedirectResponse`.
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "public function .*\): (View|RedirectResponse|JsonResponse)" | Measure-Object | Select-Object -ExpandProperty Count`
  - **Expect:** `12`. `php -l` on the file passes.
  - **Effort:** S

- [ ] **DPRE-20** · L · MDL-04 · `Modules/Accounting/app/Models/DepreciationEntry.php:72-80` — delete the two unused duplicate relations.
  - **Touches:** `Modules/Accounting/app/Models/DepreciationEntry.php`
  - **Before** (`DepreciationEntry.php:67-82`):
    ```php
        public function computedByUser(): BelongsTo
        {
            return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
        }

        public function computer(): BelongsTo
        {
            return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
        }

        public function creator(): BelongsTo
        {
            return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
        }

        // ─── Scopes ──────────────────────────────────────────────────
    ```
  - **After** (`DepreciationEntry.php:67-72`):
    ```php
        public function computedByUser(): BelongsTo
        {
            return $this->belongsTo(\Modules\SchoolSetup\Models\User::class, 'computed_by');
        }

        // ─── Scopes ──────────────────────────────────────────────────
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Models\DepreciationEntry.php" -Pattern "function (computer|creator)"`
  - **Expect:** no output; `computedByUser` is still the only `computed_by` relation.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **DPRE-18** · M · QRY-15/QRY-03 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:36-41, 126-131` — load only the dropdown columns and drop the unused period query.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (`DepreciationEntryController.php:36-41`):
    ```php
            $fixedAssets = FixedAsset::with('assetCategory')->where('is_active', true)->where('status', 'Active')->orderBy('name')->get();
            $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
            $periods = \Modules\Accounting\Models\AccountingPeriod::where('is_active', true)->orderBy('start_date')->get();
            $vouchers = Voucher::orderByDesc('voucher_date')->limit(100)->get();

            return view('accounting::depreciation-entry.create', compact('fixedAssets', 'financialYears', 'periods', 'vouchers'));
    ```
  - **After** (`DepreciationEntryController.php:36-44`):
    ```php
            $fixedAssets = FixedAsset::select(['id', 'name', 'asset_code'])->where('is_active', true)->where('status', 'Active')->orderBy('name')->get();
            $financialYears = FinancialYear::select(['id', 'name'])->where('is_active', true)->orderByDesc('start_date')->get();
            $vouchers = Voucher::select(['id', 'voucher_type_id', 'voucher_display_no', 'voucher_number', 'voucher_prefix', 'voucher_suffix'])
                ->with('voucherType:id,prefix,suffix,number_width,code')
                ->orderByDesc('voucher_date')
                ->limit(100)
                ->get();

            return view('accounting::depreciation-entry.create', compact('fixedAssets', 'financialYears', 'vouchers'));
    ```
  - **Before** (`DepreciationEntryController.php:126-131`):
    ```php
            $fixedAssets = FixedAsset::with('assetCategory')->where('is_active', true)->orderBy('name')->get();
            $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
            $periods = \Modules\Accounting\Models\AccountingPeriod::where('is_active', true)->orderBy('start_date')->get();
            $vouchers = Voucher::orderByDesc('voucher_date')->limit(100)->get();

            return view('accounting::depreciation-entry.edit', compact('depreciationEntry', 'fixedAssets', 'financialYears', 'periods', 'vouchers'));
    ```
  - **After** (`DepreciationEntryController.php:126-134`):
    ```php
            $fixedAssets = FixedAsset::select(['id', 'name', 'asset_code'])->where('is_active', true)->orderBy('name')->get();
            $financialYears = FinancialYear::select(['id', 'name'])->where('is_active', true)->orderByDesc('start_date')->get();
            $vouchers = Voucher::select(['id', 'voucher_type_id', 'voucher_display_no', 'voucher_number', 'voucher_prefix', 'voucher_suffix'])
                ->with('voucherType:id,prefix,suffix,number_width,code')
                ->orderByDesc('voucher_date')
                ->limit(100)
                ->get();

            return view('accounting::depreciation-entry.edit', compact('depreciationEntry', 'fixedAssets', 'financialYears', 'vouchers'));
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "select\(\['id', 'name', 'asset_code'\]\)"`
  - **Expect:** 2 matches; no `$periods` and no `assetCategory` eager load remain in `create`/`edit`; both views still render every dropdown (they read only `id`, `name`, `asset_code` and `formatted_number`).
  - **Effort:** S

- [ ] **DPRE-21** · L · QRY-02 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:208` — paginate 10 rows under a distinct page name, and eager-load only what the trash view prints. Also closes the `trashed` half of DPRE-22.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (`DepreciationEntryController.php:208`):
    ```php
            $entries = DepreciationEntry::onlyTrashed()->with(['fixedAsset.assetCategory', 'financialYear', 'period', 'voucher', 'computedByUser'])->orderByDesc('deleted_at')->paginate(15);
    ```
  - **After** (`DepreciationEntryController.php:208-211`):
    ```php
            $entries = DepreciationEntry::onlyTrashed()
                ->with(['fixedAsset:id,name,asset_code', 'financialYear:id,name'])
                ->orderByDesc('deleted_at')
                ->paginate(10, ['*'], 'depreciationTrashPage');
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "paginate\(10, \['\*'\], 'depreciationTrashPage'\)"`
  - **Expect:** 1 match; `/accounting/depreciation-entry/trash/view` shows 10 rows per page and its links use `depreciationTrashPage`.
  - **Effort:** S

## 7. Views (F10)

- [ ] **DPRE-23** · L · VIEW-01 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php:111-118; Modules/Accounting/resources/views/depreciation-entry/show.blade.php:78, 82` — compute the asset totals once in the controller instead of twice through the model accessors. Also closes the `show` half of DPRE-22.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`, `Modules/Accounting/resources/views/depreciation-entry/show.blade.php`
  - **Before** (`DepreciationEntryController.php:111-118`):
    ```php
        public function show(DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.view');

            $depreciationEntry->load(['fixedAsset.assetCategory', 'financialYear', 'period', 'voucher', 'computedByUser']);

            return view('accounting::depreciation-entry.show', compact('depreciationEntry'));
        }
    ```
  - **After** (`DepreciationEntryController.php:111-132`):
    ```php
        public function show(DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.view');

            $depreciationEntry->load(['fixedAsset.assetCategory', 'financialYear', 'voucher']);

            $accumulatedDepreciation = 0.0;
            $currentBookValue = 0.0;

            if ($depreciationEntry->fixedAsset) {
                $accumulatedDepreciation = (float) $depreciationEntry->fixedAsset
                    ->depreciationEntries()
                    ->where('is_posted', true)
                    ->sum('depreciation_amount');

                $currentBookValue = strtolower((string) $depreciationEntry->fixedAsset->status) === 'disposed'
                    ? 0.0
                    : max(0.0, round((float) $depreciationEntry->fixedAsset->purchase_cost - $accumulatedDepreciation, 2));
            }

            return view('accounting::depreciation-entry.show', compact('depreciationEntry', 'accumulatedDepreciation', 'currentBookValue'));
        }
    ```
  - **Before** (`show.blade.php:78` and `show.blade.php:82`):
    ```blade
                                    <strong class="text-danger">₹ {{ number_format((float) $depreciationEntry->fixedAsset->accumulated_depreciation, 2) }}</strong>
    ```
    ```blade
                                    <strong class="text-success">₹ {{ number_format((float) $depreciationEntry->fixedAsset->current_value, 2) }}</strong>
    ```
  - **After** (`show.blade.php:78` and `show.blade.php:82`):
    ```blade
                                    <strong class="text-danger">₹ {{ number_format($accumulatedDepreciation, 2) }}</strong>
    ```
    ```blade
                                    <strong class="text-success">₹ {{ number_format($currentBookValue, 2) }}</strong>
    ```
  - **Verify:** `Select-String -Path "Modules\Accounting\resources\views\depreciation-entry\show.blade.php" -Pattern "accumulated_depreciation|current_value"; Select-String -Path "Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php" -Pattern "currentBookValue"`
  - **Expect:** no output from the view check (both accessor reads are gone); 2 matches in the controller (the assignment and the `compact()`). With query logging, the show page runs one `SUM` instead of two.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [ ] **DPRE-24** · L · STY-02 · `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php` — make the file Pint-clean. Run this **after** every ticked code item above.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/DepreciationEntryController.php`
  - **Before** (Pint report, current file):
    ```json
    {"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\DepreciationEntryController.php","fixers":["single_quote","fully_qualified_strict_types","concat_space","method_chaining_indentation","not_operator_with_successor_space","blank_line_before_statement","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]}]}
    ```
  - **After:** run the formatter on this file only:
    ```powershell
    vendor\bin\pint Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php --format agent
    ```
    This resolves the nine fixers listed above. It may reindent the pasted blocks in §1, §3, §5, §6, §7 and the chosen §9 options; that is expected, and it is why this item runs last.
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\DepreciationEntryController.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[]}`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **DPRE-09** · H · DECISION · VAL-07 — should the create-page preview compute WDV with the asset's own method and rate, instead of always straight-line?
  - **Why it is a decision:** it is an accounting-formula change. The preview result is written into the create form's amount input, so the chosen formula becomes the posted charge for any user who accepts the prefill.
  - **Current behaviour** (`calculatePreview`, lines 254-275): `$usefulLife`, `$depRate` and `$method` are read only from `$asset->assetCategory`; `annual_depreciation` is always `(cost - salvage) / usefulLife`; `accumulated_depreciation` is `annual × age`; `suggested_amount` is the annual figure.
  - (a) ⭐ **Recommended — use the asset's effective method/rate/life and a real WDV formula.** Assets with their own `depreciation_method`/`depreciation_rate`/`useful_life_years` override their category; ignoring them prefills an SLM figure for a WDV asset.
    - **Before** (`DepreciationEntryController.php:254-275`):
      ```php
              $cat = $asset->assetCategory;
              $cost = (float) $asset->purchase_cost;
              $salvage = (float) $asset->salvage_value;
              $usefulLife = max(1.0, (float) ($cat?->useful_life_years ?? 1.0));
              $depRate = (float) ($cat?->depreciation_rate ?? 0.0);
              $method = $cat?->depreciation_method ?? 'SLM';

              // Calculate age in years from purchase date to depreciation date
              $purchaseDate = $asset->purchase_date ? \Carbon\Carbon::parse($asset->purchase_date) : now();
              $targetDate = \Carbon\Carbon::parse($date);
              $daysDiff = max(0, $purchaseDate->diffInDays($targetDate));
              $ageYears = round($daysDiff / 365.25, 2);

              // Formulas:
              // 1. Annual Depreciation = (Purchase Cost - Salvage Value) / Useful Life (Years)
              $annualDepreciation = max(0.0, round(($cost - $salvage) / $usefulLife, 2));

              // 2. Accumulated Depreciation = Annual Depreciation * Current Age (Years)
              $formulaAccumulatedDepreciation = min($cost - $salvage, max(0.0, round($annualDepreciation * $ageYears, 2)));

              // 3. Current Value = Purchase Cost - Accumulated Depreciation
              $formulaCurrentValue = max(0.0, round($cost - $formulaAccumulatedDepreciation, 2));
      ```
    - **After** — replace the block above (line numbers shift by DPRE-03/DPRE-23; anchor to the block text, not the numbers):
      ```php
              $cost = (float) $asset->purchase_cost;
              $salvage = (float) $asset->salvage_value;
              $usefulLife = max(1, $asset->getEffectiveUsefulLife());
              $depRate = $asset->getEffectiveDepreciationRate();
              $method = $asset->getEffectiveDepreciationMethod();

              // Calculate age in years from purchase date to depreciation date
              $purchaseDate = $asset->purchase_date ? \Carbon\Carbon::parse($asset->purchase_date) : now();
              $targetDate = \Carbon\Carbon::parse($date);
              $daysDiff = max(0, $purchaseDate->diffInDays($targetDate));
              $ageYears = round($daysDiff / 365.25, 2);

              // 1. Annual depreciation follows the asset's effective method:
              //    SLM = (Purchase Cost - Salvage Value) / Useful Life (Years)
              //    WDV = Opening WDV x Depreciation Rate / 100
              $postedAccumulated = (float) $asset->depreciationEntries()->where('is_posted', true)->sum('depreciation_amount');
              $openingWdv = max($salvage, round($cost - $postedAccumulated, 2));
              $annualDepreciation = $method === 'WDV'
                  ? max(0.0, min(max(0.0, $openingWdv - $salvage), round($openingWdv * ($depRate / 100), 2)))
                  : max(0.0, round(($cost - $salvage) / $usefulLife, 2));

              // 2. Accumulated Depreciation to the depreciation date.
              $formulaAccumulatedDepreciation = $method === 'WDV'
                  ? min(
                      max(0.0, $cost - $salvage),
                      max(0.0, round($cost - ($cost * ((1 - ($depRate / 100)) ** $ageYears)), 2))
                  )
                  : min($cost - $salvage, max(0.0, round($annualDepreciation * $ageYears, 2)));

              // 3. Current Value = Purchase Cost - Accumulated Depreciation
              $formulaCurrentValue = max(0.0, round($cost - $formulaAccumulatedDepreciation, 2));
      ```
    - `suggested_amount` (line 295) stays `$annualDepreciation` and is now method-aware.
  - (b) Keep the SLM-only preview but stop prefilling the amount, so a wrong suggestion can never become a posted charge. Delete these three lines in `create.blade.php` (206-208):
    ```blade
                            if (amountInput && !amountInput.value) {
                                amountInput.value = parseFloat(data.suggested_amount).toFixed(2);
                            }
    ```
    The breakdown card still shows the (SLM) figures; only the auto-fill is removed.
  - (c) Record as accepted: the preview stays SLM-only and keeps prefilling the amount.
  - ➜ Choice: ____

- [ ] **DPRE-10** · H · DECISION · VAL-07 — may a posted entry be permanently deleted?
  - **Why it is a decision:** force-delete is irreversible and the correct guard depends on whether a linked journal voucher exists. Live data: all 5 entries are `is_posted = 1` with `voucher_id = NULL`, so a blanket "posted" block would make force-delete unusable today, while a linked voucher is the case that actually corrupts the ledger.
  - **Current behaviour** (`forceDelete`, lines 229-242 after DPRE-05): deletes with no check; a posted entry with a voucher leaves the voucher posted while `FixedAsset::accumulated_depreciation` drops.
  - (a) ⭐ **Recommended — refuse only when the entry is posted *and* linked to a voucher.** In `forceDelete` (as written by DPRE-05), replace this region:
    ```php
            $entry = DepreciationEntry::withTrashed()->findOrFail($id);

            DB::transaction(function () use ($entry) {
    ```
    with:
    ```php
            $entry = DepreciationEntry::withTrashed()->findOrFail($id);

            if ($entry->is_posted && $entry->voucher_id) {
                return back()->with('error', 'This depreciation entry is posted to a voucher. Reverse the voucher before permanently deleting the entry.');
            }

            DB::transaction(function () use ($entry) {
    ```
    Everything from `$entry->forceDelete();` onward is unchanged.
  - (b) Refuse whenever `is_posted` is true — stricter, but it blocks all 5 live rows until they are unposted (there is no unpost UI). Replace the same region with:
    ```php
            $entry = DepreciationEntry::withTrashed()->findOrFail($id);

            if ($entry->is_posted) {
                return back()->with('error', 'Posted depreciation entries cannot be permanently deleted.');
            }

            DB::transaction(function () use ($entry) {
    ```
    If DPRE-17 option (b) is also chosen, use `$depreciationEntry` in place of `$entry` and skip the `findOrFail` line (the model is bound).
  - (c) Record as accepted; optionally reverse the voucher first. `VoucherService` has no reversal method today (owned by `VoucherController`), so this needs a new finding before any code.
  - ➜ Choice: ____

- [ ] **DPRE-13** · M · DECISION · AUTH-05 — keep the string permission gates and delete the inert policy, or move authorization into the policy?
  - **Why it is a decision:** two authorization sources exist and only one is live. Worse, `AccountingServiceProvider.php:150` references `DepreciationEntryPolicy` with **no import**, so it registers `Modules\Accounting\Providers\DepreciationEntryPolicy` — a class that does not exist (the real policy is in `Modules\Accounting\Policies`). Both deleting and converting are multi-file changes, and converting renames the check on every route.
  - (a) ⭐ **Recommended — keep the string gates (they are the real ACL) and delete the dead policy.** Delete `Modules/Accounting/app/Policies/DepreciationEntryPolicy.php`, and in `AccountingServiceProvider.php` delete both lines:
    ```php
    use Modules\Accounting\Models\DepreciationEntry;
    ```
    ```php
            Gate::policy(DepreciationEntry::class, DepreciationEntryPolicy::class);
    ```
    (`DepreciationEntry` is imported only for that registration — verified, 2 occurrences.) ⚠ SHARED: the provider is shared.
  - (b) Keep the policy and convert all 11 gates to policy form, making the policy the single source: add `use Modules\Accounting\Policies\DepreciationEntryPolicy;` to the provider, then replace the gate strings with `Gate::authorize('viewAny', DepreciationEntry::class)`, `Gate::authorize('create', DepreciationEntry::class)`, `Gate::authorize('view', $depreciationEntry)`, `Gate::authorize('update', $depreciationEntry)`, `Gate::authorize('delete', $depreciationEntry)`, `Gate::authorize('restore', $depreciationEntry)`, `Gate::authorize('forceDelete', $depreciationEntry)` at the matching methods. `trashed()` has no model instance for `restore` — keep a string gate `tenant.accounting.depreciation-entry.restore` there, or invent an ability. DPRE-02 is still required either way.
  - (c) Record as accepted: leave the dead registration and the unused policy in place (no runtime effect, since the registered class name is never resolved).
  - ➜ Choice: ____

- [ ] **DPRE-15** · M · DECISION · VAL-07 — must a depreciation charge be capped at the remaining depreciable value?
  - **Why it is a decision:** it is a business rule with an accounting consequence: the voucher is posted for the full amount while `closing_wdv` is floored at salvage, so an over-sized charge makes the sub-ledger and the journal disagree.
  - (a) ⭐ **Recommended — reject a charge above `opening_wdv − salvage_value`.** Add to `DepreciationEntryRequest`, after `attributes()`:
    ```php
        public function after(): array
        {
            return [
                function (Validator $validator): void {
                    if ($validator->errors()->isNotEmpty()) {
                        return;
                    }

                    $asset = FixedAsset::find($this->input('fixed_asset_id'));
                    if (!$asset) {
                        return;
                    }

                    $maxCharge = max(0.0, round((float) $this->input('opening_wdv', 0) - (float) $asset->salvage_value, 2));

                    if ((float) $this->input('depreciation_amount', 0) > $maxCharge) {
                        $validator->errors()->add(
                            'depreciation_amount',
                            'The depreciation amount may not exceed the opening WDV less the salvage value (₹' . number_format($maxCharge, 2) . ').'
                        );
                    }
                },
            ];
        }
    ```
    Add `use Illuminate\Validation\Validator;` to the request's imports: after `Illuminate\Validation\Rule;` if DPRE-06 is ticked, otherwise after `Illuminate\Foundation\Http\FormRequest;`. Works on create and on update because DPRE-08 preserves `opening_wdv`.
  - (b) Clamp the amount silently instead of rejecting. In `store()`, replace
    ```php
            $depreciationAmount = (float) $validated['depreciation_amount'];
    ```
    with
    ```php
            $maxDepreciationAmount = max(0.0, (float) $validated['opening_wdv'] - (float) $fixedAsset->salvage_value);
            $depreciationAmount = min((float) $validated['depreciation_amount'], $maxDepreciationAmount);
            $validated['depreciation_amount'] = $depreciationAmount;
    ```
    This stores and posts the capped figure but hides the typo from the user; not recommended without a visible warning.
  - (c) Record as accepted: no cap.
  - ➜ Choice: ____

- [ ] **DPRE-17** · M · DECISION · CTL-03 — keep `$id` + `findOrFail` on the two trash actions, or adopt `withTrashed()` route model binding?
  - **Why it is a decision:** it changes the route parameter names in the shared route file and the two method signatures, for a cosmetic consistency gain — the report found no user-visible failure.
  - (a) ⭐ **Recommended — keep the current shape (no code change).** The trash routes need soft-deleted rows, `findOrFail` on `onlyTrashed()`/`withTrashed()` is explicit, and the report records no failure. §10 keeps it as accepted.
  - (b) Adopt binding. ⚠ SHARED route file; apply after DPRE-07. In `routes/web.php` (post-DPRE-07 lines):
    ```php
    Route::post('/depreciation-entry/{depreciation_entry}/restore', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'restore'])->name('depreciation-entry.restore')->withTrashed();
    Route::delete('/depreciation-entry/{depreciation_entry}/force-delete', [\Modules\Accounting\Http\Controllers\DepreciationEntryController::class, 'forceDelete'])->name('depreciation-entry.forceDelete')->withTrashed();
    ```
    In the controller, replace the two methods (as written by DPRE-05):
    ```php
        public function restore(DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.restore');

            DB::transaction(function () use ($depreciationEntry) {
                $depreciationEntry->restore();
                $depreciationEntry->update(['is_active' => true]);

                activityLog($depreciationEntry, 'Restored', [
                    'message' => 'Depreciation Entry restored.',
                    'id'      => $depreciationEntry->id,
                ]);
            });

            return redirect()->route('accounting.depreciation-entry.trashed')->with('success', 'Depreciation Entry restored successfully.');
        }

        public function forceDelete(DepreciationEntry $depreciationEntry)
        {
            Gate::authorize('tenant.accounting.depreciation-entry.forceDelete');

            DB::transaction(function () use ($depreciationEntry) {
                $depreciationEntry->forceDelete();

                activityLog($depreciationEntry, 'Deleted', [
                    'message' => 'Depreciation Entry permanently deleted.',
                    'id'      => $depreciationEntry->id,
                ]);
            });

            return redirect()->route('accounting.depreciation-entry.trashed')->with('success', 'Depreciation Entry permanently deleted.');
        }
    ```
    If DPRE-10 option (a) is also chosen, insert its guard after the `Gate::authorize` line using `$depreciationEntry` instead of `$entry`. The trash view's `$entry->id` links keep working.
  - (c) Bind only `restore` and leave `forceDelete` on `$id`. Same route edit for the restore line only, plus the `restore` method above; `forceDelete` stays as DPRE-05 wrote it.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| DPRE-22 | Its two lines are rewritten by DPRE-21 (`trashed`) and DPRE-23 (`show`). A separate item would make two ticked items edit the same lines; the eager loads are trimmed in those two items. |
| DPRE-25 | Informational (L, VAL-05): `days_in_use` is neither submitted by the forms nor computed, so the column is always `NULL` (5/5 live rows). Which pro-rata policy to use is an accounting decision; no code is proposed in this pass. |
| DPRE-04 | No separate item: the missing-asset 404 is restored by the DPRE-01 catch removal (`findOrFail` moves above the transaction). |
| DPRE-11 | No separate item: the `Log::error(...getMessage())` calls are deleted with the DPRE-01 catches; the central handler reports the exception. |
| DPRE-12 | No separate item: DPRE-01 moves the `Created` audit row inside the transaction. |
| DPRE-14 | No separate item: DPRE-03 moves `fixed_asset_id` and `date` into `DepreciationPreviewRequest`, so a bad date is a 422. |
| DPRE-16 | No separate item: DPRE-01 adds the constructor injection and calls `$this->voucherService`. |
| DPRE-17 | If option (a) is chosen, the current `$id` + `findOrFail` shape is accepted: the trash routes need soft-deleted rows and a 404 on an unknown id is correct, so nothing changes. Options (b)/(c) are the actual code changes. |
| §7 partial | `_depreciation-entries.blade.php` (AccDashboardController, CLAIMED): its permission strings and create-modal duplication are recorded in report §7, not fixed here. The DPRE-02 permission key also governs the tab's visibility. |
| §7 `FixedAsset` | The `SUM` accessors are owned by the `FixedAssetController` report; DPRE-23 stops the show page from calling them rather than editing the model. |
| §7 `BaseAccountingModel`, `AccountingContext` | Hard-coded fallback user `1`; not reached by this controller's fillables. Owned by other reports. |
| §7 `VoucherService` | Internals (numbering, items, posting) were not audited; owned by `VoucherController` (CLAIMED). |
