# Final Audit — Accounting / CampusController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/CampusController.php` (327 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/setup-masters?tab=campuses` (list + create modal) · `/accounting/campus/create` · `/accounting/campus/{id}` (view) · `/accounting/campus/{id}/edit` · `/accounting/campus/trash/view` |
| Menu path | Accounting → Setup & Masters → Campuses tab |
| Who uses it | School Admin and Super Admin. Both hold all seven `tenant.accounting.campus.*` permissions (`sys_role_has_permissions_jnt`, exact-name query below). No other seeded role holds them. |
| What a user does here | A campus is a physical site of the school (a reporting dimension, not separate books). The user adds a campus (code, name, address), marks exactly one campus as "primary", reorders the list by drag-and-drop, toggles active/inactive, and moves a campus to the trash where it can be restored or permanently deleted. |
| Tables written | `acc_campuses` (insert/update/soft-delete/force-delete) and the tenant activity log `sys_activity_logs` (written by the common `activityLog()` helper). |
| Tables read | `acc_campuses`. The modal/list screen is rendered by `AccDashboardController@setupMasters` (a different controller). |
| Live data | `acc_campuses` on `xyz_school_00000000000040008000_202627`: total=4, trashed=0, is_primary=2 (⚠ two primary rows exist — see F13 / cross-cutting note). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready as it stands, but the defects are mechanical rather than architectural. The single worst finding is **CMPS-01 (B)**: every write path echoes `$e->getMessage()` to the browser, so a failed save shows the raw SQL/exception text (table names, column names, driver errors) to the user, and because the unique index on `acc_campuses.code` collides with a soft-delete-aware validation rule (**CMPS-09, H**) a perfectly ordinary "re-use a trashed code" attempt triggers exactly that leak. The second systemic issue is D1: all eight mutating methods use `try/catch` + manual `DB::beginTransaction()/commit()/rollBack()` instead of the Laravel idiom, and `forceDelete()` returns from inside an open transaction. The controller is otherwise small (327 lines, 13 methods — not a god controller) and correctly authorized. Effort to fix the plan: **M** (roughly half a day: one transaction/error rewrite of eight methods, a validation tweak, a route verb change, plus seven decisions — a unique-index choice, shared base classes, permission constants, a route re-scope, and a duplicate create UI).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 4 | 11 | 8 | 7 | 24 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CMPS-01, CMPS-02, CMPS-03, CMPS-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CMPS-05, CMPS-06, CMPS-24 | F9 Queries/Perf | CMPS-18, CMPS-19 |
| F3 Authorization | CMPS-07, CMPS-08 | F10 Views | clean |
| F4 Validation | CMPS-09, CMPS-10 | F11 Security/Tenancy | CMPS-21 |
| F5 Routes | CMPS-11 | F12 Style | CMPS-22 |
| F6 Controller shape | CMPS-12, CMPS-13, CMPS-14, CMPS-15, CMPS-16, CMPS-20 | F13 Deep read | CMPS-23 |
| F7 Models | CMPS-17 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/CampusController.php` | controller | 327 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/Campus.php` | model | 83 | this report (registry line 565) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/CampusRequest.php` | FormRequest | 62 | this report (registry line 566) | ✅ |
| 4 | `Modules/Accounting/resources/views/campus/create.blade.php` | blade | 96 | this report | ✅ |
| 5 | `Modules/Accounting/resources/views/campus/edit.blade.php` | blade | 133 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/campus/show.blade.php` | blade | 120 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/campus/trash.blade.php` | blade | 69 | this report | ✅ |
| 8 | `Modules/Accounting/resources/views/campus/index.blade.php` | blade | 92 | this report | ✅ (dead — CMPS-16) |
| 9 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | this report — **unclaimed shared class** (77 models extend it) | ✅ |
| 10 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | this report — **unclaimed shared class** | ✅ |
| 11 | `database/migrations/tenant/2026_09_16_100002_create_acc_campuses_table.php` | migration | 52 | this report | ✅ |
| 12 | `Modules/Accounting/routes/web.php` | route file | 534 | ⚠ SHARED — not owned by this report | ↗ linked (checked only) |
| 13 | `app/Helpers/activityLog.php` | helper | 51 | common | cross-cutting (§7) |
| 14 | `resources/views/components/**` (`x-backend.*`, `x-tenantcore.*`) | components | — | common | not audited (§7) |
| 15 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_campuses.blade.php` | blade | 284 | ↗ [gaurav/Accounting/AccDashboardController](../AccDashboardController/01-report.md) | ↗ linked |
| 16 | `config/permissionslist.php` | config | 1764 | common/shared | checked only |
| 17 | `config/breadcrumbs.php` | config | — | common | checked only |

No pre-applied files (no `PRE-APPLIED-*.md` applies to the Accounting module).

The two classes `BaseAccountingModel` and `AccountingContext` are **not** in `_Info/00-CLASS-OWNERS.md` although 77 models extend the former. They are shared, so they are listed in the auditor hand-back as *unclaimed shared classes* and audited here (§5 of `final-audit.md`).

## 4. Routes

```
GET|HEAD  accounting/campus                          accounting.campus.index        @index
POST      accounting/campus                          accounting.campus.store        @store
GET|HEAD  accounting/campus/create                   accounting.campus.create       @create
POST      accounting/campus/reorder                  accounting.campus.reorder      @reorder
GET|HEAD  accounting/campus/trash/view               accounting.campus.trashed      @trashed
GET|HEAD  accounting/campus/{campus}                 accounting.campus.show         @show
PUT|PATCH accounting/campus/{campus}                 accounting.campus.update       @update
DELETE    accounting/campus/{campus}                 accounting.campus.destroy      @destroy
GET|HEAD  accounting/campus/{campus}/edit            accounting.campus.edit         @edit
POST      accounting/campus/{campus}/make-primary    accounting.campus.makePrimary  @makePrimary
POST      accounting/campus/{campus}/toggle-status   accounting.campus.toggleStatus @toggleStatus
DELETE    accounting/campus/{id}/force-delete        accounting.campus.forceDelete  @forceDelete
GET|HEAD  accounting/campus/{id}/restore             accounting.campus.restore      @restore
```

Every route carries the tenant middleware chain `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:Accounting, Authenticate, EnsureEmailIsVerified` (RTE-05 clean).

Unrouted public methods: none — all 13 public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 17 | GET accounting/campus | `tenant.accounting.campus.viewAny` | — | — | — | ok |
| `create` | 24 | GET accounting/campus/create | `tenant.accounting.campus.create` | — | — | — | CMPS-20 |
| `store` | 31 | POST accounting/campus | `tenant.accounting.campus.create` | controller | 'Created' | acc_campuses, sys_activity_logs | CMPS-01,04,05,06,09,15 |
| `show` | 70 | GET accounting/campus/{campus} | `tenant.accounting.campus.view` | — | — | — | ok |
| `edit` | 77 | GET accounting/campus/{campus}/edit | `tenant.accounting.campus.update` | — | — | — | ok |
| `update` | 84 | PUT accounting/campus/{campus} | `tenant.accounting.campus.update` | controller | 'Updated' | acc_campuses, sys_activity_logs | CMPS-01,04,05,06,09,15,23 |
| `makePrimary` | 125 | POST …/make-primary | `tenant.accounting.campus.update` | controller | 'MadePrimary' | acc_campuses, sys_activity_logs | CMPS-01,04,05,06,14 |
| `destroy` | 167 | DELETE accounting/campus/{campus} | `tenant.accounting.campus.delete` | controller | 'Trashed' | acc_campuses, sys_activity_logs | CMPS-01,04,05 |
| `toggleStatus` | 203 | POST …/toggle-status | `tenant.accounting.campus.update` | controller | 'Toggled' | acc_campuses, sys_activity_logs | CMPS-01,04,05 |
| `reorder` | 238 | POST accounting/campus/reorder | `tenant.accounting.campus.update` | controller | **none** | acc_campuses | CMPS-01,04,05,10,18,24 |
| `trashed` | 262 | GET …/trash/view | `tenant.accounting.campus.restore` | — | — | — | CMPS-19 |
| `restore` | 271 | GET …/{id}/restore | `tenant.accounting.campus.restore` | controller | 'Restored' | acc_campuses, sys_activity_logs | CMPS-01,02,04,05,11,12 |
| `forceDelete` | 298 | DELETE …/{id}/force-delete | `tenant.accounting.campus.forceDelete` | controller | 'Deleted' | acc_campuses, sys_activity_logs | CMPS-01,02,04,05,12 |

## 6. Findings

### F1 — Errors

#### CMPS-01 · B · ERR-01 — Raw exception text is shown to the user on every failed write

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:66,121,160,163,199,234,258,294,324` — methods `store()`, `update()`, `makePrimary()`, `destroy()`, `toggleStatus()`, `reorder()`, `restore()`, `forceDelete()` |
| **Root cause** | Each `catch (\Throwable $e)` builds the flash/JSON message by concatenating `$e->getMessage()`. A `QueryException` message contains the SQL statement, the table name and the column name. |
| **Consequence** | Any failed save (for example re-using a trashed `code`, see CMPS-09) shows the user a raw SQL error such as `SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'ABC' for key 'acc_campuses.uq_acc_campus_code'` instead of a friendly message. |
| **Reproduce** | Trash the campus with code `MAIN`, then create a new campus with code `MAIN`: the DB unique index fires and the red flash prints the SQL text. |
| **Fix approach** | Remove the `catch` blocks entirely (D1). Let the central handler in `bootstrap/app.php` render the failure; no message is composed from the exception. |
| **Plan item** | CMPS-01 in `02-fix-plan.md` §1 (same item also resolves CMPS-02/03/04/05) |

```php
// CampusController.php:59-67 — CURRENT (representative; the same shape repeats 8x)
} catch (\Throwable $e) {
    DB::rollBack();
    Log::error('Failed to create Campus', [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
    ]);

    return back()->withInput()->with('error', 'Failed to create Campus: ' . $e->getMessage());
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "getMessage"
62:'error' => $e->getMessage(),
66:return back()->withInput()->with('error', 'Failed to create Campus: ' . $e->getMessage());
118:'error' => $e->getMessage(),
121:return back()->withInput()->with('error', 'Failed to update Campus: ' . $e->getMessage());
157:Log::error('Failed to set primary campus', ['id' => $campus->id, 'error' => $e->getMessage()]);
160:return response()->json(['success' => false, 'message' => 'Failed to set primary campus: ' . $e->getMessage()], 500);
163:return back()->with('error', 'Failed to set primary campus: ' . $e->getMessage());
196:'error' => $e->getMessage(),
199:return back()->with('error', 'Failed to delete Campus: ' . $e->getMessage());
232:Log::error('Failed to toggle Campus status', ['id' => $campus->id, 'error' => $e->getMessage()]);
234:return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
256:Log::error('Failed to reorder Campuses', ['error' => $e->getMessage()]);
258:return response()->json(['success' => false, 'message' => 'Failed to reorder: ' . $e->getMessage()], 500);
292:Log::error('Failed to restore Campus', ['id' => $id, 'error' => $e->getMessage()]);
294:return back()->with('error', 'Failed to restore Campus: ' . $e->getMessage());
322:Log::error('Failed to force delete Campus', ['id' => $id, 'error' => $e->getMessage()]);
324:return back()->with('error', 'Failed to delete Campus: ' . $e->getMessage());
```

#### CMPS-02 · H · ERR-02 — A missing record gives a redirect instead of a 404 (`findOrFail()` inside `try`)

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:276-277` (`restore()`), `303-304` (`forceDelete()`) |
| **Root cause** | `Campus::onlyTrashed()->findOrFail($id)` / `Campus::withTrashed()->findOrFail($id)` sit **inside** the `try`. The `ModelNotFoundException` (which should be a 404) is caught by the generic `catch (\Throwable $e)` and converted to `back()->with('error', …)`. |
| **Consequence** | Opening a restore/force-delete link for an id that no longer exists shows a red flash and logs a failure, instead of a clean 404. Under the current code it also leaks the exception text (CMPS-01). |
| **Reproduce** | Open `/accounting/campus/999999/restore`. Expected 404; actual: redirect back with "Failed to restore Campus: …". |
| **Fix approach** | Move `findOrFail()` above the transaction and remove the `try` (D1). |
| **Plan item** | CMPS-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CampusController.php:275-278 — CURRENT
        DB::beginTransaction();
        try {
            $model = Campus::onlyTrashed()->findOrFail($id);
            $model->restore();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "findOrFail"
277:$model = Campus::onlyTrashed()->findOrFail($id);
304:$model = Campus::withTrashed()->findOrFail($id);
```

#### CMPS-03 · M · ERR-05 — `Log::error()` logs the message string, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:61-64,116-119,157,194-197,232,256,292,322` |
| **Root cause** | The catch blocks pass `['error' => $e->getMessage()]` (or `getTraceAsString()`) to `Log::error()` instead of the exception object. |
| **Consequence** | When a save fails in production the log has only a bare message, with no stack trace, so the failure cannot be located. |
| **Reproduce** | static only — requires a failing write and inspection of `storage/logs`. |
| **Fix approach** | Remove the catches (D1). Where a service must log, use `report($e)`. |
| **Plan item** | CMPS-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CampusController.php:61-64 — CURRENT
            Log::error('Failed to create Campus', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "Log::error"
61:Log::error('Failed to create Campus', [
116:Log::error('Failed to update Campus', [
157:Log::error('Failed to set primary campus', ['id' => $campus->id, 'error' => $e->getMessage()]);
194:Log::error('Failed to trash Campus', [
232:Log::error('Failed to toggle Campus status', ['id' => $campus->id, 'error' => $e->getMessage()]);
256:Log::error('Failed to reorder Campuses', ['error' => $e->getMessage()]);
292:Log::error('Failed to restore Campus', ['id' => $id, 'error' => $e->getMessage()]);
322:Log::error('Failed to force delete Campus', ['id' => $id, 'error' => $e->getMessage()]);
```

#### CMPS-04 · M · ERR-00 — Controller `try/catch` blocks violate the D1 idiom

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, D1) — *no `try/catch` in a controller unless a D2 shape; `DB::transaction()` rolls back and rethrows by itself* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:40/59, 95/114, 130/155, 176/192, 217/230, 245/254, 276/290, 303/320` |
| **Root cause** | All eight mutating methods wrap the write in `try { … } catch (\Throwable $e) { … }`, which is the *Variant H* house style the final audit replaced with the Laravel idiom. |
| **Consequence** | Every catch is a place to get ERR-01/02/05 wrong (as they are, above), and the friendly message is composed by hand instead of by the central handler. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Delete the `try/catch` and the manual transaction; use one `DB::transaction(fn () => …)`. |
| **Plan item** | CMPS-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CampusController.php:40 and 59 — CURRENT (open and close of one of the 8 blocks)
        try {
                …
        } catch (\Throwable $e) {
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "\btry \{|\} catch"
40:try {        59:} catch (\Throwable $e) {
95:try {       114:} catch (\Throwable $e) {
130:try {      155:} catch (\Throwable $e) {
176:try {      192:} catch (\Throwable $e) {
217:try {      230:} catch (\Throwable $e) {
245:try {      254:} catch (\Throwable $e) {
276:try {      290:} catch (\Throwable $e) {
303:try {      320:} catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### CMPS-05 · M · TXN-02 — Manual `beginTransaction()/commit()/rollBack()` instead of the closure form; `forceDelete()` returns inside an open transaction

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, never manual `beginTransaction`/`commit`/`rollBack`; never `return` between them* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:39/55/60, 94/110/115, 129/144/156, 175/188/193, 216/227/231, 244/251/255, 275/287/291, 302/317/321`; the early return is at `302-307` |
| **Root cause** | Each method opens a transaction by hand. In `forceDelete()` the primary-campus guard at line 305-307 returns `back()` **after** `DB::beginTransaction()` (line 302) and before any `commit()`/`rollBack()`, so the transaction is left open on the connection. |
| **Consequence** | An early return during force-delete leaves an uncommitted transaction open for the rest of the request; a later accidental write in the same connection can be rolled back or locked. |
| **Reproduce** | static only — the guard path at `forceDelete` for a primary campus. |
| **Fix approach** | Replace manual transactions with `DB::transaction(fn () => …)` and move the guard above it. |
| **Plan item** | CMPS-01 in `02-fix-plan.md` §1 (also resolves this) |

```php
// CampusController.php:302-307 — CURRENT (return between begin and commit)
        DB::beginTransaction();
        try {
            $model = Campus::withTrashed()->findOrFail($id);
            if ($model->isPrimary()) {
                return back()->with('error', 'The primary campus cannot be permanently deleted.');
            }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "beginTransaction|DB::commit|DB::rollBack"
39:DB::beginTransaction();   55:DB::commit();   60:DB::rollBack();
94:DB::beginTransaction();  110:DB::commit();  115:DB::rollBack();
129:DB::beginTransaction(); 144:DB::commit();  156:DB::rollBack();
175:DB::beginTransaction(); 188:DB::commit();  193:DB::rollBack();
216:DB::beginTransaction(); 227:DB::commit();  231:DB::rollBack();
244:DB::beginTransaction(); 251:DB::commit();  255:DB::rollBack();
275:DB::beginTransaction(); 287:DB::commit();  291:DB::rollBack();
302:DB::beginTransaction(); 317:DB::commit();  321:DB::rollBack();
```

#### CMPS-06 · M · TXN-06 — Check-then-act with no lock: `max('ordinal') + 1` and the "one primary" rule

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M) — *check-then-act needs a lock or a unique index (`count()` then insert, `exists()` then `create()`)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:37` (`Campus::max('ordinal') + 1`), `45` (create), `96-100`/`131-135` (unset others then set primary) |
| **Root cause** | `max('ordinal') + 1` reads a value and the insert happens in a separate statement with no `lockForUpdate()`; the same pattern applies to "unset every other primary, then set this one". The `acc_campuses` table has no unique index enforcing a single primary. |
| **Consequence** | Two simultaneous "Add campus" requests can receive the same display order, and two simultaneous "Make primary" requests can both end up primary (the live data already shows 2 primary rows). |
| **Reproduce** | static only — needs concurrent requests; the existing 2-primary state is the evidence. |
| **Fix approach** | Wrap the read in `lockForUpdate()` inside the transaction, or accept the model's `saving` hook as the single owner of the primary rule and add a partial unique index (see CMPS-09 decision). |
| **Plan item** | CMPS-06 in `02-fix-plan.md` §9 |

```php
// CampusController.php:36-45 — CURRENT
        $validated['created_by'] = auth()->id();
        $validated['ordinal'] = Campus::max('ordinal') + 1;

        DB::beginTransaction();
        try {
            if (!empty($validated['is_primary'])) {
                Campus::query()->update(['is_primary' => false]);
            }

            $campus = Campus::create($validated);
```

**Evidence**
```
$ php dbprobe (acc_campuses counts)
total=4 trashed=0 primary=2
```

#### CMPS-24 · M · TXN-04 — `reorder()` changes data with no audit entry

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) / house A3 — *every mutation records an `activityLog()` entry inside the transaction* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:244-253` (`reorder()`) |
| **Root cause** | `reorder()` updates the `ordinal` of every campus but never calls `activityLog()`; every other mutating method does. |
| **Consequence** | Changes to the campus display order leave no trace in the audit log, so it is impossible to say who reordered the list or when. |
| **Reproduce** | Drag a campus row, then open the activity log: no entry. |
| **Fix approach** | Add one `activityLog(auth()->user(), 'Reordered', […])` inside the transaction (the helper accepts any `Authenticatable` as subject). |
| **Plan item** | CMPS-24 in `02-fix-plan.md` §6 (done together with CMPS-18) |

```php
// CampusController.php:244-253 — CURRENT (no activityLog)
        DB::beginTransaction();
        try {
            $ids = $request->input('ids');
            foreach ($ids as $ordinal => $id) {
                Campus::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }

            DB::commit();

            return response()->json(['success' => true, 'message' => 'Order updated.']);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "activityLog"
47: activityLog($campus, 'Created', …
102: activityLog($campus, 'Updated', …
137: activityLog($campus, 'MadePrimary', …
181: activityLog($campus, 'Trashed', …
221: activityLog($campus, 'Toggled', …
281: activityLog($model, 'Restored', …
311: activityLog($model, 'Deleted', …
(no hit between 238 and 260 — reorder)
```

### F3 — Authorization

#### CMPS-07 · L · AUTH-04 — The same permission is authorized twice (FormRequest + Gate)

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/Accounting/app/Http/Requests/CampusRequest.php:17` and `Modules/Accounting/app/Http/Controllers/CampusController.php:33` (`store`) and `:86` (`update`) |
| **Root cause** | `CampusRequest::authorize()` maps POST→`create` and PUT→`update` on `tenant.accounting.campus` (via `AuthorizesTenantFeature`), and the controller then calls `Gate::authorize('tenant.accounting.campus.create'|'.update')` for the same request. |
| **Consequence** | Two identical permission checks run per store/update request; a future change to one of them silently diverges. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first) and drop the redundant `Gate::authorize` in `store()`/`update()`. |
| **Plan item** | CMPS-07 in `02-fix-plan.md` §4 |

```php
// CampusRequest.php:15-18 (FIRST check) and CampusController.php:33 (SECOND check)
    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.campus');
    }
```
```php
        Gate::authorize('tenant.accounting.campus.create');   // store()
        Gate::authorize('tenant.accounting.campus.update');   // update()
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Requests\CampusRequest.php -Pattern "authorizeByCrudPermission"
17:return $this->authorizeByCrudPermission('tenant.accounting.campus');
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "campus.create'|campus.update'"
33:Gate::authorize('tenant.accounting.campus.create');
86:Gate::authorize('tenant.accounting.campus.update');
```

#### CMPS-08 · M · AUTH-06 — Permission strings repeated as literals in 13 places

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place (a Policy or constants), not repeated as literals in every method* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:19,26,33,72,79,86,127,169,205,240,264,273,300` (and the same literals in the request and the views) |
| **Root cause** | The seven `tenant.accounting.campus.*` names are hard-coded in every method, in `CampusRequest`, and in the blades. |
| **Consequence** | A rename or typo in one place produces a permission check that silently never matches, because `Gate::before()` hides the mistake for Super Admin. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Introduce constants (or a Policy) and reference them from the controller/request. This is a cross-file refactor → DECISION. |
| **Plan item** | CMPS-08 in `02-fix-plan.md` §9 |

```php
// CampusController.php:19-20 — CURRENT (representative)
        Gate::authorize('tenant.accounting.campus.viewAny');

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'campuses']);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "Gate::authorize"
19:tenant.accounting.campus.viewAny   26:campus.create   33:campus.create   72:campus.view
79:campus.update  86:campus.update  127:campus.update  169:campus.delete
205:campus.update 240:campus.update 264:campus.restore 273:campus.restore 300:campus.forceDelete
```

### F4 — Validation and input

#### CMPS-09 · H · VAL-04 — Soft-delete × unique-index trap on `acc_campuses.code`

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *a uniqueness rule must mirror the DB unique index including soft-delete semantics* |
| **Where** | `Modules/Accounting/app/Http/Requests/CampusRequest.php:25` vs `database/migrations/tenant/2026_09_16_100002_create_acc_campuses_table.php:35` |
| **Root cause** | The DB has a plain `unique('code')` index (`uq_acc_campus_code`) that still holds trashed rows, but the validation rule adds `->whereNull('deleted_at')`, so the validator believes a code held by a trashed row is free. |
| **Consequence** | Re-creating a campus with the code of a trashed campus passes validation and then throws a `QueryException` at insert, which CMPS-01 shows to the user as raw SQL instead of "Code already taken". |
| **Reproduce** | Trash campus `MAIN`, then create a new campus with code `MAIN`. |
| **Fix approach** | Either (a) drop `->whereNull('deleted_at')` so the rule mirrors the index exactly (app-level, no migration — recommended), or (b) change the index to `(code, deleted_at)` (migration). This is a DECISION. |
| **Plan item** | CMPS-09 in `02-fix-plan.md` §9 |

```php
// CampusRequest.php:25 — CURRENT
            'code'        => ['required', 'string', 'max:20', Rule::unique('acc_campuses', 'code')->ignore($id)->whereNull('deleted_at')],
```
```php
// 2026_09_16_100002_create_acc_campuses_table.php:35 — CURRENT
            $table->unique('code', 'uq_acc_campus_code');
```

**Evidence**
```
$ Select-String ...CampusRequest.php -Pattern "unique"
25:Rule::unique('acc_campuses', 'code')->ignore($id)->whereNull('deleted_at')
26:Rule::unique('acc_campuses', 'name')->ignore($id)->whereNull('deleted_at')
$ Select-String ...2026_09_16_100002_create_acc_campuses_table.php -Pattern "unique"
35:$table->unique('code', 'uq_acc_campus_code');
```

#### CMPS-10 · M · VAL-05 — `reorder()` validates `ids` as an array but not its elements

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *every field is typed (`integer`, `boolean`…); `sometimes`/loose rules validate nothing* (also VAL-02, inline validation) |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:242,247-249` |
| **Root cause** | The only rule is `'ids' => 'required|array'`; the individual ids are never checked as integers or as existing campuses. |
| **Consequence** | A crafted request can pass strings/objects as ids; the values are bound safely but the reorder silently ignores unknown ids and returns "Order updated." |
| **Reproduce** | POST `/accounting/campus/reorder` with `{"ids":["x"]}` — accepted. |
| **Fix approach** | Add `'ids.*' => 'integer'` (or `exists:acc_campuses,id`), or move the whole check into a FormRequest. |
| **Plan item** | CMPS-10 in `02-fix-plan.md` §5 |

```php
// CampusController.php:242,247-249 — CURRENT
        $request->validate(['ids' => 'required|array']);
…
            $ids = $request->input('ids');
            foreach ($ids as $ordinal => $id) {
                Campus::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }
```

**Evidence**
```
$ Read CampusController.php:242
        $request->validate(['ids' => 'required|array']);
```

### F5 — Routes

#### CMPS-11 · H · RTE-01 — A restore (state change) is performed over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, …); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:365` → `CampusController@restore` |
| **Root cause** | The route is registered as `Route::get('/campus/{id}/restore', …)`, and `restore()` writes to the database. |
| **Consequence** | Any crawl, browser prefetch, or a link shared in chat can silently restore a trashed campus with no CSRF token and no confirmation. |
| **Reproduce** | While logged in, open `/accounting/campus/{trashedId}/restore` directly — the campus is restored. |
| **Fix approach** | Change the verb to POST (route-file change → ⚠ SHARED, and the calling `action-trashed` component must point at the same route name). |
| **Plan item** | CMPS-11 in `02-fix-plan.md` §5 |

```php
// routes/web.php:365 — CURRENT
Route::get('/campus/{id}/restore', [CampusController::class, 'restore'])->name('campus.restore');
```

**Evidence**
```
$ php artisan route:list (via routesprobe) — verb column
GET|HEAD  accounting/campus/{id}/restore   accounting.campus.restore
```

### F6 — Controller shape

#### CMPS-12 · L · CTL-03 — `restore()`/`forceDelete()` use `$id` + `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (L) — *use route model binding (`->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:271,277,298,304` |
| **Root cause** | Both methods accept a raw `$id` and load the model by hand. |
| **Consequence** | None user-visible; it is a consistency/maintainability issue and blocks the automatic 404 that binding provides. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Bind `Campus $campus` with `->withTrashed()` on the route, then use the bound model. |
| **Plan item** | CMPS-12 in `02-fix-plan.md` §5 |

```php
// CampusController.php:271-279 — CURRENT
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.campus.restore');

        DB::beginTransaction();
        try {
            $model = Campus::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);
```

**Evidence**
```
$ Select-String ...CampusController.php -Pattern "findOrFail"
277:$model = Campus::onlyTrashed()->findOrFail($id);
304:$model = Campus::withTrashed()->findOrFail($id);
```

#### CMPS-13 · L · CTL-04 — Ten public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:17,24,31,70,77,84,125,167,203,238` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type; the other ten do not. |
| **Consequence** | None user-visible; typing drift. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Add `: RedirectResponse` / `: View` / `: JsonResponse` (as appropriate) to the ten methods. |
| **Plan item** | CMPS-13 in `02-fix-plan.md` §8 |

```php
// CampusController.php:17,24 — CURRENT
    public function index()
    {
    public function create()
    {
```

**Evidence**
```
$ Select-String ...CampusController.php -Pattern "public function"
17:index()   24:create()   31:store(  70:show(  77:edit(  84:update(
125:makePrimary(  167:destroy(  203:toggleStatus(  238:reorder(
262:trashed(): \Illuminate\View\View   271:restore($id): \Illuminate\Http\RedirectResponse
298:forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### CMPS-14 · L · CTL-08 — `makePrimary()` uses the `request()` helper instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; do not call the `request()` helper inside controller methods* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:146,159` |
| **Root cause** | The method signature is `makePrimary(Campus $campus)`; it reaches for `request()->wantsJson()` / `request()->ajax()`. |
| **Consequence** | None user-visible; inconsistent request handling. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Change the signature to `makePrimary(Request $request, Campus $campus)` and use `$request`. |
| **Plan item** | CMPS-14 in `02-fix-plan.md` §8 |

```php
// CampusController.php:146,159 — CURRENT
            if (request()->wantsJson() || request()->ajax()) {
```

**Evidence**
```
$ Select-String ...CampusController.php -Pattern "request\(\)"
146:if (request()->wantsJson() || request()->ajax()) {
159:if (request()->wantsJson() || request()->ajax()) {
```

#### CMPS-15 · M · CTL-06 — The "one primary campus" rule is implemented twice (controller + model), inconsistently

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in services/actions; a controller method reads input, calls one service, returns a response* (also deep-read Q3, duplicate implementations) |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:41-43,96-98,131-135` and `Modules/Accounting/app/Models/Campus.php:37-46` |
| **Root cause** | The model's `saving` hook already unsets every other primary campus, and every controller method repeats the same bulk update. Two owners of one invariant. |
| **Consequence** | The two copies can diverge (and already have: see CMPS-23); the model's hook runs `withoutEvents` so the controller's copy is dead weight. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Keep the model hook as the single owner and delete the controller's duplicate bulk updates (or move the whole rule into a service). This is a behaviour refactor → DECISION. |
| **Plan item** | CMPS-15 in `02-fix-plan.md` §9 |

```php
// Campus.php:37-46 — one copy
        static::saving(function (self $model): void {
            if ($model->is_primary) {
                static::withoutEvents(function () use ($model) {
                    static::where('id', '!=', $model->id ?? 0)
                        ->where('is_primary', true)
                        ->update(['is_primary' => false]);
                });
            }
        });
```
```php
// CampusController.php:41-43,96-98,131-135 — the other copy
            if (!empty($validated['is_primary'])) {
                Campus::query()->update(['is_primary' => false]);
            }
```

**Evidence**
```
$ Select-String ...Campus.php -Pattern "is_primary"
41:static::where('id', '!=', $model->id ?? 0)->where('is_primary', true)->update(['is_primary' => false]);
$ Select-String ...CampusController.php -Pattern "update\(\['is_primary' => false\]\)"
42:Campus::query()->update(['is_primary' => false]);
97:Campus::where('id', '!=', $campus->id)->update(['is_primary' => false]);
131:Campus::where('id', '!=', $campus->id)->update(['is_primary' => false]);
```

#### CMPS-16 · L · CTL-10 — Dead view `campus/index.blade.php` and dead `Campus::selectable()`

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L) — *no dead code: unused methods, unused files* |
| **Where** | `Modules/Accounting/resources/views/campus/index.blade.php` (92 lines, never rendered) and `Modules/Accounting/app/Models/Campus.php:79-82` (`selectable()`, no caller) |
| **Root cause** | `index()` redirects to the setup-masters page, whose Campuses tab is rendered by `pages/partials/setup-masters/_campuses.blade.php`; `campus/index.blade.php` is referenced nowhere. `Campus::selectable()` is defined but never called. |
| **Consequence** | None user-visible; the dead view drifts from the real UI and misleads the next developer. |
| **Reproduce** | static only — grep for callers. |
| **Fix approach** | Delete `campus/index.blade.php` and `Campus::selectable()` (or confirm a consumer first). |
| **Plan item** | CMPS-16 in `02-fix-plan.md` §5 |

```php
// Campus.php:79-82 — CURRENT
    public static function selectable()
    {
        return static::active()->orderBy('ordinal')->get();
    }
```

**Evidence**
```
$ grep -R "campus.index" (php/blade) → only breadcrumb config/registry, no view reference
app/Services/Breadcrumbs/registry.php:114
config/breadcrumbs.php:1444
$ grep "selectable(" Modules/Accounting → only definitions (Campus, CostCategory, Currency), no callers
Campus.php:79:public static function selectable()
```

#### CMPS-20 · L · CTL-05 — Two "create campus" UIs (modal + full page)

| Field | Value |
|---|---|
| **Rule** | CTL-05 (L) — *no copy-paste; the same form duplicated* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:24-29` (`create()`) + `resources/views/campus/create.blade.php` vs `pages/partials/setup-masters/_campuses.blade.php:133-179` (modal) |
| **Root cause** | The live tab creates a campus through the modal (POST `accounting.campus.store`), while the routed `create()` page duplicates the same fields. |
| **Consequence** | Two forms to maintain; only the modal is reachable from the live tab. |
| **Reproduce** | Compare `?tab=campuses` → "Add Campus" (modal) with `/accounting/campus/create` (full page). |
| **Fix approach** | Decide which UI is canonical and remove the other. This changes a routed page → DECISION. |
| **Plan item** | CMPS-20 in `02-fix-plan.md` §9 |

```php
// CampusController.php:24-29 — CURRENT
    public function create()
    {
        Gate::authorize('tenant.accounting.campus.create');

        return view('accounting::campus.create');
    }
```

**Evidence**
```
$ grep -R "_campuses" setup-masters.blade.php
setup-masters.blade.php:39:@include('accounting::pages.partials.setup-masters._campuses')
$ grep -R "campus.create" views → create.blade.php + modal form action route('accounting.campus.store')
```

### F7 — Models

#### CMPS-17 · L · CTL-10 — `Campus` re-declares `use SoftDeletes` already applied by its parent

| Field | Value |
|---|---|
| **Rule** | CTL-10 (L, extended to redundant declarations) — *no dead/redundant code* |
| **Where** | `Modules/Accounting/app/Models/Campus.php:13` vs `Modules/Accounting/app/Models/BaseAccountingModel.php:14` |
| **Root cause** | `BaseAccountingModel` already `use SoftDeletes`; `Campus` (which extends it) adds `use SoftDeletes;` a second time. |
| **Consequence** | None user-visible; redundant trait import that suggests the author was unsure where soft-delete came from. |
| **Reproduce** | static only — code shape. |
| **Fix approach** | Remove the redundant `use SoftDeletes;` (and the now-unused import) from `Campus`. |
| **Plan item** | CMPS-17 in `02-fix-plan.md` §5 |

```php
// Campus.php:13 — CURRENT (parent already uses the trait)
    use SoftDeletes;
```

**Evidence**
```
$ Select-String ...BaseAccountingModel.php -Pattern "use SoftDeletes"
14:    use SoftDeletes;
$ Select-String ...Campus.php -Pattern "use SoftDeletes"
13:    use SoftDeletes;
```

### F8 — Services and jobs

clean — no service, job, event, listener or command is named by this controller (`grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Listener)\b' CampusController.php` → no output). The two reached support classes (`BaseAccountingModel`, `AccountingContext`) are audited under F11.

### F9 — Queries and performance

#### CMPS-18 · H · QRY-01 — A query runs inside a `foreach` in `reorder()` (N updates)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; bulk-write instead* (also QRY-07) |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:247-249` |
| **Root cause** | The reorder loop issues one `UPDATE` per id (`Campus::where('id',$id)->update(...)`) instead of a single bulk statement. |
| **Consequence** | Reordering a list of N campuses fires N separate UPDATE statements; on a large list this is N round-trips inside one transaction. |
| **Reproduce** | Drag-reorder the campus list with the query log on — N updates. |
| **Fix approach** | Update in one pass (`Campus::whereIn('id', $ids)->…`) or a CASE expression; realistically small lists, but the pattern is the finding. |
| **Plan item** | CMPS-18 in `02-fix-plan.md` §6 (done together with CMPS-24) |

```php
// CampusController.php:247-249 — CURRENT
            $ids = $request->input('ids');
            foreach ($ids as $ordinal => $id) {
                Campus::where('id', $id)->update(['ordinal' => $ordinal + 1]);
            }
```

**Evidence**
```
$ Read CampusController.php:247-249
247:            foreach ($ids as $ordinal => $id) {
248:                Campus::where('id', $id)->update(['ordinal' => $ordinal + 1]);
249:            }
```

#### CMPS-19 · M · QRY-02 — The trash list paginates at 15, not the standard 10, with no distinct page name

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) / C12 — *lists paginate; the standard page size is 10 with a distinct `pageName` per list* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:266` |
| **Root cause** | `paginate(15)` uses a non-standard size and the default page name (`page`), so it can collide with another paginator on the same screen. |
| **Consequence** | The trash list is inconsistent with the rest of the app and can fight a second paginator for the `page` query parameter. |
| **Reproduce** | Open `/accounting/campus/trash/view` — 15 rows per page. |
| **Fix approach** | Use `paginate(10, ['*'], 'campus_page')` (or the project's standard) and `->withQueryString()`. |
| **Plan item** | CMPS-19 in `02-fix-plan.md` §6 |

```php
// CampusController.php:266 — CURRENT
        $campuses = Campus::onlyTrashed()->orderBy('name')->paginate(15);
```

**Evidence**
```
$ Read CampusController.php:266
266:        $campuses = Campus::onlyTrashed()->orderBy('name')->paginate(15);
```

### F10 — Views

clean — `Select-String` over `resources/views/campus/*.blade.php` for `Model::|DB::|->get()|->count()|->where(|@php|{!!` returned **no output**: no queries, no raw output, no `@php` blocks. Row actions use `x-backend.table.action` / `action-trashed` and the status switch uses `x-backend.table.status-switch`. (The live list lives in `_campuses.blade.php`, owned by the AccDashboard report — see §7.)

### F11 — Security and tenancy

#### CMPS-21 · M · SEC-03 — Hard-coded user/campus id fallbacks of `1` in the reached support classes

| Field | Value |
|---|---|
| **Rule** | SEC-03 (M) — *no hard-coded ids or fallbacks such as `?? 1` for a user/tenant/status id* |
| **Where** | `Modules/Accounting/app/Models/BaseAccountingModel.php:28` (`Auth::id() ?? 1`), `Modules/Accounting/app/Services/AccountingContext.php:100` (`return 1;`) and `:108` (`Auth::id() ?? 1`) |
| **Root cause** | When no authenticated user/campus is available, both helpers silently fall back to id `1`. `Campus::create()` reaches `AccountingContext::getUserId()` through `BaseAccountingModel::creating`. |
| **Consequence** | A campus created without a resolved user is stamped with `created_by = 1` (and other models with `campus_id = 1`), attributing the record to the wrong identity instead of failing or leaving it null. |
| **Reproduce** | static only — the fallback is unconditional. |
| **Fix approach** | Return `null` (or throw) when the identity cannot be resolved. **Shared class** (77 models) → ⚠ SHARED, high blast radius → DECISION. |
| **Plan item** | CMPS-21 in `02-fix-plan.md` §9 |

```php
// AccountingContext.php:106-109 — CURRENT
    public static function getUserId(): ?int
    {
        return Auth::id() ?? 1;
    }
```

**Evidence**
```
$ Read BaseAccountingModel.php:28 →  $model->updated_by = Auth::id() ?? 1;
$ Read AccountingContext.php:100 →  return 1;
$ Read AccountingContext.php:108 →  return Auth::id() ?? 1;
```

### F12 — Style

#### CMPS-22 · L · STY-02 — Pint fails on all three in-scope PHP files

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php`, `Modules/Accounting/app/Models/Campus.php`, `Modules/Accounting/app/Http/Requests/CampusRequest.php` |
| **Root cause** | Import order, binary/not operator spacing, fully-qualified return types and unused imports are not normalised. |
| **Consequence** | None user-visible; inconsistent style. |
| **Reproduce** | `Pint --test` reports `fail` for all three files. |
| **Fix approach** | `vendor/bin/pint <file> --format agent` on the touched files (never `--dirty`). |
| **Plan item** | CMPS-22 in `02-fix-plan.md` §8 (one item, three files) |

```php
// CampusController.php:262 — CURRENT (FQCN return type; Pint would import it)
    public function trashed(): \Illuminate\View\View
```

**Evidence**
```
$ vendor\bin\pint --test CampusController.php Campus.php CampusRequest.php --format agent
{"tool":"pint","result":"fail","files":[
 {"path":"...CampusController.php","fixers":["fully_qualified_strict_types","concat_space","not_operator_with_successor_space","ordered_imports","binary_operator_spaces"]},
 {"path":"...Campus.php","fixers":["no_unused_imports","ordered_imports","binary_operator_spaces"]},
 {"path":"...CampusRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Q1 write-overwrites? · Q2 deleted-before-replaced? · Q3 duplicate impls? · Q4 soft-delete×unique? · Q5 race? · Q6 auth hole? · Q7 lying message? · Q8 dead feature?

| Method | Q1 | Q2 | Q3 | Q4 | Q5 | Q6 | Q7 | Q8 |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | CMPS-15 | CMPS-09 | CMPS-06 | ok | ok | ok |
| `update` | CMPS-23 | ok | CMPS-15 | CMPS-09 | CMPS-06 | ok | ok | ok |
| `makePrimary` | ok | ok | CMPS-15 | ok | CMPS-06 | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `reorder` | ok | ok | ok | ok | CMPS-06 | ok | ok | CMPS-24 |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |

#### CMPS-23 · M · CTL-06/VAL-07 — `update()` can deactivate the primary campus, which `toggleStatus()` forbids

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) business rules in the controller (also VAL-07, cross-field checks belong in one place) |
| **Where** | `Modules/Accounting/app/Http/Controllers/CampusController.php:90-92` (the only guard in `update()`) compared with `:209-214` (`toggleStatus()` guard) |
| **Root cause** | `update()` guards only the *unsetting* of `is_primary`; it does not guard `is_active`. The edit form (uncheck "Active Status") therefore lets a primary campus become inactive, while `toggleStatus()` returns a 422 "The primary campus cannot be deactivated." |
| **Consequence** | A primary campus can be saved inactive through the edit page, breaking the invariant the toggle endpoint defends and possibly leaving the tenant with no active primary. |
| **Reproduce** | Edit the primary campus, uncheck "Active Status", Save — it becomes inactive. |
| **Fix approach** | Add the same `is_active` guard to `update()` (see the plan's After block). |
| **Plan item** | CMPS-23 in `02-fix-plan.md` §1 (folded into the CMPS-01 rewrite of `update()`) |

```php
// CampusController.php:90-92 — CURRENT (guards is_primary, not is_active)
        if ($campus->isPrimary() && empty($validated['is_primary'])) {
            return back()->withInput()->with('error', 'The primary campus cannot be unset directly. Designate another campus as primary instead.');
        }
```

**Evidence**
```
$ Read CampusController.php:90-92 and 209-214
90: if ($campus->isPrimary() && empty($validated['is_primary'])) {
209:if ($campus->isPrimary() && !$request->boolean('is_active')) {
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:257-273` (`setupMasters`) | Builds the campus list with `$campusesQuery->get()` — **unbounded, no pagination**; the live Campuses tab can grow without limit | QRY-02 | the AccDashboardController report |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_campuses.blade.php:106,117-119` | `Gate::check()` calls inside Blade and `:canEdit`/`:canView`/`:canDelete` props passed to `x-backend.table.action` | VIEW standard / component | the AccDashboardController report (component is common) |
| `app/Helpers/activityLog.php` | Writes to `sys_activity_logs`; central-vs-tenant routing is correct, no defect found | — | common |
| `resources/views/components/**` (`x-backend.*`) | Referenced with `url="accounting.campus"`; must resolve `…toggleStatus` / `…makePrimary` route names (they exist) | — | common (not audited) |
| `acc_campuses` data | The live tenant has **2 rows with `is_primary = 1`**, although the DDL comment says "exactly one campus is primary". The seeder inserts campuses with raw `DB::table(...)`, bypassing the model hook that enforces the rule (CMPS-06). | TXN-06 | data owners / future generator work |

## 8. Not covered, and why

- **The scanner and the self-check were skipped.** `final-audit-reports/_tools/scanfilter.py` and `_tools/selfcheck.py` are **missing** from the repository (`Test-Path` → `False` for both), and `scan.php` must not be run. Therefore the F1–F13 checklist in this report was worked **manually** with `read`/`grep`, `php -l`, `pint --test` and the uncached route probe. No scan-JSON evidence is quoted.
- **Routes** were taken from a freshly generated uncached list (`route:clear` + `APP_ROUTES_CACHE=$env:TEMP\fa-nocache.php`); the raw JSON was piped through the `routesprobe.php` helper only.
- **No tests were run** (D4). Runtime behaviour (BR entries live, queue jobs, the actual N-update count) is verified by static reading plus the DB counts in §0.
- **The `x-backend.*` components and the shared layout** were not opened; component-level misbinding would be a cross-cutting note, not this controller's finding.
- **`campus/create.blade.php`, `edit.blade.php`, `show.blade.php`, `trash.blade.php`** were read but not rendered; no Blade compile check was run.
