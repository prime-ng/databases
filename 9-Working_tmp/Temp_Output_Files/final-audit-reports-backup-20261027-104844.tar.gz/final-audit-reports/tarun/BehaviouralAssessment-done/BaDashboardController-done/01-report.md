# Final Audit — BehaviouralAssessment / BaDashboardController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` (2151 lines, 37 methods — 6 public, 31 private)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost/behavioural-assessment` (dashboard) · `/behavioural-assessment/masters` (masters) · `/behavioural-assessment/setup` (setup) · `/behavioural-assessment/assessments-page` (assessments) · `/behavioural-assessment/incidents-page` (incidents) · `/behavioural-assessment/reports-page` (reports & audit) — each is a tabbed page |
| Menu path | Behavioural Assessment → Dashboard / Masters / Setup / Assessments / Incidents / Reports |
| Who uses it | Anyone holding `tenant.behavioural-assessment.{dashboard\|masters\|setup\|assessments-page\|incidents-page\|reports-page}.viewAny` (all derived from `$crud` in `config/permissionslist.php` so Admin, HOD, Principal, class teachers typically hold them); reports-page additionally gates its analytics tabs behind `reports.viewAny`, `teacher-consistency.view`, `demographic-analytics.view` |
| What a user does here | Reads KPI strips and charts (assessment completion, incidents by week/month/severity/location, escalation count, open interventions, deadlines, failed notifications, score bands, at-risk students). From Masters/Setup creates and edits master data in dialogs (rating scales, categories, interventions, comment bank, class mapping, periods, config, class-scale overrides) — those POSTs go to other controllers; this controller only renders the lists. From Assessments/Incidents/Reports lists filters and drills into records; the demographics tab on reports-page is the only thing this controller writes. |
| Tables written | `ba_audit_log` — one row per Demographics analytics run (`ba_audit_log` currently 0 rows) |
| Tables read | `ba_assessment_periods`, `ba_assessments`, `ba_assessment_ratings`, `ba_computed_scores`, `ba_computed_overall`, `ba_incidents`, `ba_incident_witnesses_jnt`, `ba_incident_interventions_jnt`, `ba_notifications`, `ba_behaviour_points`, `ba_audit_log`, `ba_framework_snapshots`, `ba_score_runs`, `ba_categories`, `ba_criteria`, `ba_rating_scales`, `ba_rating_levels`, `ba_configs`, `ba_class_category_jnt`, `ba_class_scale_jnt`, `ba_comment_bank`, plus views `v_ba_assessment_progress`, `v_ba_open_interventions`, `v_ba_at_risk_students`, `v_ba_incident_summary`, plus `std_students`, `std_student_academic_sessions`, `sys_users` (names), `sch_*` and `org_academic_sessions` lookups |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `ba_incidents` 24 · `ba_assessments` 17 · `ba_behaviour_points` 0 · `ba_notifications` 0 · `ba_audit_log` 0 · `ba_score_runs` 2 · `ba_framework_snapshots` 1 · `ba_assessment_ratings` 21,996 · `ba_computed_overall` 193 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The controller is **ready for production after a handful of fixes**. It is a read-mostly dashboard: all six routes are GET, every routed method authorizes by a permission name that exists in `config/permissionslist.php`, every listed query is indexed or bounded, and 58 reached blades compile clean. The single worst finding is that one GET request — `reports-page?tab=demographics&dm_period_id=…` — **writes** a `ba_audit_log` row, so a link prefetcher or a double tap logs a fake "analytics run"; fixing it needs a route change, so it is a decision. The second real defect is an in-controller `try/catch` that logs only `$e->getMessage()` (the trace is lost). The rest is manageable: the controller is a 2,151-line god controller whose split is deferred (D3), some methods are over the length limits, one blade runs two queries, and there is an over-wide `compact()` and emoji-heavy comments. Rough effort to apply the ticked plan: S–M (about half a day, excluding the deferred decisions).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 6 | 2 | 5 | 10 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BH-01 | F8 Services/Jobs | BH-07 |
| F2 Transactions/Audit | clean | F9 Queries/Perf | BH-08 |
| F3 Authorization | clean | F10 Views | BH-10 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | BH-02 | F12 Style | BH-11 |
| F6 Controller shape | BH-03, BH-04, BH-05, BH-06 | F13 Deep read | BH-02 (+ table in F13) |
| F7 Models | clean (all linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php` | controller | 2151 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Support/BaDashboardCache.php` | support | 63 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaScoreRun.php` | model | 103 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Models/BaFrameworkSnapshot.php` | model | 80 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/resources/views/pages/dashboard.blade.php` | view | 395 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/resources/views/pages/masters.blade.php` | view | 28 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/resources/views/pages/setup.blade.php` | view | 28 | this report | ✅ |
| 8 | `Modules/BehaviouralAssessment/resources/views/pages/assessments.blade.php` | view | 40 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/resources/views/pages/incidents.blade.php` | view | 132 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/resources/views/pages/reports.blade.php` | view | 377 | this report | ✅ |
| 11 | `…/pages/partials/masters/_rating-scales.blade.php` | view | 110 | this report | ✅ |
| 12 | `…/pages/partials/masters/_rating-scales-create-modal.blade.php` | view | 120 | this report | ✅ |
| 13 | `…/pages/partials/masters/_categories.blade.php` | view | 195 | this report | ✅ |
| 14 | `…/pages/partials/masters/_categories-create-modal.blade.php` | view | 14 | this report | ✅ |
| 15 | `…/pages/partials/masters/_interventions.blade.php` | view | 206 | this report | ✅ |
| 16 | `…/pages/partials/masters/_interventions-create-modal.blade.php` | view | 13 | this report | ✅ |
| 17 | `…/pages/partials/masters/_comment-bank.blade.php` | view | 204 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 18 | `…/pages/partials/masters/_comment-bank-modals.blade.php` | view | 23 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 19 | `…/pages/partials/setup/_class-mapping.blade.php` | view | 515 | this report | ✅ |
| 20 | `…/pages/partials/setup/_periods.blade.php` | view | 234 | this report | ✅ |
| 21 | `…/pages/partials/setup/_periods-create-modal.blade.php` | view | 13 | this report | ✅ |
| 22 | `…/pages/partials/setup/_configuration.blade.php` | view | 166 | this report | ✅ |
| 23 | `…/pages/partials/setup/_configuration-create-modal.blade.php` | view | 13 | this report | ✅ |
| 24 | `…/pages/partials/setup/_class-scale-modals.blade.php` | view | 32 | this report | ✅ |
| 25 | `…/pages/partials/setup/_snapshots.blade.php` | view | 208 | this report | ✅ |
| 26 | `…/pages/partials/setup/_snapshot-modal.blade.php` | view | 206 | this report | ✅ |
| 27 | `…/pages/partials/assessments/_my-assessments.blade.php` | view | 160 | this report | ✅ |
| 28 | `…/pages/partials/assessments/_my-assessments-scripts.blade.php` | view | 280 | this report | ✅ |
| 29 | `…/pages/partials/assessments/_ratings.blade.php` | view | 321 | this report | ✅ |
| 30 | `…/pages/partials/assessments/_remarks.blade.php` | view | 259 | this report | ✅ |
| 31 | `…/pages/partials/assessments/_remark-show-modal.blade.php` | view | 21 | this report | ✅ |
| 32 | `…/pages/partials/assessments/_review-queue.blade.php` | view | 193 | this report | ✅ |
| 33 | `…/pages/partials/assessments/_assessment-modal.blade.php` | view | 79 | this report | ✅ |
| 34 | `…/pages/partials/assessments/_assessment-show-modal.blade.php` | view | 19 | this report | ✅ |
| 35 | `…/pages/partials/incidents/_log.blade.php` | view | 241 | this report | ✅ |
| 36 | `…/pages/partials/incidents/_witnesses.blade.php` | view | 243 | this report | ✅ |
| 37 | `…/pages/partials/incidents/_interventions-applied.blade.php` | view | 192 | this report | ✅ |
| 38 | `…/pages/partials/incidents/_worklist.blade.php` | view | 135 | this report | ✅ |
| 39 | `…/pages/partials/incidents/_outbox.blade.php` | view | 218 | this report | ✅ |
| 40 | `…/pages/partials/incidents/_behaviour-points.blade.php` | view | 253 | this report | ✅ |
| 41 | `…/pages/partials/incidents/_create-modal.blade.php` | view | 81 | this report | ✅ |
| 42 | `…/pages/partials/incidents/_case-modals.blade.php` | view | 271 | this report | ✅ |
| 43 | `…/pages/partials/incidents/_case-actions.blade.php` | view | 71 | this report | ✅ |
| 44 | `…/pages/partials/incidents/_behaviour-points-modals.blade.php` | view | 79 | this report | ✅ |
| 45 | `…/pages/partials/reports/_student-scores.blade.php` | view | 442 | this report | ✅ |
| 46 | `…/pages/partials/reports/_category-summary.blade.php` | view | 274 | this report | ✅ |
| 47 | `…/pages/partials/reports/_period-report.blade.php` | view | 532 | this report | ✅ |
| 48 | `…/pages/partials/reports/_at-risk.blade.php` | view | 129 | this report | ✅ |
| 49 | `…/pages/partials/reports/_teacher-consistency.blade.php` | view | 93 | this report | ✅ |
| 50 | `…/pages/partials/reports/_demographics.blade.php` | view | 102 | this report | ✅ |
| 51 | `…/pages/partials/reports/_audit-trail.blade.php` | view | 283 | this report | ✅ |
| 52 | `…/pages/partials/reports/_exports.blade.php` | view | 136 | ↗ [tarun/BehaviouralAssessment-done/BaReportController-done](../BaReportController-done/01-report.md) | ↗ linked |
| 53 | `…/assessment/_signal-badges.blade.php` | view | 34 | this report | ✅ |
| 54 | `…/incident/_create-fields.blade.php` | view | 195 | this report | ✅ |
| 55 | `…/incident/_partials/_witness-picker-scripts.blade.php` | view | 90 | this report | ✅ |
| 56 | `…/category/_create-fields.blade.php` | view | 84 | this report | ✅ |
| 57 | `…/intervention/_create-fields.blade.php` | view | 64 | this report | ✅ |
| 58 | `…/rating-scale/_create-fields.blade.php` | view | 201 | this report | ✅ |
| 59 | `…/class-scale/_fields.blade.php` | view | 74 | this report | ✅ |
| 60 | `…/config/_create-fields.blade.php` | view | 16 | this report | ✅ |
| 61 | `…/assessment-period/_create-fields.blade.php` | view | 83 | this report | ✅ |
| 62 | `…/comment-bank/_fields.blade.php` | view | 89 | this report | ✅ |
| 63 | `Modules/BehaviouralAssessment/app/Models/BaAssessment.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentController-done](../BaAssessmentController-done/01-report.md) | ↗ linked |
| 64 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentPeriod.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 65 | `Modules/BehaviouralAssessment/app/Models/BaAssessmentRating.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 66 | `Modules/BehaviouralAssessment/app/Models/BaBehaviourPoint.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 67 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 68 | `Modules/BehaviouralAssessment/app/Models/BaCategory.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 69 | `Modules/BehaviouralAssessment/app/Models/BaClassCategoryJnt.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaClassCategoryController-done](../BaClassCategoryController-done/01-report.md) | ↗ linked |
| 70 | `Modules/BehaviouralAssessment/app/Models/BaClassScaleJnt.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaClassScaleController-done](../BaClassScaleController-done/01-report.md) | ↗ linked |
| 71 | `Modules/BehaviouralAssessment/app/Models/BaComputedOverall.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaReportController-done](../BaReportController-done/01-report.md) | ↗ linked |
| 72 | `Modules/BehaviouralAssessment/app/Models/BaComputedScore.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentPeriodController-done](../BaAssessmentPeriodController-done/01-report.md) | ↗ linked |
| 73 | `Modules/BehaviouralAssessment/app/Models/BaConfig.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaConfigController-done](../BaConfigController-done/01-report.md) | ↗ linked |
| 74 | `Modules/BehaviouralAssessment/app/Models/BaCriterion.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 75 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 76 | `Modules/BehaviouralAssessment/app/Models/BaIncidentInterventionJnt.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaInterventionCaseController-done](../BaInterventionCaseController-done/01-report.md) | ↗ linked |
| 77 | `Modules/BehaviouralAssessment/app/Models/BaIncidentWitnessJnt.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaIncidentController-done](../BaIncidentController-done/01-report.md) | ↗ linked |
| 78 | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaInterventionController-done](../BaInterventionController-done/01-report.md) | ↗ linked |
| 79 | `Modules/BehaviouralAssessment/app/Models/BaNotification.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaNotificationController-done](../BaNotificationController-done/01-report.md) | ↗ linked |
| 80 | `Modules/BehaviouralAssessment/app/Models/BaRatingLevel.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaRatingScaleController-done](../BaRatingScaleController-done/01-report.md) | ↗ linked |
| 81 | `Modules/BehaviouralAssessment/app/Models/BaRatingScale.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaRatingScaleController-done](../BaRatingScaleController-done/01-report.md) | ↗ linked |
| 82 | `Modules/BehaviouralAssessment/app/Models/BaStudentRemark.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentController-done](../BaAssessmentController-done/01-report.md) | ↗ linked |
| 83 | `Modules/BehaviouralAssessment/app/Models/BaCommentBank.php` | model | — | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 84 | `Modules/BehaviouralAssessment/app/Services/BaBehaviourPointService.php` | service | — | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 85 | `Modules/BehaviouralAssessment/app/Services/BaFrameworkSnapshotService.php` | service | — | ↗ [tarun/BehaviouralAssessment-done/BaReportController-done](../BaReportController-done/01-report.md) | ↗ linked |
| 86 | `Modules/BehaviouralAssessment/app/Services/BehaviouralScoreService.php` | service | — | ↗ [tarun/BehaviouralAssessment-done/BaReportController-done](../BaReportController-done/01-report.md) | ↗ linked |
| 87 | `Modules/BehaviouralAssessment/app/Services/BaReviewSignalService.php` | service | — | ↗ [tarun/BehaviouralAssessment-done/BaAssessmentController-done](../BaAssessmentController-done/01-report.md) | ↗ linked |
| 88 | `Modules/BehaviouralAssessment/app/Services/BaInterventionCaseService.php` | service | — | ↗ [tarun/BehaviouralAssessment-done/BaInterventionCaseController-done](../BaInterventionCaseController-done/01-report.md) | ↗ linked |
| 89 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 90 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 91 | `Modules/BehaviouralAssessment/app/Support/BaDispatch.php` | support | — | ↗ [tarun/BehaviouralAssessment-done/BaNotificationController-done](../BaNotificationController-done/01-report.md) | ↗ linked |
| 92 | `Modules/StudentProfile/app/Models/Student.php` | model (other module, reached via relations and the witnesses blade) | — | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController/01-report.md) | ↗ linked |
| 93 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` | controller (static reuse: `EAGER`, `contextLookups`) | — | common/other report | ❌ referenced only — see §7 |
| 94 | `Modules/SchoolSetup/app/Models/Employee.php` | model (other module) | — | common §4.2 | ❌ referenced only |
| 95 | `Modules/SchoolSetup/app/Models/Subject.php` | model (other module) | — | common §4.2 | ❌ referenced only |
| 96 | `Modules/SchoolSetup/app/Models/SchoolClass.php` | model (other module) | — | common §4.2 | ❌ referenced only |
| 97 | `Modules/SchoolSetup/app/Models/ClassSection.php` | model (other module) | — | common §4.2 | ❌ referenced only |
| 98 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model (other module) | — | common §4.2 | ❌ referenced only |
| 99 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model (other module) | — | ↗ [TimetableFoundation/AcademicTermController](../../../TimetableFoundation/AcademicTermController/01-report.md) | ↗ linked |

No pre-applied files (no `PRE-APPLIED-2026-10-10.md` exists for BehaviouralAssessment).

## 4. Routes

All six routes for this controller, from the fresh uncached route list (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json`):

```
GET|HEAD behavioural-assessment                                       behavioural-assessment.dashboard                     Modules\BehaviouralAssessment\Http\Controllers\BaDashboardController@index
GET|HEAD behavioural-assessment/assessments-page                      behavioural-assessment.assessments-page              Modules\BehaviouralAssessment\Http\Controllers\BaDashboardController@assessmentsPage
GET|HEAD behavioural-assessment/incidents-page                        behavioural-assessment.incidents-page                Modules\BehaviouralAssessment\Http\Controllers\BaDashboardController@incidentsPage
GET|HEAD behavioural-assessment/masters                               behavioural-assessment.masters                       Modules\BehaviouralAssessment\Http\Controllers\BaDashboardController@masters
GET|HEAD behavioural-assessment/reports-page                          behavioural-assessment.reports-page                  Modules\BehaviouralAssessment\Http\Controllers\BaDashboardController@reportsPage
GET|HEAD behavioural-assessment/setup                                 behavioural-assessment.setup                         Modules\BehaviouralAssessment\Http\Controllers\BaDashboardController@setup
```

All six are GET (no state change expected → BH-02), all point at methods that exist, all six public methods are routed (`index` 151, `masters` 394, `setup` 458, `assessmentsPage` 636, `incidentsPage` 1397, `reportsPage` 1726). Unrouted public methods: **none**. The whole set sits behind the module's tenancy + auth middleware group (`Route::middleware(['web', InitializeTenancyByDomain::class, PreventAccessFromCentralDomains::class, EnsureTenantIsActive::class, EnsureTenantHasModule::class.':BehaviouralAssessment', 'auth', 'verified'])->prefix('behavioural-assessment')…`, `Modules/BehaviouralAssessment/app/Providers/RouteServiceProvider.php:25-36`).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 151 | GET /behavioural-assessment | `tenant.behavioural-assessment.dashboard.viewAny` | — | — | — | — |
| `masters` | 394 | GET /masters | `tenant.behavioural-assessment.masters.viewAny` | — | — | — | BH-06 |
| `setup` | 458 | GET /setup | `tenant.behavioural-assessment.setup.viewAny` | — | — | — | BH-04 (85 lines), BH-06 |
| `assessmentsPage` | 636 | GET /assessments-page | `tenant.behavioural-assessment.assessments-page.viewAny` | — | — | — | BH-08 (via maps) |
| `incidentsPage` | 1397 | GET /incidents-page | `tenant.behavioural-assessment.incidents-page.viewAny` | — | — | — | BH-04 (104), BH-06, BH-10 (via witnesses view) |
| `reportsPage` | 1726 | GET /reports-page | `tenant.behavioural-assessment.reports-page.viewAny` | — | — | `ba_audit_log` (only when the demographics tab is active and a period is chosen) | BH-02, BH-04 (209), BH-05, BH-06 |
| `resolveScale` | 78 | — (private) | — | — | — | — | BH-07 |
| `gradeLegend` | 104 | — (private) | — | — | — | — | — |
| `dashboardKpis` | 197 | — (private) | — | — | — | — | — |
| `dashboardIncidents` | 228 | — (private) | — | — | — | — | — |
| `dashboardOps` | 295 | — (private) | — | — | — | — | — |
| `dashboardScores` | 325 | — (private) | — | — | — | — | BH-07 |
| `activeConfig` | 386 | — (private) | — | — | — | — | — |
| `frameworkSnapshotsTab` | 544 | — (private) | — | — | — | — | — |
| `snapshotIntegrity` | 593 | — (private) | — | — | — | — | BH-01 |
| `snapshotClassNames` | 620 | — (private) | — | — | — | — | — |
| `myAssessmentsQuery` | 716 | — (private) | — | — | — | — | — |
| `ratingClassSectionIds` | 745 | — (private) | — | — | — | — | — |
| `ratingStudentIds` | 773 | — (private) | — | — | — | — | — |
| `ratingClassCounts` | 794 | — (private) | — | — | — | — | — |
| `ratingsQuery` | 809 | — (private) | — | — | — | — | — |
| `ratingScoreMapQuery` | 841 | — (private) | — | — | — | — | BH-08 |
| `ratingDetailMapQuery` | 922 | — (private) | — | — | — | — | BH-08 |
| `ratingStudentMapQuery` | 957 | — (private) | — | — | — | — | — |
| `auditTrailDetail` | 995 | — (private) | — | — | — | — | — |
| `periodReportDetail` | 1090 | — (private) | — | — | — | — | BH-04 (167 lines) |
| `decoratePeriodStudents` | 1258 | — (private) | — | — | — | — | — |
| `remarksQuery` | 1320 | — (private) | — | — | — | — | — |
| `remarkSummary` | 1349 | — (private) | — | — | — | — | — |
| `remarkScoreMap` | 1371 | — (private) | — | — | — | — | — |
| `reviewQueueQuery` | 1389 | — (private) | — | — | — | — | — |
| `behaviourPointsData` | 1502 | — (private) | — | — | — | — | BH-04 (121 lines) |
| `interventionCaseData` | 1624 | — (private) | — | — | — | — | — |
| `outboxData` | 1687 | — (private) | — | — | — | — | — |
| `atRiskRegister` | 1936 | — (private) | — | — | — | — | — |
| `teacherConsistency` | 1997 | — (private) | — | — | — | — | BH-04 (84 lines) |
| `demographicAnalytics` | 2082 | — (private) | — | — | — | `ba_audit_log` (1 row, on GET) | BH-02 |

## 6. Findings

### F1 — Errors

#### BH-01 · M · ERR-05 — `snapshotIntegrity()` catches `\Throwable` and logs only `$e->getMessage()`, losing the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* (plus ERR-00/D1: the catch itself is a controller catch outside the D2 shapes) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:602-608`, method `snapshotIntegrity()` |
| **Root cause** | The `catch (\Throwable $e)` was written to keep one corrupt snapshot from 500-ing the whole Setup page, but it logs `$e->getMessage()` into a `\Illuminate\Support\Facades\Log::warning(...)` context — no trace, no exception object. When `BaFrameworkSnapshotService::verify()` later throws from a deeper layer, the log shows only a one-line message and operators cannot see where it came from. |
| **Consequence** | A failing snapshot shows "Unverified" on the tab and the log entry has no stack trace, so diagnosing the cause is guesswork. |
| **Reproduce** | Static only — a snapshot whose JSON no longer matches its checksum or whose stored JSON shape changed would trigger it; the tab degrades silently to "Unverified". |
| **Fix approach** | Replace the `Log::warning(...)` line with `report($e);` (logs the exception object). The catch stays (per-row isolation on a read-only integrity badge); the D1-shape concern is noted for the split pass. This also removes the un-imported `\Log::` usage on the same line. |
| **Plan item** | BH-01 in `02-fix-plan.md` §3 |

```php
            try {
                return [$snapshot->id => (bool) $service->verify($snapshot)];
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('BA snapshot verify failed', ['snapshot_id' => $snapshot->id, 'error' => $e->getMessage()]);

                return [$snapshot->id => null];
            }
```

**Evidence**
```
$ sed -n '602,608p' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
            try {
                return [$snapshot->id => (bool) $service->verify($snapshot)];
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('BA snapshot verify failed', ['snapshot_id' => $snapshot->id, 'error' => $e->getMessage()]);

                return [$snapshot->id => null];
            }
$ grep -n 'getMessage' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
605:                \Illuminate\Support\Facades\Log::warning('BA snapshot verify failed', ['snapshot_id' => $snapshot->id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

clean — the only mutating call in the whole controller is the single-row audit insert in `demographicAnalytics()` (`BaAuditLog::log(...)` at line 2140 → one `static::create()`), so TXN-01 (more than one write) and TXN-03 (irreversible side effect) do not apply; there is no `activityLog()` (BA audits through its own `ba_audit_log`), and no `beginTransaction/commit/rollBack` exists anywhere in the controller:

```
$ grep -nE "::create\(|->save\(|->update\(|->delete\(|::insert\(|::upsert\(|BaAuditLog::log|beginTransaction|rollBack|commit\(" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
2140:        BaAuditLog::log(
```

### F3 — Authorization

clean — every one of the six routed methods calls `Gate::authorize` as its first statement, before loading any record; the analytics sub-tabs on reports-page are gated server-side by permission (`$tabGates` at lines 1879-1886 plus `Gate::allows` guards), and every permission string exists in `config/permissionslist.php` (lines 1400-1447):

```
$ grep -oE "Gate::(authorize|allows)\('[^']+'" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php | sort -u
Gate::allows('tenant.behavioural-assessment.assessments-page.viewAny'
Gate::allows('tenant.behavioural-assessment.framework-snapshots.view'
Gate::allows('tenant.behavioural-assessment.incidents.create'
Gate::allows('tenant.behavioural-assessment.incidents-page.viewAny'
Gate::allows('tenant.behavioural-assessment.notifications.view'
Gate::allows('tenant.behavioural-assessment.reports.viewAny'
Gate::allows('tenant.behavioural-assessment.reviews.viewAny'
Gate::authorize('tenant.behavioural-assessment.assessments-page.viewAny'
Gate::authorize('tenant.behavioural-assessment.dashboard.viewAny'
Gate::authorize('tenant.behavioural-assessment.incidents-page.viewAny'
Gate::authorize('tenant.behavioural-assessment.masters.viewAny'
Gate::authorize('tenant.behavioural-assessment.reports-page.viewAny'
Gate::authorize('tenant.behavioural-assessment.setup.viewAny'
$ grep -nE "behavioural-assessment\.(dashboard|masters|setup|assessments-page|incidents-page|reports-page|framework-snapshots|notifications|intervention-cases|behaviour-points|reports|teacher-consistency|demographic-analytics)\b" config/permissionslist.php
1400:        'behavioural-assessment.dashboard' => $crud,
1401:        'behavioural-assessment.masters' => $crud,
...
1447:        'behavioural-assessment.demographic-analytics' => ['view'],
```

### F4 — Validation and input

clean — this controller never writes user input to a model (no FormRequest needed for a read controller), and every query-string filter is either type-cast (`(int)`, `->integer(...)`, `request()->filled(...)`) or validated against a model constant/enum before it can reach SQL (`in_array(request('severity'), BaIncident::SEVERITIES, true)`, `in_array(request('entity_type'), BaAuditLog::ENTITY_TYPES, true)`, `in_array(request('bp_type'), [...]`, `in_array(request('ar_reason'), ['score','incidents'], true)`, `in_array(request('pr_trend'), [...]`). The `demographicAnalytics` dimension is whitelisted against the `available ⊆ DEMOGRAPHIC_DIMENSIONS` set before use (line 2102).

### F5 — Routes

#### BH-02 · H · RTE-01 — a GET request writes a `ba_audit_log` row when the Demographics tab runs

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET: GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:2140-2147`, method `demographicAnalytics()`; the write fires from `reportsPage()` (`GET /behavioural-assessment/reports-page`) |
| **Root cause** | `reportsPage` is a GET route, and whenever the demographics tab is the active one (`$activeTab === 'demographics'`), holds `demographic-analytics.view` and carries a `dm_period_id`, `demographicAnalytics()` unconditionally inserts a `ba_audit_log` row. The audit is a write on a read route. |
| **Consequence** | A browser prefetch, a link-scanner or a double-clicked tab creates a spurious "Demographic analytics run" audit row, so the audit trail records analytics runs nobody actually ran. |
| **Reproduce** | Open `GET /behavioural-assessment/reports-page?tab=demographics&dm_period_id=<any id>` while holding the view permission — a `ba_audit_log` row with `field_name = demographic_analytics` appears (on the audited tenant, `ba_audit_log` is currently 0 rows, so the difference is visible). |
| **Fix approach** | Move the audit write off the GET path. Recommended: only record the audit when the user actively *chooses* to run the analytics cut (a POST), or drop the audit to `afterCommit`/job semantics — each option changes either routes or UX, so it is a decision. |
| **Plan item** | BH-02 in `02-fix-plan.md` §9 (DECISION) |

```php
        BaAuditLog::log(
            BaAuditLog::ENTITY_EXPORT,
            (int) $period->id,
            'demographic_analytics',
            null,
            json_encode(['period_id' => $period->id, 'dimension' => $dimension, 'min_group' => $minGroup, 'groups' => $groups->count()]),
            'Demographic analytics run'
        );
```

**Evidence**
```
$ grep -nE "BaAuditLog::log|GET.*reports-page|demographicAnalytics" <route probe + source>
route: GET|HEAD behavioural-assessment/reports-page ... BaDashboardController@reportsPage
1892:        $demographics = Gate::allows($tabGates['demographics'])
1893:            ? $this->demographicAnalytics($activeTab === 'demographics') : null;
2140:        BaAuditLog::log(
```

### F6 — Controller shape

#### BH-03 · M · CTL-01 — 2,151-line god controller; split is DEFERRED (D3)

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — *no god controllers: over 1,000 lines → split by resource/responsibility* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:47-58` (class declaration) |
| **Root cause** | Six pages, 31 private helpers, the rating tab's maps, the period report, the audit trail facets, the analytics tabs and the incident/assessment lists all live in one class. The rulebook threshold is 1,000 lines; the controller is 2,151 lines. |
| **Consequence** | The file is hard for a new developer to navigate and every page shares the class's private helpers, so a change to one tab can break another. |
| **Reproduce** | Static only — open the file. |
| **Fix approach** | Split into per-page controllers or view services when the team runs the god-controller split pass (D3). Not applied in this pass. |
| **Plan item** | BH-03 in `02-fix-plan.md` §9 (DECISION, DEFERRED) |

```php
class BaDashboardController extends Controller
{
    /*
     * Colour-band edges for a score badge, as fractions of the scale's range
     * above its minimum. 0.25 and 0.50 reproduce exactly the 2 and 3 this
     * dashboard used to hard-code, for the seeded 1..5 scale, so nothing changes
     * colour there — but a 0..4 or 3..10 scale now bands on its own range
     * instead of on numbers that mean nothing on it.
     */
    private const BAND_DANGER_FRACTION = 0.25;

    private const BAND_WARN_FRACTION = 0.50;
```

**Evidence**
```
$ wc -l Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
2151 Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
$ grep -cE 'public function' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
6
```

#### BH-04 · H · CTL-02 — six methods exceed the length limits; two exceed 150 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *methods over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:1726-1935` (`reportsPage`, 209 lines), `:1090-1256` (`periodReportDetail`, 167), `:1397-1501` (`incidentsPage`, 104), `:1502-1623` (`behaviourPointsData`, 121), `:458-543` (`setup`, 85), `:1997-2081` (`teacherConsistency`, 84) |
| **Root cause** | The god-controller shape forces each page method to assemble every block (reportsPage alone builds the hub, the scores table, the category summaries, the period report, the audit trail and the analytics tabs — most of them unconditionally, even when the tab is not active). |
| **Consequence** | Long methods are hard to review; `reportsPage`'s unconditional work means every reports-page load runs several heavy aggregates (assessmentScores, category totals, audit-trail facets, at-risk register) even when the active tab shows none of them. |
| **Reproduce** | Static only — method-length measurement below. |
| **Fix approach** | Extract per-tab builders and gate them by the active tab (with the same permission guards that already exist for the P5 analytics). This is part of the split pass; defer per D3. |
| **Plan item** | BH-04 in `02-fix-plan.md` §9 (DECISION, DEFERRED) |

```php
    public function reportsPage(): View
    {
        Gate::authorize('tenant.behavioural-assessment.reports-page.viewAny');
        $activeTab = request('tab', 'reports-hub');
```

**Evidence**
```
$ awk '/^    (public|private) function/{m=$0; gsub(/.*function /,"",m); if(n!="") print n, s, NR-1, NR-1-s; n=m; s=NR} END{print n, s, NR, NR-s}' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php | tail -12
public function incidentsPage 1397 1501 104
private function teacherConsistency 1997 2081 84
private function demographicAnalytics 2082 2151 69
public function setup 458 543 85
private function periodReportDetail 1090 1256 167
public function reportsPage 1726 1935 209
private function behaviourPointsData 1502 1623 121
```

#### BH-05 · M · CTL-07 — `compact()` of 26 variables on reports-page

| Field | Value |
|---|---|
| **Rule** | CTL-07 (M) — *no `compact()` of more than ~15 variables; build a view model / array* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:1895-1905`, method `reportsPage()` |
| **Root cause** | 26 variables are passed to the reports view in one `compact()`, which makes the payload invisible to static analysis (a typo in a string silently passes `null`). |
| **Consequence** | A mistyped variable name renders a blank block on the page with no error; the array keys are only discoverable by counting. |
| **Reproduce** | Static only. |
| **Fix approach** | Replace the `compact()` call with an explicit array literal (paste-ready in the plan). |
| **Plan item** | BH-05 in `02-fix-plan.md` §6 |

```php
        return view('behaviouralassessment::pages.reports', compact(
            'totalAssessments', 'studentsRated', 'totalIncidents', 'openPeriods',
            'hubStatusCounts', 'recentPeriods', 'incidentTrend',
            'allPeriods', 'allClassSections', 'allCategories',
            'assessmentScores', 'categoryRatingTotals', 'categoryCriteriaDetail', 'ratingScaleMax',
            'categoryScoreStats', 'csFrozen',
            'periodReport', 'selectedPeriod', 'periodSectionBreakdown', 'periodStudents',
            'auditStats', 'auditFacets',
            'auditLog',
            'atRisk', 'consistency', 'demographics'
        ));
```

**Evidence**
```
$ sed -n '1895,1905p' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php | grep -c "'[a-zA-Z]*'"
26
```

#### BH-06 · L · CTL-08 — the `request()` helper is used 98 times instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:394-397` (and 98 call sites across the file) |
| **Root cause** | The page methods take no `Request` parameter and read filters through the global `request()` helper (`request('tab')`, `request('search')`, `request()->filled(...)`, …). |
| **Consequence** | The methods are coupled to the global request state and are painful to call outside an HTTP context (e.g. in the deferred split pass). |
| **Reproduce** | Static only. |
| **Fix approach** | Inject `Request` into the six public methods and thread it into the private helpers. A whole-file codemod; deferring it to the split pass avoids touching the same lines twice. |
| **Plan item** | none — see plan §10 |

```php
    public function masters(): View
    {
        Gate::authorize('tenant.behavioural-assessment.masters.viewAny');
        $activeTab = request('tab', 'rating-scales');
```

**Evidence**
```
$ grep -cE '\brequest\(' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
98
```

### F7 — Models

clean — every BA model and service this controller reaches is already owned by another report and is listed as `↗ linked` in §3. Bread-and-butter usage was checked here (not re-audited): relations referenced in the views are all eager-loaded by the controller (`BaAssessment::with(['period','subject','classSection.class','classSection.section'])`, `BaIncident::with(['student','reportedBy.user','category'])`, `BaFrameworkSnapshot::with(['period:id,name,status','capturedBy:id,name'])`, `BaScoreRun::with(['period:id,name','triggeredBy:id,name'])`, etc.), the raw `ba_assessment_ratings` joins carry `whereNull('deleted_at')` soft-delete guards, and the `ratingsQuery` shape (`select('student_id')`, paginated on `['student_id']`) matches what `_ratings.blade.php` reads (`$row->student_id`). The two unowned models this report audits — `BaScoreRun` (103 lines) and `BaFrameworkSnapshot` (80 lines) — both declare `$fillable`, cast every boolean/date/JSON/integer column, have typed relations and `UPDATED_AT = null` with `created_at` cast; both tables exist in the tenant DB (`ba_score_runs` 2 rows, `ba_framework_snapshots` 1 row). Nothing to fix.

### F8 — Services and jobs

#### BH-07 · M · SVC-02 — services are resolved per call with `app(...)` instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection — not `app(Foo::class)` mid-method* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:78-84` and 9 call sites (`app(BehaviouralScoreService::class)` / `app(BaFrameworkSnapshotService::class)` / `app(BaReviewSignalService::class)` at lines 80, 84, 329, 357, 675, 902, 1176, 1847, 2004) |
| **Root cause** | The controller resolves `BehaviouralScoreService`, `BaFrameworkSnapshotService` and `BaReviewSignalService` inside methods. Because each `app()` call builds a fresh instance, the services' internal memoisation (e.g. `BaFrameworkSnapshotService::$memo` in `frameworkFor()`) is lost between call sites within the same request, so the same framework lookup can run more than once (e.g. `resolveScale()` + `dashboardScores()` + `reportsPage()` + `teacherConsistency()` on one screen). |
| **Consequence** | A school-wide dashboard request can recompute the same locked-framework snapshot lookup several times; the class is also harder to construct in the split pass. |
| **Reproduce** | Static only — count the `app(...)` call sites and note the memo is per-instance. |
| **Fix approach** | Add a constructor that receives the three services and store them as properties; replace the nine call sites. Defer with the split pass to avoid churn, or do it now — see plan §9. |
| **Plan item** | BH-07 in `02-fix-plan.md` §9 (DECISION) |

```php
    private function resolveScale(?BaAssessmentPeriod $period, ?int $classId = null): array
    {
        $scale = app(BehaviouralScoreService::class)->scaleForPeriod($period, $classId);
```

**Evidence**
```
$ grep -nE '\bapp\([A-Za-z\\]' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
80:        $scale = app(BehaviouralScoreService::class)->scaleForPeriod($period, $classId);
84:        $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($period);
329:            $frozen = app(BaFrameworkSnapshotService::class)->lockedFramework($model);
357:            $config = app(BehaviouralScoreService::class)->configFor((int) $period['session_id']);
675:            'reviewSignals' => app(\Modules\BehaviouralAssessment\Services\BaReviewSignalService::class)->forAssessments($reviewQueue->getCollection()),
902:        $scoreService = app(BehaviouralScoreService::class);
1176:        $framework = app(BaFrameworkSnapshotService::class)->frameworkFor($period);
1847:        $csFrozen = app(BaFrameworkSnapshotService::class)->lockedFramework($csPeriod);
2004:        $config = app(BehaviouralScoreService::class)->configFor((int) $period->academic_session_id) ?? $this->activeConfig();
```

### F9 — Queries and performance

#### BH-08 · M · QRY-05 — the Ratings tab builds whole-scope per-student maps instead of only the visible page's

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate in SQL: `->get()->groupBy()` over a whole table is a perf trap* (also QRY-02) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:904-919` and `:936-939` (`ratingScoreMapQuery`, `ratingDetailMapQuery`) |
| **Root cause** | When the Ratings tab is open with no class filter, `ratingStudentIds()` returns every current student ("everyone"), and the two map builders then `->get()` the whole `ba_assessment_ratings` (or `ba_computed_scores`) set for those students and group in PHP — while the page shows a 10-student paginator. `ratingDetailMapQuery` additionally eager-loads `criterion` and `ratingLevel` for every rating row. On the audited tenant that is 21,996 rating rows fetched to render 10 students. |
| **Consequence** | The tab's first open (default scope) costs one large unfiltered fetch that grows with every rating saved; memory and latency scale with total ratings, not with the page. |
| **Reproduce** | Open `/behavioural-assessment/assessments-page?tab=ratings` with no `rat_class_id`; the query log shows the full ratings table loaded once for the maps. |
| **Fix approach** | Scope the three maps to the paginated page's student ids (they are already keyed by student id, so the blade and the `@json($ratingDetailMap)` client lookup are unaffected), or paginate the detail map. This touches method signatures + the caller; defer with the split pass or implement now — see plan §9. |
| **Plan item** | BH-08 in `02-fix-plan.md` §9 (DECISION) |

```php
        return BaAssessmentRating::with(['criterion.category'])
            ->whereIn('student_id', $studentIds)
            ->whereNotNull('rating_value')
            ->whereHas('assessment', fn ($q) => $q->when($periodId, fn ($q) => $q->where('period_id', $periodId)))
            ->get()
            ->groupBy('student_id')
            ->map(function ($ratings) use ($scoreService, $scale) {
                $byCat = $ratings->groupBy(fn ($r) => $r->criterion?->category_id);
```

**Evidence**
```
$ sed -n '904,919p' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
        return BaAssessmentRating::with(['criterion.category'])
            ->whereIn('student_id', $studentIds)
            ->whereNotNull('rating_value')
            ->whereHas('assessment', fn ($q) => $q->when($periodId, fn ($q) => $q->where('period_id', $periodId)))
            ->get()
            ->groupBy('student_id')
            ->map(function ($ratings) use ($scoreService, $scale) {
                $byCat = $ratings->groupBy(fn ($r) => $r->criterion?->category_id);
...
$ php artisan tinker --execute '... \DB::table("ba_assessment_ratings")->count() ...'
ba_assessment_ratings=21996
```

QRY-08 (leading-wildcard LIKE, 16 scanner hits): checked, not a finding — the wildcard searches run on `students.first_name/last_name/admission_no` (~1.4k rows) and `ba_incidents` (24 rows on the audited tenant); the rulebook allows these on small tables. QRY-11 (interpolated raw SQL at lines 2115/2122): checked, not a finding — the interpolated column names come from the private `DEMOGRAPHIC_DIMENSIONS` constant and the `$dimension` is whitelisted against `$enabled` before use, so no user input reaches the raw SQL. QRY-13 (paginators without `->withQueryString()`): checked, not a finding — every paginator's links are built with `->appends(...)->links()` in the blades (or `->appends(request()->except(...))` on the controller for the audit trail / period report / at-risk lists), so filters survive pagination (`grep -rn 'appends(' resources/views/pages/partials` shows all 20 paginator render sites). QRY-01 (query in a loop): checked, not present — `decoratePeriodStudents`, `snapshotIntegrity`, `teacherConsistency` and the loop-based decoders all read from pre-fetched keyed collections; `BaFrameworkSnapshotService::verify()` is pure (no query per snapshot, confirmed in the linked service). QRY-15 candidates: checked, not a finding — the unbounded `->get()` calls target master-data dropdowns (categories, classes, rating scales, academic sessions), not record lists.

### F10 — Views

#### BH-10 · M · VIEW-01 — `_witnesses.blade.php` runs two model queries inside the template

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (M, lowered from H) — *no queries in Blade: pass data from the controller* (severity lowered: two bounded lookups, not per-row, result correct — this is architecture/latency debt, not a wrong answer) |
| **Where** | `Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_witnesses.blade.php:122-131` |
| **Root cause** | The witnesses tab needs student and staff names for the witness ids in the current page, so the lookup was written in an `@php` block directly inside the blade ("the controller that builds $witnesses is shared with other tabs, so the lookup lives here"). |
| **Consequence** | Every render of the witnesses tab issues two extra queries from the template layer; a future refactor of the page layout or a change to the models behind `Student`/`Employee` can break the page at compile time in ways the controller cannot protect against. |
| **Reproduce** | Open `/behavioural-assessment/incidents-page?tab=witnesses` with witness rows; the debug bar shows the two queries originating from the blade's `@php`. |
| **Fix approach** | Compute the two maps in `incidentsPage()` (it already has `$witnesses`) and pass `witnessStudentMap` / `witnessStaffMap` to the view; the blade then reads the variables. |
| **Plan item** | BH-10 in `02-fix-plan.md` §7 |

```php
    @php
        // Witness names in two queries for the whole page, not one per row. The controller that
        // builds $witnesses is shared with other tabs, so the lookup lives here.
        $wRows = $witnesses->getCollection();
        $wStudents = \Modules\StudentProfile\Models\Student::whereIn('id', $wRows->where('witness_type', 'student')->pluck('witness_id')->all())
            ->get()->keyBy('id');
        $wStaff = \Modules\SchoolSetup\Models\Employee::with('user')
            ->whereIn('id', $wRows->where('witness_type', '!=', 'student')->pluck('witness_id')->all())
            ->get()->keyBy('id');
    @endphp
```

**Evidence**
```
$ grep -rnE "DB::|::where\(|->get\(\)" Modules/BehaviouralAssessment/resources/views/pages/partials/incidents/_witnesses.blade.php
126:        $wStudents = \Modules\StudentProfile\Models\Student::whereIn('id', $wRows->where('witness_type', 'student')->pluck('witness_id')->all())
127:            ->get()->keyBy('id');
128:        $wStaff = \Modules\SchoolSetup\Models\Employee::with('user')
129:            ->whereIn('id', $wRows->where('witness_type', '!=', 'student')->pluck('witness_id')->all())
130:            ->get()->keyBy('id');
```

Rest of F10 clean — no `{!! !!}` anywhere in the pages tree, all 58 reached blades compile and lint (evidence below), the relations used in `@foreach` are the ones the controller eager-loads, and row actions use `x-backend.table.action` with permission attributes.

```
$ php artisan tinker --execute '<compile every reached blade + php -l the output>'
compiled+linted OK: 58
bad: 0
```

### F11 — Security and tenancy

clean — no `env()` outside config (grep: none), no debug leftovers (`dd`/`dump`/`ray`/`phpinfo`: none), no user text through `{!! !!}`, no hard-coded ids (`?? N` matches are scale/config defaults, not identity ids), and the dashboard cache is properly tenant-scoped: `BaDashboardCache` builds every key as `ba:dashboard:<tenantId>:v<version>:<name>` because the `CacheTenancyBootstrapper` is disabled estate-wide — the scanner's TEN-02 hits are false positives from the helper methods not showing the concatenation:

```
$ sed -n '26,62p' Modules/BehaviouralAssessment/app/Support/BaDashboardCache.php
    private static function tenantId(): string
    {
        return (string) (function_exists('tenant') ? (tenant('id') ?? 'central') : 'central');
    }
    private static function versionKey(): string
    {
        return 'ba:dashboard:'.self::tenantId().':version';
    }
    ...
        $key = 'ba:dashboard:'.self::tenantId().':v'.self::version().':'.$name;
```

### F12 — Style

#### BH-11 · L · STY-04 — emoji markers in comments and a copy-pasted docblock

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no copy-pasted docblocks* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php:736,864,889,1080,1932` (`⚠` glyphs) and `:1608-1613` (a docblock describing `outboxData` stacked above `interventionCaseData`, which has its own docblock) |
| **Root cause** | Warning glyphs were used to call out subtle traps inside comments, and when `outboxData()` was split out of the incidents page its docblock stayed behind, above `interventionCaseData()`. |
| **Consequence** | Inconsistent comment style; the orphaned docblock at 1608-1613 describes `outboxData` while sitting on `interventionCaseData`, so the reader of the latter sees the wrong `@return` shape. |
| **Reproduce** | Static only. |
| **Fix approach** | Remove the `⚠ ` prefix from the five comment lines and delete the orphaned docblock lines 1608-1613. |
| **Plan item** | BH-11 in `02-fix-plan.md` §8 |

```php
    /**
     * Notification Outbox list + per-status counts for incidentsPage(). Returns an empty
     * paginator and zero counts when the viewer lacks notifications.view (the tab is hidden then).
     *
     * @return array{0: LengthAwarePaginator, 1: array<string, int>}
     */
    /**
     * Case-management data for the Incidents page (BA v3 P4, BRD screen 27, BR-BA-080).
```

**Evidence**
```
$ grep -n "⚠" Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php | cut -d: -f1 | tr '\n' ' '; echo
736 864 889 1080 1932
$ sed -n '1608,1613p' Modules/BehaviouralAssessment/app/Http/Controllers/BaDashboardController.php
    /**
     * Notification Outbox list + per-status counts for incidentsPage(). Returns an empty
     * paginator and zero counts when the viewer lacks notifications.view (the tab is hidden then).
     *
     * @return array{0: LengthAwarePaginator, 1: array<string, int>}
     */
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There is exactly one mutating path in the controller — `demographicAnalytics()` (the reports-page demographics tab) — which writes one `ba_audit_log` row.

| # | Question | `demographicAnalytics()` (ba_audit_log insert) |
|---|---|---|
| 1 | Can a write overwrite data it should not? | ok — single append-only insert; nothing is updated or reset |
| 2 | Is anything deleted before its replacement is stored? | ok — no deletes anywhere in the controller |
| 3 | Duplicate implementations of one operation? | ok — one analytics implementation; grade/score computation lives in `BehaviouralScoreService` (owned elsewhere) and is only read here |
| 4 | Soft-delete × unique index trap? | ok — n/a for a single audit insert |
| 5 | Race? | ok — a single insert; a score recompute during the request could change the underlying numbers between the query and the audit insert, but the audit row records what was rendered (the same array), so no corruption |
| 6 | Authorization hole? | BH-02 — the write rides a GET; it is gated (`demographic-analytics.view`) but the gate does not make a GET write acceptable |
| 7 | Does any message lie? | ok — `'Demographic analytics run'` and the logged filters (`period_id`, `dimension`, `min_group`, `groups`) match what ran |
| 8 | Dead feature? | ok — opt-in via `allowed_demographics_json`; the tab computes when enabled and a period is chosen |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaAuditLogController.php` | `BaDashboardController` reuses its public `EAGER` const and static `contextLookups()` (lines 1012, 1068). Works; it is worth extracting the audit-trail query building into a service when the module is reshaped, so one controller does not depend on another controller's statics. | STY/CTL-06 (informational) | split pass / module owner |
| Shared components `x-backend.*`, layouts, `config/permissionslist.php` | No defect found; the permission keys referenced by the gates (`dashboard`, `masters`, `setup`, `assessments-page`, `incidents-page`, `reports-page`, `framework-snapshots`, `notifications`, `intervention-cases`, `behaviour-points`, `reports`, `teacher-consistency`, `demographic-analytics`) all exist in config. | — | — |

## 8. Not covered, and why

- **Browser rendering** — the six pages were not opened in a browser; tab switches, chart drawing, the `@json($ratingDetailMap)` client lookup and the modal flows were verified by reading the blades and controller only.
- **The Demographics write end-to-end** — the audit insert on GET (BH-02) is proven statically (call site + the gate); it was not executed over HTTP (this audit is read-only and D4 forbids test runs).
- **Internals of linked services** — `BehaviouralScoreService`, `BaFrameworkSnapshotService`, `BaReviewSignalService`, `BaInterventionCaseService`, `BaBehaviourPointService` and the BA models are audited in their owner reports; only this controller's usage was checked here.
- **Behaviour Points tab live flow** — `ba_behaviour_points` has 0 rows and the feature is off on the audited tenant (`is_behaviour_points_enabled` 0), so `behaviourPointsData()`'s enabled branch was read, not executed.
- **Pagination UX on every filter** — verified statically that each paginator's links carry `appends(...)`; the visual result was not clicked through.