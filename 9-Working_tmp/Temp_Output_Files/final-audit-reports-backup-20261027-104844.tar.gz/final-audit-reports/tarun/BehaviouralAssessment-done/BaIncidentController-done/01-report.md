# Final Audit — BehaviouralAssessment / BaIncidentController

**Audited:** 2026-10-12 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php` (581 lines, 20 public methods incl. `__construct`, 19 routed)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/behavioural-assessment/incidents` (index → redirects to `/behavioural-assessment/incidents-page?tab=log`); `/behavioural-assessment/incidents/create`; `/behavioural-assessment/incidents/{incident}` (show); `/behavioural-assessment/incidents/{incident}/edit`; `/behavioural-assessment/incidents/{incident}/timeline`; `/behavioural-assessment/incidents/{incident}/witnesses/{witness}/statement` (GET reads, POST saves); `/behavioural-assessment/incidents/trash` |
| Menu path | Behavioural Assessment → Incidents (`glb_menus` id 304, route `behavioural-assessment.incidents-page`, permission `tenant.behavioural-assessment.incidents-page.viewAny`) |
| Who uses it | Roles that hold the permission, measured in `sys_role_has_permissions_jnt` on test.localhost — `viewAny`/`view`/`create`/`update`/`delete`: **Super Admin, School Admin**; `witness-confidential` and `escalate` are additionally held by **Principal** |
| What a user does here | Log a behaviour incident (positive reinforcement or negative incident) about one student, optionally attaching evidence files and naming students/staff as witnesses. Edit the mutable parts of an incident (severity escalation, follow-up date, witness list, intervention list). Move it along its lifecycle (open → under review → action taken → resolved → closed), record/revise witness statements, append follow-up notes, add/remove applied interventions, and cancel an incident with a reason. |
| Tables written | `ba_incidents`, `ba_incident_attachments`, `ba_incident_followups`, `ba_incident_witnesses_jnt`, `ba_incident_intervention_jnt`, `ba_audit_logs` (via `BaAuditLog::log`), `sys_activity_logs` (via the `activityLog()` helper) |
| Tables read | the five `ba_incident*` tables above, `ba_audit_logs`, `ba_categories`, `ba_criteria`, `ba_interventions`, `ba_configs`, `sch_org_academic_sessions_jnt`, `std_students`, `sch_employees`, `sys_users` |
| Live data | tenant test.localhost — `ba_incidents` 24 live / 0 trashed; `ba_incident_attachments` 0 live / 0 trashed; `ba_incident_followups` 2 live (no `deleted_at` column); `ba_incident_witnesses_jnt` 18 live / 0 trashed; `ba_incident_intervention_jnt` 30 live / 0 trashed |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready as-is**: it carries one true blocker (evidence files are written to disk *inside* the database transaction, so a rollback leaves orphaned files) and two high-severity issues (the `restore` action changes state over **GET**, and the incident detail page runs a database query inside its Blade template). The good news is that the hard part is done well — authorization is present on every routed method, permission names are declared and seeded, the write rules (immutable core facts, escalate-only severity, diffed witness/intervention links, append-only follow-ups, cancel-not-delete) live in three services and are respected. The single worst finding is **BAI-01**: `store()` uploads each attachment to the private disk from inside `DB::transaction(...)`, so any failure after the first file (or a rollback) leaves a file on disk with no database row — a silent storage leak and an evidence-integrity risk. Effort to clear the plan: **M** (roughly one developer-day; most items are mechanical, two are decisions).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 13 | 6 | 7 | 22 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | BAI-02, BAI-03 | F8 Services/Jobs | BAI-14, BAI-15, BAI-16 |
| F2 Transactions/Audit | BAI-01, BAI-04, BAI-05, BAI-06 | F9 Queries/Perf | BAI-13, BAI-17, BAI-18 |
| F3 Authorization | BAI-07 | F10 Views | BAI-19, BAI-20 |
| F4 Validation | BAI-08 | F11 Security/Tenancy | BAI-21 |
| F5 Routes | BAI-09 | F12 Style | BAI-22 |
| F6 Controller shape | BAI-10, BAI-11, BAI-12 | F13 Deep read | see table — no new IDs |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php` | controller | 581 | this report | ✅ |
| 2 | `Modules/BehaviouralAssessment/app/Models/BaIncident.php` | model | 238 | this report | ✅ |
| 3 | `Modules/BehaviouralAssessment/app/Models/BaIncidentAttachment.php` | model | 61 | this report | ✅ |
| 4 | `Modules/BehaviouralAssessment/app/Models/BaIncidentFollowup.php` | model | 68 | this report | ✅ |
| 5 | `Modules/BehaviouralAssessment/app/Models/BaIncidentWitnessJnt.php` | model | 81 | this report | ✅ |
| 6 | `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php` | service | 633 | this report | ✅ |
| 7 | `Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php` | service | 124 | this report | ✅ |
| 8 | `Modules/BehaviouralAssessment/app/Services/BaWitnessService.php` | service | 200 | this report | ✅ |
| 9 | `Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentRequest.php` | FormRequest | 216 | this report | ✅ |
| 10 | `Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentCancelRequest.php` | FormRequest | 38 | this report | ✅ |
| 11 | `Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentFollowupRequest.php` | FormRequest | 72 | this report | ✅ |
| 12 | `Modules/BehaviouralAssessment/app/Http/Requests/BaIncidentTransitionRequest.php` | FormRequest | 46 | this report | ✅ |
| 13 | `Modules/BehaviouralAssessment/app/Http/Requests/BaWitnessStatementRequest.php` | FormRequest | 48 | this report | ✅ |
| 14 | `Modules/BehaviouralAssessment/resources/views/incident/create.blade.php` | view | 358 | this report | ✅ |
| 15 | `Modules/BehaviouralAssessment/resources/views/incident/edit.blade.php` | view | 327 | this report | ✅ |
| 16 | `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php` | view | 748 | this report | ✅ |
| 17 | `Modules/BehaviouralAssessment/resources/views/incident/timeline.blade.php` | view | 240 | this report | ✅ |
| 18 | `Modules/BehaviouralAssessment/resources/views/incident/trashed.blade.php` | view | 90 | this report | ✅ |
| 19 | `Modules/BehaviouralAssessment/resources/views/incident/_partials/_witness-picker.blade.php` | view partial | 96 | this report | ✅ |
| 20 | `Modules/BehaviouralAssessment/resources/views/incident/_partials/_witness-picker-scripts.blade.php` | view partial | 62 | this report | ✅ |
| 21 | `Modules/BehaviouralAssessment/app/Models/BaCriterion.php` | model | 91 | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 22 | `Modules/BehaviouralAssessment/app/Models/BaIntervention.php` | model | 93 | ↗ [tarun/BehaviouralAssessment-done/BaInterventionController-done](../BaInterventionController-done/01-report.md) | ↗ linked |
| 23 | `Modules/BehaviouralAssessment/app/Support/BaTriggerError.php` | support | 34 | ↗ [tarun/BehaviouralAssessment-done/BaBehaviourPointController-done](../BaBehaviourPointController-done/01-report.md) | ↗ linked |
| 24 | `Modules/BehaviouralAssessment/app/Support/BaActor.php` | support | 43 | ↗ [tarun/BehaviouralAssessment-done/BaCommentBankController-done](../BaCommentBankController-done/01-report.md) | ↗ linked |
| 25 | `Modules/BehaviouralAssessment/app/Models/BaIncidentInterventionJnt.php` | model | 118 | ↗ [tarun/BehaviouralAssessment-done/BaInterventionCaseController-done](../BaInterventionCaseController-done/01-report.md) | ↗ linked |
| 26 | `Modules/BehaviouralAssessment/app/Models/BaAuditLog.php` | model | 191 | ↗ [tarun/BehaviouralAssessment-done/BaAuditLogController-done](../BaAuditLogController-done/01-report.md) | ↗ linked |
| 27 | `Modules/BehaviouralAssessment/app/Models/BaCategory.php` | model | 118 | ↗ [tarun/BehaviouralAssessment-done/BaCategoryController-done](../BaCategoryController-done/01-report.md) | ↗ linked |
| 28 | `Modules/BehaviouralAssessment/app/Models/BaConfig.php` | model | 132 | not owned by any report | ↗ linked (cross-cutting — read-only use) |
| 29 | `Modules/StudentProfile/app/Models/Student.php` | other module | — | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController/01-report.md) | ↗ linked |
| 30 | `Modules/SchoolSetup/app/Models/Employee.php` | other module | — | common (other module) | ❌ not audited here |
| 31 | `Modules/BehaviouralAssessment/routes/web.php` | route file | 172 | common (shared) | ✅ routes reviewed |
| 32 | `config/permissionslist.php` | config | — | common (shared) | ✅ names verified |

No in-scope file appears in a module `PRE-APPLIED-*.md`. `_create-fields.blade.php` sits in the incident folder but is only included by `BaDashboardController::incidentsPage` (`pages/partials/incidents/_create-modal.blade.php`), so it is out of scope for this controller.

## 4. Routes

```
GET|HEAD behavioural-assessment/incidents                        behavioural-assessment.incidents.index               BaIncidentController@index
POST    behavioural-assessment/incidents                        behavioural-assessment.incidents.store               BaIncidentController@store
GET|HEAD behavioural-assessment/incidents/create                 behavioural-assessment.incidents.create              BaIncidentController@create
GET|HEAD behavioural-assessment/incidents/criteria/{category}    behavioural-assessment.incidents.criteria            BaIncidentController@getCriteria
GET|HEAD behavioural-assessment/incidents/trash                  behavioural-assessment.incidents.trashed             BaIncidentController@trashed
DELETE  behavioural-assessment/incidents/{id}/force-delete      behavioural-assessment.incidents.forceDelete         BaIncidentController@forceDelete
GET|HEAD behavioural-assessment/incidents/{id}/restore           behavioural-assessment.incidents.restore             BaIncidentController@restore
GET|HEAD behavioural-assessment/incidents/{incident}             behavioural-assessment.incidents.show                BaIncidentController@show
PUT|PATCH behavioural-assessment/incidents/{incident}             behavioural-assessment.incidents.update              BaIncidentController@update
DELETE  behavioural-assessment/incidents/{incident}             behavioural-assessment.incidents.destroy             BaIncidentController@destroy
POST    behavioural-assessment/incidents/{incident}/cancel      behavioural-assessment.incidents.cancel              BaIncidentController@cancel
GET|HEAD behavioural-assessment/incidents/{incident}/edit        behavioural-assessment.incidents.edit                BaIncidentController@edit
POST    behavioural-assessment/incidents/{incident}/follow-up   behavioural-assessment.incidents.follow-up           BaIncidentController@followUp
POST    behavioural-assessment/incidents/{incident}/interventions behavioural-assessment.incidents.interventions.add   BaIncidentController@addIntervention
DELETE  behavioural-assessment/incidents/{incident}/interventions/{jnt} behavioural-assessment.incidents.interventions.remove BaIncidentController@removeIntervention
GET|HEAD behavioural-assessment/incidents/{incident}/timeline    behavioural-assessment.incidents.timeline            BaIncidentController@timeline
POST    behavioural-assessment/incidents/{incident}/transition  behavioural-assessment.incidents.transition          BaIncidentController@transition
GET|HEAD behavioural-assessment/incidents/{incident}/witnesses/{witness}/statement behavioural-assessment.incidents.witnesses.statement BaIncidentController@witnessStatement
POST    behavioural-assessment/incidents/{incident}/witnesses/{witness}/statement behavioural-assessment.incidents.witnesses.statement.store BaIncidentController@recordWitnessStatement
```

Unrouted public methods: none. Every public method except `__construct` is routed (19 routed actions); `destroy()` and `forceDelete()` are routed but deliberately disabled (they `abort(403)` unconditionally — BR-BA-072 "cancel, never delete").

Route-model-binding check (§3.3.1): `parameterNames()` are `show/update/edit/cancel/follow-up/timeline/transition/witnesses = ["incident"]`, `interventions.remove = ["incident","jnt"]`, `restore = ["id"]`. Only `removeIntervention(BaIncident $incident, int $jntId)` and the `witness*` methods' `$witness` use a name that lets binding resolve; the other methods take `int $id` while the parameter is literally named `{incident}` and rely on positional passing. This works (Laravel's `ControllerDispatcher` passes route values positionally and coercively), but it is the subject of BAI-10.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `__construct` | 49 | — | — | — | — | — | — |
| `index` | 55 | GET /behavioural-assessment/incidents | `tenant.behavioural-assessment.incidents.viewAny` | none | none | none | clean |
| `create` | 62 | GET /incidents/create | `...incidents.create` | none | none | none (reads `formOptions`) | BAI-13 |
| `store` | 78 | POST /incidents | `...incidents.create` | controller | `'Stored'` (line 113, after commit) | ba_incidents, ba_incident_witnesses_jnt, ba_incident_intervention_jnt, ba_incident_attachments, ba_audit_logs | BAI-01, BAI-02, BAI-04, BAI-08 |
| `edit` | 120 | GET /{incident}/edit | `...incidents.update` | none | none | none | clean |
| `update` | 151 | PUT/PATCH /{incident} | `...incidents.update` | controller | `'Updated'` (line 165, after commit) | ba_incidents, jnt tables, ba_audit_logs | BAI-04 |
| `destroy` | 177 | DELETE /{incident} | `abort(403)` | none | none | none | clean (disabled by design) |
| `cancel` | 183 | POST /{incident}/cancel | `...incidents.delete` | controller | `'Cancelled'` (line 194, after commit) | ba_incidents, ba_audit_logs | BAI-04 |
| `trashed` | 208 | GET /incidents/trash | `...incidents.restore` | none | none | none | clean |
| `restore` | 219 | GET /{id}/restore | `...incidents.restore` | controller | `'Restored'` (line 228, inside tx) | ba_incidents, sys_activity_logs | BAI-06, BAI-09 |
| `forceDelete` | 245 | DELETE /{id}/force-delete | `abort(403)` | none | none | none | clean (disabled by design) |
| `show` | 250 | GET /{incident} | `...incidents.view` | none | none | none (reads) | BAI-17, BAI-19, BAI-20 |
| `transition` | 299 | POST /{incident}/transition | `...incidents.update` | controller | `'StatusChanged'` (line 318, after commit) | ba_incidents, jnt tables, ba_audit_logs | BAI-04 |
| `witnessStatement` | 335 | GET /{incident}/witnesses/{witness}/statement | `...incidents.view` | none | none | ba_audit_logs (read audit) | clean |
| `recordWitnessStatement` | 363 | POST /{incident}/witnesses/{witness}/statement | `...incidents.update` | controller | **none** | ba_incident_witnesses_jnt, ba_audit_logs | BAI-05 |
| `followUp` | 394 | POST /{incident}/follow-up | `...incidents.update` | controller | `'FollowedUp'` (line 410, after commit) | ba_incident_followups, ba_incidents, ba_audit_logs | BAI-04 |
| `timeline` | 418 | GET /{incident}/timeline | `...incidents.view` | none | none | none (reads) | BAI-11 |
| `addIntervention` | 431 | POST /{incident}/interventions | `...incidents.update` | controller | **none** | ba_incident_intervention_jnt | BAI-05, BAI-08 |
| `removeIntervention` | 464 | DELETE /{incident}/interventions/{jnt} | `...incidents.update` | controller | `'InterventionRemoved'` (line 480, after commit) | ba_incident_intervention_jnt | BAI-04, BAI-12 |
| `getCriteria` | 489 | GET /incidents/criteria/{category} | `...incidents.viewAny` | none | none | none (reads ba_criteria) | clean |

## 6. Findings

### F1 — Errors

#### BAI-02 · M · ERR-05 — the logger records the exception message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception object (`report($e)` / `['exception' => $e]`), not `$e->getMessage()` alone — the message loses the trace* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:520`, method `failed()`; and `:238`, method `restore()` |
| **Root cause** | Both log sites pass `'error' => $e->getMessage()` into `Log::error(...)` — a flat string with no stack trace, no file/line, no chain. |
| **Consequence** | When a write fails on production, the operator sees only the message text in the log and cannot see where it came from; debugging is guesswork. |
| **Reproduce** | Static only — the log line runs only on a failed write, so it needs a forced DB error. |
| **Fix approach** | Replace the array entry `['error' => $e->getMessage()]` with `['exception' => $e]` (or call `report($e)` and log only context). |
| **Plan item** | BAI-02 in `02-fix-plan.md` §3 |

```php
        Log::error('BaIncidentController::'.$method.' failed', $context + ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error\|getMessage" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
238:            Log::error('BaIncidentController::restore failed', ['error' => $e->getMessage()]);
520:        Log::error('BaIncidentController::'.$method.' failed', $context + ['error' => $e->getMessage()]);
```

#### BAI-03 · M · ERR-00 — every write is wrapped in a controller-level try/catch that D2 does not sanction

| Field | Value |
|---|---|
| **Rule** | ERR-00 (D1, no default severity) — under the settled Laravel idiom D1 there is **no** try/catch in controllers; D2 lists the only allowed catches (`\DomainException`; one truncate-then-rebuild catch; `SnapshotProtectionException` verbatim; service `report($e)` + fixed message). Mapping a DB trigger rejection is **not** among them. |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:100-111, 157-163, 188-192, 312-316, 373-382, 404-408, 451-457, 468-472` — one `try { DB::transaction(...) } catch (Throwable $e) { return $this->failed(...) }` per write, funnelled through `failed()` at `:505-527`. |
| **Root cause** | The module deliberately catches `Throwable` to translate a MySQL `SQLSTATE 45000` trigger message (`BA: …`) into a 422 form error via `BaTriggerError::message()`. This is the only place the friendly trigger text can reach the user (the central handler in `bootstrap/app.php` would render its generic error). It is centralised, consistent and re-throws `ValidationException`/`ModelNotFoundException`/`HttpExceptionInterface`, so ERR-02 is not violated — but it is still a controller try/catch outside the D2 list. |
| **Consequence** | No user-visible defect today. The risk is drift: each new method must remember to route through `failed()`, and the shape contradicts D1's one-renderer design. |
| **Reproduce** | Static only — verified by reading the eight `try {` sites. |
| **Fix approach** | **Decision** — either keep this as the module's documented ERR-01 exception (comment each catch naming ERR-01 + date), or move the trigger mapping into a custom exception handled in `bootstrap/app.php`. |
| **Plan item** | BAI-03 in `02-fix-plan.md` §9 (DECISION) |

```php
    private function failed(Throwable $e, string $method, Request $request, array $context = []): RedirectResponse|JsonResponse
    {
        if ($e instanceof ValidationException || $e instanceof ModelNotFoundException || $e instanceof HttpExceptionInterface) {
            throw $e;
        }
```

**Evidence**
```
$ grep -n "try {" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
100:        try {
157:        try {
188:        try {
223:        try {
312:        try {
373:        try {
404:        try {
451:        try {
468:        try {
```

### F2 — Transactions and audit

#### BAI-01 · B · TXN-03 — evidence files are written to disk inside the database transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B) — *no irreversible side effect (file write/delete, mail, HTTP) inside a transaction or before the write succeeds; do it after commit* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:100-108`, method `store()`; the side effect is `Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php` (`:50-86`) which calls `Storage::disk('local')->putFileAs(...)` at `:56`. |
| **Root cause** | `store()` creates the incident **and** uploads every attachment from inside the same `DB::transaction` closure. `putFileAs()` writes a file immediately; if a later file throws, or the transaction rolls back for any reason, the already-written files stay on the private disk with no `ba_incident_attachments` row. |
| **Consequence** | Orphaned evidence files accumulate in tenant storage (`<tenant>/behavioural-assessment/incidents/<id>/…`) forever — a silent storage leak and an evidence file with no owning incident record. |
| **Reproduce** | Log an incident with 2 attachments and force the second upload or the DB insert to fail; the first file remains in `storage/app/<tenant>/behavioural-assessment/incidents/<id>/`. |
| **Fix approach** | **Decision** — (a) stage the files before the transaction and delete them if it rolls back, (b) move uploads after commit and report partial evidence failures, or (c) accept and add a cleanup job. |
| **Plan item** | BAI-01 in `02-fix-plan.md` §1 (Blocker, DECISION) |

```php
        try {
            $incident = DB::transaction(function () use ($request, $reporter, $files) {
                $incident = $this->service->create($request->validated(), $reporter);
                foreach ($files as $file) {
                    $this->attachmentService->store($incident, $file, null, false, $reporter);
                }

                return $incident;
            });
        } catch (Throwable $e) {
            return $this->failed($e, 'store', $request);
        }
```

**Evidence**
```
$ grep -n "putFileAs" Modules/BehaviouralAssessment/app/Services/BaIncidentAttachmentService.php
56:        $path = Storage::disk(self::DISK)->putFileAs($dir, $file, Str::uuid()->toString().'.'.$ext);
```

#### BAI-04 · M · TXN-04 — `activityLog()` runs after the transaction commits, in six methods

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes — not after commit* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:100-113, 158-169, 189-197, 313-321, 405-413, 469-486` — `store()` line 113 (tx ends 108), `update()` line 165 (tx ends 160), `cancel()` line 194 (tx ends 192), `transition()` line 318 (tx ends 316), `followUp()` line 410 (tx ends 408), `removeIntervention()` line 480 (tx ends 472). |
| **Root cause** | Each write is committed by `DB::transaction(...)` and only then does the controller call the `activityLog()` helper, which writes `sys_activity_logs` in a separate statement. If that helper fails, the business write is already committed and the API/POST returns a 500 even though the change landed. |
| **Consequence** | The activity trail can silently miss a change, and a log failure is reported to the user as a failed operation even though the incident was modified. |
| **Reproduce** | Static only — the log call is outside every closure; see output below. |
| **Fix approach** | Move each `activityLog(...)` call inside its `DB::transaction` closure, after the service call (see plan §3 for the six paste-ready edits). |
| **Plan item** | BAI-04 in `02-fix-plan.md` §3 |

```php
        activityLog($incident, 'Stored', ['message' => 'BaIncident was stored.']);
```

**Evidence**
```
$ grep -n "activityLog" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
113:        activityLog($incident, 'Stored', ['message' => 'BaIncident was stored.']);
165:        activityLog($incident, 'Updated', [
194:        activityLog($incident, 'Cancelled', [
228:                activityLog($incident, 'Restored', ['message' => 'BaIncident was restored.']);
318:        activityLog($incident, 'StatusChanged', [
410:        activityLog($incident, 'FollowedUp', [
480:        activityLog($incident, 'InterventionRemoved', [
```

Note: `restore()` (line 228) already places its `activityLog()` inside the transaction — the six methods above do not.

#### BAI-05 · M · TXN-04 — two write paths record no activity log at all

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) / house A3 — *a mutation is described by an activity-log row* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:363-391` (`recordWitnessStatement`) and `:431-462` (`addIntervention`). |
| **Root cause** | Every other mutating method calls `activityLog(...)`, but these two do not. The service behind `addIntervention` (`BaIncidentService::createInterventionCase()`, `:610-632`) writes no `BaAuditLog` row either, so adding an intervention case leaves **no** audit trail of any kind; `removeIntervention` does log (`:480`). |
| **Consequence** | "Who added this corrective intervention to the incident, and when" cannot be answered from either the activity log or the module audit log — an audit gap on a safeguarding record. |
| **Reproduce** | Add an intervention from the incident detail page, then query `sys_activity_logs` and `ba_audit_logs` for the incident — nothing is written for the add. |
| **Fix approach** | Add an `activityLog(...)` call inside each transaction, mirroring `removeIntervention()`'s event shape. |
| **Plan item** | BAI-05 in `02-fix-plan.md` §3 |

```php
        return $added
            ? back()->with('success', 'Intervention added.')
            : back()->with('error', 'That intervention is already applied to this incident.');
```

**Evidence**
```
$ grep -n "activityLog" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php | sed -n '1,40p'
113: activityLog(...)   # store
165: activityLog(...)   # update
194: activityLog(...)   # cancel
228: activityLog(...)   # restore
318: activityLog(...)   # transition
410: activityLog(...)   # followUp
480: activityLog(...)   # removeIntervention
(no line between 363 and 462 — recordWitnessStatement and addIntervention are absent)
```

#### BAI-06 · M · TXN-05 — `restore()` builds the HTTP response inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()`/`response()` after it* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:223-233`, method `restore()` |
| **Root cause** | The `DB::transaction` closure ends with `return redirect()->route(...)->with(...)`, so a `RedirectResponse` is constructed while the transaction is open; the `return` also exits the closure before any post-commit code could run. |
| **Consequence** | No user-visible defect, but it couples response construction to the transaction and is the documented anti-shape for TXN-05. |
| **Reproduce** | Static only — response object literal inside the closure. |
| **Fix approach** | Return the restored `BaIncident` from the closure and build the redirect afterwards. |
| **Plan item** | BAI-06 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($id) {
                $incident = BaIncident::onlyTrashed()->findOrFail($id);
                $incident->restore();

                activityLog($incident, 'Restored', ['message' => 'BaIncident was restored.']);

                return redirect()
                    ->route('behavioural-assessment.incidents.trashed')
                    ->with('success', 'Incident restored successfully.');
            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ sed -n '223,233p' Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
        try {
            return DB::transaction(function () use ($id) {
                $incident = BaIncident::onlyTrashed()->findOrFail($id);
                $incident->restore();

                activityLog($incident, 'Restored', ['message' => 'BaIncident was restored.']);

                return redirect()
                    ->route('behavioural-assessment.incidents.trashed')
                    ->with('success', 'Incident restored successfully.');
            });
```

### F3 — Authorization

#### BAI-07 · L · AUTH-04 — the same permission is checked twice on six write methods

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `BaIncidentController.php:80, 153, 185, 301, 365, 396`; the FormRequest `authorize()` runs first (`BaIncidentRequest:38-43`, `BaIncidentCancelRequest:18-21`, `BaIncidentTransitionRequest:21-24`, `BaWitnessStatementRequest:18-21`, `BaIncidentFollowupRequest:23-26`). |
| **Root cause** | Each write method's FormRequest already authorizes the CRUD permission derived from the HTTP verb (`AuthorizesTenantFeature::authorizeByCrudPermission`), and the controller then calls `Gate::authorize(...)` for the same action. |
| **Consequence** | None for the user; a small maintenance cost — two places must agree on the permission name. |
| **Reproduce** | Static only — see evidence. |
| **Fix approach** | Keep the FormRequest guard (it runs first) and drop the duplicate `Gate::authorize` in the six controller methods. Accepted as low priority. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted; the FormRequest guard runs first, the controller guard only adds a redirect shape) |

```php
        Gate::authorize('tenant.behavioural-assessment.incidents.create');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
57: Gate::authorize('tenant.behavioural-assessment.incidents.viewAny');
64: Gate::authorize('tenant.behavioural-assessment.incidents.create');
80: Gate::authorize('tenant.behavioural-assessment.incidents.create');
122: ...
153: ...
185: ...
...
```

### F4 — Validation and input

#### BAI-08 · M · VAL-02 — inline `$request->validate()` in two write methods

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest, not inline `$request->validate()` — except a one-field AJAX toggle* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:90-97` (`store()`, the attachment rules) and `:441-449` (`addIntervention()`, `intervention_id` + `notes`). |
| **Root cause** | `store()` validates the attachment upload inline on top of its `BaIncidentRequest`; `addIntervention()` has no FormRequest and validates two fields (plus a cross-field `Rule::exists()->whereNot(...)`) in the controller. Neither is a one-field toggle. |
| **Consequence** | The rules and their custom messages are split between the FormRequest and the controller, so the same input can be validated two different ways. |
| **Reproduce** | Static only. The cross-field rules were **executed** and behave correctly (evidence below), so this is a location/maintenance finding, not a rule bug. |
| **Fix approach** | **Decision** — add the attachment rules to `BaIncidentRequest` and create a `BaIncidentInterventionRequest`, or accept inline validation for these two. |
| **Plan item** | BAI-08 in `02-fix-plan.md` §9 (DECISION) |

```php
        $request->validate([
            'attachments' => ['nullable', 'array', 'max:5'],
            'attachments.*' => BaIncidentAttachmentService::fileRules(),
        ], [
            'attachments.max' => 'Attach at most 5 files when logging an incident.',
            'attachments.*.max' => 'An attachment may not be larger than 10 MB.',
            'attachments.*.mimes' => 'Allowed file types: '.implode(', ', BaIncidentAttachmentService::MIMES).'.',
        ]);
```

**Evidence** — cross-field rules executed against a realistic tenant payload (D4: no tests written; a read-only tinker probe):
```
CASE1 witness=subject errors: ["The student involved in the incident cannot also be listed as a witness."]
CASE2 polarity errors: ["A positive reinforcement must be linked to a positive-polarity category."]
CASE3 reward-on-negative errors: ["Reward interventions cannot be applied to a negative incident: Award/Certificate."]
```

### F5 — Routes

#### BAI-09 · H · RTE-01 — `restore` changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/BehaviouralAssessment/routes/web.php:117`; the controller method `restore()` (`BaIncidentController.php:219-242`). Rendered as a GET form by the shared component `resources/views/components/backend/table/action-trashed.blade.php:29-44`. |
| **Root cause** | The route is registered with `Route::get(...)`. The trashed-list action component reads the route's first verb and renders a plain `<form method="GET">` (no `@csrf`), so clicking Restore issues a GET that mutates `ba_incidents`. |
| **Consequence** | A link prefetcher, a browser back/forward, or an embedded `<img src>` pointing at `/behavioural-assessment/incidents/5/restore` restores a trashed incident without any CSRF token or intent. |
| **Reproduce** | Open `/behavioural-assessment/incidents/trash` and hover the Restore button (GET); or call the URL directly from an unauthenticated-of-intent context. |
| **Fix approach** | **Decision** — change the route to `Route::post(...)` (the shared component already adapts and adds `@csrf`); it is a route-file change and therefore needs Tarun's explicit tick. |
| **Plan item** | BAI-09 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED) |

```php
Route::get('incidents/{id}/restore', [BaIncidentController::class, 'restore'])->name('incidents.restore');
```

**Evidence**
```
$ grep -n "restore" Modules/BehaviouralAssessment/routes/web.php
117:Route::get('incidents/{id}/restore', [BaIncidentController::class, 'restore'])->name('incidents.restore');

$ grep -n "confirm-action-form-restore\|method=" resources/views/components/backend/table/action-trashed.blade.php
29:    <form action="{{ route($restoreRouteName, $restoreParams) }}"
30:          method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
```

### F6 — Controller shape

#### BAI-10 · M · CTL-03 — `findOrFail($id)` instead of route model binding, while the route parameter is already `{incident}`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding (`show(Homework $homework)`), not `$id` + `findOrFail`* |
| **Where** | `BaIncidentController.php:120, 151, 183, 250, 299, 394, 418, 431` — `edit/update/cancel/show/transition/followUp/timeline/addIntervention` all take `int $id` and call `BaIncident::findOrFail($id)`, yet the route parameter is named `{incident}`. |
| **Root cause** | The routes were declared as `{incident}` but the methods kept the old `int $id` signature, so binding never fires (a non-class parameter is spliced positionally); only `removeIntervention(BaIncident $incident, ...)` actually binds. |
| **Consequence** | No user-visible defect (positional passing works), but the `{incident}`/`$id` mismatch is fragile and would silently break if the parameter order changed; it also blocks the cleaner `abort(404)`/authorization flow. |
| **Reproduce** | Static only — `route:list` parameter names versus method signatures (evidence below). |
| **Fix approach** | **Decision** — convert the eight methods to `BaIncident $incident` binding in a dedicated pass (D3: deferred, broad mechanical refactor); `BaIncidentRequest::incident()` already handles a bound model (`$id instanceof BaIncident`). |
| **Plan item** | BAI-10 in `02-fix-plan.md` §9 (DECISION, deferred) |

```php
    public function show(int $id): View
    {
        Gate::authorize('tenant.behavioural-assessment.incidents.view');
        $incident = BaIncident::with([
            'student',
            'reportedBy.user',
            'category',
            'criterion',
            'interventions',
            'witnesses',
        ])->findOrFail($id);
```

**Evidence**
```
$ php artisan tinker --execute '... parameterNames() ...'
behavioural-assessment.incidents.show params=["incident"] methods=["GET","HEAD"]
behavioural-assessment.incidents.update params=["incident"] methods=["PUT","PATCH"]
behavioural-assessment.incidents.interventions.remove params=["incident","jnt"] methods=["DELETE"]
```

#### BAI-11 · M · CTL-05 — the same six-relation eager-load array is copy-pasted in `show()` and `timeline()`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload repeated in two methods* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:253-260` (`show()`) and `:421-424` (`timeline()`) |
| **Root cause** | Both methods load the incident with the same relations, but `show()` lists them one per line and `timeline()` lists them comma-packed — so the two lists can drift (they already differ only in formatting). |
| **Consequence** | A future relation added to one screen but not the other causes a lazy-load (N+1) or an undefined-relation error on the other screen. |
| **Reproduce** | Static only — identical relation set in both `with([...])` calls. |
| **Fix approach** | Extract the relation list to a private const or a small `incidentForDisplay(int $id): BaIncident` loader used by both. |
| **Plan item** | BAI-11 in `02-fix-plan.md` §5 |

```php
        $incident = BaIncident::with([
            'student', 'reportedBy.user', 'category', 'criterion',
            'interventions', 'witnesses',
        ])->findOrFail($id);
```

**Evidence**
```
$ grep -n "BaIncident::with" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
123:        $incident = BaIncident::with(['student', 'reportedBy.user', 'category', 'criterion', 'witnesses', 'interventions'])->findOrFail($id);
253:        $incident = BaIncident::with([
421:        $incident = BaIncident::with([
```

#### BAI-12 · L · CTL-08 — `removeIntervention()` uses the `request()` helper instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:471`, method `removeIntervention(BaIncident $incident, int $jntId)` |
| **Root cause** | The method has no `Request` parameter, so the `failed()` call passes the global `request()` helper. |
| **Consequence** | None for the user; inconsistent with every other method, which receive `Request`/FormRequest by injection. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `Request $request` as the first parameter and pass `$request` to `failed()`. |
| **Plan item** | BAI-12 in `02-fix-plan.md` §5 |

```php
            return $this->failed($e, 'removeIntervention', request(), ['id' => $incident->id]);
```

**Evidence**
```
$ grep -n "request()" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
471:            return $this->failed($e, 'removeIntervention', request(), ['id' => $incident->id]);
```

### F7 — Models

clean — `grep -n "protected \$table\|SoftDeletes" Modules/BehaviouralAssessment/app/Models/BaIncident*.php` shows all four owned models declare `$table` and use `SoftDeletes` only where the table has `deleted_at` (`BaIncidentFollowup` correctly omits it and sets `UPDATED_AT = null` with a `created_at` cast); all booleans/dates/decimals are cast; `BaIncident::interventions()` uses `->wherePivotNull('deleted_at')`; every table exists (live counts: `ba_incidents` 24, `ba_incident_attachments` 0, `ba_incident_followups` 2, `ba_incident_witnesses_jnt` 18). No Spatie `InteractsWithMedia` model in scope (TEN-01/MDL-05 not applicable).

### F8 — Services and jobs

#### BAI-14 · M · SVC-02 — `BaIncidentService::transition()` resolves a service with `app()` mid-method

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php:439`, method `transition()` |
| **Root cause** | `BaIncidentService` has no constructor and resolves `BaWitnessService` from the container only at the point of freezing witness rows on closure. |
| **Consequence** | No user-visible defect; it hides the dependency and makes the service harder to test/reason about. |
| **Reproduce** | Static only. |
| **Fix approach** | Inject `private readonly BaWitnessService $witnessService` in the constructor and call `$this->witnessService->freezeForIncident(...)`. |
| **Plan item** | BAI-14 in `02-fix-plan.md` §5 |

```php
        if ($to === BaIncident::STATUS_CLOSED && BaWitnessService::freezeOnClosure()) {
            app(BaWitnessService::class)->freezeForIncident($incident);
        }
```

**Evidence**
```
$ grep -n "app(BaWitnessService" Modules/BehaviouralAssessment/app/Services/BaIncidentService.php
439:            app(BaWitnessService::class)->freezeForIncident($incident);
```

#### BAI-15 · M · SVC-04 — two implementations of "record a witness statement"

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; two copies that disagree are a bug source* |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaWitnessService.php:77-120` (`record()`, used by the statement endpoint) and `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php:193-238` (`recordWitnessStatements()`, used by `update()`). |
| **Root cause** | The edit form writes statements through `BaIncidentService::recordWitnessStatements()`, while the statement modal writes through `BaWitnessService::record()`. They handle different fields — `record()` also sets `is_confidential`, `recordWitnessStatements()` does not — and they compute the audit `field` values differently (the older method emits `'recorded'`/`null` inverted), so the same action records different audit rows depending on the screen. |
| **Consequence** | A statement revised from the edit form and the same statement revised from the modal produce different audit-log entries and different confidentiality handling; the audit trail of a restricted read is unreliable. |
| **Reproduce** | Revise a witness statement from `/incidents/{id}/edit` (posts `witness_statements`) and from the statement modal (`/witnesses/{witness}/statement`), then compare `ba_audit_logs` rows. |
| **Fix approach** | **Decision** — route the edit form through `BaWitnessService::record()` too, or unify the audit semantics behind one method. |
| **Plan item** | BAI-15 in `02-fix-plan.md` §9 (DECISION) |

```php
    public function record(BaIncidentWitnessJnt $witness, string $statement, bool $isConfidential, Employee $recorder): void
```

**Evidence**
```
$ grep -rn "function recordWitnessStatements\|function record(" Modules/BehaviouralAssessment/app/Services
Modules/BehaviouralAssessment/app/Services/BaIncidentService.php:193:    public function recordWitnessStatements(BaIncident $incident, array $statements, ?Employee $recorder): void
Modules/BehaviouralAssessment/app/Services/BaWitnessService.php:77:    public function record(BaIncidentWitnessJnt $witness, string $statement, bool $isConfidential, Employee $recorder): void
```

#### BAI-16 · L · SVC-05 — session/config lookups are re-queried on every call inside one request

| Field | Value |
|---|---|
| **Rule** | SVC-05 (M) — *repeated lookups inside a request (status ids, settings) are memoised or cached once* (downgraded to L: each is a single cheap `value()` query on a small table) |
| **Where** | `BaIncidentService::currentEmployee()` (`:62-67`, called by the controller and again by `BaIncidentRequest::after()` and `BaIncidentFollowupRequest::after()`), `BaIncidentService::backdatingDays()` (`:70-79`, called by `BaIncidentRequest::rules()` **and** `messages()`), `BaWitnessService::freezeOnClosure()` (`:123-132`). |
| **Root cause** | Each static helper runs its own `OrganizationAcademicSession` + `BaConfig`/`Employee` query and caches nothing for the duration of the request. |
| **Consequence** | A create/edit page issues several extra identical queries; negligible at current data volumes but avoidable. |
| **Reproduce** | Static only — count the call sites below. |
| **Fix approach** | Memoise `currentEmployee()` and `backdatingDays()` in a static property keyed by user/session for the request. |
| **Plan item** | BAI-16 in `02-fix-plan.md` §6 |

```php
    public static function currentEmployee(): ?Employee
    {
        $userId = auth()->id();

        return $userId === null ? null : Employee::where('user_id', $userId)->first();
    }
```

**Evidence**
```
$ grep -rn "currentEmployee()\|backdatingDays()\|freezeOnClosure()" Modules/BehaviouralAssessment/app
... BaIncidentController.php (4x) BaIncidentService.php (4x) BaIncidentRequest.php (3x) BaIncidentFollowupRequest.php (1x) BaWitnessService.php (1x)
```

### F9 — Queries and performance

#### BAI-13 · M · QRY-15 — `BaIncident::formOptions()` loads every active student and employee for the create/edit form

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form* |
| **Where** | `Modules/BehaviouralAssessment/app/Models/BaIncident.php:229-237`, method `formOptions()`, called by `BaIncidentController::create()`/`edit()` and by `BaDashboardController::incidentsPage()`. |
| **Root cause** | Each option list is an unfiltered `->get()`. On test.localhost this pulls **1,824 active students** and **139 active employees** into memory and into the `<select>` markup on every render of the form. |
| **Consequence** | A large school's "Log Incident" page becomes slow and renders a multi-megabyte HTML select; the browser may hang while building the student dropdown. |
| **Reproduce** | Open `/behavioural-assessment/incidents/create` and watch the initial response size / time grow with the student roll. |
| **Fix approach** | **Decision** — replace the student/staff selects with a searchable (AJAX) picker, or at least add a cap/scope. Behaviour change, so Tarun chooses. |
| **Plan item** | BAI-13 in `02-fix-plan.md` §9 (DECISION) |

```php
        return [
            'students' => Student::where('is_active', true)->orderBy('first_name')->get(),
            'staffMembers' => Employee::with('user')->where('is_active', true)->orderBy('first_name')->get(),
            'categories' => BaCategory::whereNull('parent_id')->where('is_active', true)->orderBy('sort_order')->get(),
            'interventions' => BaIntervention::where('is_active', true)->orderBy('sort_order')->orderBy('name')->get(),
        ];
```

**Evidence**
```
$ php artisan tinker --execute '...counts...'
std_students(active)=1824
sch_employees(active)=139
ba_interventions(active)=12
```

#### BAI-17 · M · QRY-12 / CTL-10 — `show()` computes an unused witness collection and then re-runs the same two queries

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once* (with CTL-10 dead code: the result is never rendered) |
| **Where** | `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:262` (`resolveWitnessPeople()`, defined `:546-555`) and `:267` (`$this->witnessService->rows($incident)`); the view never references `$studentWitnesses`/`$staffWitnesses`. |
| **Root cause** | `resolveWitnessPeople()` runs one `Student::whereIn(...)` and one `Employee::with('user')->whereIn(...)`. `BaWitnessService::rows()` (`:167-170`) then runs the **same two queries** again. The `resolveWitnessPeople` result is passed to `show.blade.php` as `$studentWitnesses`/`$staffWitnesses`, which the template does not use. |
| **Consequence** | Every incident detail view issues two redundant database queries and ships two dead variables; the dead loader can silently diverge from the live one. |
| **Reproduce** | Open `/behavioural-assessment/incidents/{incident}` and count the `std_students`/`sch_employees` queries in the query log. |
| **Fix approach** | Delete the `resolveWitnessPeople()` call and method, and drop the two variables from `compact()`. |
| **Plan item** | BAI-17 in `02-fix-plan.md` §6 |

```php
        [$studentWitnesses, $staffWitnesses] = $this->resolveWitnessPeople($incident);
        $followups = $this->followupLog($incident);

        // Witness rows WITHOUT statement text: the text is fetched per witness by
        // witnessStatement(), so each disclosure is a deliberate, audited read (BR-BA-031).
        $witnessRows = $this->witnessService->rows($incident);
```

**Evidence**
```
$ grep -n "studentWitnesses\|staffWitnesses\|witnessRows" Modules/BehaviouralAssessment/resources/views/incident/show.blade.php
254:                        @if($witnessRows->isEmpty())
267:                                        @foreach($witnessRows as $w)
(no reference to $studentWitnesses or $staffWitnesses)
```

#### BAI-18 · L · QRY-07 — per-row `->save()` inside the witness/intervention diff loops

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes (`whereIn(...)->update()`/`insert()`) instead of `create()`/`update()` per row in a loop* (downgraded to L: the loop bound is the number of witnesses/interventions on **one** incident, and each iteration writes a per-row `BaAuditLog` row) |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaIncidentService.php:227-232` (`recordWitnessStatements`), `:509-518` (`syncWitnesses`), `:549-557` (`syncInterventions`) |
| **Root cause** | Each loop `forceFill(...)->save()`s one row at a time because each row carries a distinct audit entry and distinct values. |
| **Consequence** | For a typical incident (< 10 witnesses/interventions) this is a handful of statements; it only matters if a single incident ever links dozens of people. |
| **Reproduce** | Static only. |
| **Fix approach** | Accept — a bulk update would have to drop the per-row audit or batch the audit rows separately. |
| **Plan item** | none — see `02-fix-plan.md` §10 (accepted) |

```php
            $row->forceFill([
                'statement' => $text,
                'statement_recorded_by' => $text === null ? null : $recorder?->id,
                'statement_recorded_at' => $text === null ? null : now(),
                'updated_by' => $actorId,
            ])->save();
```

**Evidence**
```
$ grep -n "->save();" Modules/BehaviouralAssessment/app/Services/BaIncidentService.php
232:            ])->save();
518:            ])->save();
556:                $row->forceFill(['notes' => $note, 'updated_by' => $actorId])->save();
```

### F10 — Views

#### BAI-19 · H · VIEW-01 — the incident detail template runs a database query

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no queries in Blade (`Model::`, `->get()`); pass data from the controller* |
| **Where** | `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php:583-586` (inside the `@php` block `:578-587`) |
| **Root cause** | The "Add Intervention" modal's `<select>` options are built by an inline `BaIntervention::where(...)->get()` in the template, computing the forbidden intervention type there too. |
| **Consequence** | A query runs in the view layer on every detail page open, inside `@can(update)`; it also bypasses the controller's query budget and is invisible to query-count review. |
| **Reproduce** | Open `/behavioural-assessment/incidents/{incident}?` as a user with `incidents.update`; the intervention dropdown is populated by the template query. |
| **Fix approach** | Move the `$forbiddenType`/`$allInterventions` computation into `show()` and pass `$allInterventions` (and `$forbiddenType` if the view still needs it) to the template. |
| **Plan item** | BAI-19 in `02-fix-plan.md` §7 |

```php
        $forbiddenType = $incident->incident_type === \Modules\BehaviouralAssessment\Models\BaIncident::TYPE_POSITIVE
            ? \Modules\BehaviouralAssessment\Models\BaIntervention::TYPE_CORRECTIVE
            : \Modules\BehaviouralAssessment\Models\BaIntervention::TYPE_REWARD;
        $allInterventions = \Modules\BehaviouralAssessment\Models\BaIntervention::where('is_active', true)
            ->where('intervention_type', '!=', $forbiddenType)
            ->orderBy('sort_order')->orderBy('name')->get();
```

**Evidence**
```
$ grep -n "BaIntervention::where" Modules/BehaviouralAssessment/resources/views/incident/show.blade.php
583:        $allInterventions = \Modules\BehaviouralAssessment\Models\BaIntervention::where('is_active', true)
```

#### BAI-20 · L · VIEW-02 — `$incident->resolvedBy` is not eager-loaded on the detail page

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations used in the template are eager-loaded by the controller* (downgraded to L: a single `belongsTo`, one extra query for a resolved incident, not inside a loop) |
| **Where** | `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php:50-51` uses `$incident->resolvedBy`; `show()`'s `with([...])` list (`Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:253-260`) omits `resolvedBy`. |
| **Root cause** | `resolvedBy` was added to the resolved banner but not to the eager-load list. |
| **Consequence** | One lazy `sch_employees` query whenever a resolved incident is opened. |
| **Reproduce** | Open a resolved incident and watch the extra query. |
| **Fix approach** | Add `'resolvedBy.user'` to the `show()` eager-load list. |
| **Plan item** | BAI-20 in `02-fix-plan.md` §7 |

```php
                        @if($incident->resolvedBy)
                            by {{ $incident->resolvedBy->user?->name ?? 'Employee #'.$incident->resolved_by }}
```

**Evidence**
```
$ grep -n "resolvedBy" Modules/BehaviouralAssessment/resources/views/incident/show.blade.php Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
resources/views/incident/show.blade.php:50:                        @if($incident->resolvedBy)
resources/views/incident/show.blade.php:51:                            by {{ $incident->resolvedBy->user?->name ?? 'Employee #'.$incident->resolved_by }}
(the controller has no `resolvedBy` in any with([...]) list)
```

### F11 — Security and tenancy

#### BAI-21 · M · TEN-02 — the witness read-audit dedupe cache is keyed by witness id only, not by tenant

| Field | Value |
|---|---|
| **Rule** | TEN-02 (H) — *cache keys and static/in-memory caches include the tenant* (downgraded to M: it only bites on a long-lived worker, and the defect is a skipped audit row, not a disclosure) |
| **Where** | `Modules/BehaviouralAssessment/app/Services/BaWitnessService.php:40-41` (`private static array $auditedReads = []`) and `:63-67`. |
| **Root cause** | The static dedupe is keyed by `(int) $witness->id`. `BaActor::$systemIds` is correctly keyed by database name; this one is not. Under a persistent worker (Laravel Octane / a resident queue worker) the array survives across tenant switches, so tenant A's witness id 5 can suppress the read-audit row for tenant B's witness id 5. |
| **Consequence** | Under a persistent worker, a confidential-statement disclosure can go unlogged in `ba_audit_logs` — the read-audit guarantee (BR-BA-031) silently fails. |
| **Reproduce** | Static only — no Octane is configured in this estate today, so it cannot be exercised in the browser. |
| **Fix approach** | Key the static array by `tenant + witness id`, or reset it at the start of each request (a request-scoped instance property on the injected service rather than a static). |
| **Plan item** | BAI-21 in `02-fix-plan.md` §6 |

```php
    /** @var array<int, true> witness ids whose read was already audited in this request */
    private static array $auditedReads = [];
```

**Evidence**
```
$ grep -n "auditedReads" Modules/BehaviouralAssessment/app/Services/BaWitnessService.php
41:    private static array $auditedReads = [];
64:        if (! isset(self::$auditedReads[$id])) {
66:            self::$auditedReads[$id] = true;
```

### F12 — Style

#### BAI-22 · L · STY-04 — commented-out markup and two untyped private helpers

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no commented-out code; no copy-pasted docblocks* (plus CTL-04 return types, reported here as style because the helpers are private) |
| **Where** | `Modules/BehaviouralAssessment/resources/views/incident/show.blade.php:562-566` (a commented-out `<tr>` block longer than 3 lines); `Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php:530` (`followupLog()`) and `:573` (`witnessRows()`) declare no return type. |
| **Root cause** | A debug/leftover table row was commented out instead of deleted; two private helpers were written without return types while all public methods have them. |
| **Consequence** | Cosmetic and maintenance noise only. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete the commented block; add `: Collection` return types (the `Collection` import already exists). |
| **Plan item** | BAI-22 in `02-fix-plan.md` §8 |

```php
                                {{-- <tr>
                                    <td class="text-muted small fw-semibold bg-light">ID</td>
                                    <td class="small">#{{ $incident->id }}</td>
                                </tr> --}}
```

**Evidence**
```
$ grep -n "private function followupLog\|private function witnessRows" Modules/BehaviouralAssessment/app/Http/Controllers/BaIncidentController.php
530:    private function followupLog(BaIncident $incident)
573:    private function witnessRows(BaIncident $incident)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Legend: `ok` = checked, no defect; a `BAI-nn` cell = the finding that answers the question.

| Method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-del × unique? | 5 race? | 6 authz hole? | 7 lying message? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok (core facts written once) | BAI-01 (file before commit) | ok | ok (`uq_guard` virtual column makes live rows unique) | ok | ok | ok | ok |
| `update` | ok (mutable fields only; `prepareForValidation` strips core facts) | ok | BAI-15 (statements) | ok | ok | ok | ok | ok |
| `cancel` | ok (terminal guard) | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok (`uq_guard`) | ok | ok | ok | ok (legacy, documented) |
| `transition` | ok (forward-only, `nextStates`) | ok | ok | ok | ok | ok | ok | ok |
| `recordWitnessStatement` | ok (frozen + confidential guards) | ok | BAI-15 | ok | ok | ok | ok | BAI-05 (no activity log) |
| `followUp` | ok (append-only) | ok | ok | ok | ok | ok | ok | ok |
| `addIntervention` | ok (duplicate returns false) | ok | ok | ok (`uq_ba_inc_int`) | ok (unique index present) | ok | ok | BAI-05 (no activity log) |
| `removeIntervention` | ok (soft delete only) | ok | ok | ok | ok | ok | ok (404 when nothing removed) | ok |
| `destroy` / `forceDelete` | ok (both `abort(403)`) | ok | ok | ok | ok | ok | ok | ok (retired deliberately) |
| `getCriteria` | n/a (read) | n/a | ok | n/a | n/a | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/BehaviouralAssessment/app/Http/Controllers/BaInterventionCaseController.php` (`run()`, already AUDITED) | Uses the same controller try/catch + `Log::error(..., ['error' => $e->getMessage()])` pattern as BAI-03/BAI-02 | ERR-00, ERR-05 | module-wide one change (BAI-02/BAI-03 group) |
| `resources/views/components/backend/table/action-trashed.blade.php` (shared component) | Renders a GET form for any `.restore` route whose first verb is GET — the enabler for BAI-09; it correctly adapts to POST if the route changes | RTE-01 | do NOT edit the component; fix the route (BAI-09) |
| `Modules/StudentProfile/app/Models/Student.php` / `Modules/SchoolSetup/app/Models/Employee.php` | Other-module models, reached here as option lists; `formOptions()` loads them unbounded (BAI-13 is owned by this report because the query lives in `BaIncident`) | QRY-15 | owner reports / BAI-13 |
| `Modules/BehaviouralAssessment/app/Models/BaIntervention.php`, `BaCriterion.php`, `BaActor.php`, `BaTriggerError.php`, `BaIncidentInterventionJnt.php`, `BaAuditLog.php`, `BaCategory.php`, `BaConfig.php` | Audited elsewhere; this report only checks how the controller uses them (arguments, guards) | — | see `00-CLASS-OWNERS.md` |

## 8. Not covered, and why

- **`BaDashboardController::incidentsPage()`** — the page that hosts the "Log Incident" dialog and includes `_create-fields.blade.php`; it is a separate (god) controller and is not part of this controller's scope. Its own audit will cover the dialog.
- **`BaIncidentAttachmentController`** (upload/download/destroy of evidence) — a separate controller; not audited here. The private-disk + authorised-download claim for SEC-05 was read from `BaIncidentAttachmentService` only.
- **Events** `IncidentCreated`, `IncidentSeverityEscalated`, `IncidentCancelled` and their listeners (`ShouldDispatchAfterCommit`) — dispatched by the services but not deep-read; JOB-01..05 not assessed for them.
- **Blade files not rendered in this review**: `witness-picker` partials were read for `Model::`/`{!! !!}` (clean) but not every branch was executed.
- **DB trigger SQL** — `database/migrations/tenant/2026_06_16_130643_create_ba_triggers.php` was only skimmed to confirm `SQLSTATE 45000` + `BA:` prefix via `BaTriggerError`; the full trigger bodies were not audited (they are in the TimetableFoundation-style migrations, out of this controller's file scope).
- **Pint** — the audit does not run `vendor/bin/pint --test`; STY-02 is therefore `⚠ UNVERIFIED — running Pint in test mode on the in-scope files would settle it`.
