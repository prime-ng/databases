# Fix Plan — ParentPortal / ParentTeacherController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. There are **no** `⚠ SHARED` items in this plan — every item touches only this controller and its own blade.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the `tarun/ParentPortal-done/ParentDashboardController` report (shared service) |
| `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | owned by the legacy `TimetableFoundation/AcademicTermController` report |
| `Modules/TimetableFoundation/app/Models/Activity.php` / `ActivityTeacher.php` | owned by the legacy `TimetableFoundation/ActivityController` report |
| `Modules/StudentProfile/app/Models/*` | reached through `ParentContextService` (ParentDashboardController scope) |
| `Modules/ParentPortal/routes/web.php` | shared route file; this plan makes no route changes |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | claimed by the `tarun/ParentPortal-done/ParentHealthController` report |
| `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` | module glue (common, §4.2) |
| `app/Helpers/activityLog.php`, `parentportal::layouts.app` | common (referenced, never audited here) |

## 1. Blockers reachable today

None — no B-severity findings.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [x] **PTC-01** · M · ERR-07/ERR-05 (D1) · `ParentTeacherController.php:100-116` — remove the D2-unapproved `try/catch` around the audit log; log the child's own name (drops a lazy query); drop the trace-less `Log::error` and the `Log` import.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php`
  - **Before** (`ParentTeacherController.php:13`) — remove the now-unused import:
    ```php
    use Illuminate\Support\Facades\Log;
    ```
    **After:** delete the line — `Log` is no longer referenced anywhere in the file.
  - **Before** (`ParentTeacherController.php:100-116`):
    ```php
        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed teachers list',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
    ```
  - **After:**
    ```php
        // The audit row is this method's only write; a single insert needs no transaction
        // (TXN-01 N/A), and D1 allows no try/catch here (PTC-01, 2026-10-13).
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed teachers list',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ],
        ]);
    ```
  - **Verify:** `grep -n "try {\|catch (\|getMessage\|Log::error\|use Illuminate\\\\Support\\\\Facades\\\\Log" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php`
  - **Expect:** no output. (This item also fixes PTC-03: `request()->route()` becomes `$request->route()`.)
  - **Effort:** S

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

None.

## 7. Views (F10)

- [x] **PTC-05** · M · VIEW · `teachers/index.blade.php:19` + `ParentTeacherController.php:46-48, 118-120` — stop the header term name reaching for the nonexistent `academicTerm` relation; pass `termName` from the controller instead.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php`, `Modules/ParentPortal/resources/views/teachers/index.blade.php`
  - **Before** (`ParentTeacherController.php:46-48`):
    ```php
        $termId = AcademicTerm::where('academic_session_id', $session->academic_session_id)
            ->where('is_current', true)
            ->value('id');
    ```
  - **After:**
    ```php
        $term = AcademicTerm::where('academic_session_id', $session->academic_session_id)
            ->where('is_current', true)
            ->first(['id', 'term_name']);

        $termId = $term?->id;
    ```
  - **Before** (`ParentTeacherController.php:118-120`):
    ```php
        return view('parentportal::teachers.index', compact(
            'child', 'session', 'teachers',
        ));
    ```
  - **After:**
    ```php
        return view('parentportal::teachers.index', [
            'child'    => $child,
            'session'  => $session,
            'teachers' => $teachers,
            'termName' => $term?->term_name,
        ]);
    ```
  - **Before** (`teachers/index.blade.php:19`):
    ```blade
                    {{ $session->academicTerm?->name ?? '' }}
    ```
  - **After:**
    ```blade
                    {{ $termName ?? '' }}
    ```
  - **Verify:** `grep -rn "academicTerm" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php Modules/ParentPortal/resources/views/teachers/index.blade.php`
  - **Expect:** no output. The no-class branch (returns at `ParentTeacherController.php:33-38`) needs no `termName` key — the header block is never rendered when `classSection` is missing, and the Blade uses `?? ''`.
  - **Effort:** S

## 8. Style (F12) — one item per file

- [x] **PTC-02** · M · CTL-02 · `ParentTeacherController.php:25` — extract the 32-line teacher-map builder (lines 65-98) into a private `buildTeacherMap()` so `index()` drops under 80 lines.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php`
  - **Before** (imports — `ParentTeacherController.php:8-9`):
    ```php
    use Illuminate\Http\Request;
    use Illuminate\View\View;
    ```
  - **After:**
    ```php
    use Illuminate\Http\Request;
    use Illuminate\Support\Collection;
    use Illuminate\View\View;
    ```
  - **Before** (call site — `ParentTeacherController.php:65-98`):
    ```php
        // Build a flat teacher list: keyed by teacher_id.
        // Each entry holds the teacher model + a collection of subjects they teach.
        $teacherMap = [];

        foreach ($activities as $activity) {
            if (! $activity->subject) {
                continue;
            }

            foreach ($activity->teachers as $actTeacher) {
                $teacher = $actTeacher->teacher;
                if (! $teacher) {
                    continue;
                }

                $tid = $teacher->id;
                if (! isset($teacherMap[$tid])) {
                    $teacherMap[$tid] = [
                        'teacher'  => $teacher,
                        'subjects' => collect(),
                    ];
                }

                // Add subject if not already present
                if (! $teacherMap[$tid]['subjects']->contains('id', $activity->subject->id)) {
                    $teacherMap[$tid]['subjects']->push($activity->subject);
                }
            }
        }

        // Sort alphabetically by teacher name
        $teachers = collect($teacherMap)
            ->sortBy(fn ($entry) => $entry['teacher']->user?->name ?? '')
            ->values();
    ```
  - **After:**
    ```php
        // Build a flat, alphabetically-sorted subject → teacher map (extracted for length, PTC-02).
        $teachers = $this->buildTeacherMap($activities);
    ```
  - **Before** (insert point — `ParentTeacherController.php:17-19`, after the constructor):
    ```php
    public function __construct(
        private readonly ParentContextService $context,
    ) {}
    ```
  - **After:**
    ```php
    public function __construct(
        private readonly ParentContextService $context,
    ) {}

    /**
     * Build a flat, alphabetically-sorted teacher list from the term's activities.
     * One entry per teacher: the Teacher model plus the subjects they teach.
     *
     * @param  \Illuminate\Support\Collection<int, \Modules\TimetableFoundation\Models\Activity>  $activities
     * @return \Illuminate\Support\Collection<int, array{teacher: \Modules\SchoolSetup\Models\Teacher, subjects: \Illuminate\Support\Collection<int, \Modules\SchoolSetup\Models\Subject>}>
     */
    private function buildTeacherMap(Collection $activities): Collection
    {
        $teacherMap = [];

        foreach ($activities as $activity) {
            if (! $activity->subject) {
                continue;
            }

            foreach ($activity->teachers as $actTeacher) {
                $teacher = $actTeacher->teacher;
                if (! $teacher) {
                    continue;
                }

                $tid = $teacher->id;
                if (! isset($teacherMap[$tid])) {
                    $teacherMap[$tid] = [
                        'teacher'  => $teacher,
                        'subjects' => collect(),
                    ];
                }

                if (! $teacherMap[$tid]['subjects']->contains('id', $activity->subject->id)) {
                    $teacherMap[$tid]['subjects']->push($activity->subject);
                }
            }
        }

        return collect($teacherMap)
            ->sortBy(fn ($entry) => $entry['teacher']->user?->name ?? '')
            ->values();
    }
    ```
  - **Verify:** `grep -n "buildTeacherMap\|public function index" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php`
  - **Expect:** 3 lines — the `$teachers = $this->buildTeacherMap(...)` call, the `private function buildTeacherMap` definition, and `public function index`.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PTC-04** · M · DECISION · deep-read Q7/Q1 — what should the page show when no academic term is flagged `is_current`?
  - **Why it is a decision:** the correct fallback is a product choice (between-terms behaviour decides which teachers a parent sees); mechanically it is a one-query change on the lines PTC-05 already edits.
  - (a) ⭐ Always term-scope: prefer the current term, fall back to the latest term of the same academic session — one query, applied on top of PTC-05's `$term` query:
    ```php
    $term = AcademicTerm::where('academic_session_id', $session->academic_session_id)
        ->orderByDesc('is_current')
        ->orderByDesc('term_start_date')
        ->first(['id', 'term_name']);
    ```
    The list is always scoped to exactly one term and the header/footer stay truthful. Touches only the controller lines PTC-05 already edits; no view change.
  - (b) Keep the unfiltered fallback but make the copy honest: pass a `noCurrentTerm` flag to the view and change the footer (blade line 161) to say no current term is set — the page still lists historical teachers.
  - (c) Strictest: when no term is current, render the existing empty "No Teachers Found" state with a "no current term set" note — parents see nothing until a term is flagged current.
  - ➜ Choice: (a) — always term-scope, prefer current then latest 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PTC-03 | Covered inside PTC-01 — its After block replaces `request()->route()` with `$request->route()`; no separate edit needed. |