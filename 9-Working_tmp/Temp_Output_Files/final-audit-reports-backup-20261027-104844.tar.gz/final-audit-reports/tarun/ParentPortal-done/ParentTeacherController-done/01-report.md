# Final Audit — ParentPortal / ParentTeacherController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php` (122 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/teachers` |
| Menu path | Parent Portal → My Teachers (sidebar link to `parent-portal.teachers.index`) |
| Who uses it | Parents (user_type = `PARENT`) logged into the Parent Portal. There is no permission key for this portal; access is gated by `ParentPortalMiddleware` (user_type=PARENT + a `std_guardians` row + at least one linked child with `can_access_parent_portal = 1`). |
| What a user does here | A parent opens the page for the child that is currently active in the portal. The page shows the child's class and section, and a grid of subject teachers assigned to that class–section in the current academic term — each card has the teacher's name, employee code, the subjects they teach, and their email / mobile. There is nothing to click, create, edit or submit; this is a pure read-only directory page. |
| Tables written | `sys_activity_logs` (a "Viewed" audit row on every page view). Through the shared `ParentContextService::resolveChild()`, `ppt_parent_sessions.last_active_at` / `active_student_id` may be updated for parents with more than one child. |
| Tables read | `std_students` (active child), `std_student_academic_sessions` (the child's current session), `sch_academic_term` (current term), `tt_activities` (term's activities), `tt_activity_teacher` (activity → teacher links), `sch_teachers`, `sys_users` (teacher accounts), `sch_subjects`; plus via `ParentContextService`: `sys_users`, `std_guardians`, `std_student_guardian_jnt`. |
| Live data | ⚠ UNVERIFIED — the dev database has no initialized tenant (`prime_db.tenants` does not exist; confirmed `Schema::hasTable("tenants") === false`), so live row counts could not be measured. The dev DB matches the known BUG-004 state (tenant migration pipeline commented out, new tenants get empty DBs). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready as written, but only just. The screen is a correctly-scoped read-only directory: the child is resolved by the shared `ParentContextService` (so a parent can only ever see their own linked child's class teachers), the activity load is term-and-class scoped with valid eager loads, and there is no N+1. Three defects stand between it and go-live. The single worst finding is the pre-D1 error wrapper around the audit log: a `try/catch (\Throwable)` in a controller, plus a trace-less `Log::error(..., ['error' => $e->getMessage()])` — the exact shape the protocol abolished, and it also triggers a lazy `Student::user` query on every page view. The term display is broken twice over: the header prints a term name through a relation (`academicTerm`) that does not exist on `StudentAcademicSession`, so it is silently blank forever; and when no term is flagged `is_current`, the activity filter is silently skipped, so the list shows teachers from every term while the footer claims "the current academic term". Effort: the two mechanical fixes (PTC-01, PTC-02) plus the small view fix (PTC-05) are about an hour; PTC-04 needs one product decision.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 4 | 1 | 1 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PTC-01 | F8 Services/Jobs | clean (service linked) |
| F2 Transactions/Audit | clean | F9 Queries/Perf | clean |
| F3 Authorization | clean (middleware gate) | F10 Views | PTC-05 |
| F4 Validation | clean (no input) | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | clean |
| F6 Controller shape | PTC-02, PTC-03 | F13 Deep read | PTC-04 |
| F7 Models | clean (linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php` | controller | 122 | this report | ✅ |
| 2 | `Modules/ParentPortal/resources/views/teachers/index.blade.php` | view | 167 | this report | ✅ |
| 3 | `Modules/ParentPortal/routes/web.php` | routes (`teachers` row, line 166 only) | 199 | this report (block only; shared file, not registered) | ✅ |
| 4 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (usage checked, findings in §7) |
| 5 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model | 139 | ↗ [TimetableFoundation/AcademicTermController](../../../TimetableFoundation/AcademicTermController/01-report.md) | ↗ linked (usage checked) |
| 6 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | 345 | ↗ [TimetableFoundation/ActivityController](../../../TimetableFoundation/ActivityController-done/01-report.md) | ↗ linked (usage checked) |
| 7 | `Modules/TimetableFoundation/app/Models/ActivityTeacher.php` | model | 107 | ↗ [TimetableFoundation/ActivityController](../../../TimetableFoundation/ActivityController-done/01-report.md) | ↗ linked (usage checked) |
| 8 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked (authz gate for F3) |
| 9 | `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` | provider | 100 | common (module glue, §4.2) | referenced only |
| 10 | `Modules/StudentProfile/app/Models/{Student,StudentAcademicSession}.php` | models | — | ↗ via `ParentContextService` → [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (usage checked; the missing `academicTerm` relation is PTC-05's root cause) |

No pre-applied files (the module has no `PRE-APPLIED-*.md` entry; the D10 workbook only covered TimetableFoundation).

Common classes referenced but not audited here (per `.claude/rules/final-audit.md` §4.2): `App\Http\Controllers\Controller`, `Request`, `View`, `Log`, `auth()`, `activityLog()` helper (`app/Helpers/activityLog.php`), `parentportal::layouts.app` layout, `Str::plural` (common façade).

## 4. Routes

```
GET|HEAD parent-portal/teachers                                  parent-portal.teachers.index                       Modules\ParentPortal\Http\Controllers\ParentTeacherController@index
```

Unrouted public methods: none (the only public method, `index()`, is routed; `__construct` is not a route action).

Middleware on the group (from `Modules/ParentPortal/Providers/RouteServiceProvider.php::mapWebRoutes()`): `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:ParentPortal`, `auth`, `ParentPortalMiddleware`.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 25 | GET `parent-portal/teachers` | `ParentPortalMiddleware` (user_type + guardian + child-linkage check; no gate string) | none — a single audit-row insert needs no transaction | `'Viewed'` | `sys_activity_logs` (audit row); via service: `ppt_parent_sessions` (multi-child parents only) | PTC-01, PTC-02, PTC-03, PTC-04, PTC-05 |

## 6. Findings

### F1 — Errors

#### PTC-01 · M · ERR-07 (settled by D1) + ERR-05 — the audit log is wrapped in the try/catch the protocol abolished, and the catch logs a trace-less message

| Field | Value |
|---|---|
| **Rule** | ERR-00/D1 (H) — *D1 settles ERR-00: no try/catch in controllers; a controller try/catch is a finding unless it is one of the D2 shapes (DomainException, the truncate-then-rebuild single catch, SnapshotProtectionException). ERR-07 (M): read-only methods need no try/catch. ERR-05 (M): log the exception object, not `getMessage()` alone — the trace is lost.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php:100-116` (comment + `try` at 104 + catch at 114-116), plus the now-orphaned `use Illuminate\Support\Facades\Log;` at line 13 |
| **Root cause** | The method was written under the old house rule A1: keep the audit write in a `try` so a failed audit row "must never take a parent's page down". `final-audit.md` §1 D1 settled on the Laravel idiom, and none of the D2 allowed shapes apply here (no `\DomainException`, no TRUNCATE-then-rebuild, no `SnapshotProtectionException`). The comment at 100-103 is the A1-era justification and is stale. The catch also logs only `$e->getMessage()` (`Log::error('view log failed', ['error' => $e->getMessage()])`), which loses the stack trace (ERR-05), and the `student_name` line prefers `$child?->user?->name` — a lazy `Student::user` query on every page view — over the child's own `full_name` accessor (Student.php:295) which needs no query at all. |
| **Consequence** | A read page carries a D2-forbidden control-flow shape and loses the audit row's trace when it fails; every page view also pays an extra lazy query to log the wrong name (the student's account name instead of the child's own name). |
| **Reproduce** | Static only — open the file. The lazy query is visible in the query log when `DB::listen()` is on; the wrong name shows in `sys_activity_logs.context` after any page view. |
| **Fix approach** | Per D1, remove the `try`/`catch` and the `Log` import, and keep the `activityLog()` call plain (this method's only write is that single insert — no transaction needed, see F2). Replace `$child?->user?->name ?? $child?->full_name ?? null` with `$child?->full_name ?? null` (removes the lazy query), and `request()->route()?->getName()` with `$request->route()?->getName()` (fixes PTC-03 in the same edit). |
| **Plan item** | PTC-01 in `02-fix-plan.md` §3 |

```php
// ParentTeacherController.php:100-116 — CURRENT
        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed teachers list',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|Log::error\|getMessage\|request()->route()" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php
104:        try {
114:        } catch (\Throwable $e) {
115:            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
111:                    'route' => request()->route()?->getName(),
```

F1 is otherwise clean — nothing reaches the user via `withErrors`/`json`/`back()` (there are no error paths to the user at all), no `catch (\RuntimeException)`, no swallowed write-path failure beyond the audit row above.

### F2 — Transactions and audit

clean — this method's only write is the single `activityLog()` insert into `sys_activity_logs` (`grep -n "activityLog(" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php` → 1 call, line 105). The scanner's TXN-01 candidate ("1 writes + activityLog with no transaction") is a false positive: TXN-01 requires **more than one** write (two models, or a model + its audit row). Here there is no business write at all — the audit row IS the write — so no transaction is required, exactly as the sibling `ParentHealthController` report concludes for the same shape. The `ParentContextService` write on the read path (`ppt_parent_sessions`) is the service's concern — see §7.

### F3 — Authorization

clean — `grep -n "Gate::authorize\|can:" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php` → no output, and none is needed: the route sits behind `auth` + `ParentPortalMiddleware`, which enforces user_type=PARENT, a `std_guardians` row, and at least one linked child with `can_access_parent_portal = 1` (AUTH-01 satisfied by route middleware, per the module convention recorded in the `ParentHealthController` report). Record-level scoping (AUTH-03) is enforced through `ParentContextService::resolveChild()`: the class/section used for the teacher query comes only from the service-resolved child, so a parent can only ever see the teachers of their own linked child's class — no cross-family access. This portal deliberately authorizes by user_type rather than a permission key (see the middleware comment), so there is no `config/permissionslist.php` entry and no dead permission logic (AUTH-05/AUTH-06: checked, not present).

### F4 — Validation and input

clean — `index()` reads no user input: `$request` is used only for `resolveChild($request)` and the route name in the audit context. Nothing to validate (VAL-01..07: checked, not present).

### F5 — Routes

clean — verified with the uncached probe in §4. The route points at an existing method (RTE-02); the route is a read over GET (RTE-04); the only public method is routed (RTE-03); the route sits inside the tenant + auth + portal middleware group (RTE-05); no state change over GET beyond the audit log and the service's session touch — the codebase-wide accepted pattern (RTE-01); no `Route::resource` prefix conflict (RTE-06).

### F6 — Controller shape

PTC-02 and PTC-03 below. Size is 122 lines / 1 public method (CTL-01 clean). Return type present (`: View`, CTL-04 clean). `compact()` carries 3 variables (CTL-07 clean). No debug leftovers (CTL-09 clean). No dead code beyond the `Log` import PTC-01 removes (CTL-10 clean). The teacher-map builder (lines 67-98) is presentation mapping — PTC-02's extraction is the length fix, not a CTL-06 split.

#### PTC-02 · M · CTL-02 — `index()` is 97 lines, over the 80-line ceiling

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php:25-121`, method `index()` (the map builder occupies 67-98) |
| **Root cause** | The method chains five phases — child resolution, session load, term lookup, activity load, and a 32-line flat-map builder with two nested `foreach` loops. The last phase is self-contained (input: `$activities`; output: sorted teacher collection) and is the reason the method crosses 80 lines. |
| **Consequence** | None functional today — pure maintainability debt; the method is long enough that a future edit to the map logic must first understand the surrounding query chain. |
| **Reproduce** | Static only — `sed -n '25,121p'` shows the span. |
| **Fix approach** | Extract the map builder (lines 67-98) into a private `buildTeacherMap(Collection $activities): Collection` method and call it from `index()`. Paste-ready code is in plan item PTC-02. |
| **Plan item** | PTC-02 in `02-fix-plan.md` §8 |

```php
// ParentTeacherController.php:65-98 — CURRENT
        // Build a flat teacher list: keyed by teacher_id.
        // Each entry holds the teacher model + a collection of subjects they teach.
        $teacherMap = [];

        foreach ($activities as $activity) {
            if (! $activity->subject) {
                continue;
            }

            foreach ($activity->teachers as $actTeacher) {
                $teacher = $actTeacher->teacher;
                if (! $teacher) {
                    continue;
                }

                $tid = $teacher->id;
                if (! isset($teacherMap[$tid])) {
                    $teacherMap[$tid] = [
                        'teacher'  => $teacher,
                        'subjects' => collect(),
                    ];
                }

                // Add subject if not already present
                if (! $teacherMap[$tid]['subjects']->contains('id', $activity->subject->id)) {
                    $teacherMap[$tid]['subjects']->push($activity->subject);
                }
            }
        }

        // Sort alphabetically by teacher name
        $teachers = collect($teacherMap)
            ->sortBy(fn ($entry) => $entry['teacher']->user?->name ?? '')
            ->values();
```

**Evidence**
```
$ sed -n '25,121p' Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php | wc -l
97
$ grep -nE 'public function [a-zA-Z_]+' Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php
25:    public function index(Request $request): View
```

#### PTC-03 · L · CTL-08 — `request()` helper used while `$request` is injected

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php:111`, method `index()` |
| **Root cause** | The method already receives `Request $request` but reads the route name through the global `request()->route()` helper instead of the injected instance. |
| **Consequence** | None today — purely a consistency/maintainability issue (the injected parameter becomes misleading). |
| **Reproduce** | Static only — the code is visibly inconsistent with the injected `$request`. |
| **Fix approach** | Replace `request()->route()?->getName()` with `$request->route()?->getName()`. |
| **Plan item** | PTC-01 in `02-fix-plan.md` §3 — its After block writes `$request->route()?->getName()` |

```php
// ParentTeacherController.php:111 — CURRENT
                    'route' => request()->route()?->getName(),
```

**Evidence**
```
$ grep -n "request()->route()" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php
111:                    'route' => request()->route()?->getName(),
```

### F7 — Models

clean, linked — `AcademicTerm`, `Activity` and `ActivityTeacher` are owned by the legacy TimetableFoundation reports (see §3) and are not re-audited here. This controller's usage is correct: `AcademicTerm::where('academic_session_id', $session->academic_session_id)->where('is_current', true)->value('id')` is a single scalar read; `Activity::query()->where('class_id', …)->where('section_id', …)->where('is_active', true)` filters by the child's class–section and the SoftDeletes global scope excludes trashed rows; the eager-load path `subject`, `teachers` (filtered `is_active`, ordered `ordinal`), `teachers.teacher.user` are all valid relations on the linked models (verified `ActivityTeacher::teacher()` at ActivityTeacher.php:76, `Teacher::user()` at Teacher.php:44, and the `ordinal`/`is_active` columns at ActivityTeacher.php:27-28). `AcademicTerm` has no `name` column — its display column is `term_name` (PTC-05 relies on this). Model defects found by the scanner (`Activity` MDL-03 on `parallelGroups`, `Activity` STY-01 missing `strict_types`) belong to the owners — see §7.

### F8 — Services and jobs

clean, linked — `ParentContextService` is owned by [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md). This controller's usage is correct: `resolveChild($request)` is called once and returns an in-scope `Student`, so the class/section fed to the teacher query can only ever be the parent's own child's. The service is constructor-injected, not instantiated mid-method (SVC-02 clean). The service's own defects (HTTP in service, untransactioned writes, writes on the read path, emoji comments) belong to its owner — see §7.

### F9 — Queries and performance

clean — no queries inside loops anywhere (QRY-01 clean): the `foreach ($activities …)` at 69-93 touches only already-loaded relations (`$activity->subject`, `$activity->teachers`, `$actTeacher->teacher`, `$teacher->user`) and the `contains()`/`push()` calls are in-memory collection work. The list is not paginated (QRY-02) but is naturally bounded — one class–section in one term, typically 10-30 rows — so `->get()` is acceptable here; a paginator would be overkill on a directory card grid. The eager loads cover every relation the view and the sort closure touch except the two term display items that are their own findings: the lazy `Student::user` lookup in the audit context (removed by PTC-01) and the nonexistent `academicTerm` relation in the blade (PTC-05). The same Resource lookup is resolved once per request (QRY-12 clean).

### F10 — Views

#### PTC-05 · M · VIEW (module-finalization §4 "?? on a nonexistent column is silent forever") — the header term name points at a relation and column that do not exist

| Field | Value |
|---|---|
| **Rule** | VIEW (M); module-finalization §4 catalogue — *a `??` on a column/relation that does not exist is silent forever; the F10 checklist's own example* |
| **Where** | `Modules/ParentPortal/resources/views/teachers/index.blade.php:19`, inside the sub-header `<p>` |
| **Root cause** | The header prints `{{ $session->academicTerm?->name ?? '' }}`. `StudentAcademicSession` has **no** `academicTerm()` relation — its relations are `academicSession()` (StudentAcademicSession.php:100), `student()`, `classSection()`, `boardingLogs()`, `transportAllocation()`, etc. Eloquent returns `null` for a missing relation method, so this line never renders anything. And even if the relation existed, `AcademicTerm`'s display column is `term_name`, not `name` — the wrong column for the second time. The net effect: the term name in the "Class — Section · Term" header is silently blank on every page view, and no error is ever raised. |
| **Consequence** | The header's term label is always empty; the developer intent (show which term this teacher list belongs to) is dead code that looks alive. |
| **Reproduce** | Open `/parent-portal/teachers` — the sub-header reads "Class – Section ·" with nothing after the dot, on every load. |
| **Fix approach** | The controller already queries the current term (lines 46-48); have it fetch the term record (`id` for the filter, `term_name` for the header) and pass `termName` into both `view()` payloads. Blade prints `{{ $termName ?? '' }}`. This keeps the fix inside this controller + view — adding the relation would touch a model owned by the `ParentDashboardController` service scope (see §8). |
| **Plan item** | PTC-05 in `02-fix-plan.md` §7 |

Blade `teachers/index.blade.php:19` — CURRENT:

```blade
                {{ $session->academicTerm?->name ?? '' }}
```

**Evidence**
```
$ grep -n "academicTerm" Modules/StudentProfile/app/Models/StudentAcademicSession.php
(no output — the relation does not exist)
$ grep -nE "function (academicSession|academicTerm|classSection)\b" Modules/StudentProfile/app/Models/StudentAcademicSession.php
100:    public function academicSession()
109:    public function classSection()
$ grep -n "term_name" Modules/TimetableFoundation/app/Models/AcademicTerm.php
29:        'term_name',
```

F10 is otherwise clean: no `Model::`/`DB::` calls in the template (VIEW-01 clean — the eager-loaded relations `classSection.class` and `classSection.section` are read as properties, no queries); every relation used inside `@foreach` is eager-loaded by the controller (VIEW-02 clean — `$teacher->user` at line 63 is loaded via `teachers.teacher.user`); no `{!! !!}` on user text (VIEW-03 clean — names, emails and subjects all print through `{{ }}`); no create/edit form, no table actions, no export/import gates (nothing for the modal/table-action/export standards); the breadcrumb is the portal layout's static trail. The footer note at line 161 is part of the PTC-04 decision, not a separate finding.

### F11 — Security and tenancy

clean for this controller — no `env()` outside config (SEC-01); no personal data over-exposed (SEC-02 — the page renders a Blade directory and shows only the public contact details of the *child's own teachers*, which is the feature's purpose; no JSON endpoint returns whole models); no hard-coded ids or `?? 1` fallbacks (SEC-03); nothing sensitive is logged — the audit context holds the child id and (after PTC-01) the child's own name (SEC-04); no file-serving routes here (SEC-05); no caches (TEN-02 clean); no central models reached from tenant context (TEN-03 clean); no tenant file URLs (TEN-04 clean).

### F12 — Style

clean — `declare(strict_types=1)` present (line 3, STY-01); imports are sorted and blank-line-free and have one import per class (STY-02, STY-05 — verified `sed -n '7,13p'`); variables are camelCase and unabbreviated (STY-03); comments are English without emoji and without commented-out code (STY-04 — the only stale comment, lines 100-103, is the A1-era justification removed by PTC-01); user-facing strings here are Blade text, not flashed messages (STY-07 N/A).

### F13 — Deep read (answer all 8 questions for every mutating method)

#### PTC-04 · M · DECISION · deep-read Q7/Q1 — when no term is flagged `is_current`, the teacher list silently includes every term, and the footer claims the current one

| Field | Value |
|---|---|
| **Rule** | Deep-read Q7 *"does any message lie?"* and Q1 *"can a write/read return data it should not?"* (D — scanner can't see it); M — a wrong result on a real screen, but only in the no-current-term state |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php:53-57` (the `->when($termId, …)` filter) and the lying copy at `Modules/ParentPortal/resources/views/teachers/index.blade.php:161` (footer note) |
| **Root cause** | `$termId` comes from `AcademicTerm::where('academic_session_id', …)->where('is_current', true)->value('id')`. The `->when($termId, fn ($q) => …)` is a tolerant fallback: when no term is flagged `is_current`, the `academic_term_id` filter is silently **skipped** and the query returns activities (and therefore teachers) from **every** term for that class–section — including long-gone staff. The blade footer, however, always says "Showing teachers assigned to X's class in the current academic term", so the page claims a scope it did not apply. |
| **Consequence** | Between terms (or when a school never flags a current term) a parent sees a directory of every teacher ever assigned to the class–section, while the page states it is showing the current term — stale contacts, and a message that lies. |
| **Reproduce** | With no term flagged `is_current` for the child's academic session, open `/parent-portal/teachers` — the grid lists teachers from past terms and the footer still says "in the current academic term". |
| **Fix approach** | Product decision (three options in plan item PTC-04): always term-scope with a latest-term fallback, keep the unfiltered fallback but make the copy honest, or show an empty state until a term is flagged. Applied on top of PTC-05's `$term` query shape. |
| **Plan item** | PTC-04 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentTeacherController.php:53-57 — CURRENT
        $activities = Activity::query()
            ->where('class_id', $classId)
            ->where('section_id', $sectionId)
            ->where('is_active', true)
            ->when($termId, fn ($q) => $q->where('academic_term_id', $termId))
```

**Evidence**
```
$ grep -n "when(\$termId" Modules/ParentPortal/app/Http/Controllers/ParentTeacherController.php
57:            ->when($termId, fn ($q) => $q->where('academic_term_id', $termId))
$ grep -n "current academic term" Modules/ParentPortal/resources/views/teachers/index.blade.php
161:        Showing teachers assigned to {{ $child->first_name }}'s class in the current academic term.
```

| Question | `index()` |
|---|---|
| 1. Can a write overwrite data it should not? | ok — the only write is a fresh `sys_activity_logs` insert; nothing is overwritten |
| 2. Is anything deleted before its replacement is stored? | ok — no deletes |
| 3. Duplicate implementations of one operation? | ok — single teacher-map builder (extraction target, PTC-02, does not duplicate it) |
| 4. Soft-delete × unique index trap? | ok — reads only; SoftDeletes models exclude trashed rows by global scope |
| 5. Is there a race? | ok — no check-then-act write |
| 6. Authorization hole? | ok — middleware + `resolveChild()` scope; teachers are scoped to the parent's own child's class-section |
| 7. Does any message lie? | **PTC-04** — when no term is flagged `is_current`, the activity filter is skipped and the page lists teachers of *every* term while the footer says "in the current academic term"; also PTC-05 — the header term label silently never renders |
| 8. Dead feature? | ok — the page's output is consumed by parents; each teacher card's contact data is the point of the screen |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` (:104) | `resolveChild()` calls `abort(redirect(...))` from a service — services must not touch HTTP | SVC-01 (M) | tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/ParentPortal/app/Services/ParentContextService.php` (:202-221) | `getOrCreateSession()` performs 2 writes (`update` or `create` + `last_active_at` touch) with no transaction | TXN-01 (H) | tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/ParentPortal/app/Services/ParentContextService.php` (:93-124) | `resolveChild()` writes `ppt_parent_sessions` on a GET read path (updates `active_student_id`), and `getOrCreateSession()` touches `last_active_at` every request | SVC-03 (H) | tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/ParentPortal/app/Services/ParentContextService.php` (:26, :32, :144) | emoji in comments | STY-04 (L) | tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/TimetableFoundation/app/Models/Activity.php` (:250) | `parallelGroups()` is a `belongsToMany` over a soft-delete pivot (`tt_parallel_group_activity`) without `wherePivotNull('deleted_at')` | MDL-03 (H) | TimetableFoundation/ActivityController report (owner) |
| `Modules/TimetableFoundation/app/Models/Activity.php` (:1) | missing `declare(strict_types=1)` | STY-01 (L) | TimetableFoundation/ActivityController report (owner) |
| `Modules/StudentProfile/app/Models/StudentAcademicSession.php` | no `academicTerm()` relation — the blade's `$session->academicTerm` has silently returned null since the page was written; fixed locally by PTC-05 (pass `termName` from the controller) rather than by adding a relation to a model owned by the ParentDashboardController service scope | VIEW / §4 catalogue | PTC-05 (this report) + note for the model owner |
| `Modules/ParentPortal/resources/views/teachers/index.blade.php` (:161) | the footer claims "the current academic term" even when the filter was skipped — decision on intended behaviour is PTC-04 | deep-read Q7 (M) | this report, DECISION |

## 8. Not covered, and why

- **Live row counts** — the dev DB has no initialized tenant (`tenants` table absent from `prime_db`; confirmed `Schema::hasTable("tenants") === false`), matching the known BUG-004 state. Counts are marked UNVERIFIED in §0.
- **Browser rendering** — D4 forbids running the screen; the Blade was read statically (PTC-05's "silently blank" claim is proven by the missing relation, not by a screen capture).
- **`parentportal::layouts.app` and other portal layouts** — common layouts, referenced not audited here (§4.2).
- **The `academicTerm` relation on `StudentAcademicSession`** — adding it would touch a model in the `ParentDashboardController` service scope; PTC-05 fixes the symptom in this controller instead, and the missing relation is recorded in §7 for the model's owner.
- **`activityLog()` helper internals** — common helper (`app/Helpers/activityLog.php`), referenced not audited; PTC-01 only changes how *this* controller calls it.