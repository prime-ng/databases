# Final Audit — ParentPortal / ParentDashboardController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php` (286 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal` (dashboard), `http://test.localhost:8000/parent-portal/children` (My Children) |
| Menu path | Parent Portal → Dashboard / My Children (portal home after OTP login) |
| Who uses it | `PARENT` user-type accounts (the ParentPortalMiddleware role gate — asserted in `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php:37`). No Spatie permission strings exist in this module; the middleware is the single gate. |
| What a user does here | A parent opens the portal to see one dashboard per child: attendance %, today's timetable, pending homework, upcoming exams, fee status, leave counts and recent notifications. On "My Children" they can switch which child the whole portal acts as (AJAX POST, persisted in `ppt_parent_sessions.active_student_id`). |
| Tables written | `ppt_parent_sessions` (active child switch, session create/update — via `ParentContextService`), `sys_activity_logs` (tenant `Viewed`/`Switched` audit rows via the `activityLog()` helper) |
| Tables read | `std_guardians`, `std_student_guardian_jnt`, `std_students`, `std_student_academic_session` (+ `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `sch_subject_groups`, `sch_subject_group_subject_jnt`, `sch_subjects`), `std_student_attendance`, `tt_timetable_cells` + timetable snapshots, `lms_homework`/`lms_homework_submission`, `lms_exam_allocations` + exam tables, `fee_student_assignments`/`fee_invoices` (via `currentFeeAssignemnt` relation), `std_leave_applications`, notifications (system `notifications` table) |
| Live data | ⚠ UNVERIFIED — the audit session had no reachable tenant DB (the shared `prime_db` connection has no tenant tables; tenant rows live in per-tenant databases). Row counts on test.localhost were not measured. DDL and migration files are quoted for the schema claims below. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. The dashboard and children pages render the right *shape* of data and are correctly scoped to the parent's own children, but three things block go-live: (1) the switch-child AJAX endpoint leaks raw exception text and wrong HTTP codes to the caller (`PDC-01`, B), (2) the session-create path in the owned `ParentContextService` can crash a multi-child parent's first page load because it writes a NOT NULL column that mass-assignment drops (`PCS-02`, B), and (3) the dashboard's attendance percentage uses the same wrong status list the sibling attendance report flagged as `PAT-05` — any `Half Day` or `Short Leave` day is silently excluded (`PDC-09`, H). Around those, `switchChild` does two DB writes with no transaction and a comment that claims it writes nothing at all (`PDC-04`), `index()` is a 156-line method (`PDC-07`), and `resolveChild()` performs a write on every read path (`PCS-01`). Everything is fixable in place with S/M effort; no route name or URL changes are proposed.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 5 | 9 | 3 | 4 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PDC-01, PDC-02, PDC-03 | F8 Services/Jobs | PCS-01, PCS-03, PCS-04 |
| F2 Transactions/Audit | PDC-04, PCS-01 | F9 Queries/Perf | PDC-11, PDC-12 |
| F3 Authorization | clean | F10 Views | PDC-13 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | PDC-06, PDC-14, PCS-05 |
| F6 Controller shape | PDC-05, PDC-07, PDC-08 | F13 Deep read | PDC-04, PDC-09, PDC-10, PCS-02 |
| F7 Models | PDC-09, PDC-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php` | controller | 286 | this report | ✅ |
| 2 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | this report (pre-assigned, 00-CLASS-OWNERS.md:309) | ✅ |
| 3 | `Modules/ParentPortal/app/Http/Requests/SwitchChildParentDashboardRequest.php` | FormRequest | 17 | this report (used only here) | ✅ |
| 4 | `Modules/ParentPortal/resources/views/children/index.blade.php` | view | 260 | this report | ✅ |
| 5 | `Modules/ParentPortal/resources/views/dashboard/index.blade.php` | view | 450 | this report | ✅ |
| 6 | `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | FormRequest base | 26 | ↗ [ParentComplaintController](../ParentComplaintController-done/01-report.md) | ↗ linked |
| 7 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked |
| 8 | `Modules/StudentProfile/app/Models/Student.php` | model | 446 | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController/01-report.md) | ↗ linked (usage only) |
| 9 | `Modules/StudentProfile/app/Models/Guardian.php` | model | — | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) | ↗ linked |
| 10 | `Modules/StudentProfile/app/Models/StudentGuardianJnt.php` | model | — | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) | ↗ linked |
| 11 | `Modules/ParentPortal/app/Models/ParentSession.php` | model | 141 | ↗ [ParentAccountController](../ParentAccountController-done/01-report.md) | ↗ linked (usage only; PAC-04/PAC-05 own the column/fillable defects) |
| 12 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | — | ↗ [gaurav/StudentProfile/AttendanceController](../../../gaurav/StudentProfile/AttendanceController/01-report.md) | ↗ linked (usage only) |
| 13 | `Modules/LmsHomework/app/Models/Homework.php` | model | — | ↗ [ParentHomeworkController](../ParentHomeworkController-done/01-report.md) | ↗ linked |
| 14 | `Modules/LmsHomework/app/Models/HomeworkSubmission.php` | model | — | ↗ [ParentHomeworkController](../ParentHomeworkController-done/01-report.md) | ↗ linked |
| 15 | `Modules/LmsExam/app/Models/ExamAllocation.php` | model | — | ↗ [shailesh/LmsExam/ExamAllocationController](../../../shailesh/LmsExam/ExamAllocationController/01-report.md) | ↗ linked |
| 16 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | — | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md) | ↗ linked |
| 17 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | — | ↗ [TimetableFoundation/TimetableController](../../TimetableFoundation/TimetableController-done/01-report.md) | ↗ linked |
| 18 | `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | service | — | ↗ [TimetableFoundation/TimetableFoundationController](../../TimetableFoundation/TimetableFoundationController/01-report.md) | ↗ linked |
| 19 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | — | ↗ [tarun/StandardTimetable/StandardTimetableController-done](../StandardTimetable/StandardTimetableController-done/01-report.md) | ↗ linked |

No pre-applied files.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null \
  | php -r '$r=json_decode(stream_get_contents(STDIN),true);
            foreach($r as $x) if(str_contains($x["action"],"ParentDashboardController@"))
              printf("%-7s %-60s %-45s %s\n",$x["method"],$x["uri"],$x["name"]??"-",$x["action"]);'

GET|HEAD parent-portal                                                parent-portal.dashboard                       Modules\ParentPortal\Http\Controllers\ParentDashboardController@index
GET|HEAD parent-portal/children                                       parent-portal.children                        Modules\ParentPortal\Http\Controllers\ParentDashboardController@children
POST    parent-portal/switch-child                                   parent-portal.switch-child                    Modules\ParentPortal\Http\Controllers\ParentDashboardController@switchChild
```

Middleware on all three routes (from `route:list`): `web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains, Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\EnsureTenantIsActive, App\Http\Middleware\EnsureTenantHasModule:ParentPortal, Illuminate\Auth\Middleware\Authenticate, Modules\ParentPortal\Http\Middleware\ParentPortalMiddleware`.

Unrouted public methods: none — `index`, `children`, `switchChild` are the only public methods and all three are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `children` | 34 | GET parent-portal/children | ParentPortalMiddleware (route) | none — read + audit | 'Viewed' | sys_activity_logs | PDC-02, PDC-03, PDC-06, PDC-12, PDC-13 |
| `index` | 98 | GET parent-portal | ParentPortalMiddleware (route) | none — read + audit | 'Viewed' | sys_activity_logs | PDC-02, PDC-07, PDC-08, PDC-09, PDC-10, PDC-11, PDC-06 |
| `switchChild` | 264 | POST parent-portal/switch-child | ParentPortalMiddleware + FormRequest authorize + `assertCanAccess` (service, 403) | none — write path without a transaction | 'Switched' | ppt_parent_sessions (via service), sys_activity_logs | PDC-01, PDC-04, PDC-05, PDC-06 |

## 6. Findings

### F1 — Errors

#### PDC-01 · B · ERR-01 — the switch-child AJAX returns the raw exception text (and turns 403/404 into 422)

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; no `$e->getMessage()` in JSON, flash or `back()`*; plus the settled D1 (a controller `try/catch` is a finding unless one of the D2 shapes applies — none does) and ERR-02 (H) — *a catch must never turn a 404/403/422 into a different status*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:264-285`, method `switchChild()` |
| **Root cause** | `switchChild()` wraps the whole write in `try { … } catch (\Throwable $e) { return response()->json(['status' => false, 'message' => $e->getMessage()], 422); }`. `setActiveChild()` performs `Student::findOrFail($studentId)` (a 404) and `assertCanAccess()` → `abort_unless(..., 403, …)`; both land in the generic catch, so a real 404/403 is reported as a 422 with the raw `ModelNotFoundException` text ("No query results for model [Modules\StudentProfile\Models\Student]") or the abort message, and any `QueryException` would leak SQL text. |
| **Consequence** | A parent who taps "Switch to this Child" for a child that is no longer linked sees a 422 with the model's class name (or a DB error string) instead of a clean 403; a transient DB failure shows raw SQL to the browser. |
| **Reproduce** | POST `/parent-portal/switch-child` with `student_id` that exists but is not linked to this parent: `setActiveChild` → `assertCanAccess` throws 403 → catch converts to `{"status":false,"message":"You are not authorised to view this child's data."}` HTTP 422. POST `student_id=999999999`: `findOrFail` throws → catch converts to 422 with the "No query results" text. |
| **Fix approach** | Delete the controller `try/catch` entirely (D1); validation is already in the FormRequest and the central handler in `bootstrap/app.php` renders 403/404/500 with the correct status for JSON callers. Move `activityLog()` inside a `DB::transaction` or after the write per D1/D2 with no catch. |
| **Plan item** | PDC-01 in `02-fix-plan.md` §1 |

```php
// ParentDashboardController.php:264-285 — CURRENT
    public function switchChild(SwitchChildParentDashboardRequest $request): JsonResponse
    {
        $validated = $request->validated();

        try {
            $this->context->setActiveChild($request, (int) $request->input('student_id'));
            $child = $this->context->resolveChild($request);
            activityLog(auth()->user(), 'Switched', [
                'message' => 'Switched active child',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);

            return response()->json(['status' => true, 'message' => 'Child switched.']);
        } catch (\Throwable $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage()], 422);
        }
    }
```

**Evidence**
```
$ grep -n "getMessage\|Try {\|catch (" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
283:            return response()->json(['status' => false, 'message' => $e->getMessage()], 422);
```
The central handler `bootstrap/app.php:100-153` explicitly renders `HttpExceptionInterface` with its real status and JSON for `expectsJson()` callers, so the catch is unnecessary.

#### PDC-02 · M · ERR-07 / ERR-05 — read methods wrap the audit-log write in a try/catch and log only the message

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch under either variant*; ERR-05 (M) — *log the exception, not just the message*; plus D1 (a controller catch is a finding unless a D2 shape applies — none does). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:81-93` (`children()`), `:225-241` (`index()`) |
| **Root cause** | Both read methods wrap their single `activityLog(…)` insert in `try { … } catch (\Throwable $e) { Log::error('view log failed', ['method' => …, 'error' => $e->getMessage()]); }`. The comment claims "Rule A1, scoped to the audit write" — D1 says house rule A1 does NOT apply to modules under final audit. The catch logs only `$e->getMessage()` (the trace is lost) and would also swallow any other `Throwable`. |
| **Consequence** | If the activity-log insert fails, the failure is recorded as a one-line message with no stack trace, and the same blanket catch silently absorbs unrelated errors; nobody can diagnose the audit gap. |
| **Reproduce** | Static only — the two identical `try/catch` blocks prove the behaviour; a live trigger needs fault injection. |
| **Fix approach** | Delete the `try/catch` in both methods (D1) and call `activityLog()` directly; swap the in-block `request()->route()` helper for the injected `$request`; drop the now-unused `use Illuminate\Support\Facades\Log;` import (Pint does that). |
| **Plan item** | PDC-02 in `02-fix-plan.md` §3 |

```php
// ParentDashboardController.php:225-241 — CURRENT (index(); children() is 81-93 with the same shape)
        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed dashboard',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\|getMessage" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
81:        try {                 (children audit)
91:        } catch (\Throwable $e) {
92:            Log::error('view log failed', ['method' => 'children', 'error' => $e->getMessage()]);
229:        try {                 (index audit)
239:        } catch (\Throwable $e) {
240:            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
```

#### PDC-03 · M · ERR-07 / ERR-06 — children() swallows every resolveChild() failure and silently falls back to the first child

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch*; ERR-06 (H, lowered) — *no swallowed failures — an empty catch that continues as if nothing happened*. Lowered to M because the write being swallowed belongs to the session touch inside `resolveChild()`, and the visible result is a wrong active-child indicator, not data loss. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:40-47`, method `children()` |
| **Root cause** | `resolveChild()` is called for a non-empty children list, inside `try { … } catch (\Throwable) { $activeId = $children->first()->id; }`. For multi-child parents `resolveChild()` → `getOrCreateSession()` performs a DB write (create/update of `ppt_parent_sessions`); if that write fails (see `PCS-02`), the catch silently renders "first child as active" instead of showing an error. The no-access redirect inside `resolveChild()` (`abort(redirect(...))`) would also be swallowed were it reachable here. |
| **Consequence** | A session-write failure on the children page is invisible — the parent sees the first child marked active, and the real error is never logged. |
| **Reproduce** | Static only — the empty `catch (\Throwable)` at line 44; a live trigger needs the session insert to fail (see PCS-02). |
| **Fix approach** | Remove the `try/catch` (D1). The middleware already guarantees ≥1 accessible child for this route, so `resolveChild()` cannot abort here; a genuine failure should surface through the central handler. |
| **Plan item** | PDC-03 in `02-fix-plan.md` §3 |

```php
// ParentDashboardController.php:39-47 — CURRENT
        $activeChild = null;
        if ($children->isNotEmpty()) {
            try {
                $activeChild = $this->context->resolveChild($request);
                $activeId = $activeChild->id;
            } catch (\Throwable) {
                $activeId = $children->first()->id;
            }
        }
```

**Evidence**
```
$ sed -n '39,47p' Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
        $activeChild = null;
        if ($children->isNotEmpty()) {
            try {
                $activeChild = $this->context->resolveChild($request);
                $activeId = $activeChild->id;
            } catch (\Throwable) {
                $activeId = $children->first()->id;
            }
        }
```

### F2 — Transactions and audit

#### PDC-04 · H · TXN-01 — switchChild() writes two DB rows with no transaction, and the comment claims it writes none

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside ONE `DB::transaction`*; every mutation that calls `activityLog()` counts as multi-table (controller-alignment §0.1/§6: count across the controller AND the service). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:258-284` (`switchChild`), plus `Modules/ParentPortal/app/Services/ParentContextService.php:131-148` (`setActiveChild`) |
| **Root cause** | `switchChild()` → `setActiveChild()` writes `ppt_parent_sessions` (2 writes when a session row is first created: `getOrCreateSession()` INSERT then the caller UPDATE), then `activityLog()` writes `sys_activity_logs`. No `DB::transaction` anywhere. The comment above the method says "Rule 2 deliberately does not apply: this writes session state via ParentContext, not a database row, so there is nothing to roll back" — that is false: `setActiveChild()` writes `ppt_parent_sessions.active_student_id` and `last_active_at` (service docblock line 18 confirms the row is DB-persisted). |
| **Consequence** | If the audit insert fails after the session update, the switch has happened but the audit log and the JSON response lie ("Child switched." is returned only on the happy path); a partial failure can leave the session switched without a log. |
| **Reproduce** | Static only — grep shows no `DB::transaction` in either file's write path. |
| **Fix approach** | Wrap `setActiveChild()` and the subsequent `activityLog()` in one `DB::transaction(fn () => …)` closure, delete the misleading comment, and build the JSON response after the closure returns (TXN-05). |
| **Plan item** | PDC-04 — no separate item: the whole switchChild rewrite in PDC-01 (§1) wraps the write in `DB::transaction` and fixes the comment. Listed in plan §10. |

```php
// ParentDashboardController.php:255-284 — CURRENT (comment + switchChild)
    /**
     * AJAX POST — switch the active child for this guardian session.
     */
    /**
     * Switch which child the parent is acting as.
     *
     * Rule 3 is here. Rule 2 deliberately does not apply: this writes session state via
     * ParentContext, not a database row, so there is nothing to roll back.
     */
    public function switchChild(SwitchChildParentDashboardRequest $request): JsonResponse
    {
        $validated = $request->validated();

        try {
            $this->context->setActiveChild($request, (int) $request->input('student_id'));
            $child = $this->context->resolveChild($request);
            activityLog(auth()->user(), 'Switched', [
                'message' => 'Switched active child',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);

            return response()->json(['status' => true, 'message' => 'Child switched.']);
        } catch (\Throwable $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage()], 422);
        }
    }
```

**Evidence**
```
$ grep -rn "DB::transaction" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php Modules/ParentPortal/app/Services/ParentContextService.php
(no output)
```

### F8 — Services and jobs

#### PCS-01 · H · SVC-03 / TXN-01 — resolveChild() writes (or inserts!) ppt_parent_sessions on every GET page load for multi-child parents

| Field | Value |
|---|---|
| **Rule** | SVC-03 (H) — *no writes on read paths: no updateOrCreate/firstOrCreate inside methods called by GET pages*; TXN-01 (H) — the create-then-update pair in one request is not transactional. |
| **Where** | `Modules/ParentPortal/app/Services/ParentContextService.php:93-124` (`resolveChild`), `:202-222` (`getOrCreateSession`) |
| **Root cause** | `resolveChild()` is called by `index()` and `children()` (both GET). For parents with more than one child it calls `getOrCreateSession()`, which either `UPDATE`s `last_active_at` on the latest row or `ParentSession::create(...)`s a new row; then `resolveChild()` may `UPDATE active_student_id` again (line 119-121). Every dashboard/children page view for a multi-child parent therefore performs 1-2 DB writes on a read request, with no transaction. |
| **Consequence** | Every GET for a multi-child parent writes to the database (extra load, non-idempotent reads), and on the first visit the INSERT path can crash the page (see PCS-02). |
| **Reproduce** | Open `/parent-portal` as a parent linked to 2+ children with no existing session row: `getOrCreateSession` runs `INSERT INTO ppt_parent_sessions …`. |
| **Fix approach** | Move the session touch out of the read resolution: `resolveChild()` should read only; the `last_active_at`/create logic belongs on explicit write endpoints. Wrap any create+update in one `DB::transaction`. |
| **Plan item** | PCS-01 — DECISION in `02-fix-plan.md` §9 (option a: make `resolveChild()` read-only; option c: wrap the writes in a transaction) |

```php
// ParentContextService.php:111-124 — CURRENT (resolveChild multi-child branch)
        // Multiple children: use DB-persisted active_student_id
        $guardian       = $this->resolveGuardian($request->user());
        $parentSession  = $this->getOrCreateSession($guardian, $request);
        $activeId       = $parentSession->active_student_id;

        $child = $children->firstWhere('id', $activeId) ?? $children->first();

        // Persist resolved child back if it changed (e.g. previously active child deactivated)
        if ($parentSession->active_student_id !== $child->id) {
            $parentSession->update(['active_student_id' => $child->id]);
        }

        return $this->activeChildMemo[$parentId] = $child;
```

**Evidence**
```
$ grep -n "update(\|ParentSession::create(" Modules/ParentPortal/app/Services/ParentContextService.php
120:            $parentSession->update(['active_student_id' => $child->id]);
163:        $session->update(array_filter([
210:            $session->update(['last_active_at' => now()]);
214:        return ParentSession::create([
```

#### PCS-02 · B · MDL-07 / MDL-01 — session create passes `device_type`, which is not fillable, so the NOT NULL `device_type_option_id` insert fails

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *a write to a missing/unfillable column 500s on use*; MDL-01 (H) — fillable must cover what is written; raised to B because the insert is on a normal user path (first dashboard load for a multi-child parent). |
| **Where** | `Modules/ParentPortal/app/Services/ParentContextService.php:214-221` (`getOrCreateSession` create branch) and `:163-171` (`registerDeviceToken` — shared line; the webpush half is already owned by `PAC-04` in the ParentAccountController plan) |
| **Root cause** | `ParentSession::create(['guardian_id' => …, 'active_student_id' => null, 'device_type' => 'Web', 'is_active' => true, …])`. `device_type` is NOT in `ParentSession::$fillable` (proved by `isFillable('device_type') === false`), so mass-assignment silently drops it; the `setDeviceTypeAttribute` mutator therefore never runs, and `device_type_option_id` — a NOT NULL column with no default in the tenant migration (`2026_06_16_105227_create_ppt_parent_sessions_table.php:19`) — is left unset → `QueryException` on INSERT. Same for `registerDeviceToken`'s `device_type` key. |
| **Consequence** | A parent with 2+ children whose session row does not yet exist gets a 500 on their first dashboard/children load instead of the page; the mobile device-token endpoint can fail the same way. |
| **Reproduce** | Static proof: `php -r '(…)->isFillable("device_type")'` → `false`; migration line 19 has no `->nullable()`/`->default()`. Live trigger needs a tenant with a multi-child parent and no session row (not measured — the shared `prime_db` connection has no tenant tables). |
| **Fix approach** | In the service, resolve the dropdown id and pass the real fillable key: `'device_type_option_id' => PptDropdownResolver::id('ppt_parent_sessions.device_type', 'Web') ?? PptDropdownResolver::id('ppt_parent_sessions.device_type', 'Unknown')`. This stays inside the service file (owned by this report) and does not touch `ParentSession` (owned by the account report, decision PAC-05 there). |
| **Plan item** | PCS-02 in `02-fix-plan.md` §1 (B, reachable when the create path runs — sequenced before PCS-01) |

```php
// ParentContextService.php:214-221 — CURRENT
        return ParentSession::create([
            'guardian_id'       => $guardian->id,
            'active_student_id' => null,
            'device_type'       => 'Web',
            'is_active'         => true,
            'last_active_at'    => now(),
            'created_by'        => $request->user()->id,
        ]);
```

**Evidence**
```
$ php -r 'require "vendor/autoload.php"; $a=require "bootstrap/app.php";
  $a->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
  $m = new Modules\ParentPortal\Models\ParentSession();
  echo "device_type fillable: "; var_export($m->isFillable("device_type")); echo PHP_EOL;'
device_type fillable: false

$ grep -n "device_type_option_id" database/migrations/tenant/2026_06_16_105227_create_ppt_parent_sessions_table.php
19:            $table->unsignedInteger('device_type_option_id');
```

#### PCS-03 · M · SVC-01 — resolveChild() aborts with an HTTP redirect from inside a service

| Field | Value |
|---|---|
| **Rule** | SVC-01 (M) — *services don't touch HTTP: no `redirect()`/`abort()`; pass data in, return data out*. |
| **Where** | `Modules/ParentPortal/app/Services/ParentContextService.php:103-105`, method `resolveChild()` |
| **Root cause** | When a parent has no accessible children, the service calls `abort(redirect()->route('parent-portal.no-access'))`. That makes a read resolver decide HTTP flow; because `ParentPortalBaseRequest::authorize()` wraps this call in `catch (\Exception) { return false; }`, the redirect actually becomes a bare 403 on every FormRequest path (cross-cutting note, base request owner: ParentComplaintController). |
| **Consequence** | On FormRequest paths the intended no-access redirect is converted to a 403; on the direct `index()`/`children()` paths the redirect works only because the middleware already guarantees ≥1 child, so the abort is effectively dead code today. |
| **Reproduce** | Static only — the abort is not reachable from this controller's routes because `ParentPortalMiddleware` redirects childless parents to no-access before the controller runs. |
| **Fix approach** | Return an explicit result (empty child / nullable) from the service and let the controller decide the redirect; or keep `resolveChild()` typed non-null and let caller pre-checks handle the empty case. Low-risk, coordinated with the base-request owner. |
| **Plan item** | PCS-03 — DECISION in `02-fix-plan.md` §9 (option b: keep the abort but coordinate base-request fix; the abort is unreachable from this controller's guarded routes) |

```php
// ParentContextService.php:101-105 — CURRENT
        $children = $this->getAccessibleChildren($request->user());

        if ($children->isEmpty()) {
            abort(redirect()->route('parent-portal.no-access'));
        }
```

**Evidence**
```
$ grep -n "redirect()\|abort(" Modules/ParentPortal/app/Services/ParentContextService.php
104:            abort(redirect()->route('parent-portal.no-access'));
```

#### PCS-04 · M · CTL-10 / QRY-12 — `guardianMemo` is declared but never used; `resolveGuardian()` re-queries every call

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code*; QRY-12 (M) — *the same lookup resolved multiple times in one request → resolve once*. |
| **Where** | `Modules/ParentPortal/app/Services/ParentContextService.php:43-44` (dead property), `:193-196` (`resolveGuardian`) |
| **Root cause** | `private array $guardianMemo = [];` is documented as a memo but nothing writes or reads it; `resolveGuardian()` runs `Guardian::where('user_id', $user->id)->firstOrFail()` fresh every call. In a single `switchChild()` request the guardian is looked up at least twice (once in `resolveGuardian` from `setActiveChild`, once via `getAccessibleChildren`). |
| **Consequence** | One redundant DB query per request and a misleading dead property; small, but the class is reached by ~26 controllers. |
| **Reproduce** | `grep -n "guardianMemo"` → only the declaration; `resolveGuardian` (193-196) never touches it. |
| **Fix approach** | Either wire the memo into `resolveGuardian()` (keyed by user id, like the other memos) or delete the property. Rewiring is the better fix (consistent with the children/activeChild memos). |
| **Plan item** | PCS-04 in `02-fix-plan.md` §3 |

```php
// ParentContextService.php:193-196 — CURRENT
    private function resolveGuardian(User $user): Guardian
    {
        return Guardian::where('user_id', $user->id)->firstOrFail();
    }
```

**Evidence**
```
$ grep -n "guardianMemo" Modules/ParentPortal/app/Services/ParentContextService.php
44:    private array $guardianMemo = [];
```

### F3 — Authorization

clean — every routed method sits behind `ParentPortalMiddleware` (route-level gate, owned by the ParentHealthController report) and `Authenticate`; `children()`/`index()` data is scoped by `getAccessibleChildren()` (only the parent's own linked children), and `switchChild()` additionally passes the FormRequest `authorize()` (resolveChild) and the record-level `assertCanAccess()`/`abort_unless(403)` in the service. Proof: `grep -rn "authorize\|abort_unless" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php` → none; the FormRequest `SwitchChildParentDashboardRequest::authorize()` returns `parent::authorize()` (ParentPortalBaseRequest), and `assertCanAccess` is at `ParentContextService.php:179-189`. No permission strings exist in this module (AUTH-06 n/a — middleware is the single gate).

### F4 — Validation and input

clean — the only input is `student_id` via the `SwitchChildParentDashboardRequest` FormRequest (`['required', 'integer']`), the controller never writes `$request->all()`/`except()` to a model (it passes `(int) $request->input('student_id')` to the service, which re-checks ownership), and `validated()` is read before use. The unused `$validated` variable is a CTL-10 style issue covered by PDC-05, not a validation hole.

### F5 — Routes

clean — all three methods are routed with the exact names/URIs shown in §4; no state change over GET (`switch-child` is POST); every route carries the tenant + auth + ParentPortalMiddleware stack; no `Route::resource` conflicts; no unrouted public methods.

### F6 — Controller shape

#### PDC-05 · M · CTL-10 — dead `$validated` variable in switchChild()

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:266-269` |
| **Root cause** | `$validated = $request->validated();` is assigned and then never used — the code calls `$request->input('student_id')` instead (line 269). |
| **Consequence** | The validation result is discarded; a reader cannot tell that the input is validated. |
| **Reproduce** | `grep -n "validated" ParentDashboardController.php` → only the assignment at 266 and the FormRequest import. |
| **Fix approach** | Use `$validated['student_id']` at the call site (part of the PDC-04 rewrite). |
| **Plan item** | PDC-05 — no separate item: the switchChild rewrite in PDC-01 (§1) uses `$validated['student_id']`, which makes the variable live. Listed in plan §10. |

```php
// ParentDashboardController.php:266-270 — CURRENT
        $validated = $request->validated();

        try {
            $this->context->setActiveChild($request, (int) $request->input('student_id'));
```

**Evidence**
```
$ grep -n "validated" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
266:        $validated = $request->validated();
```

(No other `$validated` use in the file.)

#### PDC-07 · H · CTL-02 — index() is 156 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *method length: over 150 lines is H*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:98-253`, method `index()` |
| **Root cause** | One method loads attendance, timetable, homework, exams, fees, leave and notifications — seven read blocks in a single `if ($session?->classSection)` section. |
| **Consequence** | Hard to review and to test; a change in one card risks another card. |
| **Reproduce** | `awk 'NR>=98 && NR<=253' … | wc -l` → 156. |
| **Fix approach** | Extract each card's data loading into private methods (or a small dashboard-summary service), keeping one method per concern; the split is fix-in-place (D3 not needed for a method-length extraction). |
| **Plan item** | PDC-07 in `02-fix-plan.md` §9 (DECISION — option a: defer the extraction, option b: extract now) |

```php
// ParentDashboardController.php:98-104 — CURRENT (head of index(); the method runs to line 253)
    public function index(Request $request): View
    {
        $child = $this->context->resolveChild($request);

        $session = $child->currentSession()
            ->with(['classSection.class', 'classSection.section', 'academicSession'])
            ->first();
```

**Evidence**
```
$ awk 'NR>=98 && NR<=253' Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php | wc -l
156
```

#### PDC-08 · M · CTL-07 — compact() passes 17 variables

| Field | Value |
|---|---|
| **Rule** | CTL-07 (M) — *no compact() of more than ~15 variables*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:243-252` |
| **Root cause** | The dashboard view payload is assembled with `compact('child','session','attendancePct',…)` — 17 vars. |
| **Consequence** | The view's data dependency is only discoverable by reading the controller; a missed variable silently becomes null in the blade. |
| **Reproduce** | `grep -n "compact("` → line 243 spans 17 names. |
| **Fix approach** | Group into a view-model array (or the extracted methods from PDC-07 return one array), and pass that. |
| **Plan item** | PDC-08 in `02-fix-plan.md` §8 |

```php
// ParentDashboardController.php:243-252 — CURRENT
        return view('parentportal::dashboard.index', compact(
            'child', 'session',
            'attendancePct', 'attendancePresent', 'attendanceTotal',
            'todayCells',
            'pendingHomework', 'pendingHomeworkCount',
            'upcomingExams', 'upcomingExamCount',
            'feeTotal', 'feePaid', 'feeDue', 'feePendingInvoices',
            'leaveCount', 'leavePendingCount',
            'notifications',
        ));
```

**Evidence**
```
$ grep -n "compact(" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
95:        return view('parentportal::children.index', compact('children', 'activeId', 'subjectsByClass'));
243:        return view('parentportal::dashboard.index', compact(
```

### F7 — Models

#### PDC-09 · H · MDL-09 — the dashboard attendance % uses status aliases that do not exist in the DB enum (Half Day / Short Leave never counted)

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L, raised to **H**) — *status/type strings are enums/constants, not literals repeated across files*; raised because the mismatch produces a wrong number on a real screen (rulebook severity H: "wrong result on a real screen"). Same family as `PAT-05` in the sibling [ParentAttendanceController](../ParentAttendanceController-done/01-report.md). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:115-118` (`index()`) |
| **Root cause** | The Present count filters `whereIn('status', ['Present', 'P', 'present'])`, but `std_student_attendance.status` is `ENUM('Present','Absent','Late','Half Day','Short Leave','Leave')` (DDL `StudentProfile_ddl_v1.6.sql:389`). `P`/`present` never match; `Half Day` and `Short Leave` rows are counted in `attendanceTotal` but never in `attendancePresent`, so the percentage is understated whenever such a day exists. |
| **Consequence** | A child with any Half Day/Short Leave day shows a lower attendance % on the dashboard than reality, and the number disagrees with the student-facing pages (the same complaint PAT-05 measured). |
| **Reproduce** | Mark a child `Half Day` for one day then open `/parent-portal`: the Attendance card shows a smaller % than counting Present+Half Day+Short Leave+Late would give. |
| **Fix approach** | Count against the real enum — mirror the choice made for PAT-05 (decision in the attendance report): treat `Present`, `Late`, `Half Day`, `Short Leave` as present for the % and drop the aliases, OR add separate buckets. This finding's plan item defers the exact rule to the PAT-05 decision to keep parent/student numbers in agreement. |
| **Plan item** | PDC-09 in `02-fix-plan.md` §9 (DECISION — tied to PAT-05; option a: match student portal, option b: separate buckets) |

```php
// ParentDashboardController.php:111-121 — CURRENT
        if ($session?->academic_session_id) {
            $attendanceTotal = StudentAttendance::where('student_id', $child->id)
                ->where('academic_session_id', $session->academic_session_id)
                ->count();
            $attendancePresent = StudentAttendance::where('student_id', $child->id)
                ->where('academic_session_id', $session->academic_session_id)
                ->whereIn('status', ['Present', 'P', 'present'])
                ->count();
            $attendancePct = $attendanceTotal > 0
                ? round(($attendancePresent / $attendanceTotal) * 100) : 0;
        }
```

**Evidence**
```
$ grep -n "status.*ENUM" pgdatabase/Backup/1-Module_DDLs_2026-06-22/StudentProfile/DDL/StudentProfile_ddl_v1.6.sql | head -2
389:    `status` ENUM('Present','Absent','Late','Half Day','Short Leave','Leave') NOT NULL,
```

#### PDC-10 · M · MDL-09 — the pending-invoice count uses case-spelling literals that exclude nothing and count Cancelled/Draft as pending

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L, raised to **M**) — *status strings as literals*; raised because it produces a wrong card value. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:206` (`index()`) |
| **Root cause** | `$feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();`. `fee_invoices.status` is `ENUM('Draft','Published','Partially Paid','Paid','Overdue','Cancelled')` (StudentFee DDL line 322). The only matching literal is `Paid`, so "pending" = every invoice that is not `Paid` — including `Draft` and `Cancelled` rows that are not actually pending. |
| **Consequence** | The "X invoice(s) pending" hint on the dashboard fee card over-counts when the assignment contains draft or cancelled invoices. |
| **Reproduce** | Create a `Cancelled` invoice for the child's fee assignment and open `/parent-portal`: the Fee Due card shows it as pending. |
| **Fix approach** | Use the module's constants (FeeInvoice status constants if present) or an explicit set `['Published','Partially Paid','Overdue']`; keep it in sync with the DDL enum. |
| **Plan item** | PDC-10 in `02-fix-plan.md` §5 |

```php
// ParentDashboardController.php:200-207 — CURRENT
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $invoices = $feeAssignment->invoices ?? collect();
            $feeTotal = (float) $invoices->sum('total_amount');
            $feePaid = (float) $invoices->sum('paid_amount');
            $feeDue = (float) $invoices->sum('balance_amount');
            $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
        }
```

**Evidence**
```
$ grep -rn "status.*ENUM" pgdatabase/Backup/1-Module_DDLs_2026-06-22/StudentFee/DDL/*.sql | grep -i "Draft.*Published"
322:    `status` ENUM('Draft', 'Published', 'Partially Paid', 'Paid', 'Overdue', 'Cancelled') NOT NULL DEFAULT 'Draft',
```

### F9 — Queries and performance

#### PDC-11 · H · QRY-05 — upcoming exams are fetched whole and filtered/sorted in PHP

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M, raised to **H**) — *`->get()->filter()->sortBy()` should be SQL `where`/`orderBy`*; raised because the query loads every active allocation for the class/section/student and then filters on `examPaper` and future dates in PHP — on a large school this is the dashboard's most expensive block. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:177-191` (`index()`) |
| **Root cause** | `ExamAllocation::where(...)->with(['examPaper.exam','examPaper.subject'])->get()->filter(fn ($a) => $a->examPaper !== null)->filter(… isFuture)->sortBy(...)`. The `examPaper !== null` filter is `whereHas('examPaper')`; the future-date and sort could use `whereDate`/`orderBy` on `scheduled_date` (with a fallback for the exam start date). |
| **Consequence** | Every dashboard load pulls all matching allocations into memory and discards most of them; grows with the school's exam setup, and the `isFuture()` filter calls `Carbon::parse` per row. |
| **Reproduce** | Open `/parent-portal` — the query at 177 runs `->get()` over all active allocations matching the class/section/student. |
| **Fix approach** | Move the `examPaper` filter into `whereHas('examPaper')`; express the date filter as SQL where possible; keep the `scheduled_date ?? exam.start_date` fallback only where SQL cannot express it (document why). |
| **Plan item** | PDC-11 in `02-fix-plan.md` §6 |

```php
// ParentDashboardController.php:177-189 — CURRENT
            $allExamAllocations = ExamAllocation::where('is_active', true)
                ->where(fn ($q) => $q
                    ->where(fn ($q1) => $q1->where('allocation_type', 'CLASS')->where('class_id', $classId))
                    ->orWhere(fn ($q2) => $q2->where('allocation_type', 'SECTION')
                        ->where('class_id', $classId)->where('section_id', $sectionId))
                    ->orWhere(fn ($q3) => $q3->where('allocation_type', 'STUDENT')->where('student_id', $child->id))
                )
                ->with(['examPaper.exam', 'examPaper.subject'])
                ->get()
                ->filter(fn ($a) => $a->examPaper !== null)
                ->filter(fn ($a) => ($d = $a->scheduled_date ?? $a->examPaper?->exam?->start_date)
                    && Carbon::parse($d)->isFuture())
                ->sortBy(fn ($a) => $a->scheduled_date ?? $a->examPaper?->exam?->start_date);
```

**Evidence**
```
$ grep -n "->get()\|->filter(\|->sortBy(" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
186:                ->filter(fn ($a) => $a->examPaper !== null)
187:                ->filter(fn ($a) => ($d = $a->scheduled_date ?? $a->examPaper?->exam?->start_date)
189:                ->sortBy(fn ($a) => $a->scheduled_date ?? $a->examPaper?->exam?->start_date);
```

#### PDC-12 · M · QRY-12 — children() re-loads relations the service already eager-loaded

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:50-54` vs `Modules/ParentPortal/app/Services/ParentContextService.php:77-81` |
| **Root cause** | `getAccessibleChildren()` eager-loads `currentSession.classSection.class` and `.section`; `children()` then calls `$children->load([... same ..., 'currentSession.academicSession'])`, re-issuing the already-loaded relations plus the academic session. |
| **Consequence** | One extra set of class/section queries per page load on the children screen. |
| **Reproduce** | Open `/parent-portal/children` — `$children->load(...)` re-queries `currentSession.classSection.*` even though the service loaded them. |
| **Fix approach** | Load only the missing relation: `$children->loadMissing('currentSession.academicSession');` (or add `academicSession` to the service's `with()`). |
| **Plan item** | PDC-12 in `02-fix-plan.md` §6 |

```php
// ParentDashboardController.php:49-54 — CURRENT
        // Eager-load extra context for the cards
        $children->load([
            'currentSession.classSection.class',
            'currentSession.classSection.section',
            'currentSession.academicSession',
        ]);
```

**Evidence**
```
$ grep -n "with(\|load(" Modules/ParentPortal/app/Services/ParentContextService.php Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php | head
ParentContextService.php:77:            ->with([
ParentDashboardController.php:50:        $children->load([
```

### F10 — Views

#### PDC-13 · M · VIEW-02 / QRY-01 — children view reads `roll_number`, which lazy-loads `currentAcademicSession` per child (N+1)

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations used inside `@foreach` are eager-loaded*; QRY-01 (H, lowered) — *no queries inside loops*; lowered because the parent typically has 1-5 children, so the blast is small but real. |
| **Where** | `Modules/ParentPortal/resources/views/children/index.blade.php:141` and `Modules/StudentProfile/app/Models/Student.php:235-237` (`getRollNumberAttribute`) |
| **Root cause** | The blade prints `{{ $ch->roll_number ?? '—' }}` inside `@foreach($children)`. `roll_number` is an accessor that calls `$this->currentAcademicSession->roll_no` — a DIFFERENT relation from `currentSession`, and it is not in the controller's `load([...])`. Each child therefore triggers a fresh `currentAcademicSession` query (plus its own eager loads). |
| **Consequence** | 1+N extra queries on the My Children page (one per child). |
| **Reproduce** | Open `/parent-portal/children` with 3 children — 3 `currentAcademicSession` lookups beyond the controller's loaded relations. |
| **Fix approach** | Add `'currentAcademicSession'` to the controller's `$children->load([...])` list (same item as PDC-12). |
| **Plan item** | PDC-13 — no separate item: PDC-12's After block adds `currentAcademicSession` to the eager-load list, which makes `roll_number` read from an already-loaded relation. Listed in plan §10. |

```php
// children/index.blade.php:141 — CURRENT
                                <div class="fw-semibold">{{ $ch->roll_number ?? '—' }}</div>
```

**Evidence**
```
$ grep -n "roll_number\|currentAcademicSession" Modules/ParentPortal/resources/views/children/index.blade.php Modules/StudentProfile/app/Models/Student.php
children/index.blade.php:141:                                <div class="fw-semibold">{{ $ch->roll_number ?? '—' }}</div>
Student.php:221:    public function currentAcademicSession()
Student.php:235:    public function getRollNumberAttribute()

$ sed -n '235,237p' Modules/StudentProfile/app/Models/Student.php   # the accessor behind roll_number
    public function getRollNumberAttribute()
    {
        return $this->currentAcademicSession->roll_no ?? null;
    }
```

Other VIEW checks — clean: no `Model::`/`DB::`/`->where(`/`->get()` in either blade (`grep -nE "Model::|DB::|->where\(|->get\("` → no output); no `{!! !!}` (`grep -n "{!!"` → no output); both blades compile with PHP `-l` after `compileString()` (rc=0).

### F11 — Security and tenancy

clean — no `env()` outside config (none in any in-scope file); no personal data over-exposed in JSON (the only JSON is the switch result, no model dump); no hard-coded ids or `?? 1`; no secrets in logs (the `Log::error` on the audit path logs a method name + exception message, not request bodies); no private file serving; no tenant caches keyed without the tenant id (no caching at all in this controller's reads); central models are not reached from tenant context.

### F12 — Style

#### PDC-06 · L · CTL-08 — `request()` helper used inside methods that already receive `$request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods*. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php:88, 236, 277` |
| **Root cause** | `request()->route()?->getName()` is used in three audit contexts although each method has the injected `$request`. |
| **Consequence** | Inconsistent style; the helper hides the dependency. |
| **Reproduce** | `grep -n "request()->" → 88, 236, 277`. |
| **Fix approach** | Use `$request->route()?->getName()`. Folded into the PDC-02 and PDC-04 rewrites. |
| **Plan item** | PDC-06 — no separate item: every `request()->route()` hit is in an audit block that PDC-01 (§1) and PDC-02 (§3) rewrite with the injected `$request`. Listed in plan §10. |

```php
// ParentDashboardController.php:88, 236, 277 — CURRENT (the helper inside the audit context)
                    'route' => request()->route()?->getName(),
```

**Evidence**
```
$ grep -n "request()->" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php
88:                    'route' => request()->route()?->getName(),
236:                    'route' => request()->route()?->getName(),
277:                    'route' => request()->route()?->getName(),
```

#### PDC-14 · L · STY-01 / STY-02 — SwitchChildParentDashboardRequest lacks strict_types and a trailing newline

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files when touched*; STY-02 (L) — Pint-clean. |
| **Where** | `Modules/ParentPortal/app/Http/Requests/SwitchChildParentDashboardRequest.php:1-17` |
| **Root cause** | No `declare(strict_types=1)` at the top; Pint reports `single_blank_line_at_eof`. |
| **Consequence** | Style debt only. |
| **Reproduce** | Static only — `php -l` passes and the request works, but the file starts with `namespace` and ends without a final newline. |
| **Fix approach** | Add the declare and let Pint fix the EOF newline. |
| **Plan item** | PDC-14 in `02-fix-plan.md` §8 |

```php
// SwitchChildParentDashboardRequest.php:1-17 — CURRENT
<?php

namespace Modules\ParentPortal\Http\Requests;

class SwitchChildParentDashboardRequest extends ParentPortalBaseRequest
{
    public function authorize(): bool
    {
        return parent::authorize();
    }

    public function rules(): array
    {
        return [
            'student_id' => ['required', 'integer'],
        ];
    }
}
```

**Evidence**
```
$ vendor/bin/pint --test Modules/ParentPortal/app/Http/Requests/SwitchChildParentDashboardRequest.php --format json
{"files":[{"path":"Modules\/ParentPortal\/app\/Http\/Requests\/SwitchChildParentDashboardRequest.php","fixers":["single_blank_line_at_eof"]}]}
```

#### PCS-05 · L · STY-04 — emoji/⚠ markers in service comments

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *English comments without emoji markers*. |
| **Where** | `Modules/ParentPortal/app/Services/ParentContextService.php:26, 32, 144` |
| **Root cause** | Comment lines carry `⚠`/`⛔` markers. |
| **Consequence** | Style debt only. |
| **Reproduce** | Static only — `grep -nP "[\x{26A0}\x{26D4}]"` on the file finds the three markers. |
| **Fix approach** | Replace emoji with plain words. |
| **Plan item** | PCS-05 in `02-fix-plan.md` §8 |

```php
// ParentContextService.php:24-28 — CURRENT (the first emoji site in the class docblock)
     * Per-request memo for the child lookup.
     *
     * ⚠ WHY: resolveChild() costs 7 queries (guardian → jnt → students →
     * currentSession → classSection → class → section) and controllers call it once
```

**Evidence**
```
$ grep -nP "[\x{26A0}\x{26D4}]" Modules/ParentPortal/app/Services/ParentContextService.php
26:             * ⚠ WHY: resolveChild() costs 7 queries (guardian → jnt → students →
32:             * ⛔ EVERY memo is KEYED BY PARENT ID, deliberately. This service decides which
144:        // ⛔ Invalidate. Without this, a switchChild() followed by any resolveChild()
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | File:line | 1 overwrite? | 2 delete-before-store? | 3 dup impl? | 4 soft-del × unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|---|
| `children` (audit write) | ParentDashboardController.php:81-93 | ok | ok | ok | ok | ok | ok | ok | ok |
| `index` (audit write) | ParentDashboardController.php:225-241 | ok | ok | ok | ok | ok | ok | ok | ok |
| `switchChild` (session write + audit) | ParentDashboardController.php:264-285 | ok — session is the only thing written and it owns the row | ok | ok | ok — session unique is (guardian_id, device_token_fcm) with nullable fcm, not a business key touched here | ok for single-writer; 2 rows across service+controller not in one tx → PDC-04 | ok — FormRequest + assertCanAccess 403 | **yes** — comment claims no DB row; response claims switch when only the audit failed → PDC-04 | ok |
| `resolveChild` (session touch) | ParentContextService.php:93-124 | ok — only updates last_active_at/active_student_id on the parent's own row | ok | ok (single path) | ok | ok | ok — data scoped to own children | ok — but does a write on a GET read → PCS-01 | ok |
| `getOrCreateSession` | ParentContextService.php:202-222 | ok | ok | **yes** — create-with-null-then-update in callers is a 2-write anti-pattern → PCS-01 | ok | ok | ok | ok | ok |
| `setActiveChild` | ParentContextService.php:131-148 | ok — session row belongs to the parent | ok | ok | ok | ok | ok — assertCanAccess 403 before the write | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php:163-171` (registerDeviceToken — this report owns the class) | `device_token_webpush_json` is NOT the real column (`device_token_webpush` per migration `2026_06_16_105227` line 18 and DDL) and `json_encode()` would double-encode into the `array` cast. **Already planned** as `PAC-04` (⚠ SHARED) in the ParentAccountController plan — do not duplicate; the fixer applies PAC-04, which owns that service line. | MDL-07 | `PAC-04` in ParentAccountController §1 |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` (owner: ParentComplaintController) | `authorize()` catches `\Exception` and returns false, so `resolveChild()`'s no-access redirect (an `HttpResponseException`) becomes a bare 403 and real service errors are masked. This is the reason `PCS-03`'s abort is effectively dead on FormRequest paths. | AUTH-02 / ERR-02 | ParentComplaintController |
| `Modules/ParentPortal/app/Models/ParentSession.php` (owner: ParentAccountController) | `device_type` not in `$fillable`; `device_type_option_id` NOT NULL — the model-side decision is `PAC-05` DECISION in the account report. My `PCS-02` fixes only the service call site; the model stays the account report's. | MDL-01 | `PAC-05` in ParentAccountController §9 |
| `Modules/StudentProfile/app/Models/Student.php` (owner: gaurav) | `currentAcademicSession` vs `currentSession` are two relations over the same row; the accessor forces `PDC-13`. Reading both is normal; the controller must eager-load whichever the views use. | QRY-12 | this report (PDC-12/PDC-13) |
| `Modules/StudentFee/.../FeeStudentAssignment` + `FeeInvoice` (owner: ParentFeeController) | `currentFeeAssignemnt` (typo "Assignemnt") is a hasOne over the current academic session; its invoices feed `PDC-10`. The typo is in gaurav's Student model — noted, not fixed here. | — | gaurav report (informational) |

## 8. Not covered, and why

- **Live row counts and a live browser check** — no reachable tenant DB in this session (the shared `prime_db` connection has no tenant tables); everything is proved statically or against DDL/migration files.
- **The mobile/API duplication** — `ParentDashboardApiController` (already AUDITED) is a separate controller; only the shared `ParentContextService` is audited here.
- **`registerDeviceToken`'s webpush line** — the column rename + double-encode is fully owned by `PAC-04` (ParentAccountController plan §1, ⚠ SHARED); this report audits the surrounding service logic but does not duplicate the fix.
- **Queue/job behaviour** — no jobs are dispatched by any in-scope path.
- **The `currentSession` vs `currentAcademicSession` duplication on `Student`** — owned by gaurav; only the eager-load fix (PDC-12/PDC-13) is in scope here.