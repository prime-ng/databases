# Fix Plan — ParentPortal / ParentDashboardController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Models/ParentSession.php` | owned by the ParentAccountController report; its `$fillable`/casts are PAC-04/PAC-05 there. `PCS-02` only changes the service call site. |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | owned by the ParentComplaintController report. |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by the ParentHealthController report. |
| `Modules/ParentPortal/routes/web.php` | no route change is needed. |
| `Modules/ParentPortal/app/Services/ParentContextService.php:163-171` (`registerDeviceToken` webpush line) | the `device_token_webpush_json` rename is PAC-04 (⚠ SHARED) in the ParentAccountController plan — that item owns the line. The `device_type` key in the same array is PAC-05's choice. |
| `database/migrations/**` | never edit an existing migration. |
| `Modules/StudentProfile/app/Models/Student.php`, `Modules/ParentPortal/resources/views/children/index.blade.php` | owned by other reports / views participate via eager-loading only; PDC-12/PDC-13 change the controller's load list, not the model or the blade. |

## 1. Blockers reachable today

- [x] **PDC-01** · B · ERR-01 (+ ERR-02, D1) · `ParentDashboardController.php:264-285` — rewrite `switchChild()` to the D1 shape: no try/catch, `DB::transaction` around the session write + activity log, response built after the transaction, `$validated['student_id']` used, injected `$request` in the audit context, and both stale docblocks removed.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:255-285`):
    ```php
    /**
     * AJAX POST — switch the active child for this guardian session.
     */
    /**
     * Switch which child the parent is acting as.
     *
     * Rule 3 is here. Rule 2 deliberately does not apply: this writes session state via
     * ParentContext, not a database row, so there is nothing to roll back.
     */
    public function switchChild(SwitchChildParentDashboardRequest $request): JsonResponse
    {
        $validated = $request->validated();

        try {
            $this->context->setActiveChild($request, (int) $request->input('student_id'));
            $child = $this->context->resolveChild($request);
            activityLog(auth()->user(), 'Switched', [
                'message' => 'Switched active child',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);

            return response()->json(['status' => true, 'message' => 'Child switched.']);
        } catch (\Throwable $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage()], 422);
        }
    }
    ```
  - **After:**
    ```php
    /**
     * AJAX POST — switch the active child for this guardian session.
     *
     * The session row (ppt_parent_sessions) and the audit row are one transaction.
     * A 403 from setActiveChild() and a 404 from findOrFail() propagate to the
     * central handler with their real status (D1, PDC-01/PDC-04 2026-10-13).
     */
    public function switchChild(SwitchChildParentDashboardRequest $request): JsonResponse
    {
        $validated = $request->validated();

        DB::transaction(function () use ($request, $validated): void {
            $this->context->setActiveChild($request, (int) $validated['student_id']);
            $child = $this->context->resolveChild($request);
            activityLog(auth()->user(), 'Switched', [
                'message' => 'Switched active child',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
            ]);
        });

        return response()->json(['status' => true, 'message' => 'Child switched.']);
    }
    ```
  - **Verify:** `grep -n "catch (\|getMessage\|request()->" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** no output (no catch, no `getMessage`, no `request()->` helper anywhere in the file after PDC-02 also runs).
  - **Effort:** S

- [x] **PCS-02** · B · MDL-01 / MDL-07 · `ParentContextService.php:214-221` — make the session-create pass a real fillable column so the NOT NULL `device_type_option_id` is set.
  - **Touches:** `Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Before** (`ParentContextService.php:214-221`):
    ```php
        return ParentSession::create([
            'guardian_id'       => $guardian->id,
            'active_student_id' => null,
            'device_type'       => 'Web',
            'is_active'         => true,
            'last_active_at'    => now(),
            'created_by'        => $request->user()->id,
        ]);
    ```
  - **After:**
    ```php
        return ParentSession::create([
            'guardian_id'            => $guardian->id,
            'active_student_id'      => null,
            'device_type_option_id'  => PptDropdownResolver::id('ppt_parent_sessions.device_type', 'Web')
                ?? PptDropdownResolver::id('ppt_parent_sessions.device_type', 'Unknown'),
            'is_active'              => true,
            'last_active_at'         => now(),
            'created_by'             => $request->user()->id,
        ]);
    ```
  - **Verify:** `grep -n "device_type_option_id\|PptDropdownResolver" Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Expect:** line 216-ish shows `'device_type_option_id'  => PptDropdownResolver::id('ppt_parent_sessions.device_type', 'Web')` and no `'device_type'       => 'Web',` in the create block. (`PptDropdownResolver` is in the same namespace — no new import needed.)
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

(none separate — PCS-02 above de-arms the new-parent crash; PCS-01 below is a DECISION because it changes the shared service's read-path behaviour.)

## 3. Errors & transactions (F1/F2)

- [x] **PDC-02** · M · ERR-07 / ERR-05 · `ParentDashboardController.php:81-93` and `:225-241` — remove the audit-log try/catch in both read methods (D1), keep `activityLog()` direct, use injected `$request`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:77-93`, `children()`):
    ```php
        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed children list',
                'context' => [
                    'student_id' => $childForLog?->id,
                    'student_name' => $childForLog?->user?->name ?? $childForLog?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'children', 'error' => $e->getMessage()]);
        }
    ```
  - **After:** (`children()`):
    ```php
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed children list',
            'context' => [
                'student_id' => $childForLog?->id,
                'student_name' => $childForLog?->user?->name ?? $childForLog?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ],
        ]);
    ```
  - **Before** (`ParentDashboardController.php:225-241`, `index()`):
    ```php
        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed dashboard',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
    ```
  - **After:** (`index()`):
    ```php
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed dashboard',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ],
        ]);
    ```
  - **Verify:** `grep -n "try {\|catch (\|Log::\|request()->" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** no output. (The unused `use Illuminate\Support\Facades\Log;` import is removed by Pint along the way.)
  - **Effort:** S

- [x] **PDC-03** · M · ERR-07 / ERR-06 · `ParentDashboardController.php:39-47` — remove the empty catch around `resolveChild()` in `children()`; the middleware already guarantees a child for this route.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:39-47`):
    ```php
        $activeChild = null;
        if ($children->isNotEmpty()) {
            try {
                $activeChild = $this->context->resolveChild($request);
                $activeId = $activeChild->id;
            } catch (\Throwable) {
                $activeId = $children->first()->id;
            }
        }
    ```
  - **After:**
    ```php
        $activeChild = null;
        if ($children->isNotEmpty()) {
            $activeChild = $this->context->resolveChild($request);
            $activeId = $activeChild->id;
        }
    ```
  - **Verify:** `grep -n "catch (\Throwable)\|catch (" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** no output after PDC-01 and PDC-02 also land.
  - **Effort:** S

- [x] **PCS-04** · M · CTL-10 / QRY-12 · `ParentContextService.php:193-196` — wire the declared-but-unused `guardianMemo` into `resolveGuardian()`.
  - **Touches:** `Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Before** (`ParentContextService.php:193-196`):
    ```php
    private function resolveGuardian(User $user): Guardian
    {
        return Guardian::where('user_id', $user->id)->firstOrFail();
    }
    ```
  - **After:**
    ```php
    private function resolveGuardian(User $user): Guardian
    {
        return $this->guardianMemo[$user->id] ??= Guardian::where('user_id', $user->id)->firstOrFail();
    }
    ```
  - **Verify:** `grep -n "guardianMemo" Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Expect:** hits on the declaration (line 44), the assignment in `resolveGuardian()` (line 195) and nothing else.
  - **Effort:** S

## 4. Authorization (F3)

(none — every routed method is behind `ParentPortalMiddleware` (route-level), `children()`/`index()` data is scoped via `getAccessibleChildren()`, and `switchChild()` adds FormRequest `authorize()` + `assertCanAccess()` (403). PDC-01 makes the 403/404 statuses real instead of a 422.)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PDC-10** · M · MDL-09 · `ParentDashboardController.php:206` — count pending invoices against the real statuses (drop the case-spelling aliases; exclude Draft/Cancelled).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:200-206`):
    ```php
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $invoices = $feeAssignment->invoices ?? collect();
            $feeTotal = (float) $invoices->sum('total_amount');
            $feePaid = (float) $invoices->sum('paid_amount');
            $feeDue = (float) $invoices->sum('balance_amount');
            $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
        }
    ```
  - **After:**
    ```php
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $invoices = $feeAssignment->invoices ?? collect();
            $feeTotal = (float) $invoices->sum('total_amount');
            $feePaid = (float) $invoices->sum('paid_amount');
            $feeDue = (float) $invoices->sum('balance_amount');
            $feePendingInvoices = $invoices->whereIn('status', [
                FeeInvoice::STATUS_PUBLISHED,
                FeeInvoice::STATUS_PARTIALLY_PAID,
                FeeInvoice::STATUS_OVERDUE,
            ])->count();
        }
    ```
  - **Verify:** `grep -n "FeeInvoice\|whereIn('status'" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** a `use Modules\StudentFee\Models\FeeInvoice;` import at the top and the `whereIn` line above. Add the import (`FeeInvoice` is the model that owns `status` — DDL row 322).
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **PDC-11** · H · QRY-05 · `ParentDashboardController.php:177-191` — push the `examPaper` null-check into SQL (`whereHas`), keep the future-date + sort in PHP (the date has two sources: `scheduled_date` or the exam start date).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:177-189`):
    ```php
            $allExamAllocations = ExamAllocation::where('is_active', true)
                ->where(fn ($q) => $q
                    ->where(fn ($q1) => $q1->where('allocation_type', 'CLASS')->where('class_id', $classId))
                    ->orWhere(fn ($q2) => $q2->where('allocation_type', 'SECTION')
                        ->where('class_id', $classId)->where('section_id', $sectionId))
                    ->orWhere(fn ($q3) => $q3->where('allocation_type', 'STUDENT')->where('student_id', $child->id))
                )
                ->with(['examPaper.exam', 'examPaper.subject'])
                ->get()
                ->filter(fn ($a) => $a->examPaper !== null)
                ->filter(fn ($a) => ($d = $a->scheduled_date ?? $a->examPaper?->exam?->start_date)
                    && Carbon::parse($d)->isFuture())
                ->sortBy(fn ($a) => $a->scheduled_date ?? $a->examPaper?->exam?->start_date);
    ```
  - **After:**
    ```php
            $allExamAllocations = ExamAllocation::where('is_active', true)
                ->where(fn ($q) => $q
                    ->where(fn ($q1) => $q1->where('allocation_type', 'CLASS')->where('class_id', $classId))
                    ->orWhere(fn ($q2) => $q2->where('allocation_type', 'SECTION')
                        ->where('class_id', $classId)->where('section_id', $sectionId))
                    ->orWhere(fn ($q3) => $q3->where('allocation_type', 'STUDENT')->where('student_id', $child->id))
                )
                ->whereHas('examPaper')
                ->with(['examPaper.exam', 'examPaper.subject'])
                ->get()
                ->filter(fn ($a) => ($d = $a->scheduled_date ?? $a->examPaper?->exam?->start_date)
                    && Carbon::parse($d)->isFuture())
                ->sortBy(fn ($a) => $a->scheduled_date ?? $a->examPaper?->exam?->start_date);
    ```
  - **Verify:** `grep -n "whereHas('examPaper')" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** one hit. The future-date and sort stay in PHP because an allocation's date falls back to the linked exam's start date (two tables), which SQL ordering cannot express simply.
  - **Effort:** M

- [x] **PDC-12** · M · QRY-12 (+ PDC-13 VIEW-02) · `ParentDashboardController.php:49-54` — load only the missing relations with `loadMissing`, and include `currentAcademicSession` (the relation behind `roll_number`).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:49-54`):
    ```php
        // Eager-load extra context for the cards
        $children->load([
            'currentSession.classSection.class',
            'currentSession.classSection.section',
            'currentSession.academicSession',
        ]);
    ```
  - **After:**
    ```php
        // Eager-load extra context for the cards. The service already loaded
        // currentSession.classSection.class/.section in getAccessibleChildren();
        // loadMissing() skips those and adds the two relations the cards read.
        $children->loadMissing([
            'currentSession.academicSession',
            'currentAcademicSession',
        ]);
    ```
  - **Verify:** `grep -n "loadMissing\|currentAcademicSession" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** the `loadMissing` call with both keys; no `$children->load(` left.
  - **Effort:** S

## 7. Views (F10)

(none — both blades compiled with `php -l` (rc=0), no `Model::`/`DB::`/`->where(`/`->get()` in Blade, no `{!! !!}`; the dashboard's `$cell->teachers` map runs over a relation eager-loaded by the controller's `with(['teachers.user', ...])`, so the scanner's VIEW-01 hit is a false positive; `children/index` uses `$ch->currentSession`, `$ch->currentSession`, `$ch->dob` — all loaded or model columns.)

## 8. Style (F12) — one item per file

- [x] **PDC-14** · L · STY-01 / STY-02 · `SwitchChildParentDashboardRequest.php` — add `declare(strict_types=1);` and let Pint fix the EOF newline.
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/SwitchChildParentDashboardRequest.php`
  - **Before** (`SwitchChildParentDashboardRequest.php:1-17`):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Requests;

    class SwitchChildParentDashboardRequest extends ParentPortalBaseRequest
    {
        public function authorize(): bool
        {
            return parent::authorize();
        }

        public function rules(): array
        {
            return [
                'student_id' => ['required', 'integer'],
            ];
        }
    }
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;

    class SwitchChildParentDashboardRequest extends ParentPortalBaseRequest
    {
        public function authorize(): bool
        {
            return parent::authorize();
        }

        public function rules(): array
        {
            return [
                'student_id' => ['required', 'integer'],
            ];
        }
    }
    ```
  - **Verify:** `grep -n "declare(strict_types" Modules/ParentPortal/app/Http/Requests/SwitchChildParentDashboardRequest.php`
  - **Expect:** line 3. Then run `vendor/bin/pint Modules/ParentPortal/app/Http/Requests/SwitchChildParentDashboardRequest.php --format agent`.
  - **Effort:** S

- [x] **PCS-05** · L · STY-04 · `ParentContextService.php` — strip the ⚠/⛔ emoji markers from the three comment sites.
  - **Touches:** `Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Before** (`ParentContextService.php:26,32,144` — the three emoji lines and their neighbours):
    ```php
     * ⚠ WHY: resolveChild() costs 7 queries (guardian → jnt → students →
    ```
    ```php
     * ⛔ EVERY memo is KEYED BY PARENT ID, deliberately. This service decides which
    ```
    ```php
        // ⛔ Invalidate. Without this, a switchChild() followed by any resolveChild()
    ```
  - **After:**
    ```php
     * Note: resolveChild() costs 7 queries (guardian → jnt → students →
    ```
    ```php
     * Important: every memo is keyed by parent id. This service decides which
    ```
    ```php
        // Invalidate. Without this, a switchChild() followed by any resolveChild()
    ```
  - **Verify:** `grep -nP "[\x{26A0}\x{26D4}]" Modules/ParentPortal/app/Services/ParentContextService.php`
  - **Expect:** no output.
  - **Effort:** S

- [x] **PDC-08** · M · CTL-07 · `ParentDashboardController.php:243-252` — replace the 17-variable `compact()` with an explicit array (one coherent change; keep the same view variables).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Before** (`ParentDashboardController.php:243-252`):
    ```php
        return view('parentportal::dashboard.index', compact(
            'child', 'session',
            'attendancePct', 'attendancePresent', 'attendanceTotal',
            'todayCells',
            'pendingHomework', 'pendingHomeworkCount',
            'upcomingExams', 'upcomingExamCount',
            'feeTotal', 'feePaid', 'feeDue', 'feePendingInvoices',
            'leaveCount', 'leavePendingCount',
            'notifications',
        ));
    ```
  - **After:**
    ```php
        return view('parentportal::dashboard.index', [
            'child' => $child,
            'session' => $session,
            'attendancePct' => $attendancePct,
            'attendancePresent' => $attendancePresent,
            'attendanceTotal' => $attendanceTotal,
            'todayCells' => $todayCells,
            'pendingHomework' => $pendingHomework,
            'pendingHomeworkCount' => $pendingHomeworkCount,
            'upcomingExams' => $upcomingExams,
            'upcomingExamCount' => $upcomingExamCount,
            'feeTotal' => $feeTotal,
            'feePaid' => $feePaid,
            'feeDue' => $feeDue,
            'feePendingInvoices' => $feePendingInvoices,
            'leaveCount' => $leaveCount,
            'leavePendingCount' => $leavePendingCount,
            'notifications' => $notifications,
        ]);
    ```
  - **Verify:** `grep -n "compact(" Modules/ParentPortal/app/Http/Controllers/ParentDashboardController.php`
  - **Expect:** only the `children()` compact at line 95 remains.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PDC-07** · H · DECISION · CTL-02 — extract `index()`'s seven read blocks into private methods, or defer?
  - **Why it is a decision:** `index()` is 156 lines (over 150 = H per rulebook). Extraction is fix-in-place, but a 150-line method rewrite is a larger diff for the small fixer model, and the screen works.
  - (a) ⭐ Defer the extraction to the split pass (D3); record CTL-02 as accepted for launch. The H is maintainability, not a wrong result.
  - (b) Extract now: pull each card block (attendance, timetable, homework, exams, fee, leave, notifications) into private methods returning the current variables.
  - ➜ Choice: (a) — defer extraction 2026-10-22

- [x] **PDC-09** · H · DECISION · MDL-09 — how should `Half Day` and `Short Leave` count in the dashboard attendance percentage?
  - **Why it is a decision:** it changes a number parents see on a real screen and must agree with the student-facing pages; the sibling attendance report (`PAT-05`) already asks the same question.
  - (a) ⭐ Mirror the PAT-05 choice — if the attendance report chooses "match the student portal" (Present, Late, Half Day, Short Leave count as present), apply the same rule here and drop the non-existent aliases (`P`, `present`).
  - (b) Count `Half Day`/`Short Leave` in their own buckets, out of the percentage (also mirrors a PAT-05 option).
  - (c) Leave as-is; record as accepted.
  - ➜ Choice: (a) — Present/Late/Half Day/Short Leave count as present 2026-10-22

- [x] **PCS-01** · H · DECISION · SVC-03 — should `resolveChild()` stop writing the parent session on GET pages?
  - **Why it is a decision:** `resolveChild()` is shared by ~26 controllers; making it read-only changes the last_active_at behaviour on every page they render, and the create path is where PCS-02's crash lives.
  - (a) ⭐ Make `resolveChild()` read-only: remove the `getOrCreateSession()` call and the correction `update()` from the multi-child branch; the session row is then created/updated only on the explicit write endpoints (`setActiveChild`, `registerDeviceToken`). Touches `ParentContextService.php` only; every caller keeps its return type.
  - (b) Keep the reads, but wrap the two writes (`getOrCreateSession()` + the `active_student_id` correction) in one `DB::transaction` — fixes TXN-01 inside the service, leaves the write-on-read (SVC-03).
  - (c) Leave as-is; record as accepted (the touch is small).
  - ➜ Choice: (a) — resolveChild is read-only on the multi-child branch 2026-10-22

- [x] **PCS-03** · M · DECISION · SVC-01 — move the no-children redirect out of the service?
  - **Why it is a decision:** `resolveChild()` aborts with a redirect when a parent has no children. Changing the contract (return nullable + controller redirect) touches ~26 callers; the guarded web routes already redirect childless parents at the middleware, so the abort is unreachable from this controller today.
  - (a) Keep the abort (`abort(redirect(...))`) and let the base-request owner (ParentComplaintController) fix its `authorize()` catch that turns the redirect into a bare 403. Record SVC-01 as accepted for this controller.
  - (b) ⭐ Change `resolveChild()` to return `?Student` and let each controller abort/redirect — bigger blast radius, coordinated, out of this pass.
  - (c) Leave as-is; record as accepted.
  - ➜ Choice: (a) — keep the abort; SVC-01 accepted 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PDC-04 | Implemented by PDC-01 — the `switchChild()` rewrite wraps the session write + audit log in one `DB::transaction` and deletes the false "not a database row" comment. |
| PDC-05 | Implemented by PDC-01 — the rewrite uses `$validated['student_id']`, making the previously dead variable live. |
| PDC-06 | Implemented by PDC-01 + PDC-02 — every `request()->route()` hit sits in an audit block that both items rewrite with the injected `$request`. |
| PDC-13 | Implemented by PDC-12 — the `loadMissing(['currentSession.academicSession', 'currentAcademicSession'])` loads the relation behind `roll_number`, removing the per-child lazy load. |