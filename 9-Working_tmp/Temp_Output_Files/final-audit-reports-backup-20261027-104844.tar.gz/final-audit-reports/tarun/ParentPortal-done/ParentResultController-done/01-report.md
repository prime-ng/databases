# Final Audit — ParentPortal / ParentResultController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php` (257 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/results` (list, 4 client-side tabs: Exams / Quizzes / Quests / Homework) · `http://test.localhost:8000/parent-portal/results/{exam}` (exam detail page) · `http://test.localhost:8000/parent-portal/results/report-card/pdf` (report-card PDF download) |
| Menu path | Parent Portal → sidebar → Results (active-link group at `Modules/ParentPortal/resources/views/layouts/_sidebar.blade.php:112-113`) |
| Who uses it | Authenticated `user_type = PARENT` accounts that have a `std_guardians` row and at least one child link with `can_access_parent_portal = 1`. The portal has NO permission keys — access is the role gate in `ParentPortalMiddleware` (`Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php`, owned by the ParentHealthController report). |
| What a user does here | Opens the active child's Results page and reads the 4 tabs: per-paper exam results (marks, %, grade, division, rank, teacher remarks), quiz results, quest results, and graded homework. Opens one exam to see its subject-wise breakdown, aggregate score and teacher remarks. Downloads the school's published report card as a PDF. No business writes: the only write is one `activityLog` audit row per page view. |
| Tables written | `sys_activity_logs` (one audit row via the `activityLog()` helper, per page view) |
| Tables read | `std_guardians`, `std_student_guardian_jnt`, `std_students` (via `ParentContextService`), `lms_exam_results`, `lms_exam_papers`, `lms_exams`, `lms_quiz_quest_results`, `lms_quizzes`, `lms_quests`, `sch_subjects`, `lms_homework_assignment`, `lms_homework`, `lms_homework_submissions` (eager loads), `hpc_reports` (report-card existence), plus the HPC module's own reads inside the delegated `generateSingleStudentPdf` (templates, report items/tables, attendance) |
| Live data | ⚠ UNVERIFIED — no tenant database is reachable from this host (the default `prime_db` connection has 0 tenant tables: `select count(*) from lms_exam_results` threw `Table 'prime_db.lms_exam_results' doesn't exist`), so live row counts were not measured. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. No pre-applied files: `final-audit-reports/tarun/ParentPortal/` has no `PRE-APPLIED-*.md`, and none of the in-scope files appear in `final-audit-reports/tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`.

## 1. Verdict

The controller is **not production-ready**: the report-card "Download" button can serve an **unpublished** report card (PRC-12, H), and the model that backs the whole screen writes its Spatie media rows to the **central** database instead of the tenant's (PRC-06, B). The single worst finding is **PRC-12**: the parent is only told *some* Published HPC report exists, but the delegated PDF generator then loads the **latest** report regardless of status — so a newer Draft/Final that the school never released is what the parent actually downloads. Effort to apply the whole plan: **M** — two decisions (the audit-write catch shape, the HPC delegate filter), one dead-branch removal, one media-model method, one index() de-duplication; the rest are small model/style items. No migrations, no route changes, no new permission keys needed for the recommended options.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 4 | 8 | 3 | 14 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PRC-01 | F8 Services/Jobs | clean — linked |
| F2 Transactions/Audit | clean | F9 Queries/Perf | PRC-13 |
| F3 Authorization | clean (dead guard = PRC-05) | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | PRC-12 |
| F5 Routes | clean | F12 Style | PRC-09, PRC-10, PRC-11, PRC-14 |
| F6 Controller shape | PRC-02, PRC-03, PRC-04, PRC-05 | F13 Deep read | PRC-05, PRC-12 |
| F7 Models | PRC-06, PRC-07, PRC-08 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php` | controller | 257 | this report | ✅ |
| 2 | `Modules/ParentPortal/resources/views/results/index.blade.php` | view | 367 | this report | ✅ |
| 3 | `Modules/ParentPortal/resources/views/results/show.blade.php` | view | 241 | this report | ✅ |
| 4 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (pre-assigned by main session 2026-10-13; owner report still CLAIMED) |
| 5 | `Modules/LmsExam/app/Models/Exam.php` | model | 462 | this report (pre-assigned 00-CLASS-OWNERS:331) | ✅ |
| 6 | `Modules/StudentPortal/app/Models/ExamResult.php` | model | 137 | this report (pre-assigned 00-CLASS-OWNERS:332) | ✅ |
| 7 | `Modules/Hpc/app/Models/HpcReport.php` | model | 174 | this report (pre-assigned 00-CLASS-OWNERS:327) | ✅ |
| 8 | `Modules/LmsHomework/app/Models/HomeworkAssignment.php` | model | 170 | ↗ [tarun/ParentPortal-done/ParentHomeworkController](../ParentHomeworkController-done/01-report.md) | ↗ linked (pre-assigned 00-CLASS-OWNERS:330); usage-only checked here |
| 9 | `Modules/Hpc/app/Http/Controllers/HpcController.php` | controller (delegate) | 2792 | Hpc module audit — ⚠ not yet claimed; this report checks the ONE delegated method's usage only | ⚠ usage-only (PRC-12) |
| 10 | `Modules/ParentPortal/routes/web.php` | routes (module, shared) | 199 | this report — evidence for the three results rows only | ✅ (rows 75-80) |
| 11 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 62 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked (claimed by opencode 2026-10-13) |

No pre-applied files.

**Common classes referenced, never audited here** (§4.2): `App\Http\Controllers\Controller`, `App\Models\BaseModel`, `app/Helpers/activityLog.php`, `Modules/ParentPortal/resources/views/layouts/**` (app, _header, _sidebar), the `DB`/`Log`/`Gate` facades, and the other-module models reached through relations/joins — `Subject`, `SchoolClass`, `Section`, `Student`, `ExamPaper`, `ExamAttempt`, `ExamType`, `OrganizationAcademicSession`, `Guardian`, `StudentGuardianJnt` — which belong to their own modules' audits. Only their use by THIS controller was checked.

## 4. Routes

Uncached `route:list` (export of 2026-10-13 10:27):

```
GET|HEAD parent-portal/results                                   parent-portal.results.index                        Modules\ParentPortal\Http\Controllers\ParentResultController@index
GET|HEAD parent-portal/results/report-card/pdf                   parent-portal.results.report-card.pdf              Modules\ParentPortal\Http\Controllers\ParentResultController@reportCardPdf
GET|HEAD parent-portal/results/{exam}                            parent-portal.results.show                         Modules\ParentPortal\Http\Controllers\ParentResultController@show
```

Declared in `Modules/ParentPortal/routes/web.php:76-80` inside the group that applies:
`web → InitializeTenancyByDomain → PreventAccessFromCentralDomains → EnsureTenantIsActive → EnsureTenantHasModule:ParentPortal → auth → ParentPortalMiddleware`, prefix `/parent-portal`, name prefix `parent-portal.` (`Modules/ParentPortal/app/Providers/RouteServiceProvider.php:65-81`).

Unrouted public methods: none — `index`, `reportCardPdf` and `show` are the only public methods (besides `__construct`) and all three are routed.

⚠ The `report-card/pdf` route has NO `{studentId}` parameter, so the `$studentId` argument of `reportCardPdf()` is always `null` on the web path — this makes the method's override branch dead code (PRC-05).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 29 | GET /parent-portal/results (`parent-portal.results.index`) | none in the controller — role gate `ParentPortalMiddleware` (user_type=PARENT + guardian + child), no permission key | none — single-row audit write, no business write | `'Viewed'` at line 132, inside try/catch | sys_activity_logs | PRC-01, PRC-02, PRC-03, PRC-13 |
| `reportCardPdf` | 156 | GET /parent-portal/results/report-card/pdf (`parent-portal.results.report-card.pdf`) | none in the controller — role gate + child-scoping; HPC admin gate `tenant.hpc.progress-card.view` deliberately bypassed via `$bypassGate = true` (parent authorized first) | none — single-row audit write + read-only PDF generation | `'Downloaded'` at line 187, inside try/catch | sys_activity_logs | PRC-01, PRC-04, PRC-05, PRC-12 |
| `show` | 207 | GET /parent-portal/results/{exam} (`parent-portal.results.show`) | none in the controller — role gate + `abort_if` 403 when the child has no published result for this exam | none — single-row audit write, no business write | `'Viewed'` at line 238, inside try/catch | sys_activity_logs | PRC-01 |

## 6. Findings

### F1 — Errors

#### PRC-01 · M · ERR-07 / ERR-00 / ERR-05 — three read methods wrap the audit write in a controller try/catch that is not a D2 shape, and log `getMessage()` without a trace

| Field | Value |
|---|---|
| **Rule** | ERR-07 (M) — *read-only methods need no try/catch under either variant*; ERR-00 / protocol D1 — *no try/catch in controllers except the D2 shapes (`\DomainException`, truncate-then-rebuild fixed message, `SnapshotProtectionException`, service `report($e)`)*; ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`*. The same pattern is repeated in all three methods. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:131-143` (`index`), `:186-199` (`reportCardPdf`), `:237-250` (`show`) |
| **Root cause** | Each method isolates the audit write so a log failure cannot take the page down (comments at 127-130 / 182-185 / 233-236 cite the old house-rule A1, which D1 supersedes for modules under final audit). The `try { activityLog(...) } catch (\Throwable $e) { Log::error('view log failed', ['method' => …, 'error' => $e->getMessage()]); }` shape is neither the D1 Laravel idiom nor one of the D2-permitted catches, and the catch logs only the message so the trace is lost. |
| **Consequence** | When the audit write fails, the failure is swallowed and the page renders as if nothing happened — no audit trail for that view, and when the message is logged there is no stack trace to investigate. |
| **Reproduce** | Not browser-reproducible without inducing a write failure; static only — the three identical catch blocks are at lines 141-143, 197-199 and 248-250. |
| **Fix approach** | DECISION (plan §9): either keep ONE isolated catch that preserves the page **and** the trace into the audit system (recommended), or delete the try/catch for strict D1 and let the central handler render (a failed audit row would then 500 the page). Either way replace `request()` with the injected `$request` (CTL-08, lines 138 / 193 / 244) and log the exception, not the message. |
| **Plan item** | PRC-01 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentResultController.php:131-143 — CURRENT (index; reportCardPdf 186-199 and show 237-250 are identical in shape)
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed results',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -n "try {\|catch (\\\\Throwable\|getMessage" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php
131:        try {
141:        } catch (\Throwable $e) {
142:            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
186:        try {
197:        } catch (\Throwable $e) {
198:            Log::error('view log failed', ['method' => 'reportCardPdf', 'error' => $e->getMessage()]);
237:        try {
248:        } catch (\Throwable $e) {
249:            Log::error('view log failed', ['method' => 'show', 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

clean — the controller makes no business write at all; every page writes exactly one `sys_activity_logs` row via the `activityLog()` helper, which is a single-row write and needs no `DB::transaction` (house-rule A2 does not apply: "one row, one table"). `reportCardPdf`'s delegated PDF generation is read-only (HpcReport/templates/items read + a PDF render). Proved by `grep -n "DB::transaction\|beginTransaction\|commit()\|rollBack" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php` → no output.

### F3 — Authorization

clean — all three routes sit behind `auth` + `ParentPortalMiddleware` (role gate: `user_type = PARENT`, guardian exists, ≥1 child with `can_access_parent_portal = 1`), and all three methods follow AUTH-03 (record-level): every query is scoped by `student_id = $child->id` where `$child` comes from `ParentContextService::resolveChild()` (which only returns children the parent may see, else aborts to the no-access page); `show()` additionally demands a published result for that exam before rendering (`abort_if($results->isEmpty(), 403)` at line 219); `reportCardPdf()` requires an existing `Published` HpcReport for the child before delegating. Proved by `grep -n "Gate::\|authorize\|permission" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php` → only the unused `use Illuminate\Support\Facades\Gate;` import at line 10. Cross-cutting note: the parent portal has no permission keys at all — module-wide, not this controller's defect (§7). ⚠ The `$studentId` override guard in `reportCardPdf` (lines 160-168) is dead code (PRC-05) — the route provides no `{studentId}`, so the guard never runs; the active-child-only path that actually runs is still authorized.

### F4 — Validation and input

clean — the controller reads no user input into any model: `index()` and `show()` take only the typed route-bound `Exam $exam`, `reportCardPdf()` takes an optional `?int $studentId = null` that the route never fills (see PRC-05). All routes are GET reads, so no FormRequest is required. Proved by `grep -n "validate\|validated\|->all()\|except(" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php` → no output.

### F5 — Routes

clean — RTE-01: the only verbs are GET and nothing mutates besides the one audit row (module-wide accepted shape); RTE-02: all three `@index`/`@reportCardPdf`/`@show` exist (`php -l` passes and all three resolve in `route:list`); RTE-03: every public method is routed; RTE-05: tenant + auth + role middleware present (see §4). The `{exam}` route parameter matches the `Exam $exam` argument exactly, so route model binding works and there is no unbound-route-model trap; `/report-card/pdf` is declared before `/{exam}` (web.php:78 before :79), so the literal path is never captured by the wildcard. Proved by the §4 route output. ⚠ One dead area: `reportCardPdf()` declares `?int $studentId` that no route parameter feeds (PRC-05).

### F6 — Controller shape

#### PRC-02 · M · CTL-02 — `index()` is 120 lines (rule: extract methods over 80 lines)

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method over 80 lines → extract; over 150 is H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:29-148`, method `index()` |
| **Root cause** | The method builds four result lists (exam / quiz / quest / homework) inline, then the audit write and the view — 120 lines of orchestration that could be four small private query builders. This is what breeds the PRC-03 duplication. |
| **Consequence** | Hard to read and easy to let the four blocks drift apart (two already have: quiz vs quest differ only in two strings — see PRC-03). |
| **Reproduce** | Static only — method spans lines 29-148. |
| **Fix approach** | Extract the four list builders into private methods (or one parameterized assessment-query helper for quiz/quest) and keep `index()` as child resolution + four calls + audit + view. |
| **Plan item** | PRC-02 in `02-fix-plan.md` §5 |

```php
// ParentResultController.php:145-148 — CURRENT (closing lines of the 120-line index() method)
        return view('parentportal::results.index', compact(
            'child', 'session', 'examResults', 'quizResults', 'questResults', 'homeworkResults'
        ));
    }
```

**Evidence**
```
$ sed -n '29,148p' Modules/ParentPortal/app/Http/Controllers/ParentResultController.php | wc -l
120
```

#### PRC-03 · M · CTL-05 — quiz and quest query builders are near-duplicate copy-paste, and the same 4-key context array repeats three times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same 30-line payload in `store` and `update`, repeated blocks* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:68-89` (quiz) vs `:92-112` (quest); the 4-key activityLog context array at `:134-139`, `:189-194`, `:240-245` |
| **Root cause** | The quiz block and the quest block are the same 21-line query builder against the same `lms_quiz_quest_results` table; only the join target (`lms_quizzes` vs `lms_quests`), the `assessment_type` literal and two aliases change. The activityLog payload is copied verbatim into all three methods. |
| **Consequence** | A fix made to the quiz query is easy to miss for quest (drift), and the three audit payloads are a chore to keep consistent. |
| **Reproduce** | Static only — `diff <(sed -n '68,89p' file) <(sed -n '92,112p' file)` shows only the 3 differing lines. |
| **Fix approach** | Folded into PRC-02's extraction: one `assessmentResultsQuery(string $type, ?int $classId, int $studentId)` for quiz+quest, and one private audit-context helper so the three callsites share a single payload. |
| **Plan item** | PRC-02 in `02-fix-plan.md` §5 (PRC-03 is fixed by the same rewrite — see plan §10) |

```php
// ParentResultController.php:68-89 — CURRENT quiz block (quest block 92-112 is identical except lms_quests/QUEST/quest_title/quest_id)
        $quizResults = DB::table('lms_quiz_quest_results as rr')
            ->join('lms_quizzes as q', 'q.id', '=', 'rr.assessment_id')
            ->when($classId, fn ($q) => $q->where('q.class_id', $classId))
            ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'q.subject_id')
            ->where('rr.student_id', $studentId)
            ->where('rr.assessment_type', 'QUIZ')
            ->where('rr.is_published', true)
            ->whereNull('rr.deleted_at')
            ->orderByDesc('rr.created_at')
            ->get([
                'rr.id',
                'q.title as quiz_title',
                'sub.name as subject_name',
                'rr.total_marks_obtained',
                'rr.max_marks',
                'rr.percentage',
                'rr.grade_obtained',
                'rr.is_passed',
                'rr.assessment_id as quiz_id',
                'rr.created_at',
            ]);
```

**Evidence**
```
$ diff <(sed -n '68,89p' Modules/ParentPortal/app/Http/Controllers/ParentResultController.php) <(sed -n '92,112p' Modules/ParentPortal/app/Http/Controllers/ParentResultController.php)
2c2
<             ->join('lms_quizzes as q', 'q.id', '=', 'rr.assessment_id')
---
>             ->join('lms_quests as q', 'q.id', '=', 'rr.assessment_id')
6c6
<             ->where('rr.assessment_type', 'QUIZ')
---
>             ->where('rr.assessment_type', 'QUEST')
13c13
<                 'q.title as quiz_title',
---
>                 'q.title as quest_title',
18c18
<                 'rr.assessment_id as quiz_id',
---
>                 'rr.assessment_id as quest_id',
```

#### PRC-04 · L · CTL-04 — `reportCardPdf()` has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:156`, method `reportCardPdf()` |
| **Root cause** | The method returns a `RedirectResponse` (warning redirect or the delegate's error redirect) or a PDF download response, but declares none: `public function reportCardPdf(Request $request, ?int $studentId = null)` |
| **Consequence** | No static signal of what the method can return; IDE and callers cannot see the contract. |
| **Reproduce** | Static only — line 156. |
| **Fix approach** | Declare `: RedirectResponse|BinaryFileResponse|StreamedResponse` (or the concrete PDF response class returned by the delegate) with the needed imports. |
| **Plan item** | PRC-04 in `02-fix-plan.md` §5 |

```php
// ParentResultController.php:156 — CURRENT
    public function reportCardPdf(Request $request, ?int $studentId = null)
```

**Evidence**
```
$ grep -n "public function reportCardPdf" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php
156:    public function reportCardPdf(Request $request, ?int $studentId = null)
```

#### PRC-05 · M · CTL-10 — the `$studentId` override in `reportCardPdf()` is dead code: the route never provides a `{studentId}`, so the intended multi-child download feature is unreachable

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused branches, unused properties* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:160-168`, method `reportCardPdf()`; route `parent-portal.results.report-card.pdf` at `web.php:78` |
| **Root cause** | The route `GET /parent-portal/results/report-card/pdf` registers NO `{studentId}` parameter, and the two blades that link the PDF (`results/index.blade.php:24`, `health/index.blade.php:143`, `documents/index.blade.php:125`) pass no argument. So `$studentId` is always `null` on the web path, the `if ($studentId !== null && $studentId !== $child->id)` guard never runs, and `$studentId = $child->id` is always what reaches the HPC delegate. |
| **Consequence** | A parent linked to several children can only ever download the ACTIVE child's report card — the "override" feature advertised by the branch and by `getAccessibleChildren($request->user())` can never trigger; the 403 IDOR guard that lives in the dead branch is also dead. |
| **Reproduce** | Visit `http://test.localhost:8000/parent-portal/results/report-card/pdf?studentId=2` — the query string is ignored; the controller never reads it and the route never binds it; the active child is always used. |
| **Fix approach** | DECISION (plan §9): (a) ⭐ remove the dead override branch and the unreachable `getAccessibleChildren` call, leaving active-child-only behaviour (matches the doc-block "for the active child"); (b) make the feature real by adding an optional `{studentId?}` route parameter with `->whereNumber('studentId')` — a route-file change; (c) leave and document. |
| **Plan item** | PRC-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentResultController.php:158-168 — CURRENT
        $child = $this->context->resolveChild($request);

        // Allow override only if the override belongs to one of the parent's own children.
        if ($studentId !== null && $studentId !== $child->id) {
            $accessible = $this->context->getAccessibleChildren($request->user())
                ->pluck('id')
                ->toArray();
            abort_unless(in_array($studentId, $accessible, true), 403);
        } else {
            $studentId = $child->id;
        }
```

**Evidence**
```
$ grep -n "studentId" Modules/ParentPortal/routes/web.php
78:    Route::get('/report-card/pdf', [ParentResultController::class, 'reportCardPdf'])->name('report-card.pdf');
$ grep -rn "report-card.pdf" Modules/ParentPortal/resources/views/ results/ 2>/dev/null | head -5
Modules/ParentPortal/resources/views/results/index.blade.php:24:    <a href="{{ route('parent-portal.results.report-card.pdf') }}" target="_blank"
Modules/ParentPortal/resources/views/health/index.blade.php:143:    <a href="{{ route('parent-portal.results.report-card.pdf') }}" target="_blank"
Modules/ParentPortal/resources/views/documents/index.blade.php:125:    <a href="{{ route('parent-portal.results.report-card.pdf') }}" target="_blank"
```

### F7 — Models

#### PRC-06 · B · MDL-05 / TEN-01 — `HpcReport` uses Spatie `InteractsWithMedia` without overriding `getMediaModel()`, so HPC report files land in the CENTRAL database

| Field | Value |
|---|---|
| **Rule** | MDL-05 / TEN-01 (B) — *every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the central DB (cross-tenant leak)* |
| **Where** | `Modules/Hpc/app/Models/HpcReport.php:13-19` (class declaration, `use InteractsWithMedia`) and `:151-155` (`registerMediaCollections`) |
| **Root cause** | `config('media-library.media_model')` is `Modules\Prime\Models\Media` (config/media-library.php:73), which pins `protected $connection = 'mysql'` — the CENTRAL database (`Modules/Prime/app/Models/Media.php:9`). `HpcReport` `use InteractsWithMedia` without defining `getMediaModel()`, so Spatie falls back to the central model for both read and write paths. Every tenant model that stores uploads is expected to override it (`App/Models/TenantMedia.php` docstring; `Modules/SchoolSetup/app/Models/User.php:214`, `Organization`, `Employee` all do). |
| **Consequence** | Report-card files uploaded against `hpc_report_files` are recorded in `prime_db.sys_media` (shared by ALL tenants) instead of the tenant's `sys_media`; two tenants with id `1` can point at each other's rows — a cross-tenant data leak and a fixture for wrong-file downloads. |
| **Reproduce** | Static only — `grep -rn "function getMediaModel" Modules/Hpc/app/Models/` returns nothing, while `config('media-library.media_model')` is the central `Modules\Prime\Models\Media` (pinned to `mysql`). |
| **Fix approach** | Add `public function getMediaModel(): string { return \App\Models\TenantMedia::class; }` to `HpcReport` (same pattern as `Modules/SchoolSetup/app/Models/User.php:214-218`). |
| **Plan item** | PRC-06 in `02-fix-plan.md` §1 |

```php
// HpcReport.php:17-19 — CURRENT
class HpcReport extends Model implements HasMedia
{
    use SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ grep -rn "function getMediaModel" Modules/Hpc/app/Models/
(no output)
$ grep -n "media_model" config/media-library.php
73:    'media_model' => Media::class,
$ grep -n "connection" Modules/Prime/app/Models/Media.php
9:    protected $connection = 'mysql';
```

#### PRC-07 · L · MDL-04 — `HpcReport` has 9 relationship methods without return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/Hpc/app/Models/HpcReport.php:79` (`student`), `:87` (`template`), `:95` (`academicSession`), `:103` (`term`), `:111` (`class`), `:119` (`section`), `:127` (`preparedBy`), `:135` (`reportItems`), `:143` (`reportTables`) |
| **Root cause** | The model predates the project's return-type convention; all 9 relations omit `: BelongsTo` / `: HasMany`, so static analysis and IDE autocomplete cannot see the relation shapes. |
| **Consequence** | Maintainability only — no runtime effect on these pages, but hidden relation types defeat tooling and the next developer. |
| **Reproduce** | Static only — see evidence. |
| **Fix approach** | Add `: BelongsTo` / `: HasMany` return types and the `Illuminate\Database\Eloquent\Relations\*` imports (`BelongsTo`, `HasMany`). |
| **Plan item** | PRC-07 in `02-fix-plan.md` §5 |

```php
// HpcReport.php:79-82 — CURRENT (representative; same shape at 87, 95, 103, 111, 119, 127, 135, 143)
    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }
```

**Evidence**
```
$ grep -n "public function " Modules/Hpc/app/Models/HpcReport.php
79:    public function student()
87:    public function template()
95:    public function academicSession()
103:    public function term()
111:    public function class()
119:    public function section()
127:    public function preparedBy()
135:    public function reportItems()
143:    public function reportTables()
```

#### PRC-08 · L · MDL-04 — `Exam::examStudentGroups()` is a relationship-shaped method without a return type

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed* |
| **Where** | `Modules/LmsExam/app/Models/Exam.php:202-207`, method `examStudentGroups()` |
| **Root cause** | Unlike the other 12 relations of `Exam` (all `: HasMany` / `: HasManyThrough` / `: BelongsTo` typed), `examStudentGroups()` returns a query-builder chain with no return type and no relation class, so tooling cannot see it as a relation. |
| **Consequence** | Maintainability only — this controller never calls it (it loads only `examType` and `academicSession`), but it is part of the pre-assigned `Exam` model audit. |
| **Reproduce** | Static only — line 202. |
| **Fix approach** | Declare a return type (`: Builder` or a proper relation) and align with the other relations. |
| **Plan item** | PRC-08 in `02-fix-plan.md` §5 |

```php
// Exam.php:200-207 — CURRENT
     * Get the student groups participating in this exam.
     */
    public function examStudentGroups()
    {
        return ExamStudentGroup::whereHas('allocations.examPaper', function($q) {
            $q->where('exam_id', $this->id);
        });
    }
```

**Evidence**
```
$ sed -n '202p' Modules/LmsExam/app/Models/Exam.php
    public function examStudentGroups()
```

### F8 — Services and jobs

clean — the only service is `ParentContextService`, which is owned by the `ParentDashboardController` report (claim at 00-CLASS-OWNERS.md:309, report still CLAIMED) and is ↗ linked here; its usage from this controller is correct (`resolveChild($request)`, `getAccessibleChildren($request->user())` — the latter only inside the dead PRC-05 branch). The `HpcController::generateSingleStudentPdf` delegate is read-only for the PDF path (no DB writes) and is usage-checked for PRC-12; the class itself belongs to the Hpc module audit. No jobs, events, mails or notifications are used.

### F9 — Queries and performance

#### PRC-13 · L · QRY-05 — homework results are loaded with `->get()->filter()` instead of filtering in SQL

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M, lowered to L) — *aggregate in SQL: `exists()` / `count()` / `whereHas`, not `->get()->filter()`*. Lowered because the set is bounded by ONE child's assignments (single digits to a few dozen rows). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:115-125`, method `index()` |
| **Root cause** | `HomeworkAssignment::…->with([...])->orderByDesc('due_date')->get()->filter(fn ($a) => $a->homework !== null)` loads every active assignment that has a submission, then filters out rows whose homework relation is missing (soft-deleted or unlinked) in PHP. The same result is expressible as `->whereHas('homework')` on the query. |
| **Consequence** | A few extra rows move through memory per child — negligible today, a slow page only if one child accumulated hundreds of assignments. |
| **Reproduce** | Static only — line 125 is `->filter(...)` after `->get()`. |
| **Fix approach** | Accepted (see plan §10): add `->whereHas('homework')` to the query and drop the PHP filter when the lists are next touched (already inside PRC-02's extraction). |
| **Plan item** | none — see plan §10 (folded into PRC-02) |

```php
// ParentResultController.php:115-125 — CURRENT
        $homeworkResults = HomeworkAssignment::where('student_id', $studentId)
            ->when($classId, fn ($q) => $q->whereHas('homework', fn ($h) => $h->where('class_id', $classId)))
            ->where('is_active', true)
            ->whereHas('submission')
            ->with([
                'homework' => fn ($q) => $q->with('subject'),
                'submission',
            ])
            ->orderByDesc('due_date')
            ->get()
            ->filter(fn ($a) => $a->homework !== null);
```

**Evidence**
```
$ sed -n '124,125p' Modules/ParentPortal/app/Http/Controllers/ParentResultController.php
            ->get()
            ->filter(fn ($a) => $a->homework !== null);
```

Rest of F9 clean: no query inside a loop; `show()` eager-loads `examPaper.subject` and `attempt` in ONE `with([...])`; `index()` eager-loads `homework.subject` and `submission`; the four query builders each hit the `lms_*` tables with join-filtered column lists (no `->get()->pluck` etc.); the `lms_exam_results` read joins `lms_exam_papers`/`lms_exams`/`sch_subjects` and selects only the columns the blades use; `when($classId, …)` class-scoping is applied to all four lists. All four lists are `->get()` (not paginated) but each is bounded by one child's records — consistent with the module's accepted per-child list pattern (ParentHomeworkController PHW-06).

### F10 — Views

clean — no queries in Blade (only `->count()`/`->filter()`/`->contains()` on collections the controller already loaded); every relation used inside `@foreach` is eager-loaded by the controller (`$result->examPaper?->subject?->name` in show.blade ← `with(['examPaper.subject','attempt'])`; `$a->homework?->subject?->name` and `$a->submission?->…` in index.blade ← the `with([...])` at 119-122; `$exam->examType`/`academicSession` ← `$exam->load([...])` at 221). No `{!! !!}` anywhere; `teacher_remarks` and `submission->remarks` are escaped with `{{ }}` (show.blade:233, index.blade:354). Both views compile: `php -l` on the `Blade::compileString()` output reported "No syntax errors detected" for both files. `index.blade.php` breadcrumb resolves the trail (Home → Results). Row "View" actions are plain links, consistent with the parent-portal module (no `x-backend.table.action` usage anywhere in this module).

### F11 — Security and tenancy

#### PRC-12 · H · SEC-02 — the report-card download pre-checks "a Published report exists" but the delegated PDF generator loads the LATEST report regardless of status, so a parent can download an unpublished report card

| Field | Value |
|---|---|
| **Rule** | SEC-02 (H) — *no personal data over-exposed: the parent screen must not hand the parent data the school has not released*. Raised from the default M because it is a live wrong-result on a real download button. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:170-179` (the `$hasReport` guard) and `:201` (the delegate call); the mismatch lives in `Modules/Hpc/app/Http/Controllers/HpcController.php:2478-2484` (existence check, any status) and `:2666-2672` (saved-values load, any status). |
| **Root cause** | The parent controller only asserts `HpcReport::where('student_id', $studentId)->where('status', 'Published')->exists()`. The delegate `generateSingleStudentPdf($request, $studentId, true)` then loads `HpcReport::where('student_id', $student_id)->latest()->first()` (line 2478) for the existence check, and `HpcReport::where('student_id', $student_id)->where('template_id', $templateId)->latest()->first()` (lines 2666-2672) for the saved values that actually fill the PDF — **neither filters on `status`**. If the school created a Draft or Final report AFTER the Published one (e.g. started the next term's draft on the same template), the parent downloads that unpublished report's values, not the Published one. |
| **Consequence** | A parent clicking "Download Report Card (PDF)" can receive the school's not-yet-published marks and remarks — data the school has not released for this parent, on a normal user path. |
| **Reproduce** | ⚠ UNVERIFIED in a browser without a tenant dataset where a Draft/Final `hpc_reports` row is newer than the Published one for the same student+template and the templates are mapped; static proof: the parent's `status='Published'` filter is applied only to the `exists()` check (lines 171-173), while the delegate's value-loading query at HpcController.php:2666-2672 has no status clause. |
| **Fix approach** | DECISION (plan §9): (a) ⭐ add `->where('status', HpcReport::STATUS_PUBLISHED)` to the two delegate queries in `HpcController::generateSingleStudentPdf` (⚠ SHARED — Hpc module controller, NOT claimed yet); (b) keep the parent-side `hasReport` check but have it re-verify `status('Published')->latest()` and document the gap; (c) pass the published report id into the delegate (signature change, ⚠ SHARED). The parent-side `exists()` guard alone is insufficient and must not be considered the fix. |
| **Plan item** | PRC-12 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentResultController.php:170-179 — CURRENT (the guard is insufficient)
        $hasReport = HpcReport::where('student_id', $studentId)
            ->where('status', 'Published')
            ->exists();

        if (! $hasReport) {
            return redirect()
                ->route('parent-portal.results.index')
                ->with('warning', 'Your school has not published a report card for '.$child->first_name.' yet. Please check back later or contact the school office.');
        }
```

**Evidence**
```
$ sed -n '2666,2672p' Modules/Hpc/app/Http/Controllers/HpcController.php
                $latestReport = HpcReport::where('student_id', $student_id)
                    ->where('template_id', $templateId)
                    ->latest()
                    ->first();

                if ($latestReport) {
$
$ sed -n '2478,2482p' Modules/Hpc/app/Http/Controllers/HpcController.php
            $latestReport = HpcReport::where('student_id', $student_id)
                ->latest()
                ->first();

            if (!$latestReport) {
```

Rest of F11 clean: no `env()` outside config; no hard-coded ids or `?? 1`; no request bodies logged (the log lines log only exception messages — see PRC-01); the delegated PDF generation goes through the HPC service with `$bypassGate = true` but only after the parent has been authorized for THIS child and a report exists — the bypass is deliberate and documented, not a hole (the hole is the status mismatch, PRC-12).

### F12 — Style

#### PRC-09 · L · STY-01 / STY-04 / STY-06 — `Exam.php` misses `declare(strict_types=1)`, carries a copy-pasted Windows-path comment, and uses the global `\DB::` facade

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (old files when touched)*; STY-04 (L) — *no copy-pasted docblocks that describe another resource*; STY-06 (L) — *one style per concern: `DB::` not `\DB::`* |
| **Where** | `Modules/LmsExam/app/Models/Exam.php:1-2` (no `declare(strict_types=1);`, line 2 `// Path: c:\laragon\www\prime_ai\...`) and `:446` (`\DB::raw('count(*) as count')`) |
| **Root cause** | The file predates the strict_types convention, keeps a Windows editor path comment, and uses the fully-qualified `\DB::` while every other file in the module imports the facade. |
| **Consequence** | Style consistency only — no runtime effect. |
| **Reproduce** | Static only — see evidence. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php`, delete the path comment, switch `\DB::` to `DB::` (import `Illuminate\Support\Facades\DB`). |
| **Plan item** | PRC-09 in `02-fix-plan.md` §8 |

```php
// Exam.php:1-3 — CURRENT
<?php
// Path: c:\laragon\www\prime_ai\prime_ai\Modules\LmsExam\app\Models\Exam.php

namespace Modules\LmsExam\Models;
```

**Evidence**
```
$ sed -n '1,3p' Modules/LmsExam/app/Models/Exam.php
<?php
// Path: c:\laragon\www\prime_ai\prime_ai\Modules\LmsExam\app\Models\Exam.php

namespace Modules\LmsExam\Models;
$ sed -n '446p' Modules/LmsExam/app/Models/Exam.php
                ->select('mode', \DB::raw('count(*) as count'))
```

#### PRC-10 · L · STY-01 — `ExamResult.php` misses `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (old files when touched)* |
| **Where** | `Modules/StudentPortal/app/Models/ExamResult.php:1-3` |
| **Root cause** | File predates the strict_types convention. |
| **Consequence** | Style consistency only. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php`. |
| **Plan item** | PRC-10 in `02-fix-plan.md` §8 |

```php
// ExamResult.php:1-3 — CURRENT
<?php

namespace Modules\StudentPortal\Models;
```

**Evidence**
```
$ sed -n '1,3p' Modules/StudentPortal/app/Models/ExamResult.php
<?php

namespace Modules\StudentPortal\Models;
```

#### PRC-11 · L · STY-01 — `HpcReport.php` misses `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (old files when touched)* |
| **Where** | `Modules/Hpc/app/Models/HpcReport.php:1-4` |
| **Root cause** | File predates the strict_types convention. |
| **Consequence** | Style consistency only. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php`. |
| **Plan item** | PRC-11 in `02-fix-plan.md` §8 |

```php
// HpcReport.php:1-4 — CURRENT
<?php

namespace Modules\Hpc\Models;
```

**Evidence**
```
$ sed -n '1,4p' Modules/Hpc/app/Models/HpcReport.php
<?php

namespace Modules\Hpc\Models;
```

#### PRC-14 · L · STY-02 — unused `use Illuminate\Support\Facades\Gate;` import in the controller

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, no unused imports* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:10` |
| **Root cause** | The controller was written to call `Gate::authorize` at some point but the role gate ends up in the middleware; the import was never removed. |
| **Consequence** | Pint would flag/remove it; misleading signal that the controller authorizes. |
| **Reproduce** | Static only — `grep -n "Gate"` shows the import at line 10 and no use. |
| **Fix approach** | Delete line 10. |
| **Plan item** | PRC-14 in `02-fix-plan.md` §8 |

```php
// ParentResultController.php:10 — CURRENT
use Illuminate\Support\Facades\Gate;
```

**Evidence**
```
$ grep -n "Gate" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php
10:use Illuminate\Support\Facades\Gate;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

No method performs a business mutation. The only writes are single-row `activityLog` audit inserts (lines 132, 187, 238) — treated here as the mutating surface, plus the delegated PDF generator which writes nothing to the DB.

| Method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impls? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `index` | ok — audit insert only | ok | PRC-03 (quiz/quest) | ok — reads only; `whereNull('er.deleted_at')` explicit | ok | ok (child-scoped) | ok — event `'Viewed'` matches read | ok |
| `reportCardPdf` | ok — audit insert only | ok | ok | ok — `HpcReport` SoftDeletes + `exists()` status filter on read | ok | PRC-12 (unpublished delegate) + PRC-05 dead guard | ok — event `'Downloaded'`; the `warning` flash is truthful | PRC-05 (dead `$studentId` override) |
| `show` | ok — audit insert only | ok | ok | ok — reads only | ok | ok (`abort_if` 403 on empty published results) | ok — event `'Viewed'` matches read | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Hpc/app/Http/Controllers/HpcController.php:2666-2672, 2478-2484` | `generateSingleStudentPdf` loads the latest `HpcReport` regardless of status, so the parent download can serve an unpublished report card (parent-side manifestation = PRC-12) | SEC-02 | Hpc module audit when it runs; until then Tarun's DECISION on PRC-12 in this plan |
| Parent portal as a whole | Module has NO permission keys; every route is gated only by `ParentPortalMiddleware` (role gate) | AUTH-01 context | module-wide decision, out of scope for one controller |
| `config/media-library.php:73` + `Modules/Prime/app/Models/Media.php:9` | The app-wide default media model is the central `Modules\Prime\Models\Media` (connection `mysql`); any other tenant model that forgets `getMediaModel()` leaks to `prime_db.sys_media` (this controller's PRC-06 is one instance) | MDL-05/TEN-01 | all module audits |
| `Modules/ParentPortal/app/Services/ParentContextService.php:104,202-222` | `resolveChild()` aborts with a redirect when no child, and `getOrCreateSession()` writes `ppt_parent_sessions` on a read path (scanner: SVC-01, TXN-01) | SVC-01, TXN-01 | ↗ ParentDashboardController report (owner) |

## 8. Not covered, and why

- **The full `HpcController` (2,792 lines)**: only `generateSingleStudentPdf` was audited, and only for how THIS controller uses it (arguments, bypass flag, status mismatch). `HpcController` is the Hpc module's own controller; it is not claimed in `00-CLASS-OWNERS.md` and belongs to the Hpc module audit.
- **The HPC PDF blade stack** (`hpc::hpc_form.pdf.*`) and `HpcReportService` internals: reached through the delegate, rendered/executed only inside the Hpc module; not compiled/rendered here.
- **`HpcReportTemplate`/`HpcReportItem`/`HpcReportTable`** models: reached only via the delegate; belong to the Hpc module audit.
- **Live row counts and browser reproduction**: no tenant database is reachable from this host, so PRC-12's browser reproduction is marked UNVERIFIED and live data is unknown (D4 — no tests were run).
- **`Exam::getStatisticsAttribute()` and the `\DB::raw` aggregate** and `Exam`'s boot-code-uniqueness hook: model members outside this controller's read path; noted for style only (PRC-09 touches the `\DB::` line).
- **Queue/console behaviour**: none used by this controller.