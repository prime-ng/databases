# Fix Plan — ParentPortal / ParentResultController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Hpc/app/Http/Controllers/HpcController.php` | Hpc module's own controller, not claimed; only the ⚠ SHARED PRC-12 item may touch it, and only when ticked |
| `Modules/ParentPortal/routes/web.php` | shared module route file; only PRC-05 option (b) mentions it, as a ⚠ SHARED route change |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the ParentDashboardController report |
| `Modules/LmsHomework/app/Models/HomeworkAssignment.php` | owned by the ParentHomeworkController report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by the ParentHealthController report |
| `config/media-library.php` | shared config; PRC-06 fixes the model, not the config |

## 1. Blockers reachable today

- [x] **PRC-06** · B · MDL-05 / TEN-01 · `Modules/Hpc/app/Models/HpcReport.php:17-19` — override `getMediaModel()` so HPC report files are written to the TENANT database, not the central one.
  - **Touches:** `Modules/Hpc/app/Models/HpcReport.php`
  - **Before** (`HpcReport.php:17-19`):
    ```php
    class HpcReport extends Model implements HasMedia
    {
        use SoftDeletes, InteractsWithMedia;
    ```
  - **After:**
    ```php
    class HpcReport extends Model implements HasMedia
    {
        use SoftDeletes, InteractsWithMedia;

        /**
         * Spatie media rows for HPC report files must live in the TENANT database
         * (final-audit PRC-06, 2026-10-13).
         */
        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Verify:** `grep -n "function getMediaModel" Modules/Hpc/app/Models/HpcReport.php`
  - **Expect:** `18:    public function getMediaModel(): string` (line number may drift by one).
  - **Effort:** S

- [x] **PRC-12** · H · DECISION · SEC-02 — the report-card PDF can be built from an UNPUBLISHED report (the delegated `generateSingleStudentPdf` loads the latest `hpc_reports` row regardless of status).
  - **Why it is a decision:** the wrong behaviour lives in `HpcController.php` (⚠ SHARED — the Hpc module's own controller, not claimed by any report), so the fix crosses module boundaries.
  - (a) ⭐ **Filter `status = Published` inside the delegate** (recommended). Add `->where('status', HpcReport::STATUS_PUBLISHED)` to the two `latestReport` queries at `HpcController.php:2478-2482` and `:2666-2672`. This is the only fix that actually prevents the parent from downloading a Draft/Final. Touches `Modules/Hpc/app/Http/Controllers/HpcController.php` (⚠ SHARED) — see Before/After below.
  - (b) Keep it parent-side only: tighten the `hasReport` check to `->where('status', 'Published')->latest()->first()`. This does NOT bind what the delegate renders (the delegate takes only `$studentId`), so it does not fix the leak — recorded as accepted-risk documentation only.
  - (c) Pass the published report id into `generateSingleStudentPdf` (signature change). Touches the same shared controller plus the caller; more invasive.
  - ➜ Choice: (a) — filter Published inside the shared delegate 2026-10-22
  - **Touches (option a):** `Modules/Hpc/app/Http/Controllers/HpcController.php`
  - **Before** (`HpcController.php:2478-2482`):
    ```php
            $latestReport = HpcReport::where('student_id', $student_id)
                ->latest()
                ->first();
    ```
  - **After (option a):**
    ```php
            $latestReport = HpcReport::where('student_id', $student_id)
                ->where('status', HpcReport::STATUS_PUBLISHED)
                ->latest()
                ->first();
    ```
  - **Before** (`HpcController.php:2666-2672`):
    ```php
                $latestReport = HpcReport::where('student_id', $student_id)
                    ->where('template_id', $templateId)
                    ->latest()
                    ->first();
    ```
  - **After (option a):**
    ```php
                $latestReport = HpcReport::where('student_id', $student_id)
                    ->where('template_id', $templateId)
                    ->where('status', HpcReport::STATUS_PUBLISHED)
                    ->latest()
                    ->first();
    ```
  - **Verify:** `grep -cn "where('status', HpcReport::STATUS_PUBLISHED)" Modules/Hpc/app/Http/Controllers/HpcController.php`
  - **Expect:** `2`
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

## 3. Errors & transactions (F1/F2)

- [x] **PRC-01** · M · DECISION · ERR-07 / ERR-00 / ERR-05 — the three audit-write try/catches in `index()` (131-143), `reportCardPdf()` (186-199) and `show()` (237-250) are not a D2 shape and log `getMessage()` without a trace.
  - **Why it is a decision:** the code deliberately isolates the audit write so a failed log cannot take a page down. Strict D1 would remove the try/catch and let the central handler render (a failed audit row would then 500 the page). The recommendation keeps the isolation AND fixes the two real defects: `report($e)` (trace) and the injected `$request` (CTL-08).
  - (a) ⭐ **Keep ONE isolated catch that preserves the page and the trace** (recommended): replace each catch body with `report($e);` and change `request()->route()?->getName()` to `$request->route()?->getName()`. This keeps the page up on an audit failure and logs the full exception object.
  - (b) **Strict D1**: delete the try/catch entirely in all three methods. A failed audit write would then 500 the parent's page — against the property the comments in the code are protecting.
  - ➜ Choice: (a) — isolated catch with report($e) 2026-10-22
  - **Touches (option a):** `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Before** (`ParentResultController.php:131-143`, method `index()`):
    ```php
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed results',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
    ```
  - **After (option a):**
    ```php
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed results',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    ```
  - **Before** (`ParentResultController.php:186-199`, method `reportCardPdf()`):
    ```php
        try {
            activityLog(auth()->user(), 'Downloaded', [
                'message' => 'Downloaded report card PDF',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'student_id_downloaded' => $studentId,
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'reportCardPdf', 'error' => $e->getMessage()]);
        }
    ```
  - **After (option a):**
    ```php
        try {
            activityLog(auth()->user(), 'Downloaded', [
                'message' => 'Downloaded report card PDF',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'student_id_downloaded' => $studentId,
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    ```
  - **Before** (`ParentResultController.php:237-250`, method `show()`):
    ```php
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed exam result details',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'exam_id' => $exam->id,
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'show', 'error' => $e->getMessage()]);
        }
    ```
  - **After (option a):**
    ```php
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed exam result details',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'exam_id' => $exam->id,
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    ```
  - **Verify:** `grep -n "getMessage\|request()->route" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Expect:** no output (all three rewritten). If option (b) is chosen instead, `grep -n "try {"` → no output.
  - **Effort:** S

## 4. Authorization (F3)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PRC-02** · M · CTL-02 / CTL-05 / QRY-05 — rewrite the 120-line `index()` by extracting the four list builders into private methods; this also removes the quiz/quest copy-paste (PRC-03) and the `->get()->filter()` PHP filter (PRC-13).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Import Before** (`ParentResultController.php:7-12`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    ```
  - **Import After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Collection;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    ```
  - **Before** (`ParentResultController.php:29-148`, the whole `index()` method):
    ```php
    public function index(Request $request): View
    {
        $child = $this->context->resolveChild($request);
        $session = $child->currentSession()->first();
        $studentId = $child->id;
        // Scope every list to the child's CURRENT class — other classes' rows are not theirs.
        $classId = $session?->classSection?->class_id;

        // ── Exam Results (per-paper, mirrors student portal) ─────────────────
        $examResults = DB::table('lms_exam_results as er')
            ->join('lms_exam_papers as ep', 'ep.id', '=', 'er.exam_paper_id')
            ->when($classId, fn ($q) => $q->where('ep.class_id', $classId))
            ->join('lms_exams as e', 'e.id', '=', 'er.exam_id')
            ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'ep.subject_id')
            ->where('er.student_id', $studentId)
            ->where('er.is_published', true)
            ->whereNull('er.deleted_at')
            ->orderByDesc('er.created_at')
            ->get([
                'er.id',
                'e.title as exam_title',
                'ep.title as paper_title',
                'ep.paper_code',
                'ep.total_marks',
                'ep.duration_minutes',
                'er.total_marks_obtained',
                'er.total_marks_possible',
                'er.percentage',
                'er.grade_obtained',
                'er.result_status',
                'er.division',
                'er.rank_in_class',
                'er.teacher_remarks',
                'er.created_at',
                'sub.name as subject_name',
                'er.exam_paper_id',
                'er.exam_id',
            ]);

        // ── Quiz Results ──────────────────────────────────────────────────────
        $quizResults = DB::table('lms_quiz_quest_results as rr')
            ->join('lms_quizzes as q', 'q.id', '=', 'rr.assessment_id')
            ->when($classId, fn ($q) => $q->where('q.class_id', $classId))
            ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'q.subject_id')
            ->where('rr.student_id', $studentId)
            ->where('rr.assessment_type', 'QUIZ')
            ->where('rr.is_published', true)
            ->whereNull('rr.deleted_at')
            ->orderByDesc('rr.created_at')
            ->get([
                'rr.id',
                'q.title as quiz_title',
                'sub.name as subject_name',
                'rr.total_marks_obtained',
                'rr.max_marks',
                'rr.percentage',
                'rr.grade_obtained',
                'rr.is_passed',
                'rr.assessment_id as quiz_id',
                'rr.created_at',
            ]);

        // ── Quest Results ─────────────────────────────────────────────────────
        $questResults = DB::table('lms_quiz_quest_results as rr')
            ->join('lms_quests as q', 'q.id', '=', 'rr.assessment_id')
            ->when($classId, fn ($q) => $q->where('q.class_id', $classId))
            ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'q.subject_id')
            ->where('rr.student_id', $studentId)
            ->where('rr.assessment_type', 'QUEST')
            ->where('rr.is_published', true)
            ->whereNull('rr.deleted_at')
            ->orderByDesc('rr.created_at')
            ->get([
                'rr.id',
                'q.title as quest_title',
                'sub.name as subject_name',
                'rr.total_marks_obtained',
                'rr.max_marks',
                'rr.percentage',
                'rr.grade_obtained',
                'rr.is_passed',
                'rr.assessment_id as quest_id',
                'rr.created_at',
            ]);

        // ── Homework Results ──────────────────────────────────────────────────
        $homeworkResults = HomeworkAssignment::where('student_id', $studentId)
            ->when($classId, fn ($q) => $q->whereHas('homework', fn ($h) => $h->where('class_id', $classId)))
            ->where('is_active', true)
            ->whereHas('submission')
            ->with([
                'homework' => fn ($q) => $q->with('subject'),
                'submission',
            ])
            ->orderByDesc('due_date')
            ->get()
            ->filter(fn ($a) => $a->homework !== null);

        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed results',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }

        return view('parentportal::results.index', compact(
            'child', 'session', 'examResults', 'quizResults', 'questResults', 'homeworkResults'
        ));
    }
    ```
  - **After:**
    ```php
    public function index(Request $request): View
    {
        $child = $this->context->resolveChild($request);
        $session = $child->currentSession()->first();
        $studentId = $child->id;
        // Scope every list to the child's CURRENT class — other classes' rows are not theirs.
        $classId = $session?->classSection?->class_id;

        $examResults = $this->examResults($studentId, $classId);

        $quizResults = $this->assessmentResults('QUIZ', $studentId, $classId);

        $questResults = $this->assessmentResults('QUEST', $studentId, $classId);

        $homeworkResults = $this->homeworkResults($studentId, $classId);

        // Rule A1, scoped to the audit write. Everything else in this method is a read, so
        // the only thing that can fail destructively is the log itself — and a failed
        // audit row must never take a parent's page down with it. Rule A2 does not
        // apply: one row, one table, which is the exception §3 names.
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed results',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            report($e);
        }

        return view('parentportal::results.index', compact(
            'child', 'session', 'examResults', 'quizResults', 'questResults', 'homeworkResults'
        ));
    }

    /**
     * Per-paper exam results for the active child, filtered by their current class.
     */
    private function examResults(int $studentId, ?int $classId): Collection
    {
        return DB::table('lms_exam_results as er')
            ->join('lms_exam_papers as ep', 'ep.id', '=', 'er.exam_paper_id')
            ->when($classId, fn ($q) => $q->where('ep.class_id', $classId))
            ->join('lms_exams as e', 'e.id', '=', 'er.exam_id')
            ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'ep.subject_id')
            ->where('er.student_id', $studentId)
            ->where('er.is_published', true)
            ->whereNull('er.deleted_at')
            ->orderByDesc('er.created_at')
            ->get([
                'er.id',
                'e.title as exam_title',
                'ep.title as paper_title',
                'ep.paper_code',
                'ep.total_marks',
                'ep.duration_minutes',
                'er.total_marks_obtained',
                'er.total_marks_possible',
                'er.percentage',
                'er.grade_obtained',
                'er.result_status',
                'er.division',
                'er.rank_in_class',
                'er.teacher_remarks',
                'er.created_at',
                'sub.name as subject_name',
                'er.exam_paper_id',
                'er.exam_id',
            ]);
    }

    /**
     * Quiz or Quest result rows for the active child. $type is 'QUIZ' or 'QUEST'.
     */
    private function assessmentResults(string $type, int $studentId, ?int $classId): Collection
    {
        $joinTable = $type === 'QUIZ' ? 'lms_quizzes' : 'lms_quests';
        $titleAlias = $type === 'QUIZ' ? 'quiz_title' : 'quest_title';
        $idAlias = $type === 'QUIZ' ? 'quiz_id' : 'quest_id';

        return DB::table('lms_quiz_quest_results as rr')
            ->join($joinTable.' as q', 'q.id', '=', 'rr.assessment_id')
            ->when($classId, fn ($q) => $q->where('q.class_id', $classId))
            ->leftJoin('sch_subjects as sub', 'sub.id', '=', 'q.subject_id')
            ->where('rr.student_id', $studentId)
            ->where('rr.assessment_type', $type)
            ->where('rr.is_published', true)
            ->whereNull('rr.deleted_at')
            ->orderByDesc('rr.created_at')
            ->get([
                'rr.id',
                'q.title as '.$titleAlias,
                'sub.name as subject_name',
                'rr.total_marks_obtained',
                'rr.max_marks',
                'rr.percentage',
                'rr.grade_obtained',
                'rr.is_passed',
                'rr.assessment_id as '.$idAlias,
                'rr.created_at',
            ]);
    }

    /**
     * Graded homework assignments for the active child with subject and submission.
     */
    private function homeworkResults(int $studentId, ?int $classId): Collection
    {
        return HomeworkAssignment::where('student_id', $studentId)
            ->when($classId, fn ($q) => $q->whereHas('homework', fn ($h) => $h->where('class_id', $classId)))
            ->where('is_active', true)
            ->whereHas('submission')
            ->whereHas('homework')
            ->with([
                'homework' => fn ($q) => $q->with('subject'),
                'submission',
            ])
            ->orderByDesc('due_date')
            ->get();
    }
    ```
  - **Verify:** `php -l Modules/ParentPortal/app/Http/Controllers/ParentResultController.php && grep -n "private function\|->filter(fn" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Expect:** `No syntax errors detected`, three `private function` lines (examResults / assessmentResults / homeworkResults), and NO `->filter(fn` output.
  - **Effort:** M

- [x] **PRC-07** · L · MDL-04 · `Modules/Hpc/app/Models/HpcReport.php:79-143` — add `: BelongsTo` / `: HasMany` return types to the 9 relationship methods and import the relation classes.
  - **Touches:** `Modules/Hpc/app/Models/HpcReport.php`
  - **Import Before** (`HpcReport.php:4-16`):
    ```php

    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Import After:**
    ```php

    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    ```
  - **Before** (`HpcReport.php:77-146`, relations block):
    ```php

    /**
     * Get the student for this report
     */
    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    /**
     * Get the template for this report
     */
    public function template()
    {
        return $this->belongsTo(HpcTemplates::class, 'template_id');
    }

    /**
     * Get the academic session for this report
     */
    public function academicSession()
    {
        return $this->belongsTo(StudentAcademicSession::class, 'academic_session_id');
    }

    /**
     * Get the term for this report
     */
    public function term()
    {
        return $this->belongsTo(AcademicTerm::class, 'term_id');
    }

    /**
     * Get the class for this report
     */
    public function class()
    {
        return $this->belongsTo(SchoolClass::class, 'class_id');
    }

    /**
     * Get the section for this report
     */
    public function section()
    {
        return $this->belongsTo(Section::class, 'section_id');
    }

    /**
     * Get the user who prepared this report
     */
    public function preparedBy()
    {
        return $this->belongsTo(User::class, 'prepared_by');
    }

    /**
     * Get the report items for this report
     */
    public function reportItems()
    {
        return $this->hasMany(HpcReportItem::class, 'report_id');
    }

    /**
     * Get the report tables for this report
     */
    public function reportTables()
    {
        return $this->hasMany(HpcReportTable::class, 'report_id');
    }
    ```
  - **After:**
    ```php

    /**
     * Get the student for this report
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    /**
     * Get the template for this report
     */
    public function template(): BelongsTo
    {
        return $this->belongsTo(HpcTemplates::class, 'template_id');
    }

    /**
     * Get the academic session for this report
     */
    public function academicSession(): BelongsTo
    {
        return $this->belongsTo(StudentAcademicSession::class, 'academic_session_id');
    }

    /**
     * Get the term for this report
     */
    public function term(): BelongsTo
    {
        return $this->belongsTo(AcademicTerm::class, 'term_id');
    }

    /**
     * Get the class for this report
     */
    public function class(): BelongsTo
    {
        return $this->belongsTo(SchoolClass::class, 'class_id');
    }

    /**
     * Get the section for this report
     */
    public function section(): BelongsTo
    {
        return $this->belongsTo(Section::class, 'section_id');
    }

    /**
     * Get the user who prepared this report
     */
    public function preparedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'prepared_by');
    }

    /**
     * Get the report items for this report
     */
    public function reportItems(): HasMany
    {
        return $this->hasMany(HpcReportItem::class, 'report_id');
    }

    /**
     * Get the report tables for this report
     */
    public function reportTables(): HasMany
    {
        return $this->hasMany(HpcReportTable::class, 'report_id');
    }
    ```
  - **Verify:** `grep -n "public function student()\|public function reportTables()" Modules/Hpc/app/Models/HpcReport.php`
  - **Expect:** no output — untyped declarations are gone.
  - **Effort:** S

- [x] **PRC-08** · L · MDL-04 · `Modules/LmsExam/app/Models/Exam.php:202-207` — give `examStudentGroups()` a return type so it matches the other 12 typed relations.
  - **Touches:** `Modules/LmsExam/app/Models/Exam.php`
  - **Import Before** (`Exam.php:11-12`):
    ```php
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **Import After:**
    ```php
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **Before** (`Exam.php:200-207`):
    ```php
     * Get the student groups participating in this exam.
     */
    public function examStudentGroups()
    {
        return ExamStudentGroup::whereHas('allocations.examPaper', function($q) {
            $q->where('exam_id', $this->id);
        });
    }
    ```
  - **After:**
    ```php
     * Get the student groups participating in this exam.
     */
    public function examStudentGroups(): Builder
    {
        return ExamStudentGroup::whereHas('allocations.examPaper', function ($q) {
            $q->where('exam_id', $this->id);
        });
    }
    ```
  - **Verify:** `grep -n "public function examStudentGroups" Modules/LmsExam/app/Models/Exam.php`
  - **Expect:** `public function examStudentGroups(): Builder`
  - **Effort:** S

- [x] **PRC-04** · L · CTL-04 · `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:156` — declare the return type of `reportCardPdf()`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Import Before** (`ParentResultController.php:7-12`):
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    ```
  - **Import After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Http\Response;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    use Illuminate\View\View;
    ```
  - **Before** (`ParentResultController.php:156`):
    ```php
    public function reportCardPdf(Request $request, ?int $studentId = null)
    ```
  - **After:**
    ```php
    public function reportCardPdf(Request $request, ?int $studentId = null): RedirectResponse|Response
    ```
  - **Verify:** `grep -n "public function reportCardPdf" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Expect:** `public function reportCardPdf(Request $request, ?int $studentId = null): RedirectResponse|Response`
  - **Effort:** S

## 6. Queries & performance (F9)

## 7. Views (F10)

## 8. Style (F12) — one item per file

- [x] **PRC-09** · L · STY-01 / STY-04 / STY-06 · `Modules/LmsExam/app/Models/Exam.php` — add `declare(strict_types=1);`, delete the Windows-path comment, switch `\DB::raw` to `DB::raw` with the facade import.
  - **Touches:** `Modules/LmsExam/app/Models/Exam.php`
  - **Before** (`Exam.php:1-3`):
    ```php
    <?php
    // Path: c:\laragon\www\prime_ai\prime_ai\Modules\LmsExam\app\Models\Exam.php

    namespace Modules\LmsExam\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\LmsExam\Models;
    ```
  - **Import Before** (`Exam.php:8-12`):
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    ```
  - **Import After:**
    ```php
    use App\Models\BaseModel;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Support\Facades\DB;
    ```
  - **Before** (`Exam.php:445-446`):
    ```php
                ->select('mode', \DB::raw('count(*) as count'))
    ```
  - **After:**
    ```php
                ->select('mode', DB::raw('count(*) as count'))
    ```
  - **Verify:** `grep -n "strict_types\|Path: c:\|\\\\DB::raw" Modules/LmsExam/app/Models/Exam.php`
  - **Expect:** line `declare(strict_types=1);` present; `Path: c:` absent; `\DB::raw` absent.
  - **Effort:** S

- [x] **PRC-10** · L · STY-01 · `Modules/StudentPortal/app/Models/ExamResult.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/StudentPortal/app/Models/ExamResult.php`
  - **Before** (`ExamResult.php:1-3`):
    ```php
    <?php

    namespace Modules\StudentPortal\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\StudentPortal\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/StudentPortal/app/Models/ExamResult.php`
  - **Expect:** `3: declare(strict_types=1);`
  - **Effort:** S

- [x] **PRC-11** · L · STY-01 · `Modules/Hpc/app/Models/HpcReport.php` — add `declare(strict_types=1);`.
  - **Touches:** `Modules/Hpc/app/Models/HpcReport.php`
  - **Before** (`HpcReport.php:1-4`):
    ```php
    <?php

    namespace Modules\Hpc\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Hpc\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/Hpc/app/Models/HpcReport.php`
  - **Expect:** `3: declare(strict_types=1);`
  - **Effort:** S

- [x] **PRC-14** · L · STY-02 · `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php:10` — remove the unused `Gate` import.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Before** (`ParentResultController.php:9-11`):
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Gate;
    use Illuminate\Support\Facades\Log;
    ```
  - **After:**
    ```php
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    ```
  - **Verify:** `grep -n "Facades\\\\Gate" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PRC-05** · M · DECISION · CTL-10 — the `$studentId` override branch of `reportCardPdf()` is dead because the route `/report-card/pdf` has no `{studentId}` parameter; the intended multi-child download and its 403 guard can never run.
  - **Why it is a decision:** option (b) changes a route file (⚠ SHARED); option (a) removes behaviour that the branch advertises, so Tarun decides what the feature contract is.
  - (a) ⭐ **Remove the dead branch** (recommended): replace lines 158-168 with `$child = $this->context->resolveChild($request);  $studentId = $child->id;` keeping active-child-only download (matches the doc-block "for the active child"). No route change.
  - (b) **Make the override real**: add an optional route parameter `Route::get('/report-card/pdf/{studentId?}', ...)->whereNumber('studentId')` in `Modules/ParentPortal/routes/web.php:78` (⚠ SHARED route file) so a parent can deep-link a specific child's card; keep the branch as the IDOR guard.
  - (c) Leave as is and document.
  - ➜ Choice: (a) — remove the dead studentId override 2026-10-22
  - **Touches (option a):** `Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Before** (`ParentResultController.php:158-168`):
    ```php
        $child = $this->context->resolveChild($request);

        // Allow override only if the override belongs to one of the parent's own children.
        if ($studentId !== null && $studentId !== $child->id) {
            $accessible = $this->context->getAccessibleChildren($request->user())
                ->pluck('id')
                ->toArray();
            abort_unless(in_array($studentId, $accessible, true), 403);
        } else {
            $studentId = $child->id;
        }
    ```
  - **After (option a):**
    ```php
        $child = $this->context->resolveChild($request);

        // Active child only (final-audit PRC-05, 2026-10-13): the route has no
        // {studentId} parameter, so the previous override branch was dead code.
        $studentId = $child->id;
    ```
  - **Before (option b route, `web.php:78`):**
    ```php
        Route::get('/report-card/pdf', [ParentResultController::class, 'reportCardPdf'])->name('report-card.pdf');
    ```
  - **After (option b route):**
    ```php
        Route::get('/report-card/pdf/{studentId?}', [ParentResultController::class, 'reportCardPdf'])->whereNumber('studentId')->name('report-card.pdf');
    ```
  - **Verify (option a):** `grep -n "getAccessibleChildren" Modules/ParentPortal/app/Http/Controllers/ParentResultController.php`
  - **Expect (option a):** no output.
  - **Verify (option b):** `grep -n "report-card/pdf" Modules/ParentPortal/routes/web.php`
  - **Expect (option b):** `Route::get('/report-card/pdf/{studentId?}', ...` present.
  - **Effort:** S

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PRC-03 | CTL-05 quiz/quest copy-paste — fixed by the PRC-02 `index()` rewrite (assessmentResults helper), §5 above. |
| PRC-13 | QRY-05 `->get()->filter()` on homework — fixed inside PRC-02's `homeworkResults()` helper (`whereHas('homework')` replaces the PHP filter), §5 above. |