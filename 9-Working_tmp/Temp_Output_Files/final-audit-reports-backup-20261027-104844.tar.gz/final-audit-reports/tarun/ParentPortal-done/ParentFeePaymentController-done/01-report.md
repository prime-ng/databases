# Final Audit — ParentPortal / ParentFeePaymentController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php` (210 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /parent-portal/fees/invoice/{invoice}/pay/initiate` → `parent-portal.fees.invoice.pay.initiate` · `POST /parent-portal/fees/invoice/{invoice}/pay/callback` → `parent-portal.fees.invoice.pay.callback` — both JSON, no rendered pages |
| Menu path | Parent Portal → Fees → invoice detail page → "Pay online" button |
| Who uses it | Parents logged into the parent portal (route middleware: `auth` + `verified` + `ParentPortalMiddleware`, which requires `user_type = PARENT`, a `std_guardians` row, and ≥1 child with `can_access_parent_portal = 1`). No permission key — the portal authorizes by user type, like every other ParentPortal controller. |
| What a user does here | A parent opens an unpaid invoice for one of their children and clicks Pay. The app POSTs `initiate`, the backend asks Razorpay for an order and returns a checkout payload; the parent pays in Razorpay's page; the app POSTs `callback` with Razorpay's order id, payment id and signature. The backend verifies the HMAC signature, checks the order id, the amount and the invoice ownership, then marks the `Payment` row success, creates a fee transaction + receipt, and raises the invoice's `paid_amount`. |
| Tables written | `ptm_payment_payments`, `ptm_payment_audit_logs`, `ptm_payment_webhooks` (via the webhook path, not this callback), `fee_transactions`, `fee_receipts`, `fee_invoices`, `sys_activity_logs` (the audit helper) |
| Tables read | `ptm_payment_gateways`, `ptm_payment_payments`, `fee_invoices`, `fee_student_assignments`, `std_students`, `sys_users` (parent + child user), `fee_transactions` (idempotency check) |
| Live data | test tenant `xyz_school_00000000000040008000_202627`: `ptm_payment_payments` 60 rows (7 pending, 24 success), `ptm_payment_gateways` 6 rows (2 active), `fee_invoices` 7,296, `fee_transactions` 3,833 (3,829 Success) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready as written. The two endpoints form a real-money payment flow, and they get the security spine right — the callback verifies the Razorpay HMAC signature with `hash_equals`, rejects a ULID that does not map to the invoice, re-checks the order id and amount, and guards the success write with `lockForUpdate()` plus a status check and a unique index. That part is solid and is the reason this is not a B-severity shower.

The single worst finding is in `initiate()`: a controller `try/catch (\Throwable)` that returns `$e->getMessage()` to the user (ERR-01 / D1). Plus the failure branch of the callback can flip an already-SUCCESS payment to FAILED because `markFailed` has no status guard — the exact guard the success path has — and the same branch writes 3+ tables with no transaction. There is also a duplicate implementation of the fee-ledger credit (event listener + `recordGatewayPayment`) which only stays single because of the unique index. Rough effort: the two mechanical B/H fixes are a few hours; the two DECISION items need one product choice each.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 8 | 2 | 2 | 14 findings (13 plan items + 1 in §10; 2 are DECISIONs) |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PFPC-01 | F8 Services/Jobs | PFPC-13 |
| F2 Transactions/Audit | PFPC-03, PFPC-04, PFPC-05, PFPC-11 | F9 Queries/Perf | clean |
| F3 Authorization | clean | F10 Views | clean (no views) |
| F4 Validation | PFPC-06, PFPC-07 | F11 Security/Tenancy | clean (SEC-01/04/05) |
| F5 Routes | clean | F12 Style | PFPC-14 |
| F6 Controller shape | PFPC-08, PFPC-09, PFPC-10 | F13 Deep read | PFPC-15 |
| F7 Models | PFPC-12 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php` | controller | 210 | this report | ✅ |
| 2 | `Modules/ParentPortal/routes/web.php` | route file ($82-98: the two pay routes) | 199 | this report (routes only) | ✅ |
| 3 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked (usage checked, §7) |
| 4 | `Modules/Payment/app/Models/Payment.php` | model | 101 | this report (pre-assigned 00-CLASS-OWNERS line 324) | ✅ |
| 5 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | this report (claimed) | ✅ |
| 6 | `Modules/Payment/app/Models/PaymentAuditLog.php` | model | 43 | this report (claimed) | ✅ |
| 7 | `Modules/Payment/app/Services/PaymentService.php` | service | 182 | this report (pre-assigned line 325) | ✅ |
| 8 | `Modules/Payment/app/Services/GatewayManager.php` | service | 85 | this report (pre-assigned line 326) | ✅ |
| 9 | `Modules/Payment/app/Services/AuditService.php` | service | 104 | this report (claimed) | ✅ |
| 10 | `Modules/Payment/app/Gateways/RazorpayGateway.php` | gateway | 275 | this report (claimed) | ✅ |
| 11 | `Modules/Payment/app/Gateways/BaseGateway.php` | gateway base | 15 | this report (claimed) | ✅ |
| 12 | `Modules/Payment/app/Contracts/PaymentGatewayInterface.php` | contract | 65 | this report (claimed) | ✅ |
| 13 | `Modules/Payment/app/Contracts/Payable.php` | contract | 38 | this report (claimed) | ✅ |
| 14 | `Modules/Payment/app/DTO/PaymentData.php` | DTO | 43 | this report (claimed) | ✅ |
| 15 | `Modules/Payment/app/Events/PaymentSucceeded.php` | event | 12 | this report (claimed) | ✅ |
| 16 | `Modules/Payment/app/Events/PaymentFailed.php` | event | 15 | this report (claimed) | ✅ |
| 17 | `Modules/Payment/app/Events/PaymentInitiated.php` | event | 12 | this report (claimed) | ✅ |
| 18 | `Modules/Payment/app/Listeners/PaymentSucceededListener.php` | listener | 47 | this report (claimed) | ✅ |
| 19 | `Modules/Payment/app/Listeners/PaymentFailedListener.php` | listener | 46 | this report (claimed) | ✅ |
| 20 | `Modules/Payment/app/Listeners/PaymentInitiatedListener.php` | listener | 32 | this report (claimed) | ✅ |
| 21 | `Modules/StudentFee/app/Models/FeeInvoice.php` | model | 474 | ↗ [tarun/ParentPortal-done/ParentFeeController](../ParentFeeController-done/01-report.md) (line 333) | ↗ linked (usage checked, §7) |
| 22 | `Modules/StudentFee/app/Services/FeeInvoiceService.php` | service | 382 | ↗ [tarun/ParentPortal-done/ParentFeeController](../ParentFeeController-done/01-report.md) (line 336) | ↗ linked (usage checked, §7) |
| 23 | `Modules/StudentFee/app/Models/FeeReceipt.php`, `FeeTransaction.php` | models | — | ↗ via `ParentFeeController` | ↗ linked (reached via service call, §7) |

No in-scope file appears in a `PRE-APPLIED-2026-10-10.md` (the only such file is for TimetableFoundation).

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...ParentFeePaymentController@...'
POST  parent-portal/fees/invoice/{invoice}/pay/callback    parent-portal.fees.invoice.pay.callback    Modules\ParentPortal\Http\Controllers\ParentFeePaymentController@callback
POST  parent-portal/fees/invoice/{invoice}/pay/initiate    parent-portal.fees.invoice.pay.initiate    Modules\ParentPortal\Http\Controllers\ParentFeePaymentController@initiate
```

Both routes sit inside `Route::prefix('fees')` in `Modules/ParentPortal/routes/web.php:83-98`, whose group is mounted by the module's `RouteServiceProvider` behind `web → InitializeTenancyByDomain → PreventAccessFromCentralDomains → EnsureTenantIsActive → auth → verified → ParentPortalMiddleware` (file-header comment, web.php:34-40). Both are POST — no state change over GET (RTE-01 clean). The route parameter `{invoice}` matches the method argument `FeeInvoice $invoice` (implicit binding, RTE-03 clean) and is a tenant route (RTE-05 clean).

Unrouted public methods: none — both public methods are routed.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `initiate` | 31 | POST fees/invoice/{invoice}/pay/initiate | none (route middleware + own `abort_if` ownership check, lines 36-39) | none in controller — inside `PaymentService::initiate` (line 35) | 'PaymentInitiated' (line 44, AFTER the service's transaction) | ptm_payment_payments, ptm_payment_audit_logs, (Razorpay order external), sys_activity_logs | PFPC-01, PFPC-04, PFPC-08, PFPC-09(partial), PFPC-10, PFPC-11 |
| `callback` | 74 | POST fees/invoice/{invoice}/pay/callback | none (route middleware + own `abort_if` checks: child ownership line 85, ULID mapping line 93, signature line 111, order id line 135, amount line 150) | `DB::transaction` line 165 (success path: markSuccess + recordGatewayPayment); NO tx on the failure branches | 'PaymentFailed' (117, 136, 151) and 'Paid' (191 — AFTER the transaction) | ptm_payment_payments, ptm_payment_audit_logs, fee_transactions, fee_receipts, fee_invoices, sys_activity_logs | PFPC-03, PFPC-04, PFPC-06, PFPC-08, PFPC-09, PFPC-10, PFPC-12, PFPC-13, PFPC-15 |

## 6. Findings

### F1 — Errors

#### PFPC-01 · B · ERR-01 — `initiate()` returns the raw exception message to the user (and wraps everything in a controller try/catch, against D1)

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak*; D1 — *no try/catch in controllers* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:41-67`, method `initiate()` |
| **Root cause** | The method wraps the whole initiate flow in `try { ... } catch (\Throwable $e) { return response()->json(['error' => $e->getMessage()], 422); }`. A failure anywhere inside — a DB deadlock, a Razorpay API error, a missing gateway row — is flattened to 422 and its raw message is returned to the parent's app. ERR-01 says the exception's text (which can contain table names, SQL fragments, gateway internals) must never reach the user, and D1 removes the try/catch entirely: `DB::transaction` rolls back and the central handler in `bootstrap/app.php` renders. |
| **Consequence** | A parent whose payment fails during initiate sees internal error text in the app instead of a fixed message, and any DB name/column leaking through a `QueryException` becomes visible. |
| **Reproduce** | Trigger an error inside initiate — e.g. run with the Razorpay gateway row inactive: `GatewayManager::resolve()` throws "Payment gateway [razorpay] not found or inactive." and the catch returns it verbatim as `error`. |
| **Fix approach** | Remove the `try/catch`; let exceptions reach the central handler. Move the success `activityLog` after `PaymentService::initiate()` (which already commits inside its own transaction); if the audit write itself throws, that is a 500 the client can retry safely (the order id is stored on the payment row). |
| **Plan item** | PFPC-01 in `02-fix-plan.md` §1 |

```php
// ParentFeePaymentController.php:41-67 — CURRENT
        try {
            $result = $this->paymentService->initiate($invoice, 'razorpay');

            activityLog(auth()->user(), 'PaymentInitiated', [
                'message' => 'Initiated fee payment',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'amount' => $result['payment']->amount ?? null,
                'payment_ulid' => $result['payment']->ulid ?? null,
            ]);

            return response()->json([
                'success'      => true,
                'payment_ulid' => $result['payment']->ulid,
                'checkout'     => $result['checkout'],
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'error'   => $e->getMessage(),
            ], 422);
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
B  ERR-01  ...ParentFeePaymentController.php:63  initiate — raw exception message (Throwable) returned to the user
$ sed -n '41,67p' Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php   (quoted above — confirmed verbatim)
```

### F2 — Transactions and audit

#### PFPC-03 · H · TXN-01 — the signature-failure branch writes 3+ tables with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside one `DB::transaction`* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:111-133`, method `callback()` |
| **Root cause** | When signature verification fails, the code calls `$this->paymentService->markFailed(...)` then `activityLog(...)` with NO `DB::transaction`. `markFailed()` alone writes `ptm_payment_payments` (status update), `ptm_payment_audit_logs` (AuditService), and fires `PaymentFailed` → `PaymentFailedListener` → `FeeInvoice::recordPaymentFailure()` which writes `fee_transactions` (a Failed row, with `collected_by` resolved). Then the controller writes `sys_activity_logs`. Four table writes, no transaction: a failure halfway leaves the Payment failed but no failed fee transaction, or audit rows lost. |
| **Consequence** | A payment that fails signature verification can be recorded as failed on the payment row while its failed `fee_transactions` row is missing (or vice-versa), corrupting the fee ledger for that order. |
| **Reproduce** | Static only — induce an exception inside `recordPaymentFailure` (e.g. `collected_by` resolution fails) after `markFailed` has updated the payment; the payment row is failed but no fee transaction exists. |
| **Fix approach** | Wrap the `markFailed` + activityLog failure branch in a `DB::transaction` closure (the success path already has one). |
| **Plan item** | PFPC-03 in `02-fix-plan.md` §3 |

```php
// ParentFeePaymentController.php:111-133 — CURRENT (signature-failure branch)
        if (! $verified) {
            $this->paymentService->markFailed($payment, 'Signature verification failed', [
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            ]);

            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Fee payment failed: signature verification failed',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'reason' => 'Signature verification failed',
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Payment signature verification failed.',
            ], 422);
        }
```

**Evidence**
```
$ grep -n "markFailed\|activityLog\|DB::transaction" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
112:            $this->paymentService->markFailed($payment, 'Signature verification failed', [
117:            activityLog(auth()->user(), 'PaymentFailed', [
165:        DB::transaction(function () use ($payment, $invoice, $request): void {
```

#### PFPC-04 · M · TXN-04 — audit rows are written outside the transaction that recorded their business write

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:191` (success `'Paid'` log after the transaction at 165-187); failure logs at 117, 136, 151 (no enclosing transaction — parent of PFPC-03) |
| **Root cause** | In `callback()` the `activityLog(auth()->user(), 'Paid', ...)` call sits after the `DB::transaction(...)` has committed (line 191 after 165-187). In `initiate()` the `'PaymentInitiated'` log at line 44 runs after `PaymentService::initiate()` has committed its own transaction. A failure writing the audit row after commit yields a 500 on a request whose business write already succeeded — the app shows an error and the client may retry, but the payment is already success. |
| **Consequence** | If the audit insert fails after the paid write committed, the parent sees a network/500 error for a payment that actually succeeded; no `Paid` audit row is stored. |
| **Reproduce** | Static only — `sys_activity_logs` insert fails (e.g. a DB glitch) right after the transaction commits. |
| **Fix approach** | Move the success `activityLog('Paid')` inside the transaction, after `markSuccess` + `recordGatewayPayment` (the write it describes). The failure-branch audit rows move with PFPC-03. |
| **Plan item** | PFPC-04 in `02-fix-plan.md` §3 |

```php
// ParentFeePaymentController.php:189-202 — CURRENT (success tail of callback)
        $invoice->refresh();

        activityLog(auth()->user(), 'Paid', [
            'message' => 'Paid invoice',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => request()->route()?->getName(),
            ],
            'invoice_id' => $invoice->id,
            'amount' => $payment->amount ?? null,
            'payment_reference' => $request->input('razorpay_payment_id'),
        ]);
```

**Evidence**
```
$ grep -n "activityLog\|DB::transaction" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
44:            activityLog(auth()->user(), 'PaymentInitiated', [
117:            activityLog(auth()->user(), 'PaymentFailed', [
136:            activityLog(auth()->user(), 'PaymentFailed', [
151:            activityLog(auth()->user(), 'PaymentFailed', [
165:        DB::transaction(function () use ($payment, $invoice, $request): void {
191:        activityLog(auth()->user(), 'Paid', [
```

#### PFPC-05 · H · TXN-03 — the Razorpay order is created (external HTTP) inside the DB transaction

| Field | Value |
|---|---|
| **Rule** | TXN-03 (B → H: the side effect is an order that expires unpaid, no money moves, primary harm is an orphan order) — *no irreversible side effect inside a transaction: HTTP calls after commit* |
| **Where** | `Modules/Payment/app/Services/PaymentService.php:35-103` (`initiate`, `DB::transaction` closure calls `$this->gatewayManager->resolve()->initiate()` at line 59) |
| **Root cause** | `PaymentService::initiate()` opens `DB::transaction`, creates the local `Payment` row, then calls **Razorpay's HTTP API** (`$driver->initiate(new PaymentData(...))`) to create the gateway order WHILE the transaction is open, then updates the payment with `gateway_order_id` and commits. If anything after the HTTP call fails (the `Payment::update`, the audit write, the offline branch), the transaction rolls back the local rows but the Razorpay order already exists — an orphan order paid by nobody. The parent portal calls this exact method (controller line 42). |
| **Consequence** | A transient DB failure after the gateway call leaves a live Razorpay order with no local payment; a parent who retries pays a second order, and the orphan stays open on the merchant dashboard. |
| **Reproduce** | Static only — simulate a failure in `$payment->update([...])` (line 70) after the HTTP call; DB rolls back, Razorpay order persists. |
| **Fix approach** | Create the gateway order before the transaction (or after commit with `DB::afterCommit`) and only then write the local payment row; or restructure so the HTTP call is the last thing after the transaction. Keep this in `PaymentService` (owned by this report). |
| **Plan item** | PFPC-05 in `02-fix-plan.md` §2 (⚠ SHARED — modifies `PaymentService` which other modules call) |

```php
// PaymentService.php:54-68 — CURRENT (inside DB::transaction)
            $driver = $this->gatewayManager->resolve($gatewayCode);

            // Build PaymentData directly from the $payable already in scope —
            // avoids a morphTo() DB reload which fails for non-DB-backed payables.
            $customer = $payable->getPayableCustomer();
            $checkout = $driver->initiate(new PaymentData(
                ulid: (string) $payment->ulid,
                amount: $payment->amount,
                currency: $payment->currency,
                label: $payable->getPayableLabel(),
                customerName: $customer['name'],
                customerEmail: $customer['email'],
                customerPhone: $customer['phone'],
                metadata: $payment->metadata ?? [],
            ));
```

**Evidence**
```
$ sed -n '35,73p' Modules/Payment/app/Services/PaymentService.php
35:        return DB::transaction(function () use ($payable, $gatewayCode, $userId, $offlineData) {
...
59:            $checkout = $driver->initiate(new PaymentData(
```

#### PFPC-11 · M · TXN-04 (audit) — initiate() drops the actor: `Payment.created_by` / `initiated_by` are NULL in the parent flow

| Field | Value |
|---|---|
| **Rule** | TXN-04 / AUTH-06 (M) — audit trail completeness; the actor who initiated a write must be recorded |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:42` and `Modules/Payment/app/Services/PaymentService.php:40-52` |
| **Root cause** | The controller calls `$this->paymentService->initiate($invoice, 'razorpay')` without the `$userId` argument, so the service's defaults apply: `'created_by' => $userId` and `'initiated_by' => $userId` are both `null` (PaymentService.php:50-51). The DDL allows NULL (`initiated_by INT UNSIGNED NULL`), so the row inserts, but the payment record loses who opened it, while the *audit* log (`activityLog(auth()->user(), ...)`) has the user. The two records disagree about the actor. |
| **Consequence** | The payments screen cannot answer "which parent initiated this payment?" from the payment row — a support/audit gap on a money flow. |
| **Reproduce** | Pay an invoice; inspect `ptm_payment_payments.initiated_by` — it is NULL even though an authenticated parent exists. |
| **Fix approach** | Pass `auth()->id()` as the `$userId` argument in the controller's `initiate()` call (the service already accepts it). |
| **Plan item** | PFPC-11 in `02-fix-plan.md` §3 |

```php
// ParentFeePaymentController.php:42 — CURRENT
            $result = $this->paymentService->initiate($invoice, 'razorpay');
```

**Evidence**
```
$ sed -n '40,52p' Modules/Payment/app/Services/PaymentService.php
            $payment = Payment::create([
                'ulid'         => (string) Str::ulid(),
                'payable_type' => get_class($payable),
                'payable_id'   => $payable->getKey(),
                'gateway_id'   => $gateway->id,
                'amount'       => $payable->getPayableAmount(),
                'currency'     => 'INR',
                'status'       => Payment::STATUS_INITIATED,
                'metadata'     => $payable->getPayableMetadata(),
                'is_active'    => true,
                'created_by'   => $userId,
                'initiated_by' => $userId,
            ]);
$ sed -n '33p' Modules/Payment/app/Services/PaymentService.php
33:    public function initiate(Payable $payable, string $gatewayCode, ?int $userId = null, array $offlineData = []): array
```
Live check on the test tenant confirms the columns are NULLable (`initiated_by INT UNSIGNED NULL` in `Payment_Module_Tables.sql:189`).

### F3 — Authorization

clean — both routes sit behind `auth` + `verified` + `ParentPortalMiddleware` (the same shape every sibling ParentPortal report records), and both methods re-scope to the child: `resolveChild($request)` (line 33 / 83) then `abort_if($invoice->studentAssignment?->student_id !== $child->id, 403)` (36-39 / 85-88). The callback additionally binds the payment ULID to the invoice (`abort_if($payment->payable_type !== FeeInvoice::class || $payment->payable_id !== $invoice->getKey(), 403)`, lines 93-96) — a ULID substitution guard — and verifies the HMAC signature before any write (F11). There is no `Gate::authorize` and no permission key, matching the module's deliberate "authorize by user_type" convention, so AUTH-05/AUTH-06 are clean. Proved by `grep -n "Gate::\|authorize\|can:" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php` → no output.

### F4 — Validation and input

#### PFPC-06 · M · VAL-02 — `callback()` validates inline instead of using a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `validate()` only for a one-field AJAX toggle* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:76-81`, method `callback()` |
| **Root cause** | The method calls `$request->validate([...])` with four required string fields (4 fields, not a one-field toggle). The Payment module already ships `Modules/Payment/app/Http/Requests/PaymentCallbackRequest.php`, but its `authorize()` checks `tenant.payment.payment.create` — a permission a parent can never hold — so it is unusable here and the parent controller re-implements the rules inline. |
| **Consequence** | Duplicated validation rules that can drift, and no single place that types the callback payload. |
| **Reproduce** | Static only. |
| **Fix approach** | Create `Modules/ParentPortal/app/Http/Requests/ParentPaymentCallbackRequest.php` (authorize: true, since route middleware + the controller's own checks gate it) with the same four rules, and type-hint it in `callback()`. |
| **Plan item** | PFPC-06 in `02-fix-plan.md` §5 |

```php
// ParentFeePaymentController.php:76-81 — CURRENT
        $request->validate([
            'payment_ulid'        => ['required', 'string'],
            'razorpay_payment_id' => ['required', 'string'],
            'razorpay_order_id'   => ['required', 'string'],
            'razorpay_signature'  => ['required', 'string'],
        ]);
```

**Evidence**
```
$ grep -n "validate" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
76:        $request->validate([
```
(`Modules/Payment/app/Http/Requests/PaymentCallbackRequest.php:13` authorizes `tenant.payment.payment.create` — a backend permission, not a parent one.)

#### PFPC-07 · M · VAL-05 — `initiate()` has no invoice-state guard: a paid or cancelled invoice can be initiated

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M) — *write paths with no validation at all are M*; combined with F13 Q1 (wrong-data overwrite) |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:31-40`, method `initiate()` |
| **Root cause** | `initiate()` checks only the child-ownership `abort_if`, then calls `paymentService->initiate()` with no check on the invoice's `status`. For an already-paid invoice `getPayableAmount()` returns `0` → a ₹0 Razorpay order is created; for a cancelled invoice, a real order can be created and the callback later throws `DomainException` ("Cannot record payment on a cancelled invoice.") from `FeeInvoiceService::recordPayment()` inside the transaction — a 500 after the gateway took the money. The success path's `isPaid()` check (line 98) only exists in `callback()`, too late to stop the order. |
| **Consequence** | A parent can open a payment order against a cancelled or already-paid invoice; in the cancelled case the gateway charges the card and the app then refuses the credit. |
| **Reproduce** | Open the callback page for a cancelled invoice with balance > 0 and initiate — an order is created. |
| **Fix approach** | In `initiate()`, before creating the order, `abort_if($invoice->isPaid() || $invoice->status === FeeInvoice::STATUS_CANCELLED, 422, 'This invoice cannot be paid online.')`. |
| **Plan item** | PFPC-07 in `02-fix-plan.md` §5 |

```php
// ParentFeePaymentController.php:31-40 — CURRENT
    public function initiate(Request $request, FeeInvoice $invoice): JsonResponse
    {
        $child = $this->context->resolveChild($request);

        // Parents may only pay their active child's invoices
        abort_if(
            $invoice->studentAssignment?->student_id !== $child->id,
            403
        );

        try {
```

**Evidence**
```
$ sed -n '31,40p' Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php   (quoted above)
$ grep -n "STATUS_CANCELLED\|isPaid" Modules/StudentFee/app/Models/FeeInvoice.php
203:    public function isPaid(): bool
257:    public function cancel(int $userId, ?string $reason = null): void
```

### F5 — Routes

clean — both state-changing routes are POST (RTE-01), both point at existing methods (RTE-02), both public methods are routed (RTE-03), both are reads-only-GET for lookups (RTE-04: n/a), both sit in the tenant + auth middleware stack (RTE-05), no `Route::resource` prefix collision (RTE-06: n/a). Proved by the §4 route:list export and `grep -nE 'public function [a-zA-Z_]+'` → only `initiate`/`callback`, both routed.

### F6 — Controller shape

#### PFPC-08 · M · CTL-05 — the same 4-item `context` array is copy-pasted five times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload repeated* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:46, 119, 138, 153, 193` — the `'context' => ['student_id' => ..., 'student_name' => ..., 'module' => 'ParentPortal', 'route' => request()->route()?->getName()]` literal appears five times |
| **Root cause** | The same 4-item array (with the lazy `student_name` resolution `$child?->user?->name ?? $child?->full_name ?? null`) is spelled out five times. Any change (add a field, change the student name resolution) must be made in five places or the audit logs drift. |
| **Consequence** | Audit log content will drift on the next enhancement; maintenance cost on a money flow. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract a private helper `feeLogContext(Student $child): array` returning the 4-item array, and call it in all five places. |
| **Plan item** | PFPC-08 in `02-fix-plan.md` §5 |

```php
// ParentFeePaymentController.php:45-51 — FIRST of the five identical literals (CURRENT)
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
M  CTL-05   ...:46  - — identical 4-item array literal repeated 5× (lines 46,119,138,153,193)
```

#### PFPC-09 · M · CTL-02 — `callback()` is 136 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method over 80 lines → extract* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:74-209`, method `callback()` |
| **Root cause** | The whole payment-confirmation flow (validate, resolve child, ownership, ULID mapping, isPaid, signature verify, failure branches, order/amount mismatch branches, the success transaction, refresh, audit, JSON) is one 136-line method. |
| **Consequence** | Hard to read and test; the failure branches (PFPC-03) are easy to miss when wading through it. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract the two failure branches (signature failure, order/amount mismatch) into private helpers or a FormRequest-driven flow; keep the success transaction inline. |
| **Plan item** | PFPC-09 in `02-fix-plan.md` §5 |

```php
// ParentFeePaymentController.php:74-81 — CURRENT (callback() opens)
    public function callback(Request $request, FeeInvoice $invoice): JsonResponse
    {
        $request->validate([
            'payment_ulid'        => ['required', 'string'],
            'razorpay_payment_id' => ['required', 'string'],
            'razorpay_order_id'   => ['required', 'string'],
            'razorpay_signature'  => ['required', 'string'],
        ]);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
M  CTL-02  ...:74  callback — callback() is 136 lines
```

#### PFPC-10 · L · CTL-08 — `request()` helper used instead of the injected `$request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:50, 123, 142, 157, 197` — `request()->route()?->getName()` inside the copied context arrays |
| **Root cause** | Both methods already receive `Request $request`; the audit context calls the global helper instead. Harmless today, but inconsistent with the rest of the module. |
| **Consequence** | Style inconsistency; the helper reads a different (equivalent) request object than the typed one. |
| **Reproduce** | Static only. |
| **Fix approach** | Use `$request->route()?->getName()` inside the extracted `feeLogContext()` helper (takes `$request`). Folded into PFPC-08. |
| **Plan item** | folded into PFPC-08 in `02-fix-plan.md` §5 |

```php
// ParentFeePaymentController.php:50 — CURRENT (one of five occurrences)
                    'route' => request()->route()?->getName(),
```

**Evidence**
```
$ grep -n "request()" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
50:                    'route' => request()->route()?->getName(),
123:                    'route' => request()->route()?->getName(),
142:                    'route' => request()->route()?->getName(),
157:                    'route' => request()->route()?->getName(),
197:                'route' => request()->route()?->getName(),
```

### F7 — Models

#### PFPC-12 · M · MDL-02 — `Payment::$casts['amount'] = 'float'` for a DECIMAL(12,2) money column

| Field | Value |
|---|---|
| **Rule** | MDL-02 (M) — *casts for every decimal column: use `decimal:2`, not `float`, for money* |
| **Where** | `Modules/Payment/app/Models/Payment.php:40` (`'amount' => 'float'`), and its consequence at `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:150` (`(float) $payment->amount !== (float) $invoice->getBalanceAmount()`) |
| **Root cause** | The DDL declares `amount DECIMAL(12,2) NOT NULL`; the model casts it to `float`. The callback then compares two floats with `!==` to decide whether the paid amount matches the invoice balance. Float representation of decimal money is inexact (0.1 + 0.2 ≠ 0.3), so a two-decimal amount that the DB stores exactly can compare unequal after float conversion; the same pattern is in `RazorpayGateway::initiate()` (`(int) ($data->amount * 100)` paise conversion). |
| **Consequence** | A legitimate payment can be rejected with "Paid amount does not match invoice balance" (422) even though the amounts are equal in the DB — a support call on a money flow. |
| **Reproduce** | Static only (precision); e.g. amounts with fractional paise rounding can trip the `!==`. |
| **Fix approach** | Cast money columns as `decimal:2` on `Payment` (and `PaymentRefund`), and compare in integer paise (`bccomp` or int cents) instead of float `!==`. |
| **Plan item** | PFPC-12 in `02-fix-plan.md` §5 |

```php
// Payment.php:39-44 — CURRENT casts
    protected $casts = [
        'amount'    => 'float',
        'metadata'  => 'array',
        'paid_at'   => 'datetime',
        'is_active' => 'boolean',
    ];
```

**Evidence**
```
$ sed -n '39,44p' Modules/Payment/app/Models/Payment.php   (quoted above)
$ sed -n '150p' Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
150:        if ((float) $payment->amount !== (float) $invoice->getBalanceAmount()) {
$ grep -n "amount.*DECIMAL\|DECIMAL(12,2)" /home/tarun-chauhan/Desktop/Apps/primeworkspace/pgdatabase/NEW/Payment_Module_Tables.sql
188:    `amount` DECIMAL(12,2) NOT NULL,
```

Other model checks (clean, with evidence):
- `Payment`, `PaymentGateway`, `PaymentAuditLog`, `PaymentRefund`, `PaymentWebhook`, `OfflinePaymentRecord` all have `$fillable` declared and no `$guarded = []` (MDL-01 clean).
- `PaymentGateway::$casts['credentials'] = 'encrypted:array'` — credentials encrypted at rest (SEC-01-ish, good).
- `$table` names all exist in the DDL (`ptm_payment_payments`, `ptm_payment_gateways`, `ptm_payment_audit_logs`, … — `Payment_Module_Tables.sql`) → MDL-07 clean.
- `SoftDeletes` present and the DDL has `deleted_at` on every payment model → MDL-03/soft-deletes clean.
- `PaymentAuditLog` has `$timestamps = false` **with** a `created_at` cast — matches the §4 catalogue rule (clean).
- `PaymentAuditLog` is append-only by design (comment line 19).

### F8 — Services and jobs

#### PFPC-13 · M · SVC-04 — duplicate implementations of "credit a gateway payment to a fee invoice" (DECISION item)

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; duplicate implementations that disagree are a bug source* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:175-186` (calls `markSuccess` which fires the event AND calls `recordGatewayPayment`), `Modules/Payment/app/Listeners/PaymentSucceededListener.php:43-45`, `Modules/StudentFee/app/Models/FeeInvoice.php:349-389` (`recordPaymentSuccess`), `Modules/StudentFee/app/Services/FeeInvoiceService.php:154-202` (`recordGatewayPayment`) |
| **Root cause** | The success path does the credit twice, through two implementations: (1) `markSuccess()` fires `PaymentSucceeded` synchronously → `PaymentSucceededListener` → `FeeInvoice::recordPaymentSuccess()` writes `fee_transactions` + `fee_receipts` + updates `paid_amount`; (2) the controller then calls `feeInvoiceService->recordGatewayPayment()` which is idempotent-by-`payment_reference` and returns early because the event listener already wrote the row. It stays single today **only** because the event is synchronous and both paths use the same `payment_reference` (the Razorpay payment id). If the listener were ever queued, or a caller only used one path, behaviour changes. |
| **Consequence** | Two code paths decide "how is a successful gateway fee payment credited"; today they agree by luck of the unique index, tomorrow they may not. |
| **Reproduce** | Static only — trace `PaymentSucceeded` → listener → `recordPaymentSuccess`, then `recordGatewayPayment`'s existing-check (`FeeInvoiceService.php:159-165`). |
| **Fix approach** | DECISION: (a) keep ONLY the event-listener path (`recordPaymentSuccess`) and delete the `recordGatewayPayment` call from the controller (the listener is only registered once — verify with `grep 'PaymentSucceeded::class' Modules/Payment/app/Providers/EventServiceProvider.php`), or (b) keep ONLY the direct service call and make the listener audit-only. Both must agree about `payment_reference` semantics. |
| **Plan item** | PFPC-13 in `02-fix-plan.md` §9 (DECISION, ⚠ SHARED — touches `FeeInvoice` owned by the ParentFeeController report) |

```php
// ParentFeePaymentController.php:175-186 — CURRENT (both credit paths in one transaction)
            $this->paymentService->markSuccess($payment, [
                'payment_id' => $request->input('razorpay_payment_id'),
                'signature'  => $request->input('razorpay_signature'),
            ]);

            // Creates FeeTransaction + receipt + audit log; idempotent by gateway reference.
            $this->feeInvoiceService->recordGatewayPayment(
                invoice: $invoice,
                paymentReference: $request->input('razorpay_payment_id'),
                amount: (float) $payment->amount,
                remarks: 'Online · Razorpay Order: ' . $request->input('razorpay_order_id'),
            );
```

**Evidence**
```
$ sed -n '43,45p' Modules/Payment/app/Listeners/PaymentSucceededListener.php
43:        if ($payable && method_exists($payable, 'recordPaymentSuccess')) {
44:            $payable->recordPaymentSuccess($payment);
45:        }
$ sed -n '34,35p' Modules/Payment/app/Providers/EventServiceProvider.php
34:        PaymentSucceeded::class => [
35:            PaymentSucceededListener::class,
```

Other service checks (clean): `PaymentService`, `GatewayManager`, `AuditService`, `RazorpayGateway`, `BaseGateway` contain no `request()`, `session()`, `redirect()`, `response()`, `back()` (SVC-01 clean — the gateway and services are HTTP-clean apart from the deliberate outbound API call flagged in PFPC-05); all dependencies arrive by constructor (SVC-02 clean); no writes on read paths (`getByUlid`, `getTimeline`, `resolve` are read-only — SVC-03 clean); `resolve()` is a small factory, the one `new $driverClass()` is its job (not a CTL-06 violation). `RazorpayGateway::verify()` uses `hash_equals` (constant-time) and `hash_hmac('sha256', order.'|'.payment, secret)` — correct per Razorpay docs.

### F9 — Queries and performance

clean — no query inside a loop; the only lookups are single-row: `PaymentGateway::where('code', $gatewayCode)->where('is_active', true)->firstOrFail()` (PaymentService.php:36-38), `Payment::where('ulid', $ulid)->firstOrFail()` (PaymentService.php:180), the two `lockForUpdate()->find()` re-reads inside the callback transaction (lines 166-167 — correct locking, TXN-06-satisfying), and `FeeTransaction::where(...)->first()` in `recordGatewayPayment` (idempotency check, FeeInvoiceService.php:159-161). No pagination is needed (all single-record). Proved by reading the F8/scope files; the scanner produced no QRY rows for in-scope files.

### F10 — Views

clean — this controller renders no views; both methods return `JsonResponse`. The parent portal fees pages are rendered by `ParentFeeController` (owned by the ParentFeeController report). No Blade in scope.

### F11 — Security and tenancy

clean — `env()` appears only inside `config/` (grep of all in-scope files: only a comment in `GatewayManager.php:49` mentions `env()`; no actual call — SEC-01 clean). No request bodies or payment data logged (the failure `reason` strings are fixed literals; SEC-04 clean). No hard-coded ids or `?? 1` fallbacks (SEC-03 clean). No personal data over-exposed: the JSON responses return only `success`, `payment_ulid`, `checkout`, `new_balance`, `new_status` (SEC-02 clean). Gateway credentials are stored encrypted (`credentials => 'encrypted:array'`) and read through `config('services.razorpay')` (SEC-05/TEN clean). Tenancy: the routes sit in the tenant middleware stack and all models are tenant-scoped tables. Webhook signature verification is performed by the gateway (`verifyWebhookSignature`, `handleWebhook`) for the *server-to-server* webhook — out of this controller's path (§8). The parent-app `callback` performs its own HMAC verification before any state change — the F3/F11 brief's "callback must not trust client data" is satisfied: the credited amount is `$payment->amount` (from DB), the ULID must map to the invoice (line 93-96), the order id must match the stored `gateway_order_id` (line 135), and the signature is verified against the secret (line 105-109).

### F12 — Style

#### PFPC-14 · L · STY-01 — `GatewayManager` and `BaseGateway` lack `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files; mandatory for new files, on touch for old* |
| **Where** | `Modules/Payment/app/Services/GatewayManager.php:1-3`, `Modules/Payment/app/Gateways/BaseGateway.php:1-3` |
| **Root cause** | Both files open with `<?php` + blank + `namespace` with no strict_types declaration. (All other in-scope files — controller, services, models, gateway, DTO — already have it.) |
| **Consequence** | Inconsistent scalar typing; `GatewayManager::resolve()` receives mixed credentials without strict checks. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening `<?php` in both files. |
| **Plan item** | PFPC-14 in `02-fix-plan.md` §8 |

```php
// GatewayManager.php:1-3 — CURRENT
<?php

namespace Modules\Payment\Services;
```

**Evidence**
```
$ head -3 Modules/Payment/app/Services/GatewayManager.php
<?php

namespace Modules\Payment\Services;
$ head -3 Modules/Payment/app/Gateways/BaseGateway.php
<?php

namespace Modules\Payment\Gateways;
```

Other F12 (clean) — the controller, `PaymentService`, `AuditService`, `RazorpayGateway`, `Payment` model all carry `declare(strict_types=1)`; imports are sorted and single per class; comments are English without emoji markers in the in-scope files (the emoji comments the scanner found are all in `ParentContextService` / `FeeInvoice` / `FeeInvoiceService` — linked classes, §7).

### F13 — Deep read (answers for every mutating method)

Mutating methods in this flow: `ParentFeePaymentController::initiate`, `ParentFeePaymentController::callback`, `PaymentService::initiate`, `PaymentService::markSuccess` (inside callback tx), `PaymentService::markFailed` (signature-failure branch), `FeeInvoiceService::recordGatewayPayment` (linked, invoked from callback).

| # | Question | initiate | callback (success) | callback (failure) | markSuccess | markFailed |
|---|---|---|---|---|---|---|
| 1 | Can a write overwrite data it should not? | ok — creates a new Payment each time | ok — `isPaid()` + pending-status guard + unique payment_reference | **PFPC-15** — can flip an already-SUCCESS payment to FAILED (no status guard) | ok — only sets success fields | **PFPC-15** |
| 2 | Anything deleted before replacement stored? | ok — no deletes | ok — no deletes | ok | ok | ok |
| 3 | Duplicate implementations of one operation? | ok | **PFPC-13** (listener + recordGatewayPayment) | ok | n/a | n/a |
| 4 | Soft-delete × unique index trap? | ok | ok — unique index is soft-delete-aware (`uq_fee_transactions_payment_reference_live`) | ok | ok | ok |
| 5 | Race? | ok — no check-then-act (each initiate makes a new order; any old pending order is guarded by status at callback) | ok — `lockForUpdate()` on payment + invoice, status re-check inside the lock (TXN-06 satisfied) | ok (no check-then-act in the failure branch) | ok (guarded by caller's lock) | ok |
| 6 | Authorization hole? | ok — child ownership check before create | ok — child ownership + ULID mapping + HMAC | ok — same checks as success | ok | ok |
| 7 | Message that lies? | **PFPC-01** — raw `$e->getMessage()` can contradict what actually happened | ok — fixed messages | ok — fixed message | ok | ok |
| 8 | Dead feature? | ok | ok — idempotency check is exercised by retries/webhook | ok | ok | ok |

#### PFPC-15 · H · TXN-06 / F13-Q1 — `markFailed` can flip an already-SUCCESS payment to FAILED

| Field | Value |
|---|---|
| **Rule** | F13 Q1 / TXN-06 (H) — *a status-transition write must be guarded by the current state* (the success path's guard is the `abort_if($payment->status !== PENDING)` at line 169-173; the failure path has no equivalent) |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:111-133` (calls `markFailed` without checking `$payment->status`), `Modules/Payment/app/Services/PaymentService.php:136-154` (`markFailed` unconditionally sets `STATUS_FAILED`) |
| **Root cause** | The signature-failure branch calls `markFailed($payment, ...)` with no status check. If a second, forged or duplicated callback arrives for a payment that already reached SUCCESS (e.g. the app retries the callback after the first one committed, or an attacker replays the request with a bad signature), `markFailed` overwrites the row to `FAILED`, fires `PaymentFailed`, and `FeeInvoice::recordPaymentFailure()` writes a failed fee transaction — while the money was actually captured and the invoice is already credited. The webhook path in `RazorpayGateway::handlePaymentCaptured/Failed` deliberately only acts when `$payment->status` is in `CAPTURABLE_STATUSES` (lines 210, 243) — the callback path forgot that guard. |
| **Consequence** | A retried/tampered callback marks a real, captured payment `FAILED`, records a failed fee transaction, and leaves the paid invoice contradicting the failed payment row. |
| **Reproduce** | Pay an invoice (payment becomes SUCCESS), then POST the same callback payload again with a tampered `razorpay_signature` — `markFailed` flips the SUCCESS row to FAILED. |
| **Fix approach** | In `callback()`, before `markFailed`, `abort_unless(in_array($payment->status, [Payment::STATUS_PENDING, Payment::STATUS_INITIATED], true), 422, 'Payment is already finalised.')` — mirroring `RazorpayGateway::CAPTURABLE_STATUSES`. |
| **Plan item** | PFPC-15 in `02-fix-plan.md` §3 |

```php
// ParentFeePaymentController.php:105-116 — CURRENT (unguarded branch)
        $verified = $driver->verify([
            'razorpay_order_id'   => $request->input('razorpay_order_id'),
            'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            'razorpay_signature'  => $request->input('razorpay_signature'),
        ]);

        if (! $verified) {
            $this->paymentService->markFailed($payment, 'Signature verification failed', [
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            ]);
```

**Evidence**
```
$ sed -n '136,154p' Modules/Payment/app/Services/PaymentService.php
    public function markFailed(Payment $payment, string $reason, array $payload = []): void
    {
        $previous = $payment->status;

        $payment->update([
            'status'        => Payment::STATUS_FAILED,
            'failure_reason'=> $reason,
        ]);
$ sed -n '210p' Modules/Payment/app/Gateways/RazorpayGateway.php
210:            if (! $payment || ! in_array($payment->status, self::CAPTURABLE_STATUSES, true)) {
$ sed -n '169,173p' Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php
169:            abort_if(
170:                $payment->status !== Payment::STATUS_PENDING,
171:                422,
172:                'Payment is not in pending state.'
173:            );
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | Same set siblings recorded: `resolveChild()` touches HTTP (`abort(redirect(...))`, line 104), `getOrCreateSession()` does 2 writes with no transaction (line 202) + check-then-act race (TXN-06), emoji comments (26, 32, 144) | SVC-01, TXN-01, TXN-06, STY-04 | tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/StudentFee/app/Models/FeeInvoice.php` | `recordPaymentSuccess()` (349-389) is one half of the duplicate credit (PFPC-13); `transactions()`/`fineTransactions()` lack return types (MDL-04 L); emoji comments (310, 316, 429, 450) | SVC-04, MDL-04, STY-04 | tarun/ParentPortal-done/ParentFeeController report |
| `Modules/StudentFee/app/Services/FeeInvoiceService.php` | `recordGatewayPayment()` (154-202) is the other half of the duplicate credit (PFPC-13); `recordPayment()` is 82 lines (CTL-02); `Log::error(..., ['error' => $e->getMessage()])` at 193 (ERR-05 — logs the message, not the exception); `resolvePayerUserId()` is dead (CTL-10); emoji comments | SVC-04, CTL-02, ERR-05, CTL-10, STY-04 | tarun/ParentPortal-done/ParentFeeController report |
| `Modules/Payment/app/Gateways/RazorpayGateway.php` webhook handlers (`handlePaymentCaptured`/`handlePaymentFailed`, 188-249) | Server-to-server webhook path uses `lockForUpdate()` + status guard correctly; `app(PaymentService::class)` mid-method (SVC-02 L) | SVC-02 | Payment module's own controller report (WebhookController / ProcessWebhookJob), not this one |
| AGENTS.md SEC-004/005 "webhook behind auth middleware", "gateway whitelist bypass" | Known issues of the **payment webhook route** (`Modules/Payment/routes/webhooks.php` + `WebhookController`), not the parent-app callback audited here | SEC | Payment module controllers audit |

## 8. Not covered, and why

- **The server-to-server Razorpay webhook** (`Modules/Payment/routes/webhooks.php`, `WebhookController`, `ProcessWebhookJob`, `VerifyWebhookSignature` middleware): out of this controller's reach (the parent-app callback is a different path). The brief's webhook question is answered only at the level of the classes this controller reaches (`RazorpayGateway::handleWebhook*`, listeners); the route + middleware + job belong to a Payment-module controller report.
- **`PaymentRefund`, `PaymentWebhook`, `OfflinePaymentRecord` models** were read for registry consistency but not audited line-for-line (they are reached by the refund/webhook flows, not by this controller's two methods; their parent controller owns them).
- **Live browser reproduction** — no browser/interactive run; all reproductions are static or DB-inspection only (D4: no tests, and the mobile checkout needs a real Razorpay sandbox).
- **`config/services.php` razorpay block** — read indirectly through `GatewayManager::resolveCredentials`; not audited because it is common config (central app glue).