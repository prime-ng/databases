# Fix Plan — ParentPortal / ParentFeePaymentController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the ParentDashboardController report |
| `Modules/StudentFee/app/Models/FeeInvoice.php` | owned by the ParentFeeController report |
| `Modules/StudentFee/app/Services/FeeInvoiceService.php` | owned by the ParentFeeController report |
| `Modules/Payment/app/Listeners/*.php`, `Events/*.php` | owned by this report, but changing the credit path is a DECISION (PFPC-13); otherwise leave untouched |
| `Modules/Payment/routes/*`, `Modules/Payment/app/Http/Controllers/*` | payment webhook route + controllers, not in this controller's scope |
| any migration | never edit an existing migration |

## 1. Blockers reachable today

- [x] **PFPC-01** · B · ERR-01 · `ParentFeePaymentController.php:41-67` — remove the controller `try/catch` that sends the raw exception text to the user (D1 + ERR-01).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:41-67`):
    ```php
        try {
            $result = $this->paymentService->initiate($invoice, 'razorpay');

            activityLog(auth()->user(), 'PaymentInitiated', [
                'message' => 'Initiated fee payment',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'amount' => $result['payment']->amount ?? null,
                'payment_ulid' => $result['payment']->ulid ?? null,
            ]);

            return response()->json([
                'success'      => true,
                'payment_ulid' => $result['payment']->ulid,
                'checkout'     => $result['checkout'],
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'error'   => $e->getMessage(),
            ], 422);
        }
    ```
  - **After:**
    ```php
        $result = $this->paymentService->initiate($invoice, 'razorpay');

        activityLog(auth()->user(), 'PaymentInitiated', [
            'message' => 'Initiated fee payment',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => request()->route()?->getName(),
            ],
            'invoice_id' => $invoice->id,
            'amount' => $result['payment']->amount ?? null,
            'payment_ulid' => $result['payment']->ulid ?? null,
        ]);

        return response()->json([
            'success'      => true,
            'payment_ulid' => $result['payment']->ulid,
            'checkout'     => $result['checkout'],
        ]);
    ```
  - **Verify:** `grep -n "catch\|try {" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** no `try`/`catch` in the file (the `DB::transaction` closure at line 165 stays, but `try {`/`catch (\Throwable` are gone).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [x] **PFPC-15** · H · TXN-06 · `ParentFeePaymentController.php:111` — guard `markFailed` so it cannot flip an already-SUCCESS payment to FAILED.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:105-113`):
    ```php
        if (! $verified) {
            $this->paymentService->markFailed($payment, 'Signature verification failed', [
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            ]);
    ```
  - **After:**
    ```php
        if (! $verified) {
            abort_unless(
                in_array($payment->status, [Payment::STATUS_PENDING, Payment::STATUS_INITIATED], true),
                422,
                'Payment is already finalised.'
            );

            $this->paymentService->markFailed($payment, 'Signature verification failed', [
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            ]);
    ```
  - **Verify:** `grep -n "Payment is already finalised" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** the guard line exists before `markFailed` (line ~112).
  - **Effort:** S

## 3. Errors & transactions (F1/F2)

- [x] **PFPC-03** · H · TXN-01 · `ParentFeePaymentController.php:111-133` — wrap the signature-failure branch in a `DB::transaction` so the payment + audit + failed-fee-transaction writes are atomic.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:111-133`):
    ```php
        if (! $verified) {
            $this->paymentService->markFailed($payment, 'Signature verification failed', [
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            ]);

            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Fee payment failed: signature verification failed',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'reason' => 'Signature verification failed',
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Payment signature verification failed.',
            ], 422);
        }
    ```
  - **After:**
    ```php
        if (! $verified) {
            abort_unless(
                in_array($payment->status, [Payment::STATUS_PENDING, Payment::STATUS_INITIATED], true),
                422,
                'Payment is already finalised.'
            );

            DB::transaction(function () use ($payment, $invoice, $child, $request): void {
                $this->paymentService->markFailed($payment, 'Signature verification failed', [
                    'razorpay_order_id'   => $request->input('razorpay_order_id'),
                    'razorpay_payment_id' => $request->input('razorpay_payment_id'),
                ]);

                activityLog(auth()->user(), 'PaymentFailed', [
                    'message' => 'Fee payment failed: signature verification failed',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'invoice_id' => $invoice->id,
                    'reason' => 'Signature verification failed',
                ]);
            });

            return response()->json([
                'success' => false,
                'message' => 'Payment signature verification failed.',
            ], 422);
        }
    ```
  - **Verify:** `grep -n "DB::transaction" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** two `DB::transaction(` calls (the new failure branch at ~112 and the existing success branch at ~165).
  - **Effort:** S
  - **Note:** this item includes the PFPC-15 guard (same branch). If PFPC-15 is already applied, the fixer must NOT add the `abort_unless` twice — re-read the file and keep one copy.

- [x] **PFPC-04** · M · TXN-04 · `ParentFeePaymentController.php:189-202` — move the success `activityLog('Paid')` inside the success `DB::transaction`, after `recordGatewayPayment`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:165-208`):
    ```php
        DB::transaction(function () use ($payment, $invoice, $request): void {
            $payment = Payment::lockForUpdate()->find($payment->id);
            $invoice = FeeInvoice::lockForUpdate()->find($invoice->id);

            abort_if(
                $payment->status !== Payment::STATUS_PENDING,
                422,
                'Payment is not in pending state.'
            );

            $this->paymentService->markSuccess($payment, [
                'payment_id' => $request->input('razorpay_payment_id'),
                'signature'  => $request->input('razorpay_signature'),
            ]);

            // Creates FeeTransaction + receipt + audit log; idempotent by gateway reference.
            $this->feeInvoiceService->recordGatewayPayment(
                invoice: $invoice,
                paymentReference: $request->input('razorpay_payment_id'),
                amount: (float) $payment->amount,
                remarks: 'Online · Razorpay Order: ' . $request->input('razorpay_order_id'),
            );
        });

        $invoice->refresh();

        activityLog(auth()->user(), 'Paid', [
            'message' => 'Paid invoice',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => request()->route()?->getName(),
            ],
            'invoice_id' => $invoice->id,
            'amount' => $payment->amount ?? null,
            'payment_reference' => $request->input('razorpay_payment_id'),
        ]);

        return response()->json([
            'success'     => true,
            'new_balance' => $invoice->getBalanceAmount(),
            'new_status'  => $invoice->status,
        ]);
    ```
  - **After:**
    ```php
        DB::transaction(function () use ($payment, $invoice, $child, $request): void {
            $payment = Payment::lockForUpdate()->find($payment->id);
            $invoice = FeeInvoice::lockForUpdate()->find($invoice->id);

            abort_if(
                $payment->status !== Payment::STATUS_PENDING,
                422,
                'Payment is not in pending state.'
            );

            $this->paymentService->markSuccess($payment, [
                'payment_id' => $request->input('razorpay_payment_id'),
                'signature'  => $request->input('razorpay_signature'),
            ]);

            // Creates FeeTransaction + receipt + audit log; idempotent by gateway reference.
            $this->feeInvoiceService->recordGatewayPayment(
                invoice: $invoice,
                paymentReference: $request->input('razorpay_payment_id'),
                amount: (float) $payment->amount,
                remarks: 'Online · Razorpay Order: ' . $request->input('razorpay_order_id'),
            );

            activityLog(auth()->user(), 'Paid', [
                'message' => 'Paid invoice',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'amount' => $payment->amount ?? null,
                'payment_reference' => $request->input('razorpay_payment_id'),
            ]);
        });

        $invoice->refresh();

        return response()->json([
            'success'     => true,
            'new_balance' => $invoice->getBalanceAmount(),
            'new_status'  => $invoice->status,
        ]);
    ```
  - **Verify:** `grep -n "activityLog(auth()->user(), 'Paid'" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** the line number sits between the `recordGatewayPayment(` call and the transaction's closing `});`.
  - **Effort:** S
  - **Note:** this depends on PFPC-13's outcome for `recordGatewayPayment` (see §9). If the DECISION removes the `recordGatewayPayment` call, keep the `activityLog` inside the transaction regardless.

- [x] **PFPC-11** · M · TXN-04 (audit) · `ParentFeePaymentController.php:42` — pass the authenticated parent id into `PaymentService::initiate` so the payment row records who initiated it.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:42`):
    ```php
            $result = $this->paymentService->initiate($invoice, 'razorpay');
    ```
  - **After:**
    ```php
            $result = $this->paymentService->initiate($invoice, 'razorpay', auth()->id());
    ```
  - **Verify:** `grep -n "initiate(\$invoice" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** the call carries `'razorpay', auth()->id()`.
  - **Effort:** S
  - **Note:** `PaymentService::initiate` already accepts `?int $userId = null` (PaymentService.php:33), so no service change is needed.

## 4. Authorization (F3)

(none — both routes are gated by route middleware + the controller's own ownership/ULID/signature checks; clean per report §6 F3.)

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PFPC-06** · M · VAL-02 · `ParentFeePaymentController.php:76-81` — move the callback's inline validation into a new FormRequest.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`, new file `Modules/ParentPortal/app/Http/Requests/ParentPaymentCallbackRequest.php`
  - **Before** (`ParentFeePaymentController.php:74-83`):
    ```php
    public function callback(Request $request, FeeInvoice $invoice): JsonResponse
    {
        $request->validate([
            'payment_ulid'        => ['required', 'string'],
            'razorpay_payment_id' => ['required', 'string'],
            'razorpay_order_id'   => ['required', 'string'],
            'razorpay_signature'  => ['required', 'string'],
        ]);
    ```
  - **After:** (controller)
    ```php
    public function callback(ParentPaymentCallbackRequest $request, FeeInvoice $invoice): JsonResponse
    {
    ```
  - **After:** (new file `Modules/ParentPortal/app/Http/Requests/ParentPaymentCallbackRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;

    class ParentPaymentCallbackRequest extends FormRequest
    {
        public function authorize(): bool
        {
            // Route middleware (auth + verified + ParentPortalMiddleware) and the
            // controller's own ownership/ULID/signature checks gate this endpoint.
            return true;
        }

        public function rules(): array
        {
            return [
                'payment_ulid'        => ['required', 'string'],
                'razorpay_payment_id' => ['required', 'string'],
                'razorpay_order_id'   => ['required', 'string'],
                'razorpay_signature'  => ['required', 'string'],
            ];
        }
    }
    ```
  - **Verify:** `php -l Modules/ParentPortal/app/Http/Requests/ParentPaymentCallbackRequest.php && grep -n "ParentPaymentCallbackRequest" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** new file passes lint; controller method signature type-hints the FormRequest.
  - **Effort:** S

- [x] **PFPC-07** · M · VAL-05 · `ParentFeePaymentController.php:31-40` — reject paid/cancelled invoices before opening a Razorpay order.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:33-42`):
    ```php
        $child = $this->context->resolveChild($request);

        // Parents may only pay their active child's invoices
        abort_if(
            $invoice->studentAssignment?->student_id !== $child->id,
            403
        );

        try {
            $result = $this->paymentService->initiate($invoice, 'razorpay');
    ```
  - **After:**
    ```php
        $child = $this->context->resolveChild($request);

        // Parents may only pay their active child's invoices
        abort_if(
            $invoice->studentAssignment?->student_id !== $child->id,
            403
        );

        abort_if(
            $invoice->isPaid() || $invoice->status === FeeInvoice::STATUS_CANCELLED,
            422,
            'This invoice cannot be paid online.'
        );

        $result = $this->paymentService->initiate($invoice, 'razorpay');
    ```
  - **Verify:** `grep -n "cannot be paid online" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** the guard exists; `FeeInvoice` is already imported (line 15), `FeeInvoice::STATUS_CANCELLED` exists (FeeInvoice.php:71).
  - **Effort:** S
  - **Note:** this item overlaps PFPC-01's Before block (the `try {` line). Apply after PFPC-01 so the `try {` line is already gone; if not, keep the `try {` line and insert the `abort_if` between it and the service call.

- [x] **PFPC-08** · M · CTL-05 + PFPC-10 · L · CTL-08 · `ParentFeePaymentController.php` — extract the repeated 4-item context array into one private helper and use the injected `$request`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (five occurrences — representative, at `:45-51`):
    ```php
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
    ```
  - **After:** (add one private method to the class, and replace each of the five `'context' => [...]` literals with `'context' => $this->feeLogContext($child, $request),`):
    ```php
    /**
     * Shared audit context for payment activity logs.
     */
    private function feeLogContext(Student $child, Request $request): array
    {
        return [
            'student_id'   => $child->id,
            'student_name' => $child->user?->name ?? $child->full_name ?? null,
            'module'       => 'ParentPortal',
            'route'        => $request->route()?->getName(),
        ];
    }
    ```
  - **Verify:** `grep -c "feeLogContext" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** the helper declared once and called 5 times (6 matches total in grep -c).
  - **Effort:** M
  - **Note:** `Student` is not imported yet — add `use Modules\StudentProfile\Models\Student;` at the top of the controller (imports block after line 16). All five call sites must pass the injected `$request`.

- [x] **PFPC-09** · M · CTL-02 · `ParentFeePaymentController.php:74-209` — split `callback()` by extracting the order/amount mismatch branches into a private helper.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Before** (`ParentFeePaymentController.php:135-163` — the two mismatch branches inside `callback()`):
    ```php
        if ($payment->gateway_order_id !== $request->input('razorpay_order_id')) {
            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Fee payment failed: order ID mismatch',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'reason' => 'Returned order ID does not match the initiated payment.',
            ]);
            abort(422, 'Returned order ID does not match the initiated payment.');
        }

        if ((float) $payment->amount !== (float) $invoice->getBalanceAmount()) {
            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Fee payment failed: amount mismatch',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'reason' => 'Paid amount does not match invoice balance.',
            ]);
            abort(422, 'Paid amount does not match invoice balance.');
        }
    ```
  - **After:** (in `callback()`, replace the two blocks above with):
    ```php
        $mismatch = $this->gatewayMismatch($payment, $invoice, $child, $request);

        if ($mismatch !== null) {
            return $mismatch;
        }
    ```
    And add this private method to the class (after `callback()`, before the class's closing brace):
    ```php
    /**
     * Reject a gateway order id / amount mismatch with the same logs the old
     * inline branches wrote. Returns a 422 JsonResponse, or null when the
     * payment matches the invoice.
     */
    private function gatewayMismatch(
        Payment $payment,
        FeeInvoice $invoice,
        Student $child,
        Request $request,
    ): ?JsonResponse {
        if ($payment->gateway_order_id !== $request->input('razorpay_order_id')) {
            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Fee payment failed: order ID mismatch',
                'context' => [
                    'student_id' => $child->id,
                    'student_name' => $child->user?->name ?? $child->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'reason' => 'Returned order ID does not match the initiated payment.',
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Returned order ID does not match the initiated payment.',
            ], 422);
        }

        if ((int) round($payment->amount * 100) !== (int) round($invoice->getBalanceAmount() * 100)) {
            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Fee payment failed: amount mismatch',
                'context' => [
                    'student_id' => $child->id,
                    'student_name' => $child->user?->name ?? $child->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => $request->route()?->getName(),
                ],
                'invoice_id' => $invoice->id,
                'reason' => 'Paid amount does not match invoice balance.',
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Paid amount does not match invoice balance.',
            ], 422);
        }

        return null;
    }
    ```
  - **Verify:** `php -l Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php && grep -n "gatewayMismatch" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php`
  - **Expect:** lint passes; helper declared once and called once in `callback()`.
  - **Effort:** M
  - **Note:** this item depends on PFPC-12 (amount comparison in paise). If PFPC-12 is not ticked, keep the helper's amount line as `(float) $payment->amount !== (float) $invoice->getBalanceAmount()` to avoid changing behaviour. The signature-failure branch (lines 111-133) is left inline here — a separate change owned by PFPC-03. `Student` is not imported yet — add `use Modules\StudentProfile\Models\Student;` to the controller's imports (after line 16) when adding this helper.

- [x] **PFPC-12** · M · MDL-02 · `Payment.php:40` — cast money columns as `decimal:2` (and compare in integer paise).
  - **Touches:** `Modules/Payment/app/Models/Payment.php`, `Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php:150`, `Modules/Payment/app/Gateways/RazorpayGateway.php:49`
  - **Before** (`Payment.php:39-44`):
    ```php
    protected $casts = [
        'amount'    => 'float',
        'metadata'  => 'array',
        'paid_at'   => 'datetime',
        'is_active' => 'boolean',
    ];
    ```
  - **After:** (`Payment.php:39-44`):
    ```php
    protected $casts = [
        'amount'    => 'decimal:2',
        'metadata'  => 'array',
        'paid_at'   => 'datetime',
        'is_active' => 'boolean',
    ];
    ```
  - **Before** (`ParentFeePaymentController.php:150`):
    ```php
        if ((float) $payment->amount !== (float) $invoice->getBalanceAmount()) {
    ```
  - **After:** (`ParentFeePaymentController.php:150`):
    ```php
        if ((int) round($payment->amount * 100) !== (int) round($invoice->getBalanceAmount() * 100)) {
    ```
  - **Before** (`RazorpayGateway.php:49`):
    ```php
            'amount'          => (int) ($data->amount * 100), // paise
    ```
  - **After:** (`RazorpayGateway.php:49`):
    ```php
            'amount'          => (int) round($data->amount * 100), // paise
    ```
  - **Verify:** `grep -n "decimal:2" Modules/Payment/app/Models/Payment.php && grep -n "round(\$payment->amount" Modules/ParentPortal/app/Http/Controllers/ParentFeePaymentController.php && grep -n "round(\$data->amount" Modules/Payment/app/Gateways/RazorpayGateway.php`
  - **Expect:** all three lines changed; `(float)` money comparisons gone from the controller.
  - **Effort:** S
  - **Note:** ⚠ SHARED — `Payment.php` and `RazorpayGateway.php` are used by other Payment-module flows. `decimal:2` returns a string; the `(int) round($x * 100)` pattern converts to integer paise for comparison.

## 6. Queries & performance (F9)

(none — clean per report §6 F9.)

## 7. Views (F10)

(none — this controller renders no Blade.)

## 8. Style (F12) — one item per file

- [x] **PFPC-14** · L · STY-01 · `GatewayManager.php` and `BaseGateway.php` — add `declare(strict_types=1);` to both files that lack it.
  - **Touches:** `Modules/Payment/app/Services/GatewayManager.php`, `Modules/Payment/app/Gateways/BaseGateway.php`
  - **Before** (`GatewayManager.php:1-4`):
    ```php
    <?php

    namespace Modules\Payment\Services;
    ```
  - **After:** (`GatewayManager.php:1-5`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Services;
    ```
  - **Before** (`BaseGateway.php:1-3`):
    ```php
    <?php

    namespace Modules\Payment\Gateways;
    ```
  - **After:** (`BaseGateway.php:1-5`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\Payment\Gateways;
    ```
  - **Verify:** `head -3 Modules/Payment/app/Services/GatewayManager.php && head -3 Modules/Payment/app/Gateways/BaseGateway.php`
  - **Expect:** both files show `declare(strict_types=1);` on line 3.
  - **Effort:** S
  - **Note:** ⚠ SHARED — both files are Payment-module infrastructure used by other flows. This is a pure `declare` addition; run Pint on the two files after.

## 9. Deferred / decisions

- [x] **PFPC-13** · M · DECISION · SVC-04 — keep one implementation of "credit a successful gateway payment to a fee invoice".
  - **Why it is a decision:** the success path credits twice today: `PaymentSucceededListener` → `FeeInvoice::recordPaymentSuccess()` (models, owned by the ParentFeeController report) AND the controller's explicit `FeeInvoiceService::recordGatewayPayment()` call (services, owned by the ParentFeeController report). It stays single only because the event is synchronous and both write the same `payment_reference`.
  - (a) ⭐ keep BOTH, document why: run the event listener as the sole writer and DELETE the `recordGatewayPayment` call from the controller — minimal change, keeps the listener as the single ledger entry point for webhook + callback alike; requires confirming `PaymentSucceeded::class` is registered once (`Modules/Payment/app/Providers/EventServiceProvider.php:34`).
  - (b) keep the explicit `recordGatewayPayment` call and make the listener audit-only (a behaviour change to `PaymentSucceededListener`, which also serves the webhook path — bigger blast radius).
  - (c) leave as-is, record as accepted duplication.
  - ➜ Choice: (c) — accept the duplicate credit path 2026-10-22

- [x] **PFPC-05** · H · DECISION · TXN-03 — when to create the Razorpay order relative to the DB transaction in `PaymentService::initiate`.
  - **Why it is a decision:** moving the gateway HTTP call out of `DB::transaction` changes failure semantics for every PaymentService caller (parent portal, student portal, offline gateway, webhooks) — a shared class owned by this report but consumed module-wide. This is a behaviour change with blast radius.
  - (a) ⭐ create the order BEFORE the transaction, then write the local rows in the transaction — if the HTTP call fails, nothing local is written, so the parent retries safely; the DB insert failure after an order creation leaves an orphan order (Razorpay orders expire unpaid), which is the lesser failure.
  - (b) keep the order inside the transaction and accept the orphan-order risk (record as accepted; add a comment).
  - (c) use `DB::afterCommit()` to fire the order creation after the local write (requires re-arranging the payment row to a pending-without-order state first).
  - ➜ Choice: (b) — accept the gateway-order-inside-transaction risk 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PFPC-10 | Folded into the PFPC-08 item in §5 — the extracted `feeLogContext()` helper takes the injected `$request` and uses `$request->route()?->getName()` in all five call sites, replacing every `request()` helper use. There is no separate change. |