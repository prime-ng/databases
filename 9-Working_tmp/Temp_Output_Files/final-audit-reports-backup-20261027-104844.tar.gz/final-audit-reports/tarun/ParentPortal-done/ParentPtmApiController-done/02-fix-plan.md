# Fix Plan — ParentPortal / ParentPtmApiController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `database/migrations/tenant/2026_06_16_0943*.php` | tenant migrations — never edited (standing rule) |
| `Modules/Ptm/app/Models/{PtmEvent,PtmSlot,PtmSlotBooking,PtmBlockout}.php` | owned by the ParentPtmController (web) report — link, don't edit |
| `Modules/Ptm/app/Models/{PtmAssignment,PtmEventClassSection}.php` | Ptm family — owned by the ParentPtmController (web) report |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the ParentDashboardController report |
| `Modules/ParentPortal/app/Http/Requests/{Book,Cancel,Reschedule}ParentPtmRequest.php` | owned by the web ParentPtmController report — **used** here (PPTM-07) but never edited |
| `Modules/ParentPortal/routes/api.php` | shared route file — no route changes in this plan |
| `Modules/Notification/app/Models/Notification.php` | Notification module owns the model |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | module-wide gate — not this controller's |

## 1. Blockers reachable today

- [x] **PPTM-01** · B · ERR-01 · `ParentPtmApiController.php:180-182, 288-290` — stop sending raw exception text to the mobile client; catch only `\DomainException` and change the business throws to `DomainException`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:179-182` — book):
    ```php
            });
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    ```
  - **After:**
    ```php
            });
        } catch (\DomainException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    ```
  - **Before** (`ParentPtmApiController.php:288-290` — reschedule):
    ```php
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    ```
  - **After:**
    ```php
        } catch (\DomainException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    ```
  - **Also in the same two methods**, convert every business throw to `\DomainException` at lines 104, 107, 110, 114, 121, 128, 136, 144 (book) and 264, 265, 266, 267 (reschedule):
    - Before: `throw new \Exception('Slot is no longer available.');` (and the other business texts)
    - After: `throw new \DomainException('Slot is no longer available.');` (same text in each throw; only the class changes)
    - The notification catches inside `book()`/`cancel()` stay `catch (\Exception $e)` (they catch DB failures, not business rules) — PPTM-02 changes only their logging.
  - **Verify:** `grep -n "catch (\\\\Throwable\|throw new \\\\Exception" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** no `catch (\Throwable` and no `throw new \Exception` remains; only `catch (\DomainException` and `throw new \DomainException` in the business guards.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

- [x] **PPTM-03** · H · TXN-06 · `ParentPtmApiController.php:125-144` — serialise book()'s duplicate/overlap guards with locking re-reads inside the transaction so concurrent double-bookings surface as business messages, not raw SQL.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:125-144`):
    ```php
                $exists = PtmBooking::where('slot_id', $slot->id)
                    ->where('booked_by_user_id', auth()->id())
                    ->where('status', 'CONFIRMED')->exists();
                if ($exists) throw new \Exception('Already booked this slot.');

                $ptmEventId = $locked->assignment->ptm_event_id;

                $existing = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->where('ptm_event_id', $ptmEventId)
                    ->exists();
                if ($existing) throw new \Exception('You already have a booking for this PTM event.');

                $overlap = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->whereHas('slot', fn($q) => $q
                        ->where('slot_start', '<', $locked->slot_end)
                        ->where('slot_end', '>', $locked->slot_start))
                    ->exists();
                if ($overlap) throw new \Exception('Already have another booking at this time.');
    ```
  - **After:** (guards run with locking reads; the insert follows, then a locked post-insert re-check catches a concurrently committed row; `\DomainException` rolls the transaction back and is what PPTM-01's catch turns into a 422):
    ```php
                $exists = PtmBooking::where('slot_id', $slot->id)
                    ->where('booked_by_user_id', auth()->id())
                    ->where('status', 'CONFIRMED')->exists();
                if ($exists) throw new \DomainException('Already booked this slot.');

                $ptmEventId = $locked->assignment->ptm_event_id;

                $existing = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->where('ptm_event_id', $ptmEventId)
                    ->exists();
                if ($existing) throw new \DomainException('You already have a booking for this PTM event.');

                $overlap = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->whereHas('slot', fn ($q) => $q
                        ->where('slot_start', '<', $locked->slot_end)
                        ->where('slot_end', '>', $locked->slot_start))
                    ->exists();
                if ($overlap) throw new \DomainException('Already have another booking at this time.');
    ```
  - **After:** (lines 146-152 change so the created row is captured, then a locking post-insert re-check runs before the counters — the transaction rolls back via `\DomainException` when a parallel request committed a conflicting booking between the guards and the insert):
    ```php
                $booking = PtmBooking::create([
                    'slot_id' => $slot->id, 'ptm_event_id' => $ptmEventId,
                    'teacher_id' => $locked->teacher_id, 'student_id' => $child->id,
                    'booked_by_user_id' => auth()->id(), 'status' => 'CONFIRMED',
                    'parent_comments' => $request->input('notes'),
                    'is_active' => true, 'created_by' => auth()->id(), 'booked_at' => now(),
                ]);

                // PPTM-03 2026-10-13: locking re-read catches a booking that a parallel
                // request committed between the guards above and this insert.
                $overlapAfter = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->where('id', '!=', $booking->id)
                    ->whereHas('slot', fn ($q) => $q
                        ->where('slot_start', '<', $locked->slot_end)
                        ->where('slot_end', '>', $locked->slot_start))
                    ->lockForUpdate()
                    ->exists();
                if ($overlapAfter) throw new \DomainException('Already have another booking at this time.');
    ```
    > If PPTM-10 is also ticked (applied later in plan order), `insertBooking()` returns the created booking and this post-check moves into the helper — see PPTM-10's After.
  - **Verify:** `grep -n "lockForUpdate\|DomainException\|overlapAfter" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** the overlap guard block still exists, `PtmBooking::create` returns a captured `$booking`, and the post-insert re-check uses `lockForUpdate()`.
  - **Effort:** M

- [x] **PPTM-04** · H · TXN-06 · `ParentPtmApiController.php:194-213` — re-check the booking's `CONFIRMED` status inside the transaction under a row lock so a double-cancel cannot decrement the slot twice.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:194-205`):
    ```php
        if (!$booking->isCancellable()) {
            return response()->json(['error' => 'Booking can no longer be cancelled.'], 422);
        }

        $event = $booking->ptmEvent;

        DB::transaction(function () use ($booking) {
            $booking->update(['status' => 'CANCELLED', 'cancelled_at' => now()]);
    ```
  - **After:** (keep the early UX check; add the authoritative locked re-check inside the transaction, and wrap in the D2-allowed `\DomainException` catch so the business message reaches the client):
    ```php
        if (!$booking->isCancellable()) {
            return response()->json(['error' => 'Booking can no longer be cancelled.'], 422);
        }

        $event = $booking->ptmEvent;

        try {
            DB::transaction(function () use ($booking) {
                // PPTM-04 2026-10-13: locked re-check stops a concurrent second cancel
                // from decrementing the slot twice. Only DomainException is caught (ERR-01).
                $lockedBooking = PtmBooking::where('id', $booking->id)->lockForUpdate()->first();

                if (!$lockedBooking || $lockedBooking->status !== 'CONFIRMED') {
                    throw new \DomainException('Booking can no longer be cancelled.');
                }

                $booking->update(['status' => 'CANCELLED', 'cancelled_at' => now()]);
    ```
  - **After:** (fix the closing brace of the same method — replace the current closing of the transaction + method):
    ```php
            });
        } catch (\DomainException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }

        if ($event && $event->notify_parent_on_cancel) {
    ```
  - **Verify:** `grep -n "lockForUpdate\|DomainException\|status !== 'CONFIRMED'" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** `cancel()` has exactly one `lockForUpdate()` on the booking row and one `catch (\DomainException` wrapping the transaction.
  - **Effort:** M

- [x] **PPTM-05** · H · TXN-06 · `ParentPtmApiController.php:253-262` — re-check the booking is still `CONFIRMED` inside reschedule()'s transaction so a double-tap cannot cancel twice and create two new bookings.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:253-258`):
    ```php
            DB::transaction(function () use ($booking, $newSlotId, $child) {
                $booking->update(['status' => 'CANCELLED', 'cancelled_at' => now(), 'cancel_reason' => 'Rescheduled']);
    ```
  - **After:**
    ```php
            DB::transaction(function () use ($booking, $newSlotId, $child) {
                // PPTM-05 2026-10-13: without this lock a concurrent reschedule runs
                // the whole move twice. Only DomainException is caught (ERR-01).
                $lockedBooking = PtmBooking::where('id', $booking->id)->lockForUpdate()->first();

                if (!$lockedBooking || $lockedBooking->status !== 'CONFIRMED') {
                    throw new \DomainException('Booking can no longer be rescheduled.');
                }

                $booking->update(['status' => 'CANCELLED', 'cancelled_at' => now(), 'cancel_reason' => 'Rescheduled']);
    ```
  - **Verify:** `grep -n "lockForUpdate\|status !== 'CONFIRMED'" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** `reschedule()`'s transaction re-fetches the booking with `lockForUpdate()` and bails when it is not `CONFIRMED`.
  - **Effort:** S

- [x] **PPTM-06** · H · VAL-07 · `ParentPtmApiController.php:262-267` — apply book()'s booking-window, one-per-event and overlap guards to the reschedule target slot before inserting.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:262-268`):
    ```php
                $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();
                $this->assertSlotBelongsToChildClassSection($newSlot, $child);
                if (!$newSlot || !$newSlot->is_active) throw new \Exception('Target slot unavailable.');
                if ($newSlot->booked_count >= $newSlot->capacity) throw new \Exception('Target slot full.');
                if ($newSlot->status === 'BLOCKED') throw new \Exception('Target slot blocked.');
                if ($this->isSlotBlockedByBlockout($newSlot)) throw new \Exception('Target slot blocked by blockout.');
    ```
  - **After:**
    ```php
                $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();
                $this->assertSlotBelongsToChildClassSection($newSlot, $child);
                if (!$newSlot || !$newSlot->is_active) throw new \DomainException('Target slot unavailable.');
                if ($newSlot->booked_count >= $newSlot->capacity) throw new \DomainException('Target slot full.');
                if ($newSlot->status === 'BLOCKED') throw new \DomainException('Target slot blocked.');
                if ($this->isSlotBlockedByBlockout($newSlot)) throw new \DomainException('Target slot blocked by blockout.');

                $newEvent = $newSlot->assignment->ptmEvent;
                if ($newEvent->booking_window_start && $newEvent->booking_window_end) {
                    $now = now();
                    if ($now->lt($newEvent->booking_window_start) || $now->gt($newEvent->booking_window_end)) {
                        throw new \DomainException('Booking window is closed for this event.');
                    }
                }

                $hasBooking = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->where('ptm_event_id', $newEvent->id)
                    ->where('id', '!=', $booking->id)
                    ->exists();
                if ($hasBooking) throw new \DomainException('You already have a booking for this PTM event.');

                $overlap = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->where('id', '!=', $booking->id)
                    ->whereHas('slot', fn ($q) => $q
                        ->where('slot_start', '<', $newSlot->slot_end)
                        ->where('slot_end', '>', $newSlot->slot_start))
                    ->exists();
                if ($overlap) throw new \DomainException('Already have another booking at this time.');
    ```
  - **Verify:** `grep -n "booking_window_start\|Already have another booking\|already have a booking" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** the reschedule target-slot block contains the window, one-per-event and overlap guards (same texts as book()).
  - **Effort:** M

## 3. Errors & transactions (F1/F2)

- [x] **PPTM-02** · M · ERR-05 · `ParentPtmApiController.php:175-177, 226-228` — log the exception object, not just the message, in both notification catches.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:175-177` — book):
    ```php
                    } catch (\Exception $e) {
                        \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
                    }
    ```
  - **After:**
    ```php
                    } catch (\Exception $e) {
                        Log::error('PTM booking notification could not be created.', ['exception' => $e]);
                    }
    ```
  - **Before** (`ParentPtmApiController.php:226-228` — cancel):
    ```php
            } catch (\Exception $e) {
                \Log::error('Error creating PTM cancellation notification: ' . $e->getMessage());
            }
    ```
  - **After:**
    ```php
            } catch (\Exception $e) {
                Log::error('PTM cancellation notification could not be created.', ['exception' => $e]);
            }
    ```
  - **Also add the import** at the top of the file (after the existing `use Illuminate\Support\Facades\DB;`):
    - Before: `use Illuminate\Support\Facades\DB;`
    - After:
      ```php
      use Illuminate\Support\Facades\DB;
      use Illuminate\Support\Facades\Log;
      ```
  - **Verify:** `grep -n "Log::error\|\\\\Log::" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** both catches use `Log::error('…', ['exception' => $e])` and no `\Log::` remains.
  - **Effort:** S

## 4. Authorization (F3)

No items — F3 is clean (route middleware `auth:sanctum` + `ParentPortalMiddleware`, ownership 403s, class-section guard).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PPTM-07** · H · VAL-02/05 · `ParentPtmApiController.php:94, 150, 187, 234, 242-245` — use the module's existing FormRequests on the three write methods instead of raw `Request`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` (the FormRequests already exist and are NOT edited — they are shared with the web controller)
  - **Before** (`ParentPtmApiController.php:8-15` — imports):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    ```
  - **After:**
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Modules\ParentPortal\Http\Requests\BookParentPtmRequest;
    use Modules\ParentPortal\Http\Requests\CancelParentPtmRequest;
    use Modules\ParentPortal\Http\Requests\RescheduleParentPtmRequest;
    ```
  - **Before** (`ParentPtmApiController.php:94` — book signature):
    ```php
    public function book(Request $request, PtmSlot $slot): JsonResponse
    ```
  - **After:**
    ```php
    public function book(BookParentPtmRequest $request, PtmSlot $slot): JsonResponse
    ```
  - **Before** (`ParentPtmApiController.php:150` — notes):
    ```php
                    'parent_comments' => $request->input('notes'),
    ```
  - **After:**
    ```php
                    'parent_comments' => $request->input('notes'),
    ```
  - **Before** (`ParentPtmApiController.php:187` — cancel signature):
    ```php
    public function cancel(Request $request, PtmBooking $booking): JsonResponse
    ```
  - **After:**
    ```php
    public function cancel(CancelParentPtmRequest $request, PtmBooking $booking): JsonResponse
    ```
  - **Before** (`ParentPtmApiController.php:234` — reschedule signature):
    ```php
    public function reschedule(Request $request, PtmBooking $booking): JsonResponse
    ```
  - **After:**
    ```php
    public function reschedule(RescheduleParentPtmRequest $request, PtmBooking $booking): JsonResponse
    ```
  - **Before** (`ParentPtmApiController.php:242-245` — raw input):
    ```php
        $newSlotId = $request->input('new_slot_id');
        if (!$newSlotId) {
            return response()->json(['error' => 'No target slot specified.'], 422);
        }
    ```
  - **After:**
    ```php
        $newSlotId = $request->validated()['new_slot_id'];
    ```
    > The Laravel-idiomatic 422 for a missing/invalid `new_slot_id` now comes from the FormRequest; the manual early-return is removed.
  - **Verify:** `grep -n "function book(\|function cancel(\|function reschedule(\|safe()->notes\|validated()" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` and `grep -n "input('notes')\|input('new_slot_id')" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** the three signatures use the FormRequests; `notes` comes from `safe()`; `new_slot_id` from `validated()`; no raw `input()` on these fields remains.
  - **Effort:** S (⚠ the three FormRequests are owned by the web ParentPtmController report — using them here does not edit them, but flag it to Tarun as a shared-class dependency.)

- [x] **PPTM-08** · H · SEC-03 · `ParentPtmApiController.php:167, 218, 173, 224` — write the real tenant id and drop the hard-coded `?? 1` fallbacks in both notification writes.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:167-173` — book notification):
    ```php
                            'tenant_id' => tenant()->id,
    ```
  - **After:**
    ```php
                            'tenant_id' => tenant()->id,
    ```
    (already correct in book — no change needed here)
  - **Before** (`ParentPtmApiController.php:218-224` — cancel notification):
    ```php
                    'tenant_id' => session('tenant_id') ?? 1,
    ```
  - **After:**
    ```php
                    'tenant_id' => tenant()->id,
    ```
  - **Also change in both notification blocks** (`ParentPtmApiController.php:173` and `:224`):
    - Before: `'created_by' => auth()->id() ?? 1,`
    - After: `'created_by' => auth()->id(),`
  - **Verify:** `grep -n "?? 1\|session('tenant_id')\|tenant()->id" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** no `?? 1` and no `session('tenant_id')` remains; both notification writes use `tenant()->id`.
  - **Effort:** S

## 6. Queries & performance (F9)

No items — PPTM-12 is accepted this pass (see §10).

## 7. Views (F10)

No items — no blades in this API controller.

## 8. Style (F12) — one item per file

- [x] **PPTM-10** · M · CTL-02 · `ParentPtmApiController.php:94-185` — extract book()'s insert+log tail into a private helper so book() is under 80 lines.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:146-163` — the insert + counter + status + activityLog inside book):
    ```php
                PtmBooking::create([
                    'slot_id' => $slot->id, 'ptm_event_id' => $ptmEventId,
                    'teacher_id' => $locked->teacher_id, 'student_id' => $child->id,
                    'booked_by_user_id' => auth()->id(), 'status' => 'CONFIRMED',
                    'parent_comments' => $request->input('notes'),
                    'is_active' => true, 'created_by' => auth()->id(), 'booked_at' => now(),
                ]);

                $locked->increment('booked_count');
                $locked->update(['status' => $locked->booked_count >= $locked->capacity ? 'FULL' : 'BOOKED']);

                activityLog($locked, 'Booked', [
                    'message'    => 'Parent booked a PTM slot.',
                    'student_id' => $child->id,
                    'teacher_id' => $locked->teacher_id,
                    'slot_id'    => $slot->id,
                ]);
    ```
  - **After:** (same lines replaced with a call):
    ```php
                $booking = $this->insertBooking($locked, $ptmEventId, $child, $request->safe()->notes);
    ```
  - **After:** (new private helper, placed after `isSlotBlockedByBlockout()`):
    ```php
    /**
     * Insert the booking row and update the slot counters/status in one write path.
     * Returns the created booking (used by PPTM-03's post-insert re-check).
     */
    private function insertBooking(PtmSlot $locked, int $ptmEventId, $child, ?string $notes)
    {
        $booking = PtmBooking::create([
            'slot_id' => $locked->id, 'ptm_event_id' => $ptmEventId,
            'teacher_id' => $locked->teacher_id, 'student_id' => $child->id,
            'booked_by_user_id' => auth()->id(), 'status' => 'CONFIRMED',
            'parent_comments' => $notes,
            'is_active' => true, 'created_by' => auth()->id(), 'booked_at' => now(),
        ]);

        $locked->increment('booked_count');
        $locked->update(['status' => $locked->booked_count >= $locked->capacity ? 'FULL' : 'BOOKED']);

        activityLog($locked, 'Booked', [
            'message'    => 'Parent booked a PTM slot.',
            'student_id' => $child->id,
            'teacher_id' => $locked->teacher_id,
            'slot_id'    => $locked->id,
        ]);

        return $booking;
    }
    ```
  - **Verify:** `awk 'NR>=94 && NR<=185' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php | wc -l`
  - **Expect:** book() is under 80 lines (the insert/log tail is in `insertBooking()`).
  - **Effort:** M

- [x] **PPTM-11** · L · STY-02/06 · `ParentPtmApiController.php` — Pint-clean the file after code edits; import `Log` instead of `\Log::`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Before** (`ParentPtmApiController.php:176` — current fully-qualified log call, as it stands if PPTM-02 was not ticked):
    ```php
                        \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
    ```
  - **After:**
    ```php
                        Log::error('PTM booking notification could not be created.', ['exception' => $e]);
    ```
    > If PPTM-02 IS ticked, this line is already replaced; run Pint only.
  - **After** (Pint pass — run on the file after all code edits):
    ```bash
    vendor/bin/pint Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php --format agent
    ```
    > Also adds the `use Illuminate\Support\Facades\Log;` import once the fully-qualified call is gone.
  - **Verify:** `vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` and `grep -n "\\\\Log::" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php`
  - **Expect:** `result: pass` and no `\Log::` remains.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PPTM-09** · M · DECISION · CTL-06/SVC-04 — extract booking/cancel/reschedule into a shared service used by BOTH the API and web `ParentPtmController`?
  - **Why it is a decision:** behaviour + shared-file change; D3 defers splits; the web controller is another report's owner.
  - (a) ⭐ **Defer to the split pass (D3).** Keep the two copies this pass; record the divergence in this report and the module summary so a later pass extracts `PtmBookingService` once and points both controllers at it.
  - (b) Extract now — new `Modules/Ptm/app/Services/PtmBookingService.php` with `book()/cancel()/reschedule()` ported from this controller; update the API controller to call it, and leave the web controller a follow-up. Higher risk: the web report owns the web controller; this plan would touch beyond the named file.
  - (c) Leave as is and record as accepted divergence for this launch.
  - ➜ Choice: (a) — defer the shared-service extraction 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PPTM-12 | QRY-02 (L) — the two lists are naturally bounded (upcoming events for one class section; slots for one event) and consumed by a mobile list screen; pagination would add noise for no current-size benefit. Revisit if a tenant reports large event sets. |