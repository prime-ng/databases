# Final Audit — ParentPortal / ParentPtmApiController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` (319 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /api/v1/parent/ptm` (list events + my bookings) · `GET /api/v1/parent/ptm/{ptmEvent}` (slots by teacher) · `POST /api/v1/parent/ptm/slot/{slot}/book` · `POST /api/v1/parent/ptm/booking/{booking}/cancel` · `POST /api/v1/parent/ptm/booking/{booking}/reschedule` |
| Menu path | Parent mobile app → Parent Portal → Parent-Teacher Meeting (PTM) |
| Who uses it | Parents authenticated through the Parent Portal (user_type `PARENT`, at least one portal-enabled child). The `ParentPortalMiddleware` gate runs on every request. |
| What a user does here | A parent sees the school's upcoming PTM events and the family's confirmed bookings, picks a teacher + time slot, books it, and later cancels or moves it to another slot. Booking writes a `ptm_slot_bookings` row, bumps the slot's `booked_count`, writes an activity-log row, and (when the event flag is on) writes a `ntf_notifications` row. |
| Tables written | `ptm_slot_bookings`, `ptm_slots` (booked_count, status), `sys_activity_logs` (via `activityLog()`), `ntf_notifications` (best-effort, flagged) |
| Tables read | `ptm_events`, `ptm_event_class_sections`, `ptm_assignments`, `ptm_slots`, `ptm_slot_bookings`, `ptm_blockouts`, `std_students`, `std_student_guardian_jnt`, `std_guardians`, `sys_users`, `sch_class_sections` |
| Live data | ⚠ UNVERIFIED — no tenant DB is attached in this workspace (`prime_db` is empty of the `ptm_*` tables; the tenant migration set exists). Row counts could not be measured. Column types were verified against `database/migrations/tenant/2026_06_16_0943*.php`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready: one blocker (raw exception text reaches the API client) plus five high-severity write-path defects around concurrency and missing validation. The controller's transaction shape is good (one `DB::transaction` per mutation, `activityLog` inside), but the writes that back booking/cancel/reschedule rely on check-then-act without locks in two of the three mutations, reschedule skips the window/duplicate guards that `book()` enforces, and every notification write uses inconsistent tenant-id sources (`tenant()->id` in `book()`, `session('tenant_id') ?? 1` in `cancel()`). Because this is a live mobile API used by parents, the race conditions (double-cancel double-decrement, overlap double-booking) and the raw-SQL leak are the items to fix before go-live. Rough effort: **M — ~half a day** for the fixer plus Tarun's decision on extracting a shared booking service.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 6 | 3 | 2 | 1 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PPTM-01, PPTM-02 | F8 Services/Jobs | clean (linked) |
| F2 Transactions/Audit | PPTM-03, PPTM-04, PPTM-05 | F9 Queries/Perf | PPTM-12 |
| F3 Authorization | clean | F10 Views | clean (none — API) |
| F4 Validation | PPTM-06, PPTM-07 | F11 Security/Tenancy | PPTM-08 |
| F5 Routes | clean | F12 Style | PPTM-11 |
| F6 Controller shape | PPTM-09, PPTM-10 | F13 Deep read | see §6 table |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` | controller | 319 | this report | ✅ |
| 2 | `Modules/ParentPortal/routes/api.php` (ptm group only) | route file | 46 | this report (group audited; whole file shared by 5 API controllers) | ✅ |
| 3 | `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` (api group) | provider | 100 | common (module infrastructure) | referenced |
| 4 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | common (module gate — f3 evidence) | referenced |
| 5 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) (pre-assigned; report may still be CLAIMED per §5) | ↗ linked — usage only: `resolveChild($request)` per method, constructor injection ✓ |
| 6 | `Modules/Ptm/app/Models/PtmEvent.php` | model | 119 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) (pre-assigned; CLAIMED, not yet written) | ↗ linked — usage only |
| 7 | `Modules/Ptm/app/Models/PtmSlot.php` | model | 129 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) | ↗ linked — usage only |
| 8 | `Modules/Ptm/app/Models/PtmSlotBooking.php` | model | 98 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) | ↗ linked — usage only |
| 9 | `Modules/Ptm/app/Models/PtmBlockout.php` | model | 57 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) | ↗ linked — usage only (see §7 note: TIME columns cast as datetime) |
| 10 | `Modules/Ptm/app/Models/PtmAssignment.php` | model (relation path) | 94 | not in 00-CLASS-OWNERS; reached via `slot->assignment` — claim for the Ptm family belongs to the ParentPtmController report | ↗ linked (relation usage only) |
| 11 | `Modules/Ptm/app/Models/PtmEventClassSection.php` | model (relation path) | 77 | not in 00-CLASS-OWNERS; same owner as above | ↗ linked (relation usage only) |
| 12 | `Modules/Notification/app/Models/Notification.php` | cross-module write target | 385 | not audited here (write-only usage; Notification module owns the model) | referenced — write fields checked for `fillable` |
| 13 | `Modules/ParentPortal/app/Http/Requests/{Book,Cancel,Reschedule}ParentPtmRequest.php` | FormRequests | 41/18/18 | used by the web `ParentPtmController` → owner is its report (CLAIMED, not yet written) | referenced — **should be used by this API controller but are not (PPTM-07)** |
| 14 | `database/migrations/tenant/2026_06_16_0943{07..16}_*.php` | migrations (prove columns/unique keys) | — | common (tenant migrations — never edited) | referenced as column/constraint evidence |

No pre-applied files: `final-audit-reports/tarun/ParentPortal/` has no `PRE-APPLIED-2026-10-10.md`.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...ParentPtmApiController@...'
GET|HEAD  api/v1/parent/ptm                              api.parent.ptm.index         ...ParentPtmApiController@index
GET|HEAD  api/v1/parent/ptm/{ptmEvent}                   api.parent.ptm.show          ...ParentPtmApiController@show
POST      api/v1/parent/ptm/slot/{slot}/book             api.parent.ptm.book          ...ParentPtmApiController@book
POST      api/v1/parent/ptm/booking/{booking}/cancel     api.parent.ptm.cancel        ...ParentPtmApiController@cancel
POST      api/v1/parent/ptm/booking/{booking}/reschedule api.parent.ptm.reschedule    ...ParentPtmApiController@reschedule
```

Middleware stack (`RouteServiceProvider::mapApiRoutes`): `api` + `InitializeTenancyByDomain` + `PreventAccessFromCentralDomains` + `EnsureTenantIsActive` + `EnsureTenantHasModule:ParentPortal` + `auth:sanctum` + `ParentPortalMiddleware`.

Unrouted public methods: none (all five public methods are routed; the two private helpers are not).

Route names in the brief say "`ptm.` prefix" — actual names are `api.parent.ptm.*` (the module's `api.parent.` prefix + `ptm.`). Route param names match the method arguments (`{ptmEvent}` → `PtmEvent $ptmEvent`, `{slot}` → `PtmSlot $slot`, `{booking}` → `PtmBooking $booking`), so route model binding resolves them — no unbound-model insert risk.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | GET api/v1/parent/ptm | route middleware (auth:sanctum + ParentPortalMiddleware) + child via `resolveChild` | none (read) | none | — | PPTM-12 |
| `show` | 49 | GET api/v1/parent/ptm/{ptmEvent} | route middleware + `resolveChild` | none (read) | none | — | PPTM-12 |
| `book` | 94 | POST api/v1/parent/ptm/slot/{slot}/book | route middleware + `assertSlotBelongsToChildClassSection` | controller `DB::transaction` (line 100) | `'Booked'` (line 157, inside tx after write) | ptm_slot_bookings (insert), ptm_slots (booked_count, status), ntf_notifications (best-effort), sys_activity_logs | PPTM-01, PPTM-02, PPTM-03, PPTM-07, PPTM-08 |
| `cancel` | 187 | POST api/v1/parent/ptm/booking/{booking}/cancel | ownership 403 (`booked_by_user_id` + `student_id`) + `isCancellable()` | controller `DB::transaction` (line 200) | `'Cancelled'` (line 203, inside tx after write) | ptm_slot_bookings (status), ptm_slots (booked_count, status), ntf_notifications (outside tx), sys_activity_logs | PPTM-02, PPTM-04, PPTM-08 |
| `reschedule` | 234 | POST api/v1/parent/ptm/booking/{booking}/reschedule | ownership 403 + `allow_reschedule` + `assertSlotBelongsToChildClassSection` (new slot) | controller `DB::transaction` (line 253) | `'Rescheduled'` (line 281, inside tx after write) | ptm_slot_bookings (old status, new insert), ptm_slots (old dec, new inc/status), sys_activity_logs | PPTM-01, PPTM-05, PPTM-06, PPTM-07 |

Tables each mutation SHOULD touch, compared with what it DOES (controller-alignment §0.1): all three mutations write `ptm_slot_bookings` + `ptm_slots` + `sys_activity_logs`, and `book`/`cancel` also write `ntf_notifications` when the event flag is on. All matches — no missing write.

## 6. Findings

### F1 — Errors

#### PPTM-01 · B · ERR-01 — booking/reschedule send the raw exception text to the mobile client

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak*; also D1 (no try/catch in controllers — the only allowed catch is `\DomainException`) |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:180-182` (`book`) and `:288-290` (`reschedule`) |
| **Root cause** | Both methods wrap the `DB::transaction` in `try { … } catch (\Throwable $e) { return response()->json(['error' => $e->getMessage()], 422); }`. `\Throwable` catches `QueryException` too, so a duplicate-key error (e.g. the DB unique keys `uq_ptmBooking_slot_studentActive` / `uq_ptmBooking_event_teacher_studentActive` firing on a double-book) or any SQL error is returned verbatim to the parent's phone. |
| **Consequence** | A parent who double-submits a booking sees raw SQL text (`SQLSTATE[23000] … Duplicate entry … for key 'uq_ptmBooking_event_teacher_studentActive'`) instead of "You already have a booking for this PTM event." |
| **Reproduce** | Book a slot, then send the identical `POST /api/v1/parent/ptm/slot/{slot}/book` again fast enough to beat the exists() check — or induce any DB error — and read `error` in the JSON response. |
| **Fix approach** | Per D1/D2: drop `catch (\Throwable)`. Throw `\DomainException` for the business-rule texts, `catch (\DomainException $e)` only, return the message (business texts are user-safe); let any other exception propagate to the central renderer. |
| **Plan item** | PPTM-01 in `02-fix-plan.md` §1 |

```php
// ParentPtmApiController.php:179-182 — CURRENT (book method)
            });
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
```
```php
// ParentPtmApiController.php:288-290 — CURRENT (reschedule method)
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php
B  ERR-01   ParentPtmApiController.php:181  book — raw exception message (Throwable) returned to the user
B  ERR-01   ParentPtmApiController.php:289  reschedule — raw exception message (Throwable) returned to the user
```

#### PPTM-02 · M · ERR-05 — notification failure is logged as message text, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:175-177` (`book` notification) and `:226-228` (`cancel` notification) |
| **Root cause** | The best-effort `Notification::create` is wrapped in `catch (\Exception $e) { \Log::error('…: ' . $e->getMessage()); }`. The message only is logged, losing stack-trace and class context, and `\Log` is used fully-qualified (STY-06, see PPTM-11). |
| **Consequence** | When a notification write fails, the ops log shows only the error string with no trace, class or line — hard to debug, and the parent is never told the notification failed. |
| **Reproduce** | Static only — break the `ntf_notifications` insert (e.g. invalid `priority_id`) and inspect `storage/logs/laravel.log`. |
| **Fix approach** | Use `report($e)` (or `Log::error('…', ['exception' => $e])`) in both catches. |
| **Plan item** | PPTM-02 in `02-fix-plan.md` §3 |

```php
// ParentPtmApiController.php:175-177 — CURRENT (book)
                    } catch (\Exception $e) {
                        \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
                    }
```
```php
// ParentPtmApiController.php:226-228 — CURRENT (cancel)
            } catch (\Exception $e) {
                \Log::error('Error creating PTM cancellation notification: ' . $e->getMessage());
            }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php
M  ERR-05  ParentPtmApiController.php:176  book — logs getMessage() without the exception/trace
M  ERR-05  ParentPtmApiController.php:227  cancel — logs getMessage() without the exception/trace
```

### F2 — Transactions and audit

#### PPTM-03 · H · TXN-06 — book()'s overlap check has no lock or unique index → double-booking race

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:125-144` inside the `DB::transaction` of `book()` (lines 100-179) |
| **Root cause** | The three `exists()` guards (same slot, same event, time overlap) run before the insert. The slot row is locked (`lockForUpdate()`, line 101) which serialises per-slot requests, and the DB unique keys `uq_ptmBooking_slot_studentActive` / `uq_ptmBooking_event_teacher_studentActive` backstop the same-slot and same-event cases (verified in the tenant migration). But the **time-overlap rule (lines 138-144) has no unique-index backstop**: two slots in different events that overlap in time are different rows, so two parallel requests from the same child both pass the overlap `exists()` and both insert. |
| **Consequence** | A child can end up with two CONFIRMED bookings at the same time in two different PTM events (teacher double-booked), and the same-event duplicate surfaces as a raw duplicate-key `QueryException` (see PPTM-01). |
| **Reproduce** | Fire `book()` on two overlapping slots in different events for the same `student_id` concurrently (e.g. two mobile phones / a script). |
| **Fix approach** | Run the overlap query with `->lockForUpdate()` so concurrent transactors serialise on the child's intersecting rows, and catch the unique-violation case as a `\DomainException` (business text) rather than letting `QueryException` leak. |
| **Plan item** | PPTM-03 in `02-fix-plan.md` §2 |

```php
// ParentPtmApiController.php:138-144 — CURRENT (overlap guard inside book's transaction)
                $overlap = PtmBooking::where('student_id', $child->id)
                    ->where('status', 'CONFIRMED')
                    ->whereHas('slot', fn($q) => $q
                        ->where('slot_start', '<', $locked->slot_end)
                        ->where('slot_end', '>', $locked->slot_start))
                    ->exists();
                if ($overlap) throw new \Exception('Already have another booking at this time.');
```

**Evidence**
```
$ grep -n "uq_ptmBooking_slot_studentActive\|uq_ptmBooking_event_teacher_studentActive" database/migrations/tenant/2026_06_16_094315_create_ptm_slot_bookings_table.php
54:            $table->unique(['ptm_event_id', 'active_booking_key'], 'uq_ptmBooking_event_teacher_studentActive');
55:            $table->unique(['slot_id', 'active_booking_key'], 'uq_ptmBooking_slot_studentActive');
$ sed -n '138,144p' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php   # shown above — no lockForUpdate, no unique constraint for overlap
```

#### PPTM-04 · H · TXN-06 — cancel() re-checks status outside the transaction → double-cancel double-decrements the slot

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:194-196` (`isCancellable()` before the tx) and the `DB::transaction` at `:200-213` |
| **Root cause** | `isCancellable()` (status `CONFIRMED` + lead time) is evaluated before the transaction, and the booking row is never locked inside it. The slot row IS locked (line 208), but two concurrent cancels of the same booking both pass `isCancellable()` while the booking is still `CONFIRMED`, then both run the transaction; the second one decrements `booked_count` again. The `booked_count > 0` guard only prevents negative values, not double-counting. |
| **Consequence** | A double-tap on "Cancel" leaves `ptm_slots.booked_count` one too low, and the slot can be reported as AVAILABLE while a booking still exists. |
| **Reproduce** | Send two identical `POST …/booking/{booking}/cancel` at the same time for a confirmed booking on a slot with `booked_count >= 2`. |
| **Fix approach** | Inside the transaction, re-fetch the booking with `LockForUpdate` and bail with a `\DomainException` when its status is no longer `CONFIRMED`; decrement only then. |
| **Plan item** | PPTM-04 in `02-fix-plan.md` §2 |

```php
// ParentPtmApiController.php:194-213 — CURRENT (pre-check + transaction)
        if (!$booking->isCancellable()) {
            return response()->json(['error' => 'Booking can no longer be cancelled.'], 422);
        }

        $event = $booking->ptmEvent;

        DB::transaction(function () use ($booking) {
            $booking->update(['status' => 'CANCELLED', 'cancelled_at' => now()]);

            activityLog($booking, 'Cancelled', [
                'message'    => 'Parent cancelled a PTM booking.',
                'student_id' => $booking->student_id,
                'slot_id'    => $booking->slot_id,
            ]);
            $slot = PtmSlot::where('id', $booking->slot_id)->lockForUpdate()->first();
            if ($slot && $slot->booked_count > 0) {
                $slot->decrement('booked_count');
                $slot->update(['status' => $slot->booked_count === 0 ? 'AVAILABLE' : 'BOOKED']);
            }
        });
```

**Evidence**
```
$ sed -n '194,213p' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php   # shown above
$ grep -n "isCancellable" Modules/Ptm/app/Models/PtmSlotBooking.php
86:    public function isCancellable(): bool
```

#### PPTM-05 · H · TXN-06 — reschedule() has no CONFIRMED re-check inside the transaction → double-run double-writes

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:253-287` (`reschedule` transaction) |
| **Root cause** | `reschedule()` never verifies the booking is still `CONFIRMED` inside the transaction (no `isCancellable()` parallel, no `lockForUpdate` on the booking row). Two concurrent reschedules of the same booking both cancel the old row and both insert a new CONFIRMED booking: the old slot is decremented twice and the new slot incremented twice. The unique key `uq_ptmBooking_event_teacher_studentActive` only backstops when the target event is the same; a move to a different event is not constrained. |
| **Consequence** | A double-tap on "Reschedule" creates two new bookings (or one raw duplicate-key 422 when the target event is the same) and corrupts both slots' `booked_count`. |
| **Reproduce** | Send two identical `POST …/booking/{booking}/reschedule` with the same `new_slot_id` concurrently. |
| **Fix approach** | Inside the transaction, re-fetch the booking with `lockForUpdate()` and throw `\DomainException` unless `status === 'CONFIRMED'`; only then cancel the old and create the new. |
| **Plan item** | PPTM-05 in `02-fix-plan.md` §2 |

```php
// ParentPtmApiController.php:253-262 — CURRENT (start of reschedule transaction)
            DB::transaction(function () use ($booking, $newSlotId, $child) {
                $booking->update(['status' => 'CANCELLED', 'cancelled_at' => now(), 'cancel_reason' => 'Rescheduled']);

                $oldSlot = PtmSlot::where('id', $booking->slot_id)->lockForUpdate()->first();
                if ($oldSlot && $oldSlot->booked_count > 0) {
                    $oldSlot->decrement('booked_count');
                    $oldSlot->update(['status' => $oldSlot->booked_count === 0 ? 'AVAILABLE' : 'BOOKED']);
                }

                $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();
```

**Evidence**
```
$ sed -n '253,262p' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php   # shown above
# no ->lockForUpdate() and no status re-check anywhere in lines 253-287
```

### F3 — Authorization

clean — every routed method is behind `auth:sanctum` + `ParentPortalMiddleware` (PARENT user + guardian + at least one portal-enabled child, verified: `user_type !== 'PARENT' → 403`); `book`/`reschedule` also enforce the child's class-section match (`assertSlotBelongsToChildClassSection` → 403), and `cancel`/`reschedule` enforce record ownership (`booked_by_user_id` + `student_id` → 403).
Evidence: `grep -n "abort_unless\|user_type\|routeIs('parent-portal.no-access')" Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` — all present. Permission-key gates are not used for the parent portal API; the middleware IS the role gate (consistent with the module pattern; the web controller carries the same approach via FormRequest `authorize()`).

### F4 — Validation and input

#### PPTM-06 · H · VAL-07 — reschedule() skips the window/duplicate guards that book() enforces on the new slot

| Field | Value |
|---|---|
| **Rule** | VAL-07 (H, raised) — *business checks (window, one-booking-per-event, overlap) must run; book() has them, reschedule() does not* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:262-286` (new-slot validation + insert inside `reschedule`) vs `:118-144` (the same checks inside `book`) |
| **Root cause** | `book()` checks (1) the event booking window, (2) no existing booking for this slot, (3) one booking per event, (4) no overlapping time. `reschedule()` checks only `is_active`, capacity, `BLOCKED` and blockout (**lines 264-267**). A parent can move a booking into a different event whose window is closed, or into an event/class where the child already has a booking — creating a second CONFIRMED booking for the same event. |
| **Consequence** | A parent can obtain a booking outside the school's advertised booking window, or end up with two confirmed meetings in one PTM event. |
| **Reproduce** | Reschedule an existing booking to a slot in an event whose `booking_window_end` is in the past (or to an event where the child already has another booking). |
| **Fix approach** | Before creating the new booking, replicate book()'s window, one-per-event and overlap guards against the new slot's event. |
| **Plan item** | PPTM-06 in `02-fix-plan.md` §2 |

```php
// ParentPtmApiController.php:262-277 — CURRENT (reschedule new-slot validation + insert)
                $newSlot = PtmSlot::where('id', $newSlotId)->lockForUpdate()->first();
                $this->assertSlotBelongsToChildClassSection($newSlot, $child);
                if (!$newSlot || !$newSlot->is_active) throw new \Exception('Target slot unavailable.');
                if ($newSlot->booked_count >= $newSlot->capacity) throw new \Exception('Target slot full.');
                if ($newSlot->status === 'BLOCKED') throw new \Exception('Target slot blocked.');
                if ($this->isSlotBlockedByBlockout($newSlot)) throw new \Exception('Target slot blocked by blockout.');

                PtmBooking::create([
                    'slot_id' => $newSlot->id, 'ptm_event_id' => $newSlot->assignment->ptm_event_id,
```

**Evidence**
```
$ sed -n '118,144p' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php  # book() window + one-per-event + overlap guards (see PPTM-03 code block)
$ sed -n '262,277p' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php  # reschedule() has none of them
```

#### PPTM-07 · H · VAL-02/05 — write paths use raw request input, bypassing the module's three FormRequests

| Field | Value |
|---|---|
| **Rule** | VAL-02/05 (H) — *validation lives in a FormRequest; write paths with no validation at all are H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:94-95` (`book(Request …)`), `:150` (`$request->input('notes')`), `:242-245` (`reschedule`: `$request->input('new_slot_id')` truthiness only) |
| **Root cause** | The module already ships `BookParentPtmRequest` (`notes => nullable|string|max:1000`), `CancelParentPtmRequest`, `RescheduleParentPtmRequest` (`new_slot_id => required|integer|exists:ptm_slots,id`) — all used by the web `ParentPtmController`. The API controller instead type-hints `Request`, so `notes` is stored without length/type validation and `new_slot_id` is only checked for truthiness. |
| **Consequence** | A `notes` value of any size/type lands in `parent_comments`; a malformed or non-existent `new_slot_id` reaches `PtmSlot::where('id', …)` and, when the variable is `null`, calls the typed `assertSlotBelongsToChildClassSection(PtmSlot $slot, …)` with null → `TypeError` under `strict_types` → raw type-error text to the client (also a PPTM-01 leak). |
| **Reproduce** | POST `notes` as a 2 MB string and watch it persist; POST `reschedule` with `new_slot_id=abc` and read the raw `TypeError` in the JSON. |
| **Fix approach** | Change the three method signatures to the existing FormRequests (Book/Cancel/RescheduleParentPtmRequest) and read from `$request->validated()`. |
| **Plan item** | PPTM-07 in `02-fix-plan.md` §5 |

```php
// ParentPtmApiController.php:94-95,150 — CURRENT (book signature + notes)
    public function book(Request $request, PtmSlot $slot): JsonResponse
    {
        $child = $this->context->resolveChild($request);
        $this->assertSlotBelongsToChildClassSection($slot, $child);
```
```php
// ParentPtmApiController.php:242-245 — CURRENT (reschedule input)
        $newSlotId = $request->input('new_slot_id');
        if (!$newSlotId) {
            return response()->json(['error' => 'No target slot specified.'], 422);
        }
```

**Evidence**
```
$ grep -rn "BookParentPtmRequest\|RescheduleParentPtmRequest\|CancelParentPtmRequest" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
10:use ...Request\RescheduleParentPtmRequest;
11:use ...Request\CancelParentPtmRequest;
12:use ...Request\BookParentPtmRequest;
148:    public function book(BookParentPtmRequest $request, PtmSlot $slot): RedirectResponse
$ grep -rn "BookParentPtmRequest" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php
(no output — the API controller never uses them)
$ sed -n '23,29p' Modules/ParentPortal/app/Http/Requests/RescheduleParentPtmRequest.php
23:            'new_slot_id' => 'required|integer|exists:ptm_slots,id',
```

### F5 — Routes

clean — all five routes exist and point at existing methods (verified in §4 output); state changes are POST only (no GET mutation — RTE-01); every public method is routed (RTE-03); route params match the typed arguments (module-finalization §3.3.1 — no unbound model); the whole group sits inside tenancy + `auth:sanctum` + `ParentPortalMiddleware` (RTE-05). No custom/resource ordering issue (no `Route::resource` in this group).

### F6 — Controller shape

#### PPTM-09 · M · CTL-06 / SVC-04 — booking/cancel/reschedule business logic lives in the controller and is duplicated with the web ParentPtmController

| Field | Value |
|---|---|
| **Rule** | CTL-06/SVC-04 (M) — *business logic in services; one implementation per business operation* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:94-319` vs `Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php:146-430` |
| **Root cause** | The full booking workflow (lock slot → capacity → blockout → window → duplicate checks → insert → `booked_count` → notification) exists twice: once in this API controller and once in the web `ParentPtmController`. They already diverge — e.g. `book()` here checks booking window and one-per-event; `reschedule()` here does not, while the web controller's `reschedule` has its own (different) copy. Each fix to one copy silently widens the gap. |
| **Consequence** | Business rules (windows, duplicates, blockouts) can be enforced on the web but not the API (or vice versa) — inconsistent PTM outcomes depending on which surface the parent uses. |
| **Reproduce** | Static — compare `ParentPtmController.php:148-262` (web book) with `ParentPtmApiController.php:94-185` (API book); the guard sets differ. |
| **Fix approach** | Extract a shared `PtmBookingService` (or action class) used by both controllers. Per D3 this is deferred — see DECISION. |
| **Plan item** | PPTM-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentPtmApiController.php:100-123 — CURRENT (the duplicated guard set; the same shape exists in the web controller)
            DB::transaction(function () use ($slot, $child, $request) {
                $locked = PtmSlot::where('id', $slot->id)->lockForUpdate()->first();

                if (!$locked || !$locked->is_active) {
                    throw new \Exception('Slot is no longer available.');
                }
                if ($locked->booked_count >= $locked->capacity) {
                    throw new \Exception('Slot is fully booked.');
                }
                if ($locked->status === 'BLOCKED') {
                    throw new \Exception('Slot is blocked.');
                }

                if ($this->isSlotBlockedByBlockout($locked)) {
                    throw new \Exception('Slot is blocked by a blockout.');
                }
```

**Evidence**
```
$ grep -nE "public function (book|cancel|reschedule)|lockForUpdate|isSlotBlockedByBlockout|activityLog" Modules/ParentPortal/app/Http/Controllers/ParentPtmController.php
148:    public function book(BookParentPtmRequest $request, PtmSlot $slot): RedirectResponse
156:                $locked = PtmSlot::where('id', $slot->id)->lockForUpdate()->first();
171:                if ($this->isSlotBlockedByBlockout($locked)) {
262:                activityLog(auth()->user(), 'Booked', [
289:    public function cancel(CancelParentPtmRequest $request, PtmBooking $booking): RedirectResponse
356:    public function reschedule(RescheduleParentPtmRequest $request, PtmBooking $booking): RedirectResponse
```

#### PPTM-10 · M · CTL-02 — book() is 92 lines (> 80)

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method over 80 lines → extract* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:94-185` (92 lines) |
| **Root cause** | `book()` inlines the lock, five business guards, the insert, the counter/status updates, the activity log, and the notification block. |
| **Consequence** | Hard to follow; the missing guard in `reschedule()` is harder to notice when the reference implementation is one long method. |
| **Reproduce** | Static — count the lines. |
| **Fix approach** | Extract the new-booking write+log into a private method (or fold into the shared service of PPTM-09) — mechanical, behaviour-preserving. |
| **Plan item** | PPTM-10 in `02-fix-plan.md` §8 |

```php
// ParentPtmApiController.php:94-95 — CURRENT (method start)
    public function book(Request $request, PtmSlot $slot): JsonResponse
    {
        $child = $this->context->resolveChild($request);
        $this->assertSlotBelongsToChildClassSection($slot, $child);

        try {
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php
M  CTL-02  ParentPtmApiController.php:94  book — book() is 92 lines
$ awk 'NR>=94 && NR<=185' Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php | wc -l
92
```

### F7 — Models

clean — all Ptm models are owned by the ParentPtmController (web) report, so only usage was checked: `PtmEvent` (`active`, `upcoming`, `eventClassSections`, `allow_reschedule`, `notify_parent_on_book`) ✓; `PtmSlot` (`assignment`, `teacher`, `isAvailable()`, `booked_count`/`capacity` int casts) ✓; `PtmSlotBooking` (`ptmEvent`, `slot`, `isCancellable()`, `status` cast) ✓; `PtmBlockout` (`active`, fields) ✓ — all resolve with the arguments this controller passes. See §7 cross-note for the `start_time`/`end_time` TIME-column cast mismatch (model owned by the web report).

### F8 — Services and jobs

clean (linked) — the only service is `ParentContextService` (owned by the ParentDashboardController report): used via constructor injection and `resolveChild($request)` per method, which is the correct usage; the child is scoped per parent and memoised in the service. No HTTP in services, no writes on read paths, no jobs.

### F9 — Queries and performance

#### PPTM-12 · L · QRY-02 — index()/show() return unbounded JSON lists

| Field | Value |
|---|---|
| **Rule** | QRY-02 (default H, lowered to L) — *lists are paginated*; lowered: the datasets are naturally bounded (upcoming events for one class section; slots for one event) and consumed by a mobile list screen |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:29-40` (`index`) and `:55-63` (`show`) |
| **Root cause** | `->get()` with no `paginate()` on both lists. |
| **Consequence** | If a school creates many events/slots, the payload grows unbounded (though the class-section and `upcoming()` filters already bound it in practice). |
| **Reproduce** | Static — read the queries. |
| **Fix approach** | Optionally add `simplePaginate`/`cursorPaginate` if real deployments exceed a few dozen rows per class-event. |
| **Plan item** | PPTM-12 in `02-fix-plan.md` §10 (no fix this pass — accepted, see plan) |

```php
// ParentPtmApiController.php:29-40 — CURRENT (index events + my bookings)
        $events = PtmEvent::active()
            ->upcoming()
            ->whereHas('eventClassSections', fn($q) => $q->where('class_section_id', $classSectionId))
            ->orderBy('event_start_date')
            ->get(['id', 'title', 'description', 'event_start_date', 'booking_window_start', 'booking_window_end']);
```

**Evidence**
```
$ grep -n "paginate\|simplePaginate\|cursorPaginate" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php
(no output — no pagination)
```

### F10 — Views

clean — this is a JSON API controller; no blades are rendered (`grep -n "view(" Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` → no output).

### F11 — Security and tenancy

#### PPTM-08 · H · SEC-03 — notification writes use hard-coded fallbacks and an inconsistent tenant-id source

| Field | Value |
|---|---|
| **Rule** | SEC-03 (default M, raised to H) — *no hard-coded ids or fallbacks such as `?? 1`* — raised: on a Sanctum API there is no web session, so `session('tenant_id')` is null on every request and `cancel()` writes `tenant_id = 1` on every cancellation regardless of the real tenant |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php:167` (`tenant()->id` in book), `:218` (`session('tenant_id') ?? 1` in cancel), `:173` and `:224` (`auth()->id() ?? 1` in both notification writes) |
| **Root cause** | Inconsistent tenant sources between the two notification writes. `book()` uses `tenant()->id` (correct under stancl/tenancy); `cancel()` uses `session('tenant_id') ?? 1`. The API route group does not start the web session, so the fallback `1` is written. The `auth()->id() ?? 1` fallbacks are dead code (auth is guaranteed by `auth:sanctum`) but encode the same bad habit. |
| **Consequence** | Every cancellation notification is labelled tenant 1 in `ntf_notifications` — cross-tenant mislabelling of a notification row in a multi-tenant product. |
| **Reproduce** | Cancel a booking, then read `ntf_notifications.tenant_id` for the row with `notification_event = 'PTM_CANCELLED'`. |
| **Fix approach** | Use `tenant()->id` in `cancel()` (match `book()`), and drop both `?? 1` fallbacks (`auth()->id()` is always populated behind `auth:sanctum`). |
| **Plan item** | PPTM-08 in `02-fix-plan.md` §5 |

```php
// ParentPtmApiController.php:218-224 — CURRENT (cancel notification)
                    'tenant_id' => session('tenant_id') ?? 1,
                    'source_module' => 'Ptm', 'source_record_id' => $booking->id,
                    'notification_event' => 'PTM_CANCELLED',
                    'title' => 'PTM Slot Cancelled: ' . ($event->title ?? 'Parent-Teacher Meeting'),
                    'description' => 'Your PTM slot booking has been cancelled.',
                    'priority_id' => 'NORMAL', 'notification_status_id' => 'SENT',
                    'created_by' => auth()->id() ?? 1, 'is_active' => true,
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json \
    Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php
M  SEC-03  ParentPtmApiController.php:173  book — hard-coded id fallback: auth()->id() ?? 1
M  SEC-03  ParentPtmApiController.php:218  cancel — hard-coded id fallback: session('tenant_id') ?? 1
M  SEC-03  ParentPtmApiController.php:224  cancel — hard-coded id fallback: auth()->id() ?? 1
$ grep -n "session(" Modules/ParentPortal/app/Providers/RouteServiceProvider.php
  (no StartSession middleware in the api group — API requests carry no web session)
```

### F12 — Style

#### PPTM-11 · L · STY-02/06 — file is not Pint-clean; `\Log::` used instead of an imported `Log`

| Field | Value |
|---|---|
| **Rule** | STY-02/06 (L) — *Pint-clean; one style per concern* |
| **Where** | whole file — Pint reports 12 fixers (`function_declaration`, `fully_qualified_strict_types`, `concat_space`, `ordered_imports`, etc.) |
| **Root cause** | `\Log::error(...)` used fully-qualified (twice), `fn($q)` missing the space, etc. |
| **Consequence** | No functional impact; formatting debt the next editor pays. |
| **Reproduce** | `vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php` |
| **Fix approach** | Run Pint on this one file after the code fixes, and import `Log`. |
| **Plan item** | PPTM-11 in `02-fix-plan.md` §8 |

```php
// ParentPtmApiController.php:176 — CURRENT (fully-qualified \Log, no import)
                        \Log::error('Error creating PTM booking notification: ' . $e->getMessage());
```

**Evidence**
```
$ vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/Api/ParentPtmApiController.php 2>&1 | tail -3
{"tool":"pint","result":"fail","files":[{"path":"Modules\/ParentPortal\/app\/Http\/Controllers\/Api\/ParentPtmApiController.php","fixers":["function_declaration","fully_qualified_strict_types","control_structure_braces","concat_space","method_chaining_indentation","braces_position","statement_indentation","not_operator_with_successor_space","single_line_empty_body","blank_line_before_statement","ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Question | book() | cancel() | reschedule() |
|---|---|---|---|
| 1. Can a write overwrite data it should not? | ok — only increments its own slot's counters | ok — only sets the booking's own status | ok — old set CANCELLED, new inserted (atomic in one tx) |
| 2. Is anything deleted before its replacement is stored? | ok | ok | ok — one tx, no deletes |
| 3. Duplicate implementations of one operation? | **PPTM-09** (web + API copies) | **PPTM-09** | **PPTM-09** |
| 4. Soft-delete × unique-index trap? | ok — unique keys ride the generated `active_booking_key` (NULL when not CONFIRMED) so cancelling and re-booking is allowed; verified in migration | ok | ok |
| 5. Is there a race? | **PPTM-03** (overlap) | **PPTM-04** (double-cancel) | **PPTM-05** (double-run) |
| 6. Is there an authorization hole? | ok — class-section guard + parent-child scoping | ok — ownership 403 | ok for the booking itself; **PPTM-06** for target-event guards |
| 7. Does any message lie? | ok — "Slot booked successfully." | ok | ok — "Booking rescheduled successfully." |
| 8. Is there a dead feature? | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Ptm/app/Models/PtmBlockout.php` | `start_time`/`end_time` cast to `datetime` but the migration columns are `time` (2026_06_16_094310_create_ptm_blockouts_table.php). The API only compares with `->format('H:i:s')`, which works, but writes through the model (web side) may send date-time strings into TIME columns. | MDL-02 | ParentPtmController (web) report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | Returns web redirects (`redirect()->route(...)`) from an API-facing middleware; a machine client with no accessible child gets a redirect instead of JSON. Defensive only (the controller's `resolveChild` has the same shape) — module-wide, not this controller. | ERR-04 | ParentPortal module owner |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | `abort(redirect()->route('parent-portal.no-access'))` on an API request is a redirect to a web route; acceptable because the middleware gate prevents the no-child case, but the API contract should be JSON 403. | TEN/ERR | ParentDashboardController report (owns the service) |
| `Modules/Notification/app/Models/Notification.php` | Write-only usage from the controller; `ntf_notifications` row is created without looking up a `NotificationTarget` or dispatching — the "notify" feature may end at the row. | JOB-04/SVC | Notification module owner |

## 8. Not covered, and why

- **Live row counts / a real tenant** — no tenant DB is attached here (`prime_db` has no `ptm_*` tables); column types and unique keys verified from tenant migrations instead.
- **Behavioural proof of the races** (PPTM-03/04/05) — deliberately not reproduced with a test (D4: no testing). Evidence is static (lock scope + unique constraints).
- **The web `ParentPtmController`** (pre-assigned owner of the Ptm models, batch 10, still CLAIMED) — not audited here; only its divergence from the API was noted for PPTM-09. Its report will own the Ptm models and `PptDropdownResolver`; classes reached here only via relations (PtmAssignment, PtmEventClassSection) are left for that report to claim.
- **Notification delivery pipeline** — whether a created `ntf_notifications` row reaches the parent is the Notification module's business; only the write labels used here were reviewed.
- **`/tmp/fa-parentportal.json`** was provided pre-generated and reused as instructed; the route list was regenerated fresh (`APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json > /tmp/fa-routes.json`).