# Fix Plan — ParentPortal / ParentDashboardApiController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the ParentDashboardController report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by the ParentHealthController report |
| `Modules/ParentPortal/routes/api.php` | shared module route file |
| `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` | shared module provider |
| `Modules/StudentProfile/app/Models/{Student,StudentAcademicSession,StudentAttendance,LeaveApplication}.php` | owned by gaurav/StudentProfile reports |
| `Modules/StudentFee/app/Models/{FeeStudentAssignment,FeeInvoice}.php` | owned by the ParentFeeController report (read-only: `FeeInvoice` constants are only imported and read) |
| `database/migrations/tenant/*` | existing migrations — never edit |

## 1. Blockers reachable today

None — no B-severity finding.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — the controller has no `try/catch` and no write path (D1 clean).

## 4. Authorization (F3)

None — the route is gated by `auth:sanctum` + `ParentPortalMiddleware`, and record ownership is enforced by `resolveChild()` (linked service).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PDAS-01** · H · QRY-03 · `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:81` — read the real roll column (`roll_no`) so the JSON stops returning `roll_number: null`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php`
  - **Before** (`ParentDashboardApiController.php:81`):
    ```php
                'roll_number' => $session?->roll_number,
    ```
  - **After:**
    ```php
                'roll_number' => $session?->roll_no,
    ```
  - **Verify:** `grep -n "roll_" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php`
  - **Expect:** exactly one line, `81: 'roll_number' => $session?->roll_no,`.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **PDAS-04** · M · QRY-05 · `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:63-70` — aggregate the fee card in SQL and count pending invoices with the `FeeInvoice` constants (this also applies PDAS-03: `Cancelled` invoices stop counting as pending and the dead `['paid','PAID']` literals are dropped).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php`
  - **Before** (`ParentDashboardApiController.php:63-70`):
    ```php
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $invoices   = $feeAssignment->invoices ?? collect();
            $feeTotal   = (float) $invoices->sum('total_amount');
            $feePaid    = (float) $invoices->sum('paid_amount');
            $feeDue     = (float) $invoices->sum('balance_amount');
            $feePending = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
        }
    ```
  - **After:**
    ```php
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $feeTotals = $feeAssignment->invoices()
                ->selectRaw('COALESCE(SUM(total_amount), 0) as total')
                ->selectRaw('COALESCE(SUM(paid_amount), 0) as paid')
                ->selectRaw('COALESCE(SUM(balance_amount), 0) as due')
                ->first();
            $feeTotal   = (float) $feeTotals->total;
            $feePaid    = (float) $feeTotals->paid;
            $feeDue     = (float) $feeTotals->due;
            $feePending = $feeAssignment->invoices()
                ->whereNotIn('status', [FeeInvoice::STATUS_PAID, FeeInvoice::STATUS_CANCELLED])
                ->count();
        }
    ```
  - **Before** (`ParentDashboardApiController.php:8-13`, imports — add the `FeeInvoice` import):
    ```php
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\StudentProfile\Models\LeaveApplication;
    use Modules\StudentProfile\Models\StudentAttendance;
    ```
  - **After:**
    ```php
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\StudentFee\Models\FeeInvoice;
    use Modules\StudentProfile\Models\LeaveApplication;
    use Modules\StudentProfile\Models\StudentAttendance;
    ```
  - **Verify:** `grep -n "FeeInvoice::STATUS_PAID\|selectRaw" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php`
  - **Expect:** four lines: the import, two `selectRaw`-adjacent lines, and the `FeeInvoice::STATUS_PAID` / `FeeInvoice::STATUS_CANCELLED` count line; no remaining `'paid', 'PAID'` literals.
  - **Effort:** S

## 7. Views (F10)

None — API controller, no Blade views.

## 8. Style (F12) — one item per file

- [x] **PDAS-06** · L · STY-02 · `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:16-19` — run Pint on the file so it is Pint-clean (`binary_operator_spaces` unaligns the hand-aligned `=` / `=>`; `single_line_empty_body` collapses the empty constructor body).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php`
  - **Before** (`ParentDashboardApiController.php:16-19`):
    ```php
    public function __construct(
        private readonly ParentContextService $context,
    ) {
    }
    ```
  - **After:** (what Pint produces for the constructor; Pint applies the same `binary_operator_spaces` treatment to the aligned `=` and `=>` operators in the method body — no manual edits)
    ```php
    public function __construct(
        private readonly ParentContextService $context,
    ) {}
    ```
  - **Verify:** `vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php`
  - **Expect:** `{"tool":"pint","result":"passed",...}` (and `php -l` on the file still passes).
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PDAS-02** · H · DECISION · MDL-09 — how should `Half Day` and `Short Leave` count in the parent dashboard attendance percentage, and should the dead `P` / `present` aliases be dropped?
  - **Why it is a decision:** it changes a number parents see on the app's home screen, and the chosen rule must agree with the attendance page (PAT-05 in the ParentAttendanceController report is the same decision). The fix touches only this controller's line 42 (`whereIn('status', ...)`).
  - **What is wrong:** the `std_student_attendance.status` enum is `Present / Absent / Late / Half Day / Short Leave / Leave`; the dashboard matches `['Present','P','present']`. `P` and `present` never occur, and `Half Day` / `Short Leave` rows lower the percentage while the student-facing pages count them as present.
  - (a) ⭐ **RECOMMENDED — match the student-facing rule.** Count `Present`, `Late`, `Half Day`, `Short Leave` as present for the percentage (drop `P` / `present`). Apply the same rule to PAT-05 so mobile, web attendance and student portal agree. Touches only this controller; behaviour change is visible on the dashboard.
  - (b) **Keep only `Present` and drop the dead aliases.** `Half Day` / `Short Leave` / `Leave` days keep lowering the percentage; record the mismatch with the attendance page as accepted.
  - (c) **Defer the behaviour choice.** Apply only the alias cleanup now (`['Present']`, no `P` / `present`) and mirror whatever PAT-05 decides when the attendance page is fixed.
  - ➜ Choice: (a) — Present/Late/Half Day/Short Leave count as present 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PDAS-03 | MDL-09 fee pending-status literals — fixed inside PDAS-04's After block (the `whereNotIn('status', [FeeInvoice::STATUS_PAID, FeeInvoice::STATUS_CANCELLED])` count replaces line 69 and drops the dead `paid`/`PAID` literals); a separate item would edit the same lines twice. |
| PDAS-05 | CTL-02 86-line `summary()` — deferred: PDAS-04 shrinks the method, D3 defers structural splits, and a pure extraction after the fee rewrite is cosmetic; the fixer may extract the fee card into a private method if the ticked items leave time, but nothing depends on it. |