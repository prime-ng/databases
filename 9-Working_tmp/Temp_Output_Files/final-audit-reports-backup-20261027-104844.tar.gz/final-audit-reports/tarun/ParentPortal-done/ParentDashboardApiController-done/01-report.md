# Final Audit — ParentPortal / ParentDashboardApiController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` (112 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /api/v1/parent/dashboard` (JSON) — the mobile/PWA parent dashboard summary. Route name `api.parent.dashboard`, method `summary()`. |
| Menu path | Mobile parent app → Dashboard (home screen, first thing a parent sees after login). |
| Who uses it | Parents (`user_type = PARENT`) with a `std_guardians` row linked to at least one child via `std_student_guardian_jnt` where `can_access_parent_portal = 1`. The route sits behind `auth:sanctum` + `ParentPortalMiddleware` (user_type + guardian + portal-enabled child). There is no granular permission key for the parent portal, by design. |
| What a user does here | A parent opens the app and the dashboard shows, for the single active child, the child's name/class/section/roll number, attendance totals and percentage for the current academic session, leave counts (total and pending), a fee card (total paid / due / pending invoices), and the five most recent notifications. Nothing on this screen writes data; it is a read-only aggregation. |
| Tables written | Directly: none — `summary()` issues only SELECTs. Indirectly through `ParentContextService::resolveChild()` (owned by the ParentDashboardController report): `ppt_parent_sessions` may be created or have `active_student_id` / `last_active_at` updated on the read path. |
| Tables read | `std_students`, `std_guardians`, `std_student_guardian_jnt`, `std_student_academic_sessions`, `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `sch_org_academic_sessions_jnt` (via the session eager-load), `std_student_attendance`, `std_leave_applications`, `fee_student_assignments`, `fee_invoices`, `notifications`, and `glb_academic_sessions` (via `Student::currentFeeAssignemnt()`). |
| Live data | ⚠ UNVERIFIED — a tenant DB session was not opened (read-only audit, D4). Row counts were not measured. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The dashboard works, is scoped to the parent's own child (the `resolveChild()` call only ever returns a child from the parent's accessible set), and every number it returns is a count or a sum over that one child. It should not ship as-is because the JSON contains one field that is always null and two counts that silently disagree with other screens: `roll_number` reads a column that does not exist on the session table, so every parent always gets `roll_number: null` (PDAS-01, H); the attendance percentage excludes `Half Day` and `Short Leave` days while the student-facing pages count them as present, so a parent can see a lower percentage than the school's own screens (PDAS-02, H — a decision); and the fee "pending invoices" counter counts `Cancelled` invoices as pending because it filters on status literals that only partially match the real enum (PDAS-03, M). The fee card also computes totals in PHP over a fully-loaded invoice collection instead of letting the database aggregate (PDAS-04, M), the single method is 86 lines (PDAS-05, M, cosmetic), and the file is not Pint-clean (PDAS-06, L). Rough effort: S — a couple of hours once the attendance-counting decision is made.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 2 | 3 | 1 | 1 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean (service linked) |
| F2 Transactions/Audit | clean | F9 Queries/Perf | PDAS-04 |
| F3 Authorization | clean | F10 Views | clean (no views) |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | PDAS-06 |
| F6 Controller shape | PDAS-05 | F13 Deep read | PDAS-02, PDAS-03 |
| F7 Models | PDAS-01, PDAS-02, PDAS-03 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` | controller | 112 | this report | ✅ |
| 2 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) (registry line 309) | ↗ linked |
| 3 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) (registry line 337) | ↗ linked |
| 4 | `Modules/ParentPortal/routes/api.php` | route file | 46 | common (shared module route file) | referenced |
| 5 | `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` | provider | 100 | common (module provider, defines the API middleware stack) | referenced |
| 6 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | 126 | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md) (registry line 83) | ↗ linked |
| 7 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | 63 | ↗ [gaurav/StudentProfile/AttendanceController](../../../gaurav/StudentProfile/AttendanceController/01-report.md) (registry line 88) | ↗ linked |
| 8 | `Modules/StudentProfile/app/Models/Student.php` | model | 471 | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController/01-report.md) (registry line 75) | ↗ linked |
| 9 | `Modules/StudentProfile/app/Models/StudentAcademicSession.php` | model | 211 | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) (registry line 94) | ↗ linked |
| 10 | `Modules/StudentFee/app/Models/FeeStudentAssignment.php` | model | 226 | ↗ [tarun/ParentPortal-done/ParentFeeController](../ParentFeeController-done/01-report.md) (registry line 335) | ↗ linked |
| 11 | `Modules/StudentFee/app/Models/FeeInvoice.php` | model | 474 | ↗ [tarun/ParentPortal-done/ParentFeeController](../ParentFeeController-done/01-report.md) (registry line 333) | ↗ linked |

No pre-applied files (`PRE-APPLIED-2026-10-10.md` does not mention ParentPortal).

## 4. Routes

```
GET|HEAD  api/v1/parent/dashboard   api.parent.dashboard   Modules\ParentPortal\Http\Controllers\Api\ParentDashboardApiController@summary
```

Middleware chain (from `Modules/ParentPortal/app/Providers/RouteServiceProvider.php:85-99`):
`api`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:ParentPortal`, `auth:sanctum`, `ParentPortalMiddleware`.

Unrouted public methods: none — the only public method (`summary()`) is routed, plus the constructor.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `summary` | 26 | GET api/v1/parent/dashboard (api.parent.dashboard) | none (portal middleware `ParentPortalMiddleware`; record-level via `ParentContextService::resolveChild()`) | none (read-only) | none | none directly (indirect: `ppt_parent_sessions` via `resolveChild()`) | PDAS-01, PDAS-02, PDAS-03, PDAS-04, PDAS-05, PDAS-06 |

## 6. Findings

### F1 — Errors

clean — `grep -nE "try|catch|getMessage|report\(" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` → no output. There is no `try/catch` in the controller at all, so ERR-01..07 do not apply. The one error-path oddity — `ParentContextService::resolveChild()` aborts with a **web redirect** from a JSON API context when the parent has no active accessible child — lives in the linked service and is recorded in §7 (owned by the ParentDashboardController report).

### F2 — Transactions and audit

clean — `grep -nE "DB::transaction|activityLog|beginTransaction|->create\(|->update\(|->delete\(|->save\(" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` → no output. `summary()` issues SELECTs only, so no transaction and no `activityLog()` are needed. The write-on-read behaviour of the linked service (`getOrCreateSession()` / `$parentSession->update()` inside `resolveChild()`) is a service defect recorded in §7.

### F3 — Authorization

clean — `grep -nE "Gate::|authorize|abort|can:" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` → no output, which is correct for this route. The route sits behind `auth:sanctum` + `ParentPortalMiddleware` (`Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php:27-63`), which checks `user_type = 'PARENT'`, a guardian profile, and at least one portal-enabled child. Record-level ownership is enforced by `ParentContextService::resolveChild()`: it only ever returns a child from `getAccessibleChildren()` (the parent's own linked, active students), so a parent cannot request another family's child. The attendance, leave and fee queries all filter on `student_id = $child->id`, and the notifications come from `$request->user()` itself, so the response is scoped to this parent and this child.

### F4 — Validation and input

clean — `grep -nE "validate|validated|->all\(|except\(|request->input|query\(" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` → no output. `summary()` reads no user input at all (no query parameters, no body), so there is nothing to validate.

### F5 — Routes

clean — the live `route:list` probe (§4) shows the single GET route resolves to an existing method, reads (no state change over GET), and carries the full tenancy + `auth:sanctum` + `ParentPortalMiddleware` chain. No `Route::resource` shares the prefix, so no ordering conflict.

### F6 — Controller shape

#### PDAS-05 · M · CTL-02 — `summary()` is 86 lines, over the 80-line extraction threshold

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:26-111`, method `summary()` |
| **Root cause** | The method assembles five independent payload blocks (child identity, attendance, leave, fee, notifications) and the JSON response in one body: lines 28-31 (session), 33-44 (attendance), 46-56 (leave), 58-70 (fee), 72-110 (JSON + notifications). |
| **Consequence** | The method is harder to read and the fee block is awkward to change in place; no user-visible defect today. |
| **Reproduce** | Static only — `sed -n '26,111p'` shows the whole screen in one method. |
| **Fix approach** | Optional extraction of the fee-card computation into a private method. Deferred: PDAS-04 rewrites the fee block anyway (shrinking the method), and D3 defers structural splits; a pure extraction after those edits is cosmetic. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
    public function summary(Request $request): JsonResponse
    {
        $child = $this->context->resolveChild($request);
        $session = $child->currentSession()
            ->with(['classSection.class', 'classSection.section', 'academicSession'])
            ->first();
```

**Evidence**
```
$ grep -n "public function summary\|^}" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php
26:    public function summary(Request $request): JsonResponse
112:}

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php
M  CTL-02   Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:26  summary — summary() is 86 lines
```

### F7 — Models

#### PDAS-01 · H · QRY-03 — the JSON `roll_number` field reads a column that does not exist, so it is always `null`

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *JSON endpoints must return correct, purposeful data* — severity raised to **H** because the field returns a wrong value on every request (severity table: "wrong result"). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:81`, method `summary()` |
| **Root cause** | The child's current academic-session row stores its roll number in `roll_no` — that is the only roll column on `std_student_academic_sessions` (it is in `$fillable` at `StudentAcademicSession.php:26` and defined at migration line 20). The dashboard reads `$session?->roll_number`, which no column backs, so Eloquent returns `null` silently. |
| **Consequence** | Every parent's dashboard always shows no roll number on mobile, and no error is raised, so the defect is invisible until someone checks the JSON. |
| **Reproduce** | `GET /api/v1/parent/dashboard` for any parent: the JSON always contains `"roll_number": null` even when the child has a roll number set in the school's session record. |
| **Fix approach** | Read the real column: `'roll_number' => $session?->roll_no,`. |
| **Plan item** | PDAS-01 in `02-fix-plan.md` §5 |

```php
                'roll_number' => $session?->roll_number,
```

**Evidence**
```
$ grep -n "roll" Modules/StudentProfile/app/Models/StudentAcademicSession.php
26:        'roll_no',

$ grep -n "roll" database/migrations/tenant/2026_06_15_151307_create_std_student_academic_sessions_table.php
20:            $table->unsignedInteger('roll_no')->nullable();
```

#### PDAS-02 · H · MDL-09 — attendance "present" matches status literals that do not exist, and `Half Day` / `Short Leave` days lower the parent's percentage

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L) — *status/type strings are PHP enums or model constants, not literals repeated across files*; severity raised to **H** because the mismatch produces a wrong number on a real screen (severity table: "wrong result"), and it is the same defect already raised as PAT-05 in the ParentAttendanceController report. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:42`, method `summary()` |
| **Root cause** | The present-count matches `['Present', 'P', 'present']`, but the `std_student_attendance.status` enum is `['Present', 'Absent', 'Late', 'Half Day', 'Short Leave', 'Leave']`. The aliases `P` and `present` never occur, and the real values `Half Day` / `Short Leave` / `Leave` are excluded from "present". A child with any such day therefore gets a lower `percentage` than the student-facing pages give, which count those values as present. |
| **Consequence** | A parent whose child has a `Half Day` or `Short Leave` sees an attendance percentage on mobile that disagrees with the percentage the same parent sees on the attendance page and the student portal — a silent inconsistency, not an error. |
| **Reproduce** | Mark a student `Half Day` for one day, then open `GET /api/v1/parent/dashboard`: the `attendance.percentage` is lower than the `ParentAttendanceController` summary for the same child. |
| **Fix approach** | DECISION — how `Half Day` / `Short Leave` should count toward the parent's percentage. It must end up consistent with the PAT-05 decision on the attendance page. See PDAS-02 in `02-fix-plan.md` §9. |
| **Plan item** | PDAS-02 in `02-fix-plan.md` §9 (DECISION) |

```php
            $attendancePresent = StudentAttendance::where('student_id', $child->id)
                ->where('academic_session_id', $session->academic_session_id)
                ->whereIn('status', ['Present', 'P', 'present'])
                ->count();
```

**Evidence**
```
$ grep -n "whereIn('status'" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php
42:                ->whereIn('status', ['Present', 'P', 'present'])

$ grep -n "enum('status'" database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php
21:            $table->enum('status', ['Present', 'Absent', 'Late', 'Half Day', 'Short Leave', 'Leave']);
```

#### PDAS-03 · M · MDL-09 — the fee "pending invoices" filter uses status literals that only partially match the real enum, so `Cancelled` invoices are counted as pending

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L) — *status/type strings are PHP enums or model constants, not literals repeated across files*; severity raised to **M** because the mismatch produces a wrong count on a real screen (severity table: "wrong result" is H, but this is an informational counter on a fee card, so M with reason stays). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:69`, method `summary()` |
| **Root cause** | The pending count filters `whereNotIn('status', ['paid', 'PAID', 'Paid'])`. The `fee_invoices.status` enum is `['Cancelled', 'Draft', 'Overdue', 'Paid', 'Partially Paid', 'Published']` — Title Case only. The literals `paid` and `PAID` can never match, and the filter does not exclude `Cancelled`, so every cancelled invoice is counted as "pending". |
| **Consequence** | The mobile fee card can show "N pending invoices" when some of those invoices were cancelled, and the model constants (`FeeInvoice::STATUS_PAID`, `FeeInvoice::STATUS_CANCELLED`) are ignored in favour of hand-typed literals. |
| **Reproduce** | Cancel an invoice for the active child, then open `GET /api/v1/parent/dashboard`: the cancelled invoice still appears in `fee.pending_invoices`. |
| **Fix approach** | Use the model constants and exclude both `STATUS_PAID` and `STATUS_CANCELLED`. Applied as part of the PDAS-04 fee-block rewrite (same lines). |
| **Plan item** | none — see `02-fix-plan.md` §10 (fixed inside PDAS-04's After block) |

```php
            $feePending = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
```

**Evidence**
```
$ grep -n "whereNotIn('status'" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php
69:            $feePending = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();

$ grep -n "enum('status'" database/migrations/tenant/2026_06_16_092641_create_fee_invoices_table.php
26:            $table->enum('status', ['Cancelled', 'Draft', 'Overdue', 'Paid', 'Partially Paid', 'Published'])->default('Draft');

$ grep -n "STATUS_PAID\|STATUS_CANCELLED" Modules/StudentFee/app/Models/FeeInvoice.php
71:    public const STATUS_PAID = 'Paid';
73:    public const STATUS_CANCELLED = 'Cancelled';
```

### F8 — Services and jobs

clean for this controller's usage — the only service used is `ParentContextService` (owned by the ParentDashboardController report, scope row 2), injected through the constructor (`ParentDashboardApiController.php:16-19`, so SVC-02 is satisfied). `resolveChild($request)` is called once, before any read, and its result is the only child id ever used. No jobs, events, mail or notifications are used by this controller. The service's own defects are cross-cutting (§7).

### F9 — Queries and performance

#### PDAS-04 · M · QRY-05 — fee totals are summed in PHP over a fully-loaded invoice collection instead of letting the database aggregate

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate in SQL: `withSum`, `selectRaw`, not `->get()->sum()` over a whole table* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:63-70`, method `summary()` |
| **Root cause** | `$feeAssignment->invoices` loads every invoice row for the assignment (all columns) into a Collection, then PHP sums `total_amount`, `paid_amount`, `balance_amount` and filters by status. The `?? collect()` guard is dead code — a `hasMany` relation always returns a Collection. |
| **Consequence** | One fat query per dashboard load where two small aggregate queries would do; the penalty grows with the invoice count and is repeated on every app open. |
| **Reproduce** | Static only — enabled two lines below: the collection is loaded at line 65 and summed in PHP at lines 66-69. |
| **Fix approach** | Aggregate in SQL: one `selectRaw(...)` query for the three SUMs and one `whereNotIn` count for pending, using `FeeInvoice::STATUS_PAID` / `STATUS_CANCELLED` (also applies PDAS-03). |
| **Plan item** | PDAS-04 in `02-fix-plan.md` §6 |

```php
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $invoices   = $feeAssignment->invoices ?? collect();
            $feeTotal   = (float) $invoices->sum('total_amount');
            $feePaid    = (float) $invoices->sum('paid_amount');
            $feeDue     = (float) $invoices->sum('balance_amount');
            $feePending = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
        }
```

**Evidence**
```
$ grep -n "->sum(\|->whereNotIn(\|->invoices" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php
65:            $invoices   = $feeAssignment->invoices ?? collect();
66:            $feeTotal   = (float) $invoices->sum('total_amount');
67:            $feePaid    = (float) $invoices->sum('paid_amount');
68:            $feeDue     = (float) $invoices->sum('balance_amount');
69:            $feePending = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
```

### F10 — Views

clean — this is an API controller: it returns `response()->json(...)`, no Blade views are involved.

### F11 — Security and tenancy

clean — `grep -nE "env\(|cache|asset\(|storage|?? 1" Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` → no output. No `env()` outside `config/`; no hard-coded ids or `?? 1`; the JSON payload is a hand-mapped array (child id/name/class, counts, mapped notification fields), never a whole model, so SEC-02 holds; no secrets are logged; no cache is used, so no tenant-key concern. Tenancy: every query runs inside the tenant (the route sits in the `InitializeTenancyByDomain` stack), and the only central-table touch (`glb_academic_sessions` via `Student::currentFeeAssignemnt()`) is the Student model's own doing, on a model deliberately bound to the `global_master_mysql` connection — recorded as a cross-cutting note (§7).

### F12 — Style

#### PDAS-06 · L · STY-02 — the file is not Pint-clean: aligned `=`/`=>` operators and a two-line empty constructor body

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): binary-operator spacing, empty bodies* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php:16-19` (constructor), `:33-108` (aligned assignments and array `=>` operators) |
| **Root cause** | The file hand-aligns its `=` and `=>` operators (`$attendanceTotal   = 0;`, `'section_name'=> $sectionName,`), which the Pint `binary_operator_spaces` fixer unaligns, and the property-promotion constructor spans two lines with an empty body, which the `single_line_empty_body` fixer collapses to `) {}`. |
| **Consequence** | None functionally; the file fails the project's own formatter, so the next developer who touches it gets the alignment collapsed anyway. |
| **Reproduce** | `vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php` → `result: fail`, fixers `single_line_empty_body`, `binary_operator_spaces` (output below). |
| **Fix approach** | Run `vendor/bin/pint <file> --format agent` on this one file when the fixer touches it (protocol §9 runs Pint on touched files). No manual edit needed. |
| **Plan item** | PDAS-06 in `02-fix-plan.md` §8 |

```php
    public function __construct(
        private readonly ParentContextService $context,
    ) {
    }
```

**Evidence**
```
$ vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/Api/ParentDashboardApiController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/ParentPortal\/app\/Http\/Controllers\/Api\/ParentDashboardApiController.php","fixers":["single_line_empty_body","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

The only mutation reachable from this controller is indirect: `ParentContextService::resolveChild()` (lines 93-124 of the service) can `create()` a `ppt_parent_sessions` row via `getOrCreateSession()` or `update()` it when the active child changed. Those writes belong to the service's owner report (§7).

| # | Question | `summary()` (via `resolveChild()`) |
|---|---|---|
| 1 | Can a write overwrite data it should not? | ok — the service persists only the active-child id/last-active timestamp for this guardian, and §7 records the write-on-read concern for the owner report |
| 2 | Is anything deleted before its replacement is stored? | ok — nothing is deleted |
| 3 | Are there duplicate implementations of one operation? | §7 — `Student` has both `feeAssignment()` (hasMany) and `currentFeeAssignemnt()` (hasOne) for the same fact; owner report |
| 4 | Is there a soft-delete × unique-index trap? | ok for this controller — no create/restore here; `StudentAttendance`'s missing `SoftDeletes` is the owner report's §7 note |
| 5 | Is there a race? | §7 — `getOrCreateSession()` is check-then-act (`where → first → create`) with no lock; owner report |
| 6 | Is there an authorization hole? | ok — only the parent's own accessible child is read; every query filters on `student_id = $child->id` |
| 7 | Does any message lie? | PDAS-01 (roll_number always null), PDAS-02 (percentage disagrees with attendance page), PDAS-03 (cancelled invoices counted as pending) |
| 8 | Is there a dead feature? | ok — all five payload blocks are displayed by the app; nothing is written that no consumer reads |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` (owned by ParentDashboardController report) | `resolveChild()` aborts with a **web redirect** (`abort(redirect()->route('parent-portal.no-access'))`, lines 101-105) when the parent has no active accessible child. On this API route a parent whose children were all deactivated (the middleware only checks the guardian link, not `is_active`) receives a 302 to an HTML no-access page instead of a 403 JSON — the mobile client cannot follow the session-cookie redirect chain. Also writes on a read path (`getOrCreateSession()` create/update, lines 202-222; plus `$parentSession->update(...)` line 120) with no transaction — exactly the TXN-01/SVC-03/TXN-06 shapes the sibling ParentAttendanceController report already recorded. | ERR-04, SVC-03, SVC-01, TXN-01, TXN-06 | ParentDashboardController report |
| `Modules/StudentProfile/app/Models/Student.php` (owned by gaurav/StudentProfile/StudentReportController report) | `currentFeeAssignemnt()` (lines 315-319) executes `AcademicSession::current()->first()->id` inside the relation: if `glb_academic_sessions` has no `is_current` row, `->id` on null throws and this dashboard 500s on every load. The relation is also a duplicate of `feeAssignment()` (SVC-04) and is a bare `hasOne` (no `ofMany`/latest) so a student with two current-session assignments gets an arbitrary row. Scanner also flags MDL-05 (`InteractsWithMedia` without `getMediaModel()`, line 21). ⚠ UNVERIFIED whether a tenant can lack a current session. | MDL-05, SVC-04, null-safe relation | gaurav/StudentProfile/StudentReportController report |
| `Modules/StudentFee/app/Models/FeeStudentAssignment.php` (owned by ParentFeeController report) | No defect in how this controller uses it (the `invoices()` hasMany is called correctly). Model-level scanner hits (STY-01, MDL-04 on `invoices()`/`concessions()`, STY-04) belong to the owner report. | STY-01, MDL-04 | ParentFeeController report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` (owned by ParentHealthController report) | Portal-wide gate; no defect found in how this route uses it (it runs on the API stack and the `no-access` self-guard prevents a redirect loop). Its own `redirect()->route('login')` branch (line 33) and web-route redirects (lines 46, 60) are noted for the owner report: on Sanctum API routes the unauthenticated branch is normally unreachable (`auth:sanctum` 401s first) and the no-access redirect is meant for the web flow. | — | ParentHealthController report |

## 8. Not covered, and why

- Live row counts for §0 were not measured — that needs a real tenant DB connection, which this read-only audit did not open (D4).
- The `currentFeeAssignemnt()` null-crash risk (Student model) could not be settled ⚠ UNVERIFIED — settlement needs a tenant whose `glb_academic_sessions` has no current row, which no browser here can produce.
- `ParentContextService` internals, the four StudentProfile models, `FeeStudentAssignment` / `FeeInvoice` internals and `ParentPortalMiddleware` were not re-audited — each is owned by another report (scope rows 2-3, 6-11); only how this controller uses them was checked.
- The JSON shape was not exercised end-to-end — no Sanctum token, no tenant domain, and no mobile client were available in this read-only session; every claim about the payload comes from reading the code and the schema.