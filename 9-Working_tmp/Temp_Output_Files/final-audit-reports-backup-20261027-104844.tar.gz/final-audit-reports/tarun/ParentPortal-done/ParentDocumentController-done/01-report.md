# Final Audit — ParentPortal / ParentDocumentController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php` (516 lines, 9 public methods including the constructor)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/documents` (vault + request list, tabbed) · `…/documents/create` (new request form) · `…/documents/{id}` (request detail) · `…/documents/{id}/withdraw` (POST) · `…/documents/{id}/pay/initiate` + `…/{id}/pay/callback` (POST, Razorpay fee) · `…/documents/{id}/download` (private file) |
| Menu path | Parent Portal → Documents (Vault + Duplicate Requests) |
| Who uses it | Any authenticated user whose `user_type = 'PARENT'` with a `std_guardians` row and at least one linked child (`can_access_parent_portal = 1`). There is no per-permission key for parents; access is granted by `ParentPortalMiddleware` (owned by the ParentHealthController report). |
| What a user does here | A parent opens Documents to see (a) the published report-card vault for the active child and (b) their own duplicate-document requests. They can raise a new request for a TC / mark sheet / bonafide / etc., view a request's progress, pay the school's duplicate-document fee through Razorpay (initiate → pay → callback verifies the signature), download the fulfilled document once the school has attached it, and withdraw a still-pending request. |
| Tables written | `ppt_document_requests` (INSERT in store, is_active/deleted_at update in withdraw, fee_paid/payment_reference update in payCallback, status update in download), `fin_payments` + payment audit tables (via `PaymentService`, owned by ParentFeePaymentController report), the tenant activity log via `activityLog()` (`sys_activity_logs`), and indirectly `ppt_parent_sessions` via `ParentContextService::resolveChild()`. |
| Tables read | `ppt_document_requests`, `std_students`, `sys_dropdown_table` (via `PptDropdownResolver`), `hpc_reports` (vault), `sys_media` (central, fulfilled document), `std_guardians`, `std_student_guardian_jnt`, `ppt_parent_sessions`, `fin_payments`. |
| Live data | Tenant `00000000-0000-4000-8000-000000000001`: `ppt_document_requests` 5 live / 0 trashed (seeded, all `Completed`); dropdown keys exist (`ppt_document_requests.document_type` 7 rows, `.urgency` 2 rows, `.status` 5 rows); `fin_payments` with `payable_type = ParentDocumentRequest` → 0 rows (the payment flow has never run end-to-end in this tenant). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — not production-ready. The headline defect is PDOC-01: `store()` hands `ParentDocumentRequest::create()` the string keys `document_type`, `urgency` and `status`, but `$fillable` lists only the resolved `*_option_id` columns, so Laravel's mass-assignment silently drops the three keys and the mutators that map them to dropdown ids never run. The `*_option_id` columns are NOT NULL in the migration, so the INSERT always fails and **a parent can never create a document request**; the success flash on the `store()` path is unreachable. The single worst secondary issue is PDOC-03: the `payInitiate` JSON endpoint returns the raw exception message (`$e->getMessage()`) to the user, which can leak SQL/table/column details. Beyond that the controller copies the rejected try/catch style (D1) onto every method (including read-only ones), logs only messages instead of exceptions (ERR-05), builds responses inside transactions (TXN-05), and has one payment race (TXN-06) plus two decisions Tarun must make (the write-on-GET download, and withdrawing a request whose fee was already paid). Rough effort: the blocker and correctness fixes are S each; the controller-wide D1 rewrite is M; everything together is about a day.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 3 | 2 | 8 | 3 | 2 | 16 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PDOC-02, PDOC-03, PDOC-04 | F8 Services/Jobs | clean (linked) |
| F2 Transactions/Audit | PDOC-05, PDOC-06, PDOC-08 | F9 Queries/Perf | PDOC-15, PDOC-17 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | PDOC-09 | F11 Security/Tenancy | clean (note in §7) |
| F5 Routes | PDOC-07 | F12 Style | PDOC-16 |
| F6 Controller shape | PDOC-10, PDOC-11, PDOC-12 | F13 Deep read | table in §6 |
| F7 Models | PDOC-01, PDOC-13 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php` | controller | 516 | this report | ✅ |
| 2 | `Modules/ParentPortal/app/Models/ParentDocumentRequest.php` | model | 214 | this report (pre-assigned in registry) | ✅ |
| 3 | `Modules/ParentPortal/app/Http/Requests/StoreParentDocumentRequest.php` | FormRequest | 20 | this report | ✅ |
| 4 | `Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php` | FormRequest | 18 | this report | ✅ |
| 5 | `Modules/ParentPortal/app/Http/Requests/PayInitiateParentDocumentRequest.php` | FormRequest | 18 | this report | ✅ |
| 6 | `Modules/ParentPortal/app/Http/Requests/PayCallbackParentDocumentRequest.php` | FormRequest | 21 | this report | ✅ |
| 7 | `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | FormRequest (base) | 26 | ↗ [tarun/ParentPortal-done/ParentComplaintController](../ParentComplaintController-done/01-report.md) | ↗ linked |
| 8 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked |
| 9 | `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | service | 41 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) | ↗ linked |
| 10 | `Modules/Hpc/app/Models/HpcReport.php` | model | — | ↗ [tarun/ParentPortal-done/ParentResultController](../ParentResultController-done/01-report.md) | ↗ linked |
| 11 | `Modules/Payment/app/Models/Payment.php` | model | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 12 | `Modules/Payment/app/Services/PaymentService.php` | service | 182 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 13 | `Modules/Payment/app/Services/GatewayManager.php` | service | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 14 | `Modules/Payment/app/Gateways/RazorpayGateway.php` | gateway | — | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 15 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked |
| 16 | `Modules/StudentProfile/app/Models/Guardian.php` | model | 152 | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) | ↗ linked |
| 17 | `Modules/StudentProfile/app/Models/Student.php` | model | — | common (reached via ParentContextService; usage only here) | ↗ linked |
| 18 | `Modules/Prime/app/Models/Media.php` | model | 8 | this report (claimed 2026-10-13) | ✅ |
| 19 | `Modules/ParentPortal/routes/web.php` | routes | 199 | ↗ shared route file (system) | ↗ linked |
| 20 | `Modules/ParentPortal/resources/views/documents/index.blade.php` | view | 396 | this report | ✅ |
| 21 | `Modules/ParentPortal/resources/views/documents/create.blade.php` | view | 357 | this report | ✅ |
| 22 | `Modules/ParentPortal/resources/views/documents/show.blade.php` | view | 533 | this report | ✅ |
| 23 | `database/migrations/tenant/2026_06_16_105225_create_ppt_document_requests_table.php` | migration | 69 | reference (read for schema; never edited) | ✅ |

No pre-applied files (no `PRE-APPLIED-2026-10-10.md` entry names any of the above).

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...str_contains($x["action"],"ParentDocumentController@")...'
GET|HEAD parent-portal/documents                                 parent-portal.documents.index      Modules\ParentPortal\Http\Controllers\ParentDocumentController@index
POST    parent-portal/documents                                 parent-portal.documents.store      Modules\ParentPortal\Http\Controllers\ParentDocumentController@store
GET|HEAD parent-portal/documents/create                          parent-portal.documents.create     Modules\ParentPortal\Http\Controllers\ParentDocumentController@create
GET|HEAD parent-portal/documents/{documentRequest}               parent-portal.documents.show       Modules\ParentPortal\Http\Controllers\ParentDocumentController@show
GET|HEAD parent-portal/documents/{documentRequest}/download      parent-portal.documents.download   Modules\ParentPortal\Http\Controllers\ParentDocumentController@download
POST    parent-portal/documents/{documentRequest}/pay/callback   parent-portal.documents.pay.callback  Modules\ParentPortal\Http\Controllers\ParentDocumentController@payCallback
POST    parent-portal/documents/{documentRequest}/pay/initiate   parent-portal.documents.pay.initiate  Modules\ParentPortal\Http\Controllers\ParentDocumentController@payInitiate
POST    parent-portal/documents/{documentRequest}/withdraw       parent-portal.documents.withdraw   Modules\ParentPortal\Http\Controllers\ParentDocumentController@withdraw
```

Unrouted public methods: none. All 8 routed methods exist (RTE-02 clean). The route parameter `{documentRequest}` matches the `ParentDocumentRequest $documentRequest` argument, so implicit route-model binding works (RTE parameter-name check clean). The `GET /{documentRequest}` (show) route is registered **before** `GET /{documentRequest}/download`; Laravel matches the longer literal correctly because show's pattern does not absorb a trailing segment (verified in the exported route list — both routes resolve). All routes sit inside the module's `web` middleware group with tenancy + auth + `ParentPortalMiddleware` (RTE-05 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 41 | GET parent-portal/documents | module gate + child scope | DB::transaction on a read path (to remove) | 'Viewed' | sys_activity_logs | PDOC-02, PDOC-04, PDOC-05, PDOC-11, PDOC-15, PDOC-17 |
| `create` | 94 | GET …/documents/create | module gate + child scope | DB::transaction on a read path (to remove) | 'Viewed' | sys_activity_logs | PDOC-02, PDOC-04, PDOC-05, PDOC-11 |
| `store` | 131 | POST …/documents | FormRequest `authorize()` (child resolve) + guardian abort | controller transaction | 'Requested' | ppt_document_requests, sys_activity_logs | PDOC-01, PDOC-02, PDOC-04, PDOC-05, PDOC-11 |
| `show` | 212 | GET …/documents/{documentRequest} | `abort_unless(student_id === child->id, 403)` | DB::transaction on a read path (to remove) | 'Viewed' | sys_activity_logs | PDOC-02, PDOC-04, PDOC-05, PDOC-11 |
| `withdraw` | 261 | POST …/documents/{documentRequest}/withdraw | `abort_unless` owner + `isWithdrawable()` | controller transaction | 'Withdrawn' | ppt_document_requests, sys_activity_logs | PDOC-02, PDOC-04, PDOC-05, PDOC-09, PDOC-11 |
| `payInitiate` | 315 | POST …/documents/{documentRequest}/pay/initiate | `abort_unless` owner + `requiresPayment()` | service transaction (`PaymentService::initiate`) | 'PaymentInitiated' | fin_payments + payment audit (service), sys_activity_logs | PDOC-03, PDOC-04, PDOC-06, PDOC-11 |
| `payCallback` | 359 | POST …/documents/{documentRequest}/pay/callback | `abort_unless` owner + `abort_if` payable match + gateway signature | service + controller transactions | 'Paid' / 'PaymentFailed' | fin_payments + payment audit (service), ppt_document_requests, sys_activity_logs | PDOC-02, PDOC-04, PDOC-05, PDOC-06, PDOC-08, PDOC-10, PDOC-11 |
| `download` | 462 | GET …/documents/{documentRequest}/download | `abort_unless` owner + `isDownloadable()` | controller transaction (only write: Ready→Completed) | 'Downloaded' | ppt_document_requests, sys_activity_logs | PDOC-02, PDOC-04, PDOC-05, PDOC-07, PDOC-11, PDOC-12 |

## 6. Findings

### F1 — Errors

#### PDOC-02 · M · D1/ERR-00 + ERR-07 — every method uses the rejected try/catch style, and the read-only methods are wrapped in transactions and try/catch needlessly

| Field | Value |
|---|---|
| **Rule** | D1 (final-audit.md §1) — *no try/catch in controllers; the central handler in `bootstrap/app.php` logs and renders*; ERR-07 (M) — *read-only methods need no try/catch under either variant*. The `catch (\Throwable)` + generic flash is not one of the D2 shapes (no `\DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:41-89` (`index`), `94-126` (`create`), `131-207` (`store`), `212-256` (`show`), `261-308` (`withdraw`), `315-354` (`payInitiate`), `359-456` (`payCallback`), `462-515` (`download`) |
| **Root cause** | The controller was written in the A1 style (try → `DB::transaction` → catch), with extra `ModelNotFoundException`/`HttpExceptionInterface` rethrows added so the 404/403 classes survive. D1 settled that this whole shape is a finding. Read-only methods (`index`, `create`, `show`) do no writes of their own except the activity log, yet they open a `DB::transaction` and swallow every failure into a red flash. |
| **Consequence** | Every unexpected error (a QueryException, a TypeError, a gateway failure) is turned into the same generic red flash "The operation could not be completed." instead of the framework's own 500/JSON rendering, and the response type hacks `View|RedirectResponse` exist only to let the catch return `back()`. |
| **Reproduce** | Create any deliberate failure (e.g. trigger a query error) on these pages and watch the generic flash; conversely, the Laravel-idiom handler in `bootstrap/app.php` already renders JSON 500s for `expectsJson()` callers (verified at `bootstrap/app.php:140-149`). |
| **Fix approach** | Rewrite every method per D1/D2: delete the try/catch, delete `DB::transaction` from the read methods, keep ONE transaction on the real write methods (`store`, `withdraw`, `download`, and the `payCallback` success path), and build the response after the transaction closure. The read methods' return types narrow from `View|RedirectResponse` to `View`. |
| **Plan item** | PDOC-02 in `02-fix-plan.md` §3 (together with PDOC-03, PDOC-04, PDOC-05, PDOC-06, PDOC-08, PDOC-10, PDOC-11, PDOC-12) |

```php
// ParentDocumentController.php:43-45 — CURRENT (the shape every method repeats: try { return DB::transaction( ... )
        try {
            return DB::transaction(function () use ($request) {
```

**Evidence**
```
$ grep -n "try {\|catch (\|DB::transaction" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
43:        try {
44:            return DB::transaction(function () use ($request) {
77:        } catch (ModelNotFoundException $e) {
81:        } catch (\Throwable $e) {
96:        try {
133:        try {
214:        try {
263:        try {
322:        try {
411:        try {
464:        try {
$ grep -n "withExceptions\|expectsJson" bootstrap/app.php
83:    ->withExceptions(function (Exceptions $exceptions): void {
140:            if ($request->expectsJson() || $request->is('api/*')) {
```

#### PDOC-03 · B · ERR-01 — `payInitiate` sends the raw exception message to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (**B**) — *never send exception text to the user; SQL, table and column names leak (SECURITY_RULES 13 wins)* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:343-353`, method `payInitiate()` |
| **Root cause** | The catch on the Razorpay initiation path takes `\Throwable $e` and returns `'error' => $e->getMessage()` to the browser in the JSON body. A gateway/connection/query failure message (hostnames, SQL fragments, Razorpay API internals) is echoed verbatim. |
| **Consequence** | A payment-order failure shows the raw exception text in the parent's payment toast (the blade's JS prints `data.error`), leaking internals; the same message is logged without the exception object (see PDOC-04). |
| **Reproduce** | POST `parent-portal/documents/{id}/pay/initiate` with a request that forces a Razorpay API failure (e.g. invalid key) — the JSON body contains the gateway exception message. Static-only here because a live Razorpay failure was not simulated (D4). |
| **Fix approach** | Remove the catch (D1). Unexpected failures fall to the central handler, which renders `{"success": false, "message": "An unexpected error occurred."}` with 500 for `expectsJson()` callers (`bootstrap/app.php:140-149`); the blade's toast already falls back to `data.error || 'Failed to create payment order.'`. |
| **Plan item** | PDOC-03 in `02-fix-plan.md` §3 (part of the same controller rewrite as PDOC-02) |

```php
// ParentDocumentController.php:343-353 — CURRENT
        } catch (\Throwable $e) {
            Log::error('[ParentDoc] payInitiate failed', [
                'request_id' => $documentRequest->id,
                'error'      => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error'   => $e->getMessage(),
            ], 422);
        }
```

**Evidence**
```
$ sed -n '343,353p' Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
        } catch (\Throwable $e) {
            Log::error('[ParentDoc] payInitiate failed', [
                'request_id' => $documentRequest->id,
                'error'      => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error'   => $e->getMessage(),
            ], 422);
        }
```

#### PDOC-04 · M · ERR-05 — every failure path logs only `$e->getMessage()`, losing the trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; getMessage() alone loses the trace* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:82, 119, 203, 249, 304, 344, 441, 511` |
| **Root cause** | All eight catch blocks call `Log::error('...', ['error' => $e->getMessage()])` (or `'error' => $e->getMessage()`). The message alone cannot show where the exception was thrown. Note the central handler (`bootstrap/app.php:86-98`) already logs every reported exception with class/file/line, so the controller's own message-only log is redundant. |
| **Consequence** | Debugging any of these failures requires guessing the origin; the class/file/line that the central logger would have captured is never recorded for these paths. |
| **Reproduce** | Static only — trigger any catch path and compare the log line (message only) with what `report($e)` would have written. |
| **Fix approach** | Fold into the D1 rewrite (PDOC-02): the catches disappear, so the redundant logging disappears with them. |
| **Plan item** | PDOC-04 in `02-fix-plan.md` §3 |

```php
// ParentDocumentController.php:203 — CURRENT (one of eight identical lines)
            Log::error('ParentDocumentController::store failed', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "Log::error" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
82:            Log::error('ParentDocumentController::index failed', ['error' => $e->getMessage()]);
119:            Log::error('ParentDocumentController::create failed', ['error' => $e->getMessage()]);
203:            Log::error('ParentDocumentController::store failed', ['error' => $e->getMessage()]);
249:            Log::error('ParentDocumentController::show failed', ['error' => $e->getMessage()]);
304:            Log::error('ParentDocumentController::withdraw failed', ['error' => $e->getMessage()]);
344:            Log::error('[ParentDoc] payInitiate failed', [
441:            Log::error('ParentDocumentController::payCallback failed', [
511:            Log::error('ParentDocumentController::download failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### PDOC-05 · M · TXN-05 — responses (view / redirect / download) are built inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data (a model, a count); build `redirect()` / `response()` after it* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:72-74 (index), 111 (create), 185-187 (store), 233 (show), 286-288 (withdraw), 495 (download)` |
| **Root cause** | Each method does `return DB::transaction(function () { …; return redirect()/view()/response()->download(...); })` — the HTTP object is constructed inside the closure. For `redirect()->with('success', …)` the flash is attached while a transaction is still open; `response()->download()` hands a file stream back through the closure. |
| **Consequence** | Not a crash, but the shape makes the transaction boundary unclear and forces `View|RedirectResponse` return types; the D1 rewrite removes the whole problem. |
| **Reproduce** | Static only — read the closure bodies. |
| **Fix approach** | Fold into the D1 rewrite (PDOC-02): let the closure return the model/count, build the response after it. |
| **Plan item** | PDOC-05 in `02-fix-plan.md` §3 |

```php
// ParentDocumentController.php:185-187 — CURRENT (store)
                return redirect()
                    ->route('parent-portal.documents.index')
                    ->with('success', "Document request submitted. Request No: {$requestNumber}");

            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ grep -n "return redirect()\|return view(\|return response()->download" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
72:                return view('parentportal::documents.index', compact(
111:                return view('parentportal::documents.create', compact('child', 'documentTypes'));
185:                return redirect()
233:                return view('parentportal::documents.show', compact('child', 'documentRequest'));
286:                return redirect()
495:                return response()->download($media->getPath(), $media->file_name);
```

#### PDOC-06 · M · TXN-04 — the parent-side `activityLog` calls for the payment flow run after `PaymentService`'s own transaction has committed

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes — not after commit* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:325-336 (payInitiate), 393-403 (payCallback failure branch)` |
| **Root cause** | `PaymentService::initiate()` and `PaymentService::markFailed()` each wrap their own writes in `DB::transaction` (verified: `Modules/Payment/app/Services/PaymentService.php:35` and `:136`). The controller's `activityLog('PaymentInitiated', …)` and `activityLog('PaymentFailed', …)` run after those commits. If the parent-side log insert fails, the payment row is already persisted with no parent-side activity row. |
| **Consequence** | An audit gap on the payment-initiated and payment-failed paths: the payment itself is always audited by the service's own `AuditService`, but the parent-portal log entry is best-effort post-commit. |
| **Reproduce** | Static only — the write order is visible in the two files. |
| **Fix approach** | In `payCallback`'s failure branch, wrap the `markFailed()` + `activityLog('PaymentFailed')` pair in one controller-level `DB::transaction` (nested savepoint inside the service's own transaction). For `payInitiate`, wrap `initiate()` + `activityLog('PaymentInitiated')` in one controller-level transaction. |
| **Plan item** | PDOC-06 in `02-fix-plan.md` §3 (part of the payCallback rewrite) |

```php
// ParentDocumentController.php:387-403 — CURRENT (payment-verification failure branch)
        if (! $verified) {
            $this->paymentService->markFailed($payment, 'Signature verification failed', [
                'razorpay_order_id'   => $request->input('razorpay_order_id'),
                'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            ]);

            activityLog(auth()->user(), 'PaymentFailed', [
                'message' => 'Duplicate-document payment failed: signature verification failed',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
                'document_request_id' => $documentRequest->id,
                'reason' => 'Signature verification failed',
            ]);
```

**Evidence**
```
$ grep -n "DB::transaction\|public function initiate\|public function markFailed\|public function markSuccess" Modules/Payment/app/Services/PaymentService.php
33:    public function initiate(Payable $payable, string $gatewayCode, ?int $userId = null, array $offlineData = []): array
35:        return DB::transaction(function () use ($payable, $gatewayCode, $userId, $offlineData) {
111:    public function markSuccess(Payment $payment, array $gatewayPayload): void
136:    public function markFailed(Payment $payment, string $reason, array $payload = []): void
```

#### PDOC-08 · M · TXN-06 (lowered from H) — `payCallback` checks `fee_paid` outside any lock; two simultaneous callbacks can both pass

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H, lowered to M with reason) — *check-then-act needs a lock or a unique index; `exists()` then `create()`/`update()` races*. Lowered: the worst outcome is two `markSuccess` calls, two `Paid` activity rows and a duplicated `PaymentSucceeded` event — Razorpay charges the card once, so there is no double billing. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:374-376` (the `fee_paid` read) and `411-439` (the transaction that writes it) |
| **Root cause** | The idempotency guard `if ($documentRequest->fee_paid) …` reads the model before the `DB::transaction`. Two concurrent identical callbacks (a retried checkout handler, or a double-fired `handler()` in the blade) can both read `fee_paid === false`, then both enter the transaction and both mark the payment success + write `fee_paid = true`. |
| **Consequence** | Duplicate `Paid` activity rows and a duplicated success event (which could double-notify the school office); the financial charge itself happens once at the gateway. |
| **Reproduce** | Static only — a live double-fire was not simulated (D4). Read the check at line 374 and the write at line 418. |
| **Fix approach** | Move the re-check inside the transaction and lock the request row: `ParentDocumentRequest::whereKey($documentRequest->getKey())->lockForUpdate()->firstOrFail()` inside the closure, then re-check `fee_paid` on the locked row. |
| **Plan item** | PDOC-08 in `02-fix-plan.md` §2 (arms a latent defect; part of the payCallback rewrite) |

```php
// ParentDocumentController.php:374-376 — CURRENT
        if ($documentRequest->fee_paid) {
            return response()->json(['success' => false, 'message' => 'Fee already paid.'], 422);
        }
```

**Evidence**
```
$ grep -n "fee_paid" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
374:        if ($documentRequest->fee_paid) {
418:                'fee_paid'          => true,
```

### F4 — Validation and input

#### PDOC-09 · H · VAL-07 — a document request whose fee was already paid can still be withdrawn, and there is no refund path

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M, raised to H with reason) — *cross-field / business checks (cap not exceeded, same term, etc.) go in the Form Request's `after()` hook, not hand-written in the controller*. Raised: the wrong result is a parent who paid a fee and then withdraws — the money stays collected (no refund flow) and the request is deleted. |
| **Where** | `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:171-174` (`isWithdrawable()`), `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:268` (withdraw guard), `Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php` (no `after()` hook) |
| **Root cause** | `isWithdrawable()` returns `status === Pending` and ignores `fee_paid`. `payCallback` sets `fee_paid = true` but never changes the status, so a still-`Pending` request that was paid is withdrawable. The withdraw button in both blades is rendered from `isWithdrawable()` (index.blade.php:219, show.blade.php:372), so the parent sees and can press it; the controller guard only checks `isWithdrawable()`. |
| **Consequence** | A parent pays ₹X via Razorpay, then withdraws the request in the same session: the request is soft-deleted, the payment stays `success`, and no refund is offered anywhere. 0 live rows in this tenant have a payment yet, so no money is currently trapped — the path exists. |
| **Reproduce** | Pay a fee on a Pending request (callback sets fee_paid), reload the list, and press the withdraw button — the request disappears while the payment remains successful. |
| **Fix approach** | Behaviour change → DECISION. Recommended: block withdrawal once `fee_paid` (add `&& ! $this->fee_paid` to `isWithdrawable()`, and an `after()`/`withValidator()` check on `WithdrawParentDocumentRequest` with the fixed message "Fee already paid — contact the school office for a refund."); the buttons disappear automatically because they use the same method. |
| **Plan item** | PDOC-09 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentDocumentRequest.php:171-174 — CURRENT
    public function isWithdrawable(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }
```

**Evidence**
```
$ grep -n "isWithdrawable\|fee_paid" Modules/ParentPortal/app/Models/ParentDocumentRequest.php Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
Modules/ParentPortal/app/Models/ParentDocumentRequest.php:171:    public function isWithdrawable(): bool
Modules/ParentPortal/app/Models/ParentDocumentRequest.php:173:        return $this->status === self::STATUS_PENDING;
Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:268:                abort_unless($documentRequest->isWithdrawable(), 422, 'This request can no longer be withdrawn.');
```

### F5 — Routes

#### PDOC-07 · H · RTE-01 — the GET `download` route performs a state change (Ready → Completed + audit row)

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:470-476` (the Ready→Completed transition) + `Modules/ParentPortal/routes/web.php:148` (GET route) |
| **Root cause** | `download()` is a `GET` route whose handler, when the request is `Ready`, updates `status` to `Completed`, sets `fulfilled_at`, and logs `Downloaded`. A GET that writes violates RTE-01: the download button is a plain `<a href>` (index.blade.php:215, show.blade.php:365), so any prefetch/refresh/email-client link hit performs the transition even if the file never reaches the user, and the audit row says "Downloaded" when nothing was downloaded. |
| **Consequence** | A status transition and an audit entry occur without a deliberate user action; the request is marked Completed while the parent may have received nothing. |
| **Reproduce** | Open a Ready request's download URL in a browser (or let a prefetcher hit it) — the request flips to Completed and an activity row is written before any file is confirmed delivered. |
| **Fix approach** | Behaviour/route change → DECISION: change the download route to POST submitted as a form (like the withdraw button), or move the transition to a separate POST route, or drop the auto-transition and let the school mark Completed on seeing the `Downloaded` log. |
| **Plan item** | PDOC-07 in `02-fix-plan.md` §9 (DECISION) |

```php
// ParentDocumentController.php:470-476 — CURRENT
                // Mark as Completed on first download
                if ($documentRequest->status === ParentDocumentRequest::STATUS_READY) {
                    $documentRequest->update([
                        'status'       => ParentDocumentRequest::STATUS_COMPLETED,
                        'fulfilled_at' => $documentRequest->fulfilled_at ?? now(),
                    ]);
                }
```

**Evidence**
```
$ sed -n '148p' Modules/ParentPortal/routes/web.php
    Route::get('/{documentRequest}/download', [ParentDocumentController::class, 'download'])->name('download');
$ grep -n "STATUS_READY\|STATUS_COMPLETED\|->update(\[" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
471:                if ($documentRequest->status === ParentDocumentRequest::STATUS_READY) {
472:                    $documentRequest->update([
473:                        'status'       => ParentDocumentRequest::STATUS_COMPLETED,
```

### F6 — Controller shape

#### PDOC-10 · M · CTL-02 — `payCallback()` is 98 lines long

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:359-456` |
| **Root cause** | One method holds the whole callback: ownership checks, ULID lookup, payable-match check, fee_paid idempotency, signature verification, the failure branch (markFailed + log), and the success transaction. |
| **Consequence** | Hard to read, and the TXN-06 race (PDOC-08) sits exactly at the boundary between the checks and the transaction. |
| **Reproduce** | Static only. |
| **Fix approach** | Fold into the D1 rewrite (PDOC-02): the method shrinks when the try/catch and the duplicated context arrays are removed; the signature-verification branch can be a private helper. |
| **Plan item** | PDOC-10 in `02-fix-plan.md` §3 |

```php
// ParentDocumentController.php:359 — CURRENT
    public function payCallback(PayCallbackParentDocumentRequest $request, ParentDocumentRequest $documentRequest): JsonResponse
```

**Evidence**
```
$ awk 'NR>=359 && NR<=456' Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php | wc -l
98
```

#### PDOC-11 · M · CTL-05 (with CTL-08) — the 4-key activity-log context array is copy-pasted nine times, and the `request()` helper is called instead of the injected `$request`

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload repeated 9×*; CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:64-69, 103-108, 173-179, 224-229, 275-280, 327-332, 395-400, 429-434, 484-489` |
| **Root cause** | Every `activityLog()` call repeats `['student_id' => …, 'student_name' => …, 'module' => 'ParentPortal', 'route' => request()->route()?->getName()]`; the `route()` value uses the global `request()` helper even though every method already has an injected `Request`. |
| **Consequence** | Any change to the context shape (or the route-name key) must be made in nine places; the helper call is a style deviation. |
| **Reproduce** | Static only. |
| **Fix approach** | Add one private helper `logContext(Request $request, ?Student $child): array` and replace all nine arrays; the helper uses the injected `$request`. |
| **Plan item** | PDOC-11 in `02-fix-plan.md` §3 (applied before PDOC-02) |

```php
// ParentDocumentController.php:64-69 — CURRENT (one of nine copies)
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
```

**Evidence**
```
$ grep -c "'module' => 'ParentPortal'" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
9
$ grep -n "request()->route()" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
68:                        'route' => request()->route()?->getName(),
107:                        'route' => request()->route()?->getName(),
178:                        'route' => request()->route()?->getName(),
228:                        'route' => request()->route()?->getName(),
279:                        'route' => request()->route()?->getName(),
331:                        'route' => request()->route()?->getName(),
399:                        'route' => request()->route()?->getName(),
433:                        'route' => request()->route()?->getName(),
488:                        'route' => request()->route()?->getName(),
```

#### PDOC-12 · L · CTL-04 — `download()` has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:462` |
| **Root cause** | `public function download(Request $request, ParentDocumentRequest $documentRequest)` — no `: BinaryFileResponse`. |
| **Consequence** | Minor: the method's contract is implicit, and the D1 rewrite needs the type anyway. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `: BinaryFileResponse` (import `Symfony\Component\HttpFoundation\BinaryFileResponse`) in the D1 rewrite. |
| **Plan item** | PDOC-12 in `02-fix-plan.md` §3 |

```php
// ParentDocumentController.php:462 — CURRENT
    public function download(Request $request, ParentDocumentRequest $documentRequest)
```

**Evidence**
```
$ grep -n "public function" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php | tail -1
462:    public function download(Request $request, ParentDocumentRequest $documentRequest)
```

### F7 — Models

#### PDOC-01 · B · VAL-01/MDL — `store()` can never create a request: `document_type`, `urgency` and `status` are silently dropped by mass assignment, and the NOT NULL `*_option_id` columns stay null

| Field | Value |
|---|---|
| **Rule** | VAL-01 (**B**) — *never write unvalidated/misread input into a model; here the strong form of the same defect: the keys passed to `create()` are not `$fillable`, so Eloquent drops them before the mutators can run* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:158-170` (`ParentDocumentRequest::create([...])`), `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:47-63` (`$fillable` lists only `*_option_id`), `:104-138` (the `document_type`/`urgency`/`status` mutators that would map the strings), `database/migrations/tenant/2026_06_16_105225_create_ppt_document_requests_table.php:17,23,28` (the three columns, all NOT NULL with FK) |
| **Root cause** | The model stores dropdown ids (`document_type_option_id`, `urgency_option_id`, `status_option_id`) and exposes string accessors (`document_type`, `urgency`, `status`) with mutators that resolve the strings to ids via `PptDropdownResolver::id()`. But `$fillable` lists only the id columns, so `create([..., 'document_type' => $validated['document_type'], 'urgency' => …, 'status' => STATUS_PENDING, ...])` — via `Model::fill()` → `fillableFromArray()` — drops all three string keys before `setAttribute()` can fire the mutators. The INSERT then leaves the three NOT NULL columns null and fails with a `QueryException`, which the generic catch turns into "The operation could not be completed." |
| **Consequence** | **Every** submit of the Request Duplicate form fails with the red flash and no row is created (the `document_type`/`urgency`/`status` columns are NOT NULL, so there is no silent-insert fallback); the success flash at lines 185-187 is dead code. Proven without writing to the DB below. |
| **Reproduce** | Parent Portal → Documents → Request Duplicate → pick a type, type a reason, submit → red flash "The operation could not be completed." every time; the list stays empty. |
| **Fix approach** | Add the accessor keys `document_type`, `urgency`, `status` to `ParentDocumentRequest::$fillable` (keep the `*_option_id` keys so admin-side direct-id writes still work). The mutators then map the validated strings to the dropdown ids. |
| **Plan item** | PDOC-01 in `02-fix-plan.md` §1 |

```php
// ParentDocumentController.php:158-170 — CURRENT
                $documentRequest = ParentDocumentRequest::create([
                    'request_number' => $requestNumber,
                    'student_id'     => $child->id,
                    'guardian_id'    => $guardianId,
                    'document_type'  => $validated['document_type'],
                    'reason'         => $validated['reason'],
                    'urgency'        => $validated['urgency'],
                    'status'         => ParentDocumentRequest::STATUS_PENDING,
                    'fee_required'   => 0.00,
                    'fee_paid'       => false,
                    'is_active'      => true,
                    'created_by'     => auth()->id(),
                ]);
```

**Evidence**
```
$ php artisan tinker --execute '
$m = new \Modules\ParentPortal\Models\ParentDocumentRequest;
$m->fill(["document_type" => "TC", "reason" => "Test reason", "urgency" => "Normal", "status" => "Pending", "is_active" => true]);
echo "attributes: ".json_encode($m->getAttributes())."\n";
echo "has document_type_option_id: ".var_export(array_key_exists("document_type_option_id", $m->getAttributes()), true)."\n";
'
attributes: {"reason":"Test reason","is_active":true}
has document_type_option_id: false

$ grep -n "->nullable()" database/migrations/tenant/2026_06_16_105225_create_ppt_document_requests_table.php
33:            $table->text('admin_notes')->nullable();
37:            $table->string('payment_reference', 100)->nullable();
47:            $table->unsignedInteger('fulfilled_media_id')->nullable();
(no ->nullable() on document_type_option_id / urgency_option_id / status_option_id — they are NOT NULL)
```

#### PDOC-13 · B · MDL-05/TEN-01 — `ParentDocumentRequest` uses Spatie `InteractsWithMedia` without overriding `getMediaModel()`

| Field | Value |
|---|---|
| **Rule** | MDL-05 (**B**) / TEN-01 — *every model using `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the wrong DB (cross-tenant leak)* |
| **Where** | `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:18-23` |
| **Root cause** | The model `use`s `HasFactory, SoftDeletes, InteractsWithMedia` but never overrides `getMediaModel()`. The fulfilled document is deliberately stored in the central `sys_media` table (pinned `connection = 'mysql'` via `Modules/Prime/app/Models/Media.php:7`) and referenced by `fulfilled_media_id`; the controller reads it with `\Modules\Prime\Models\Media::find(...)` (line 479). But the trait still advertises a media collection: any future `$request->getMedia()` / `addMedia()` call in tenant context would use the default Spatie Media model on the tenant connection and fail or leak. Grep found no current caller of the collection on this model, so it is latent — not yet triggered. |
| **Consequence** | A latent cross-DB trap: a future media-collection call on a tenant request would write to / read from the wrong database, or 500 if the tenant DB has no `sys_media` table. |
| **Reproduce** | Static only — `grep -rn "ParentDocumentRequest" Modules --include=*.php` shows no `addMedia`/`getMedia` caller today. |
| **Fix approach** | Override `getMediaModel(): string` to return `\Modules\Prime\Models\Media::class`, matching the intended central `sys_media` store (the rulebook's own remedy). |
| **Plan item** | PDOC-13 in `02-fix-plan.md` §5 |

```php
// ParentDocumentRequest.php:18-23 — CURRENT
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class ParentDocumentRequest extends BaseModel implements Payable, HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ grep -n "getMediaModel\|InteractsWithMedia" Modules/ParentPortal/app/Models/ParentDocumentRequest.php
18:use Spatie\MediaLibrary\HasMedia;
19:use Spatie\MediaLibrary\InteractsWithMedia;
23:    use HasFactory, SoftDeletes, InteractsWithMedia;
$ grep -rn "addMedia\|getMedia(\|getFirstMedia" Modules --include="*.php" | grep -i "document" | head
(no hits — nothing calls the collection on ParentDocumentRequest)
```

### F9 — Queries and performance

#### PDOC-15 · L · QRY-02 (lowered from H) — the two list queries on the documents page use an unbounded `->get()`

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H, lowered to L with reason) — *lists are paginated; no unbounded `->get()` feeding a list page*. Lowered and accepted exactly as ParentEventController PEC-07 did: both lists are already scoped to one child — a handful of report cards and a handful of requests per child — so pagination would fight the blade's in-memory `whereIn('status', …)` stats without buying anything. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:48-58` |
| **Root cause** | `HpcReport::where('student_id', $child->id)->where('status', 'Published')->…->get()` and `ParentDocumentRequest::forStudent($child->id)->active()->…->get()` collect every row into memory. |
| **Consequence** | None in practice at this data size; noted for consistency with the module's accepted pattern. |
| **Reproduce** | Static only; 5 live rows in the tenant. |
| **Fix approach** | None — accepted, informational. |
| **Plan item** | none — see plan §10 |

```php
// ParentDocumentController.php:48-58 — CURRENT
                $reportCards = HpcReport::where('student_id', $child->id)
                    ->where('status', 'Published')
                    ->with(['academicSession', 'template', 'term'])
                    ->orderByDesc('report_date')
                    ->get();

                // ── Document requests raised by this parent for this child ─────────
                $documentRequests = ParentDocumentRequest::forStudent($child->id)
                    ->active()
                    ->orderByDesc('created_at')
                    ->get();
```

**Evidence**
```
$ grep -n "->get()" Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php
52:                    ->get();
58:                    ->get();
```

#### PDOC-17 · M · QRY-12 / VIEW-02 — the dropdown accessors ignore the loaded `*Option` relations, so the list page runs one `sys_dropdown_table` query per attribute per row

| Field | Value |
|---|---|
| **Rule** | QRY-12 (M) — *identical queries repeated in one request → resolve once*; VIEW-02 (M) — *relations used inside `@foreach` are eager-loaded (lazy loads in a loop = N+1)* |
| **Where** | `Modules/ParentPortal/app/Models/ParentDocumentRequest.php:104-138` (the three accessors), `Modules/ParentPortal/app/Http/Controllers/ParentDocumentController.php:55-58` (the list query — no `with(['statusOption','urgencyOption','documentTypeOption'])`), and the index blade (`documents/index.blade.php:166-199` reads `$dr->status`, `$dr->urgency`, `$dr->documentTypeLabel()` per row) |
| **Root cause** | `getStatusAttribute()` / `getUrgencyAttribute()` / `getDocumentTypeAttribute()` each call `PptDropdownResolver::value(...)` → `Dropdown::find($id)` — a fresh query per attribute read, never consulting the model's own `statusOption`/`urgencyOption`/`documentTypeOption` BelongsTo relations (defined at lines 89-102). The controller's list query does not eager-load them, so the blade's `@foreach` triggers ~6 dropdown queries per row (status is read three times per row). This is the same mechanism sibling reports found in `EventRsvp`/`ConsentForm`; the resolver itself is not memoised (owned by ParentPtmController report — cross-cutting note in §7). |
| **Consequence** | The Documents list page issue ~1 + 6N queries against `sys_dropdown_table`; with 5 rows ≈ 31 queries, scaling with every request a parent raises. |
| **Reproduce** | Open `parent-portal/documents` with N requests and watch the query log/DB profiler. |
| **Fix approach** | Make the accessors prefer the loaded relation (`$this->statusOption?->value ?? PptDropdownResolver::value(...)`) and eager-load the three relations in `index()` (and `show()`'s `load()`). |
| **Plan item** | PDOC-17 in `02-fix-plan.md` §6 |

```php
// ParentDocumentRequest.php:128-131 — CURRENT
    public function getStatusAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
    }
```

**Evidence**
```
$ grep -n "PptDropdownResolver::value" Modules/ParentPortal/app/Models/ParentDocumentRequest.php
106:        return PptDropdownResolver::value($this->attributes['document_type_option_id'] ?? null);
118:        return PptDropdownResolver::value($this->attributes['urgency_option_id'] ?? null);
130:        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
$ php artisan tinker --execute 'tenancy()->initialize(\Modules\Prime\Models\Tenant::first()); foreach (\Modules\ParentPortal\Models\ParentDocumentRequest::all() as $r) { echo $r->id." status=".$r->status." type=".$r->document_type."\n"; }'
1 status='Completed' type='Bonafide'
2 status='Completed' type='Bonafide'
3 status='Completed' type='Bonafide'
4 status='Completed' type='Bonafide'
5 status='Completed' type='Bonafide'
```

### F12 — Style

#### PDOC-16 · L · STY-01 — six in-scope PHP files are missing `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php:1-3`, `StoreParentDocumentRequest.php:1-3`, `WithdrawParentDocumentRequest.php:1-3`, `PayInitiateParentDocumentRequest.php:1-3`, `PayCallbackParentDocumentRequest.php:1-3`, `Modules/Prime/app/Models/Media.php:1-3` |
| **Root cause** | All six files start with `<?php\n\nnamespace …` without the declare. The controller and model already have it. |
| **Consequence** | Inconsistent weak typing across the Request/Media classes; the module standard is strict. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after `<?php` in each of the six files. |
| **Plan item** | PDOC-16 in `02-fix-plan.md` §8 |

```php
// PayCallbackParentDocumentRequest.php:1-3 — CURRENT (same first lines in all six)
<?php

namespace Modules\ParentPortal\Http\Requests;
```

**Evidence**
```
$ for f in Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php Modules/ParentPortal/app/Http/Requests/StoreParentDocumentRequest.php Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php Modules/ParentPortal/app/Http/Requests/PayInitiateParentDocumentRequest.php Modules/ParentPortal/app/Http/Requests/PayCallbackParentDocumentRequest.php Modules/Prime/app/Models/Media.php; do head -1 "$f" | grep -q "strict_types" || echo "missing declare: $f"; done
missing declare: Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php
missing declare: Modules/ParentPortal/app/Http/Requests/StoreParentDocumentRequest.php
missing declare: Modules/ParentPortal/app/Http/Requests/WithdrawParentDocumentRequest.php
missing declare: Modules/ParentPortal/app/Http/Requests/PayInitiateParentDocumentRequest.php
missing declare: Modules/ParentPortal/app/Http/Requests/PayCallbackParentDocumentRequest.php
missing declare: Modules/Prime/app/Models/Media.php
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong data | 2 delete-before-store | 3 duplicate impls | 4 soft-delete × unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | PDOC-01 (never writes at all) | ok | ok (one request-number generator) | ok (unique request_number; `withTrashed()` considered) | ok (`lockForUpdate` on the number source) | ok (owner + FormRequest) | ok after PDOC-01 (flash becomes reachable) | ok (feature intended; currently dead by PDOC-01) |
| `withdraw` | ok (only is_active/deleted_at) | ok (soft delete only) | ok | ok (soft delete leaves the row for the number sequence) | ok (single row lock not needed — idempotent-ish) | ok (owner + isWithdrawable) | ok | PDOC-09 (paid requests can be withdrawn, no refund) |
| `payInitiate` | ok (payment row via service) | ok | ok (one initiate path) | — (no unique on payment rows here) | ok (service transaction) | ok (owner + requiresPayment) | ok | ok |
| `payCallback` | ok (only fee_paid/payment_reference) | ok | ok (one verification path) | ok (`payment_reference` unique; nullable so multi-NULL is fine) | **PDOC-08** (fee_paid checked without lock) | ok (owner + payable match + HMAC signature `hash_equals` verified in RazorpayGateway:84-101) | ok | ok |
| `download` | ok (status/fulfilled_at only when Ready) | ok | ok (one download path) | ok | ok (status check benign) | ok (owner + isDownloadable) | **PDOC-07** ("Downloaded" logged on GET without proof of delivery) | ok |

The read-only methods (`index`, `create`, `show`) write only the activity log; their only findings are the D1/ERR-07 shape (PDOC-02) and the log-context repetitions (PDOC-11).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` (↗ ParentPtmController) | `value()` runs `Dropdown::find` on every call with no memo; this is the mechanism behind PDOC-17's N+1. A per-request memo would fix every accessor at once. | QRY-12, SVC-05 | ParentPtmController report |
| Same fillable-vs-mutator drop bug elsewhere in the module | `ConsentFormResponse.response` (CONSENT-10) and `EventRsvp.rsvp_status` (PEC) have the identical "string key not in `$fillable`, mutator never fires" defect. PDOC-01 is the third instance — a module-wide family. | VAL-01 | module summary / per-owner reports |
| `Modules/Prime/app/Models/Media.php` (claimed here) | Central `sys_media` (`connection = 'mysql'`) holds every tenant's media with no tenant discriminator; `download()` trusts `fulfilled_media_id`. The parent surface never writes that column (only admin does), so an attacker cannot set it; an admin mis-set would serve another student's document. | SEC-05 | accepted design; note only |
| `bootstrap/app.php` render closure (common) | Already renders JSON 500s for `expectsJson()` callers — the D1 rewrite of `payInitiate`/`payCallback` relies on this; verified at lines 140-149. | — | none |
| Parent portal authorization model (common) | Parents are gated by `ParentPortalMiddleware` (user_type + guardian + child link), not permission keys; every `ParentDocumentController` method adds a record-level ownership `abort_unless` — consistent with the module. | AUTH-01/03 | none |

## 8. Not covered, and why

- The Razorpay payment flow was not exercised end-to-end (no live order, D4, and no external calls); the callback's HMAC verification was read in `RazorpayGateway::verify()` (owned by the ParentFeePaymentController report) and is sound.
- The three blades were not rendered in a browser; they were read and compile-shaped (no `{!! !!}`, no Blade queries beyond accessor calls — the accessor N+1 is PDOC-17).
- `HpcReport` (vault query), `Payment`/`PaymentService`/`GatewayManager`/`RazorpayGateway`, `ParentContextService`, `PptDropdownResolver` and `ParentPortalMiddleware` are audited by their owner reports; only how this controller uses them was checked here.
- The `student_id`-scoped lists were judged by the 5-row tenant sample; a high-volume tenant was not sampled.