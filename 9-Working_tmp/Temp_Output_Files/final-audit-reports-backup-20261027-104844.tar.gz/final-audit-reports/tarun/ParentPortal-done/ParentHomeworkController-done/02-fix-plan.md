# Fix Plan — ParentPortal / ParentHomeworkController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/routes/web.php` | shared module route file; the two homework routes (lines 67-70) work as-is |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the tarun/ParentPortal-done/ParentDashboardController report |
| `Modules/ParentPortal/resources/views/layouts/**` | shared layouts (app, _header, _sidebar) |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by the tarun/ParentPortal-done/ParentHealthController report |
| `Modules/ParentPortal/resources/views/homework/show.blade.php` | used by this controller only, but the fix is made in the CONTROLLER (PHW-05 passes the right variables); the blade itself is not edited |
| `config/media-library.php` | app-wide config; PHW-09 fixes the two models instead of the config |
| `Modules/StudentProfile/app/Models/Student.php` | owned by the gaurav/StudentProfile report |
| Any other `Modules/LmsHomework/**` file (e.g. `LmsStorageService`) | out of scope of this controller's audit |
| `config/permissionslist.php`, any migration | no permission or schema change is needed |

## 1. Blockers reachable today

- [x] **PHW-05** · B · VIEW · `ParentHomeworkController.php:78-120` — rewrite `show()` so the detail page actually renders: pass `homework`/`submission` to the blade, guard a soft-deleted homework, remove the try/catch + `DB::transaction` (also fixes PHW-02, PHW-04, PHW-08).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php`
  - **Before** (`ParentHomeworkController.php:78-120`):
    ```php
    public function show(Request $request, int $id): View|RedirectResponse
    {
        try {
            return DB::transaction(function () use ($request, $id) {
                $child      = $this->context->resolveChild($request);
                $assignment = HomeworkAssignment::where('student_id', $child->id)
                    ->where('id', $id)
                    ->with([
                        'homework.subject',
                        'homework.difficultyLevel',
                        'submission',
                    ])
                    ->firstOrFail();

                $attachments = $assignment->homework->getMedia('homework_files');

                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed homework assignment',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'homework_assignment_id' => $assignment->id,
                ]);

                return view('parentportal::homework.show', compact('child', 'assignment', 'attachments'));

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('ParentHomeworkController::show failed', ['error' => $e->getMessage()]);

            // The declared return type is widened to View|RedirectResponse rather than
            // forcing a JSON body here: this renders a page, and its error path has always
            // been a redirect. Declared `: View` alone, that redirect was a TypeError.
            return back()->with('error', 'The operation could not be completed.');
        }
    }
    ```
  - **After:**
    ```php
    public function show(Request $request, int $id): View
    {
        // PHW-05 · 2026-10-13 — read-only page; D1: no try/catch, no transaction.
        // resolveChild() and firstOrFail() surface their own 302/404 via the central handler.
        $child      = $this->context->resolveChild($request);
        $assignment = HomeworkAssignment::where('student_id', $child->id)
            ->where('id', $id)
            ->with([
                'homework.subject',
                'homework.difficultyLevel',
                'homework.topic',
                'homework.lesson',
                'homework.class',
                'homework.section',
                'submission',
            ])
            ->firstOrFail();

        // PHW-05 · 2026-10-13 — the assignment row survives a soft-deleted homework; the
        // index page filters these out (index() line 41), so the detail page must too.
        if ($assignment->homework === null) {
            abort(404, 'The homework for this assignment is no longer available.');
        }

        $homework    = $assignment->homework;
        $submission  = $assignment->submission;
        $attachments = $homework->getMedia('homework_files');

        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed homework assignment',
            'context' => [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ],
            'homework_assignment_id' => $assignment->id,
        ]);

        return view('parentportal::homework.show', compact('child', 'assignment', 'homework', 'submission', 'attachments'));
    }
    ```
  - **Verify:** `grep -n "compact('child', 'assignment', 'homework', 'submission', 'attachments')\|DB::transaction\|catch (\Throwable" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php`
  - **Expect:** one line with the new `compact(...)`; no `DB::transaction` line and no `catch (\Throwable` line remain in the file.
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None — the defects that arm others (missing eager loads, swallowed errors) are all inside the PHW-05 rewrite in §1.

## 3. Errors & transactions (F1/F2)

None as direct items — PHW-01 is the DECISION item in §9 (the only standalone F1 issue); PHW-02/PHW-03/PHW-04 are fixed by PHW-05 (see §10).

## 4. Authorization (F3)

None — authorization is clean (role middleware + guardian scoping).

## 5. Validation, routes, models (F4/F5/F7)

- [x] **PHW-09** · B · MDL-05/TEN-01 · `Homework.php` + `HomeworkSubmission.php` — keep both tenant media models' Spatie rows in the tenant's `sys_media` by overriding `getMediaModel()`.
  - **Touches:** `Modules/LmsHomework/app/Models/Homework.php`, `Modules/LmsHomework/app/Models/HomeworkSubmission.php`
  - **Before** (`Homework.php:28-31`):
    ```php
    class Homework extends BaseModel implements HasMedia
    {
        use HasFactory, InteractsWithMedia, SoftDeletes;
        use SanitizesRichText;
    ```
  - **After:**
    ```php
    class Homework extends BaseModel implements HasMedia
    {
        use HasFactory, InteractsWithMedia, SoftDeletes;
        use SanitizesRichText;

        /**
         * PHW-09 · 2026-10-13 — keep this tenant model's media rows in the tenant's
         * sys_media, not the central (cross-tenant) one. Same pattern as User::getMediaModel().
         */
        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Before** (`HomeworkSubmission.php:16-19`):
    ```php
    class HomeworkSubmission extends BaseModel implements HasMedia
    {
        use HasFactory, InteractsWithMedia, SoftDeletes;
        use \App\Traits\SanitizesRichText;
    ```
  - **After:**
    ```php
    class HomeworkSubmission extends BaseModel implements HasMedia
    {
        use HasFactory, InteractsWithMedia, SoftDeletes;
        use \App\Traits\SanitizesRichText;

        /**
         * PHW-09 · 2026-10-13 — keep this tenant model's media rows in the tenant's
         * sys_media, not the central (cross-tenant) one. Same pattern as User::getMediaModel().
         */
        public function getMediaModel(): string
        {
            return \App\Models\TenantMedia::class;
        }
    ```
  - **Verify:** `grep -n "function getMediaModel" Modules/LmsHomework/app/Models/Homework.php Modules/LmsHomework/app/Models/HomeworkSubmission.php`
  - **Expect:** two `    public function getMediaModel(): string` lines, one per file.
  - **Effort:** S

- [x] **PHW-12** · M · MDL-02 · `HomeworkSubmission.php` + `HomeworkAssignment.php` — cast the boolean/int columns that the migrations define.
  - **Touches:** `Modules/LmsHomework/app/Models/HomeworkSubmission.php`, `Modules/LmsHomework/app/Models/HomeworkAssignment.php`
  - **Before** (`HomeworkSubmission.php:48-56`):
    ```php
    protected $casts = [
        'submitted_at'   => 'datetime',
        'graded_at'      => 'datetime',
        'is_late'        => 'boolean',
        'marks_obtained' => 'decimal:2',
        'sub_attachment_media_id'      => 'array',
        'is_resubmission_requested' => 'boolean',
        'score_published_at' => 'datetime',
    ];
    ```
  - **After:**
    ```php
    protected $casts = [
        'submitted_at'   => 'datetime',
        'graded_at'      => 'datetime',
        'is_late'        => 'boolean',
        'is_active'      => 'boolean',
        'marks_obtained' => 'decimal:2',
        'sub_attachment_media_id'      => 'array',
        'is_resubmission_requested' => 'boolean',
        'score_published_at' => 'datetime',
    ];
    ```
  - **Before** (`HomeworkAssignment.php:50-62`):
    ```php
    protected $casts = [
        'is_released' => 'boolean',
        'is_active' => 'boolean',
        'released_at' => 'datetime',
        'release_scheduled_date' => 'datetime',
        'due_date' => 'datetime',
        'late_submission_override_at' => 'datetime',
        'viewed_at' => 'datetime',
        'student_notified_at' => 'datetime',
        'parent_notified_at' => 'datetime',
        'reminder_sent_at' => 'datetime',
        'allow_late_submission' => 'boolean',
    ];
    ```
  - **After:**
    ```php
    protected $casts = [
        'is_released' => 'boolean',
        'is_active' => 'boolean',
        'view_count' => 'integer',
        'released_at' => 'datetime',
        'release_scheduled_date' => 'datetime',
        'due_date' => 'datetime',
        'late_submission_override_at' => 'datetime',
        'viewed_at' => 'datetime',
        'student_notified_at' => 'datetime',
        'parent_notified_at' => 'datetime',
        'reminder_sent_at' => 'datetime',
        'allow_late_submission' => 'boolean',
    ];
    ```
  - **Verify:** `grep -n "is_active.*boolean\|view_count.*integer" Modules/LmsHomework/app/Models/HomeworkSubmission.php Modules/LmsHomework/app/Models/HomeworkAssignment.php`
  - **Expect:** `'is_active'      => 'boolean',` in HomeworkSubmission and `'view_count' => 'integer',` in HomeworkAssignment.
  - **Effort:** S

- [x] **PHW-10** · L · MDL-04 · `Homework.php` + `HomeworkSubmission.php` + `HomeworkAssignment.php` — add return types to the 20 untyped relationship methods (14 + 5 + 1).
  - **Touches:** `Modules/LmsHomework/app/Models/Homework.php`, `Modules/LmsHomework/app/Models/HomeworkSubmission.php`, `Modules/LmsHomework/app/Models/HomeworkAssignment.php`
  - **Before** (imports, `Homework.php:5-26`):
    ```php
    use App\Models\BaseModel;
    use App\Traits\SanitizesRichText;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\Storage;
    use Modules\LmsHomework\Services\LmsStorageService;
    use Modules\Prime\Models\Dropdown;
    use Modules\SchoolSetup\Models\OrganizationAcademicSession;
    use Modules\SchoolSetup\Models\SchoolClass;
    use Modules\SchoolSetup\Models\Section;
    use Modules\SchoolSetup\Models\Subject;
    use Modules\SchoolSetup\Models\User;
    use Modules\Syllabus\Models\ComplexityLevel;
    use Modules\Syllabus\Models\Lesson;
    use Modules\Syllabus\Models\SyllabusSchedule;
    use Modules\Syllabus\Models\Topic;
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;
    use Spatie\MediaLibrary\MediaCollections\Models\Media;
    ```
  - **After:**
    ```php
    use App\Models\BaseModel;
    use App\Traits\SanitizesRichText;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Factories\HasFactory;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasMany;
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Support\Facades\Storage;
    use Modules\LmsHomework\Services\LmsStorageService;
    use Modules\Prime\Models\Dropdown;
    use Modules\SchoolSetup\Models\OrganizationAcademicSession;
    use Modules\SchoolSetup\Models\SchoolClass;
    use Modules\SchoolSetup\Models\Section;
    use Modules\SchoolSetup\Models\Subject;
    use Modules\SchoolSetup\Models\User;
    use Modules\Syllabus\Models\ComplexityLevel;
    use Modules\Syllabus\Models\Lesson;
    use Modules\Syllabus\Models\SyllabusSchedule;
    use Modules\Syllabus\Models\Topic;
    use Spatie\MediaLibrary\HasMedia;
    use Spatie\MediaLibrary\InteractsWithMedia;
    use Spatie\MediaLibrary\MediaCollections\Models\Media;
    ```
  - **Before** (relations, `Homework.php:83-154`):
    ```php
    public function academicSession()
    {
        return $this->belongsTo(OrganizationAcademicSession::class, 'academic_session_id');
    }

    public function class()
    {
        return $this->belongsTo(SchoolClass::class, 'class_id');
    }

    public function lesson()
    {
        return $this->belongsTo(Lesson::class, 'lesson_id');
    }

    public function section()
    {
        return $this->belongsTo(Section::class, 'section_id');
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class, 'subject_id');
    }

    public function topic()
    {
        return $this->belongsTo(Topic::class, 'topic_id');
    }

    public function submissionType()
    {
        return $this->belongsTo(Dropdown::class, 'submission_type_id');
    }

    public function difficultyLevel()
    {
        return $this->belongsTo(ComplexityLevel::class, 'difficulty_level_id');
    }

    // NOTE: release_condition is an ENUM column, not an FK. No belongsTo relation needed.
    // Access it directly: $homework->release_condition ('IMMEDIATE'|'ON_TOPIC_COMPLETE'|'ON_SCHEDULED_DATE')

    public function status()
    {
        return $this->belongsTo(Dropdown::class, 'status_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function submissions()
    {
        return $this->hasMany(HomeworkSubmission::class, 'homework_id');
    }

    public function assignments()
    {
        return $this->hasMany(HomeworkAssignment::class, 'homework_id');
    }

    public function syllabusSchedule()
    {
        return $this->belongsTo(SyllabusSchedule::class, 'schedule_id');
    }
    ```
  - **After:**
    ```php
    public function academicSession(): BelongsTo
    {
        return $this->belongsTo(OrganizationAcademicSession::class, 'academic_session_id');
    }

    public function class(): BelongsTo
    {
        return $this->belongsTo(SchoolClass::class, 'class_id');
    }

    public function lesson(): BelongsTo
    {
        return $this->belongsTo(Lesson::class, 'lesson_id');
    }

    public function section(): BelongsTo
    {
        return $this->belongsTo(Section::class, 'section_id');
    }

    public function subject(): BelongsTo
    {
        return $this->belongsTo(Subject::class, 'subject_id');
    }

    public function topic(): BelongsTo
    {
        return $this->belongsTo(Topic::class, 'topic_id');
    }

    public function submissionType(): BelongsTo
    {
        return $this->belongsTo(Dropdown::class, 'submission_type_id');
    }

    public function difficultyLevel(): BelongsTo
    {
        return $this->belongsTo(ComplexityLevel::class, 'difficulty_level_id');
    }

    // NOTE: release_condition is an ENUM column, not an FK. No belongsTo relation needed.
    // Access it directly: $homework->release_condition ('IMMEDIATE'|'ON_TOPIC_COMPLETE'|'ON_SCHEDULED_DATE')

    public function status(): BelongsTo
    {
        return $this->belongsTo(Dropdown::class, 'status_id');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updatedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function submissions(): HasMany
    {
        return $this->hasMany(HomeworkSubmission::class, 'homework_id');
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(HomeworkAssignment::class, 'homework_id');
    }

    public function syllabusSchedule(): BelongsTo
    {
        return $this->belongsTo(SyllabusSchedule::class, 'schedule_id');
    }
    ```
  - **Before** (`HomeworkSubmission.php:62-85`):
    ```php
    public function homework()
    {
        return $this->belongsTo(Homework::class, 'homework_id');
    }

    public function assignment()
    {
        return $this->belongsTo(HomeworkAssignment::class, 'assignment_id');
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    public function gradedBy()
    {
        return $this->belongsTo(SysUser::class, 'graded_by');
    }

    public function status()
    {
        return $this->belongsTo(Dropdown::class, 'status_id');
    }
    ```
  - **After:**
    ```php
    public function homework(): BelongsTo
    {
        return $this->belongsTo(Homework::class, 'homework_id');
    }

    public function assignment(): BelongsTo
    {
        return $this->belongsTo(HomeworkAssignment::class, 'assignment_id');
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    public function gradedBy(): BelongsTo
    {
        return $this->belongsTo(SysUser::class, 'graded_by');
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Dropdown::class, 'status_id');
    }
    ```
  - **Before** (imports + `submission()`, `HomeworkAssignment.php:7-8` and `:99-102`):
    ```php
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    ```
  - **After:**
    ```php
    use Illuminate\Database\Eloquent\SoftDeletes;
    use Illuminate\Database\Eloquent\Relations\BelongsTo;
    use Illuminate\Database\Eloquent\Relations\HasOne;
    ```
  - **Before** (`HomeworkAssignment.php:99-102`):
    ```php
    public function submission()
    {
        return $this->hasOne(HomeworkSubmission::class, 'assignment_id');
    }
    ```
  - **After:**
    ```php
    public function submission(): HasOne
    {
        return $this->hasOne(HomeworkSubmission::class, 'assignment_id');
    }
    ```
  - **Verify:** `grep -nE "public function (academicSession|class|lesson|section|subject|topic|submissionType|difficultyLevel|status|createdBy|updatedBy|submissions|assignments|syllabusSchedule|homework|assignment|gradedBy)\(" Modules/LmsHomework/app/Models/Homework.php Modules/LmsHomework/app/Models/HomeworkSubmission.php | grep -v "):"`
  - **Expect:** no output — every listed relation now carries `): BelongsTo` or `): HasMany`; and `grep -n "public function submission()" Modules/LmsHomework/app/Models/HomeworkAssignment.php` prints no output (now `submission(): HasOne`).
  - **Effort:** S

## 6. Queries & performance (F9)

None as direct items — PHW-06 and PHW-07 are accepted (bounded per-student list + deliberate one-query bucketing); PHW-08 is folded into PHW-05 (§1).

## 7. Views (F10)

None as direct items — the view-variable fix is PHW-05 (§1); the blade is not edited.

## 8. Style (F12) — one item per file

- [x] **PHW-11** · L · STY-01 · `Homework.php` + `HomeworkAssignment.php` + `HomeworkSubmission.php` — add `declare(strict_types=1)` to the three model files.
  - **Touches:** `Modules/LmsHomework/app/Models/Homework.php`, `Modules/LmsHomework/app/Models/HomeworkAssignment.php`, `Modules/LmsHomework/app/Models/HomeworkSubmission.php`
  - **Before** (`HomeworkAssignment.php:1-3`):
    ```php
    <?php

    namespace Modules\LmsHomework\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\LmsHomework\Models;
    ```
  - **Before** (`HomeworkSubmission.php:1-3`):
    ```php
    <?php

    namespace Modules\LmsHomework\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\LmsHomework\Models;
    ```
  - **Before** (`Homework.php:1-3`):
    ```php
    <?php

    // Path: c:\laragon\www\prime_ai\prime_ai\Modules\LmsHomework\app\Models\Homework.php

    namespace Modules\LmsHomework\Models;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    // Path: c:\laragon\www\prime_ai\prime_ai\Modules\LmsHomework\app\Models\Homework.php

    namespace Modules\LmsHomework\Models;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/LmsHomework/app/Models/Homework.php Modules/LmsHomework/app/Models/HomeworkAssignment.php Modules/LmsHomework/app/Models/HomeworkSubmission.php`
  - **Expect:** one `declare(strict_types=1);` line in each of the three files (3 lines total).
  - **Effort:** S

- [x] **PHW-13** · L · CTL-10/STY-05 · `ParentHomeworkController.php:7-18` — remove the four imports left unused after PHW-01 and PHW-05 (`ModelNotFoundException`, `Log`, `DB`, `RedirectResponse`).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php`
  - **Before** (`ParentHomeworkController.php:7-18`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\View\View;
    use Modules\LmsHomework\Models\HomeworkAssignment;
    use Modules\ParentPortal\Services\ParentContextService;
    use Illuminate\Http\RedirectResponse;
    ```
  - **After:**
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\View\View;
    use Modules\LmsHomework\Models\HomeworkAssignment;
    use Modules\ParentPortal\Services\ParentContextService;
    ```
  - **Verify:** `grep -nE "ModelNotFoundException|Facades\\Log|Facades\\DB|RedirectResponse" Modules/ParentPortal/app/Http/Controllers/ParentHomeworkController.php`
  - **Expect:** no output — the four imports are gone and nothing in the (post-PHW-01/PHW-05) body references them.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **PHW-01** · M · DECISION · ERR-07 / ERR-00 (D1) — what should happen when the list page's audit write fails?
  - **Why it is a decision:** D1 forbids controller try/catch except for D2 shapes, and this catch of `\Throwable` is not one of them; but removing it means a failed audit row renders the central 500 page. The current code prefers keeping the page alive.
  - (a) ⭐ Keep ONE isolated catch, log the exception object, and use the injected `$request` — paste-ready replacement for `ParentHomeworkController.php:59-71`:
    ```php
            // PHW-01 · 2026-10-13 — best-effort audit write must not take the page down.
            // One row, one table, so no transaction is required.
            try {
                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed homework list',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => $request->route()?->getName(),
                    ],
                ]);
            } catch (\Throwable $e) {
                // ERR-01 · 2026-10-13 — preserve the trace; keep the page alive.
                report($e);
            }
    ```
    Touches `ParentHomeworkController.php:59-71` only; the page survives and the full trace is preserved via `report($e)`; also fixes the CTL-08 `request()` usage at line 66.
  - (b) Strict D1: delete the `try`/`catch` (lines 55-71 become the bare `activityLog(...)` call) — a failed audit row then bubbles to the central handler and the parent sees a generic 500; also fixes CTL-08 the same way.
  - (c) Leave as is (current catch still logs only `getMessage()`).
  - ➜ Choice: (a) — isolated audit catch with report($e) 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| PHW-02 | Fixed by PHW-05 (§1) — the same `show()` rewrite that removes the try/catch removes the `catch (\Throwable)` that swallowed the no-access redirect. |
| PHW-03 | Fixed by PHW-01 (§9, option a/b) and PHW-05 (§1) — both rewrites replace `Log::error(... getMessage())` with `report($e)` / plain `activityLog(...)`. |
| PHW-04 | Fixed by PHW-05 (§1) — `DB::transaction` is removed from `show()`; the single-row audit write needs no transaction (the index comment already says so). |
| PHW-06 | Accepted — the assignment list is bounded by one student's released assignments (typically a few dozen rows) and the 5-tab client-side switching is designed to receive the whole set once; paginating would redesign the tab interaction. Marked M per QRY-02's default with a lowered reason. |
| PHW-07 | Accepted — the five buckets filter one bounded collection in memory; SQL aggregation would either repeat the query five times or still load every row for four of the buckets. Lowered to L. |
| PHW-08 | Fixed by PHW-05 (§1) — the rewrite's `with([...])` adds `homework.topic`, `homework.lesson`, `homework.class`, `homework.section`. |