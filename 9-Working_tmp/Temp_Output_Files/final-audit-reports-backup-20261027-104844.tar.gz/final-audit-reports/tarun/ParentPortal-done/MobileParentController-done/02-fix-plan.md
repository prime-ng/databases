# Fix Plan — ParentPortal / MobileParentController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by the ParentDashboardController report (registry line 309) |
| `Modules/StudentProfile/app/Models/Student.php` | owned by gaurav/StudentProfile/StudentReportController report |
| `Modules/LmsHomework/app/Models/Homework.php`, `HomeworkSubmission.php` | owned by the ParentHomeworkController report |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php` | owned by the TimetableFoundation/TimetableController report |
| `Modules/StudentProfile/app/Models/*` (Guardian, StudentGuardianJnt, StudentAttendance, LeaveApplication) | owned by gaurav/StudentProfile reports |
| `Modules/LmsExam/app/Models/ExamAllocation.php` | owned by the shailesh/LmsExam/ExamAllocationController report |
| `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | owned by the TimetableFoundation/TimetableFoundationController report |
| `database/migrations/**` | never edit an existing migration |
| `final-audit-reports/00-CLASS-OWNERS.md`, `final-audit-reports/tarun/ParentPortal-done/00-INDEX.md` | append or exact-match edit only; never the fixer's job here |
| `routes/api.php` | shared route file — touched ONLY if the MPC-02 decision is ticked, and then only that one group |

## 1. Blockers reachable today

None. No finding is rated B.

## 2. Fixes that arm a latent defect (sequenced)

None. The schema fix (MPC-06) arms no other finding.

## 3. Errors & transactions (F1/F2)

- [x] **MPC-01** · M · ERR-00 · `MobileParentController.php:71-77` — remove the `try/catch` around `resolveChild()` (D1: no try/catch in a controller).
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Before** (`MobileParentController.php:71-77`):
    ```php
            // Resolve active child (same logic as ParentContextService)
            $activeChildId = null;
            if ($children->isNotEmpty()) {
                try {
                    $activeChildId = $this->context->resolveChild(request())->id;
                } catch (\Throwable) {
                    $activeChildId = $children->first()->id;
                }
            }
    ```
  - **After:**
    ```php
            // Resolve active child through the shared service.
            $activeChildId = $children->isNotEmpty()
                ? $this->context->resolveChild(request())->id
                : null;
    ```
  - **Verify:** `grep -n "catch" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Expect:** no output.
  - **Effort:** S

## 4. Authorization (F3)

The only authorization finding (MPC-02) is a decision, because the fix re-scopes the route group. It is in §9.

## 5. Validation, routes, models (F4/F5/F7) and services (F8)

- [x] **MPC-05** · M · CTL-05 · `MobileParentController.php:40-67` — call the shared `ParentContextService::getAccessibleChildren()` instead of rebuilding the child query, so the set is resolved once.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Before** (`MobileParentController.php:40-67`):
    ```php
            $guardian = Guardian::where('user_id', $user->id)->first();

            if (! $guardian) {
                return response()->json([
                    'children' => [],
                    'active_child_id' => null,
                ]);
            }

            $studentIds = StudentGuardianJnt::where('guardian_id', $guardian->id)
                ->where('can_access_parent_portal', true)
                ->pluck('student_id');

            if ($studentIds->isEmpty()) {
                return response()->json([
                    'children' => [],
                    'active_child_id' => null,
                ]);
            }

            $children = Student::whereIn('id', $studentIds)
                ->where('is_active', true)
                ->with([
                    'currentSession.classSection.class',
                    'currentSession.classSection.section',
                    'currentSession.academicSession',
                ])
                ->get();
    ```
  - **After:**
    ```php
            $children = $this->context->getAccessibleChildren($user);

            if ($children->isEmpty()) {
                return response()->json([
                    'children' => [],
                    'active_child_id' => null,
                ]);
            }

            $children->load('currentSession.academicSession');
    ```
  - **Verify:** `vendor/bin/pint Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php --format agent && grep -n "StudentGuardianJnt\|Guardian::where\|Student::whereIn" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Expect:** Pint passes; the grep prints no output (the body no longer names those classes, and Pint removes the now-unused `Guardian`, `Student` and `StudentGuardianJnt` imports via `no_unused_imports`).
  - **Effort:** M

- [x] **MPC-06** · H · MDL-07 · `MobileParentController.php:193-196` — filter break periods on the real `PeriodType.is_break`, not on a `TimetableCell` attribute that does not exist.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Before** (`MobileParentController.php:193-196`):
    ```php
                    ->with(['activity.subject', 'activity.teachers.teacher.user', 'period', 'room'])
                    ->orderBy('period_ord')
                    ->get())
                    ->filter(fn ($c) => ! $c->is_break);
    ```
  - **After:**
    ```php
                    ->with(['activity.subject', 'activity.teachers.teacher.user', 'period.periodConfig.periodType', 'room'])
                    ->orderBy('period_ord')
                    ->get())
                    ->filter(fn ($c) => ! ($c->period?->periodConfig?->periodType?->is_break));
    ```
  - **Verify:** `grep -n "is_break" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Expect:** one line, reading `periodType?->is_break` (not `$c->is_break`).
  - **Effort:** S

- [x] **MPC-07** · M · SVC-02 · `MobileParentController.php:26-28, 186` — inject `SnapshotContext` in the constructor instead of resolving it with `app()`.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Before** (`MobileParentController.php:26-28`):
    ```php
        public function __construct(
            private readonly ParentContextService $context,
        ) {}
    ```
  - **After:**
    ```php
        public function __construct(
            private readonly ParentContextService $context,
            private readonly SnapshotContext $snapshot,
        ) {}
    ```
  - **Before** (`MobileParentController.php:185-186`):
    ```php
                // Today's schedule
                $todayCells = $timetableId === null ? collect() : app(SnapshotContext::class)->run($timetableId, fn () => TimetableCell::whereHas('activity', fn ($q) => $q
    ```
  - **After:**
    ```php
                // Today's schedule
                $todayCells = $timetableId === null ? collect() : $this->snapshot->run($timetableId, fn () => TimetableCell::whereHas('activity', fn ($q) => $q
    ```
  - **Verify:** `grep -n "app(SnapshotContext" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Expect:** no output.
  - **Effort:** S

## 6. Queries & performance (F9)

- [x] **MPC-08** · M · QRY-05 · `MobileParentController.php:232-237` — aggregate the fee figures in SQL and stop loading every invoice. Fixes MPC-09 in the same block.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Before** (`MobileParentController.php:232-237`):
    ```php
            $feeAssignment = $child->currentFeeAssignemnt ?? null;
            if ($feeAssignment) {
                $invoices = $feeAssignment->invoices ?? collect();
                $feeDue = (float) $invoices->sum('balance_amount');
                $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
            }
    ```
  - **After:**
    ```php
            $feeAssignment = $child->currentFeeAssignemnt ?? null;
            if ($feeAssignment) {
                $feeDue = (float) $feeAssignment->invoices()->sum('balance_amount');
                $feePendingInvoices = $feeAssignment->invoices()
                    ->whereNotIn('status', [FeeInvoice::STATUS_PAID, FeeInvoice::STATUS_CANCELLED])
                    ->count();
            }
    ```
  - **Before** (`MobileParentController.php:11`):
    ```php
    use Modules\LmsExam\Models\ExamAllocation;
    ```
  - **After:**
    ```php
    use Modules\LmsExam\Models\ExamAllocation;
    use Modules\StudentFee\Models\FeeInvoice;
    ```
  - **Verify:** `grep -n "invoices()->" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Expect:** two lines (the `sum` and the `count`), and no line reading `$invoices->sum`.
  - **Effort:** S

## 7. Views (F10)

None — this is a JSON API controller.

## 8. Style (F12) — one item per file

- [x] **MPC-11** · L · STY-04 · `MobileParentController.php:146, 163, 172-179, 228, 239, 249` — replace emoji/box-drawing comment markers with plain English.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Before** (`MobileParentController.php:172-179`):
    ```php
                /*
                | ⛔ PUBLISHED ONLY, PINNED BY ID — see PublishedTimetable.
                |
                | The old status IN (ACTIVE, GENERATED, PUBLISHED) filter let DRAFTS
                | through and pinned nothing, so the cells of every matching timetable
                | were merged into one day. Measured on this tenant: four timetables
                | matched at once.
                */
    ```
  - **After:**
    ```php
                /*
                | PUBLISHED ONLY, PINNED BY ID - see PublishedTimetable.
                |
                | The old status IN (ACTIVE, GENERATED, PUBLISHED) filter let DRAFTS
                | through and pinned nothing, so the cells of every matching timetable
                | were merged into one day. Measured on this tenant: four timetables
                | matched at once.
                */
    ```
  - **Also in the same file (same one-file style change):** replace the five box-drawing separators with plain English — `// ── Attendance ──` at line 146 → `// Attendance`; `// ── Timetable / Homework / Exams ──` at line 163 → `// Timetable, homework and exams`; `// ── Fee summary ──` at line 228 → `// Fee summary`; `// ── Leave ──` at line 239 → `// Leave`; `// ── Notifications ──` at line 249 → `// Notifications`.
  - **Verify:** `grep -nE "⛔|⚠|──" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

- [x] **MPC-02** · H · DECISION · AUTH-01 — put a parent gate on the ParentPortal mobile group, which today carries only `auth:sanctum`.
  - **Why it is a decision:** the fix re-scopes a route group in the shared route file `routes/api.php` (protocol §9.3: a route re-scope stops the fixer), and there is more than one defensible gate.
  - (a) ⭐ **Add the module's own `ParentPortalMiddleware` to the group** — makes the mobile group match the existing web API group at `Modules/ParentPortal/app/Providers/RouteServiceProvider.php:85-99`. Edit `routes/api.php`: inside the `mobile/v1` group, wrap `require base_path('Modules/ParentPortal/routes/mobile_api.php');` (line 53) in `Route::middleware(ParentPortalMiddleware::class)->group(...)` and add `use Modules\ParentPortal\Http\Middleware\ParentPortalMiddleware;` at the top. Note: that middleware returns an HTML redirect for unauthenticated and no-access users, so a JSON-aware response is still wanted — pair it with the §7 service note.
  - (b) **Add a `role:Parent` guard** to the same group, matching the StudentPortal mobile group pattern (`routes/api.php:47-50`). Simpler, but the middleware's own docblock says it avoids Spatie roles deliberately.
  - (c) **Add a controller-level `abort_unless` in each method** (no route-file change), checking a guardian row and `user_type = 'PARENT'` before any work.
  - ➜ Choice: (c) — controller-level parent guard (no route-file change) 2026-10-22

- [x] **MPC-10** · H · DECISION · MDL-09 — decide how `Half Day` and `Short Leave` count toward the parent's attendance percentage.
  - **Why it is a decision:** it is a business rule, and it must agree with the PAT-05 / PDAS-02 decision on the attendance page; the `dashboard` counter must use the same rule.
  - (a) ⭐ **Count `Present`, `Half Day` and `Short Leave` as present** (matching the student-facing pages), and use the model constants instead of the literals `'Present'`, `'P'`, `'present'`; drop `Leave` from the denominator or keep it per the attendance-page decision.
  - (b) **Count only `Present` as present** (current behaviour, minus the dead `'P'`/`'present'` literals), and state in the API that the parent number is stricter than the school's page.
  - (c) **Return the raw counts and let the app compute the percentage**, so the rule lives in one place.
  - ➜ Choice: (a) — Present/Late/Half Day/Short Leave count as present 2026-10-22

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| MPC-03 | The write-on-GET is inside `ParentContextService::resolveChild()` (owned by the ParentDashboardController report). The fix belongs to that report; this report only records how the controller triggers it. |
| MPC-04 | Method-length extraction is deferred per D3 (god-controller/method splits are deferred, never applied in this pass). MPC-08's rewrite also shrinks `dashboard()`. |
| MPC-09 | Same two lines as MPC-08; fixed inside MPC-08's After block (no separate item). |
| MPC-12 | Edits the same `children()` line as MPC-01, and only one plan item may own a line. Deferred; the fix is a one-line-per-method change using an injected `Request`. |
