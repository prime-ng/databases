# Final Audit — ParentPortal / MobileParentController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php` (284 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /api/mobile/v1/parent/children` (JSON) — the child picker; `GET /api/mobile/v1/parent/dashboard` (JSON) — the parent home summary. |
| Menu path | Mobile parent app → after login → child selector (`children`) then Dashboard (`dashboard`). |
| Who uses it | Parents (`user_type = PARENT` in the design). The route sits behind `mobile.key` (app key), `tenant.mobile` (per-school header) and `auth:sanctum` (bearer token). There is **no parent role or portal gate** on this group, so any authenticated tenant user can call it (MPC-02). There is no granular permission key for the parent portal, by design. |
| What a user does here | A parent opens the app: `children` lists every child linked to them (name, class, section, roll number, admission number, age, date of birth, gender, subjects), with one marked active. `dashboard` then shows, for the active child, the child's identity, attendance totals and percentage, pending homework, upcoming exams, a fee summary, pending leave count, today's timetable, and the five most recent notifications. Nothing on these screens is meant to write data; both are reads. |
| Tables written | Directly: none — both methods issue SELECTs only. Indirectly, through the linked `ParentContextService::resolveChild()`: `ppt_parent_sessions` can be `INSERT`ed or `UPDATE`d on these read paths (see §7). |
| Tables read | `std_guardians`, `std_student_guardian_jnt`, `std_students`, `std_student_academic_sessions`, `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `std_student_attendance`, `sch_subject_groups`, `sch_subject_group_subject_jnt`, `sch_subjects`, `tt_timetables`, `tt_timetable_cells`, `tt_activities`, `tt_sub_activities`, `tt_period_set_periods_jnt`, `tt_period_configs`, `tt_period_types`, `sch_rooms`, `lms_homework`, `lms_homework_submissions`, `sys_dropdown_table`, `lms_exam_allocations`, `lms_exam_papers`, `lms_exams`, `fee_student_assignments`, `fee_invoices`, `std_leave_applications`, `notifications`, and `glb_academic_sessions` (through `Student::currentFeeAssignemnt()`). |
| Live data | ⚠ UNVERIFIED — a tenant database session was not opened in this read-only audit (D4), so row counts for the tables above were not measured. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. These are JSON endpoints, so the app has to be used with a parent bearer token, or the URL checked with `curl` carrying the app key, school code and token.

## 1. Verdict

**Not production-ready — do not ship as-is.** The data is correctly scoped to the parent's own children (both methods filter on the guardian link with `can_access_parent_portal = 1`), so there is no cross-family leak. The problems are that the group has **no parent gate at all** (MPC-02, H): any authenticated user of the tenant reaches these endpoints, and the `dashboard` method then returns an HTML 302 redirect for a user with no children instead of a JSON 403; the "today's schedule" **break filter is dead** because it reads `$c->is_break`, an attribute `TimetableCell` does not have (MPC-06, H), so break/assembly periods are never removed; and the attendance percentage **counts the wrong status values**, so a parent sees a percentage that disagrees with the school's own attendance pages (MPC-10, H, needs a decision). The rest is medium and low: a controller `try/catch` the Laravel-idiom decision forbids (MPC-01), a duplicated copy of the service's child loader that also queries the same set twice (MPC-05), the service-locator call `app(SnapshotContext::class)` (MPC-07), the fee block aggregating in PHP over every invoice and filtering on literals that never match (MPC-08/MPC-09), two over-long methods (MPC-04), `request()` usage (MPC-12) and emoji comment markers (MPC-11). Rough effort: **S–M** — the schema, query and style items are a few hours; the two decisions (the parent gate and the attendance rule) gate the rest.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 3 | 7 | 2 | 2 | 12 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | MPC-01 | F8 Services/Jobs | MPC-07 |
| F2 Transactions/Audit | clean (controller) | F9 Queries/Perf | MPC-08, MPC-09, MPC-10 |
| F3 Authorization | MPC-02 | F10 Views | clean (no views) |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | MPC-03 | F12 Style | MPC-11, MPC-12 |
| F6 Controller shape | MPC-04, MPC-05, MPC-06 | F13 Deep read | MPC-06, MPC-10 |
| F7 Models | MPC-06 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php` | controller | 284 | this report | ✅ |
| 2 | `Modules/ParentPortal/routes/mobile_api.php` | route file | 30 | this report (shared with `MobileParentSessionController`; route group is `routes/api.php`) | ✅ |
| 3 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) (registry line 309) | ↗ linked |
| 4 | `Modules/StudentProfile/app/Models/Guardian.php` | model | 152 | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) (registry line 91) | ↗ linked |
| 5 | `Modules/StudentProfile/app/Models/StudentGuardianJnt.php` | model | 60 | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) (registry line 97) | ↗ linked |
| 6 | `Modules/StudentProfile/app/Models/Student.php` | model | 471 | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController/01-report.md) (registry line 75) | ↗ linked |
| 7 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | 63 | ↗ [gaurav/StudentProfile/AttendanceController](../../../gaurav/StudentProfile/AttendanceController/01-report.md) (registry line 88) | ↗ linked |
| 8 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | 126 | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md) (registry line 83) | ↗ linked |
| 9 | `Modules/LmsExam/app/Models/ExamAllocation.php` | model | 215 | ↗ [shailesh/LmsExam/ExamAllocationController](../../../shailesh/LmsExam/ExamAllocationController/01-report.md) (registry line 188) | ↗ linked |
| 10 | `Modules/LmsHomework/app/Models/Homework.php` | model | 308 | ↗ [tarun/ParentPortal-done/ParentHomeworkController](../ParentHomeworkController-done/01-report.md) (registry line 328) | ↗ linked |
| 11 | `Modules/LmsHomework/app/Models/HomeworkSubmission.php` | model | 242 | ↗ [tarun/ParentPortal-done/ParentHomeworkController](../ParentHomeworkController-done/01-report.md) (registry line 329) | ↗ linked |
| 12 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | 279 | ↗ [TimetableFoundation/TimetableController](../../../TimetableFoundation/TimetableController-done/01-report.md) (registry line 45) | ↗ linked |
| 13 | `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | service | 255 | ↗ [TimetableFoundation/TimetableFoundationController](../../../TimetableFoundation/TimetableFoundationController/01-report.md) (registry line 67) | ↗ linked |
| 14 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | 190 | ↗ [tarun/StandardTimetable/StandardTimetableController-done](../../StandardTimetable/StandardTimetableController-done/01-report.md) (registry line 126) | ↗ linked |

No pre-applied files — `PRE-APPLIED-2026-10-10.md` does not mention ParentPortal. Referenced (common, never audited here): `App\Http\Controllers\Controller`, the `Carbon`, `DB` and `JsonResponse` framework classes, and `routes/api.php` (the enclosing `mobile/v1` middleware group). All non-common classes were already claimed in `00-CLASS-OWNERS.md`; this report claims nothing new.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --path=mobile/v1/parent
  GET|HEAD   api/mobile/v1/parent/children Modules\ParentPortal\Http\Controll…
  GET|HEAD   api/mobile/v1/parent/dashboard Modules\ParentPortal\Http\Control…
  POST       api/mobile/v1/parent/switch-child Modules\ParentPortal\Http\Cont…
                                                            Showing [3] routes
```

Unrouted public methods: none. `__construct` is the constructor; `children()` and `dashboard()` are both routed. (`switch-child` belongs to `MobileParentSessionController`, out of scope.)

Middleware on both in-scope routes, from the uncached route list:

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '…MobileParentController@…'
GET|HEAD api/mobile/v1/parent/children
  middleware: api, App\Http\Middleware\ValidateMobileApiKey, App\Http\Middleware\InitializeTenancyByMobileHeader, Illuminate\Auth\Middleware\Authenticate:sanctum
GET|HEAD api/mobile/v1/parent/dashboard
  middleware: api, App\Http\Middleware\ValidateMobileApiKey, App\Http\Middleware\InitializeTenancyByMobileHeader, Illuminate\Auth\Middleware\Authenticate:sanctum
```

The group is defined at `routes/api.php:34` (`['mobile.key', 'tenant.mobile', 'auth:sanctum']`) and includes `Modules/ParentPortal/routes/mobile_api.php` at line 53 — **outside** the `role:Student|Parent` group that guards the StudentPortal mobile routes at lines 47-50.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `children` | 36 | GET api/mobile/v1/parent/children | none (route middleware is `auth:sanctum` only — MPC-02) | none | none | none directly; indirect `ppt_parent_sessions` via `resolveChild()` | MPC-01, MPC-02, MPC-05, MPC-12 |
| `dashboard` | 137 | GET api/mobile/v1/parent/dashboard | none (route middleware is `auth:sanctum` only — MPC-02) | none | none | none directly; indirect `ppt_parent_sessions` via `resolveChild()` | MPC-02, MPC-03, MPC-04, MPC-06, MPC-07, MPC-08, MPC-09, MPC-10, MPC-12 |

## 6. Findings

### F1 — Errors

#### MPC-01 · M · ERR-00 — `children()` wraps `resolveChild()` in a `try/catch (\Throwable)` that is not a D2 shape and swallows every failure

| Field | Value |
|---|---|
| **Rule** | ERR-00 (H default) — *the Laravel idiom: no `try/catch` in a controller; `DB::transaction()` rolls back and the central handler in `bootstrap/app.php` renders*. Protocol D1 settles ERR-00 to this idiom; the only allowed catches are the D2 shapes (`\DomainException`, the truncate-rebuild catch, `SnapshotProtectionException`, and `report($e)` in a service). Severity lowered to **M** with reason: the swallowed failure is a read-path fallback, not a write lost or a 500. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:71-77`, method `children()` |
| **Root cause** | The block catches `\Throwable` with no `report($e)`, no message and a silent fallback to `$children->first()->id`. None of the D2 shapes apply. It also catches the `HttpResponseException` that `ParentContextService::resolveChild()` throws via `abort(redirect(...))` when the parent has no accessible child, so that control-flow exception is discarded rather than rendered. |
| **Consequence** | If `resolveChild()` fails for a real reason, the parent silently gets a children list with the first child marked active and no error is logged anywhere, so the failure is invisible to the team. |
| **Reproduce** | Static only — the fallback path needs a runtime failure inside `resolveChild()`; the catch is unconditional for any exception. |
| **Fix approach** | Delete the `try/catch` (D1). `$activeChildId = $children->isNotEmpty() ? $this->context->resolveChild($request)->id : null;` and let the central handler render any genuine exception. |
| **Plan item** | MPC-01 in `02-fix-plan.md` §3 |

```php
        // Resolve active child (same logic as ParentContextService)
        $activeChildId = null;
        if ($children->isNotEmpty()) {
            try {
                $activeChildId = $this->context->resolveChild(request())->id;
            } catch (\Throwable) {
                $activeChildId = $children->first()->id;
            }
        }
```

**Evidence**
```
$ sed -n '69,77p' Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
        // Resolve active child (same logic as ParentContextService)
        $activeChildId = null;
        if ($children->isNotEmpty()) {
            try {
                $activeChildId = $this->context->resolveChild(request())->id;
            } catch (\Throwable) {
                $activeChildId = $children->first()->id;
            }
        }
```

### F2 — Transactions and audit

clean — `grep -nE "DB::transaction|activityLog|beginTransaction|->create\(|->update\(|->delete\(|->save\(" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php` → no output. Both methods issue SELECTs only, so no transaction and no `activityLog()` are needed. The write-on-read behaviour of the linked service (`resolveChild()` → `getOrCreateSession()`) is recorded in §7.

### F3 — Authorization

#### MPC-02 · H · AUTH-01 — neither routed method authorizes, and the mobile group has no parent gate

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (B default) — *every routed controller method authorizes: `Gate::authorize`, `$this->authorize`, a `can:` route middleware, or a Form Request whose `authorize()` checks a permission*. Severity lowered to **H** with reason: record-level ownership is enforced inside the methods (AUTH-03 holds), so this admits the wrong *kind* of user but exposes no other family's data; it is a missing role/portal gate, not a data leak. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:36` (`children()`) and `:137` (`dashboard()`); group at `routes/api.php:34` |
| **Root cause** | The `mobile/v1` group wraps the ParentPortal routes in `mobile.key`, `tenant.mobile` and `auth:sanctum` only. There is no `parent.portal`, no `role:` middleware, and no `Gate::authorize`/`abort_unless` in either method. The sibling web API group (`Modules/ParentPortal/app/Providers/RouteServiceProvider.php:85-99`) does add `ParentPortalMiddleware`, and the StudentPortal mobile routes add `role:Student|Parent`; the ParentPortal mobile group adds neither. |
| **Consequence** | Any authenticated user of the tenant (a student, a teacher, an admin) can reach these endpoints. A non-parent gets an empty list from `children`, and from `dashboard` an HTML 302 redirect to the web no-access page instead of a JSON 403 — the mobile client cannot follow that redirect. In both cases a wrong result is returned for a user who should be refused outright. |
| **Reproduce** | With a valid student or teacher bearer token for the tenant, call `GET /api/mobile/v1/parent/dashboard`; expected a JSON 403, actual a 302 HTML redirect (or an empty payload from `/children`). |
| **Fix approach** | DECISION — see MPC-02 in `02-fix-plan.md` §9: add the module's own `ParentPortalMiddleware` to the mobile group so it matches `/api/v1/parent`, or add a `role:` guard, or a controller-level `abort_unless`. |
| **Plan item** | MPC-02 in `02-fix-plan.md` §9 (DECISION) |

```php
    public function children(): JsonResponse
    {
        $user = auth()->user();

        $guardian = Guardian::where('user_id', $user->id)->first();
```

**Evidence**
```
$ grep -nE "Gate|authorize|abort|can:|middleware" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
(no output — the controller contains no authorization call)

$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '…'
GET|HEAD api/mobile/v1/parent/dashboard
  middleware: api, App\Http\Middleware\ValidateMobileApiKey, App\Http\Middleware\InitializeTenancyByMobileHeader, Illuminate\Auth\Middleware\Authenticate:sanctum
```

### F4 — Validation and input

clean — `grep -nE "validate|validated|->all\(|except\(|->input\(|->query\(" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php` → no output. Neither method reads a query parameter, route parameter or request body; the only request object use is `request()->user()` (validated by `auth:sanctum`), so there is no user input to validate.

### F5 — Routes

#### MPC-03 · M · RTE-01 — the two GET endpoints write to `ppt_parent_sessions` through `resolveChild()`

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H default) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it*. Severity lowered to **M** with reason: the routes are token-authenticated JSON APIs (no prefetch), and the effect is a session-row touch, not a business write. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:73` and `:140`, methods `children()` and `dashboard()` |
| **Root cause** | Both GET methods call `ParentContextService::resolveChild()`. That method's `getOrCreateSession()` can `create()` a `ppt_parent_sessions` row and can `update()` `active_student_id` / `last_active_at`; a multi-child parent with no session row is the normal case that inserts. The write is the service's, but the choice to invoke a write-capable resolver on a read route is this controller's. |
| **Consequence** | Opening the dashboard or the child list can insert or update a session row. The owner report should decide whether session creation belongs on the `POST switch-child` route instead of a GET. |
| **Reproduce** | Static only — the `create()`/`update()` calls are in the linked service (`ParentContextService.php:119-121, 202-222`); a runtime reproduction needs a tenant DB. |
| **Fix approach** | Owned by the ParentContextService report. See §10: no plan item here; the fix belongs to the service owner. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
                $activeChildId = $this->context->resolveChild(request())->id;
```

**Evidence**
```
$ grep -n "resolveChild" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
73:                $activeChildId = $this->context->resolveChild(request())->id;
140:        $child = $this->context->resolveChild(request());

$ grep -nE "->create\(|->update\(" Modules/ParentPortal/app/Services/ParentContextService.php
120:            $parentSession->update(['active_student_id' => $child->id]);
210:            $session->update(['last_active_at' => now()]);
214:        return ParentSession::create([
```

### F6 — Controller shape

#### MPC-04 · M · CTL-02 — `dashboard()` is 147 lines and `children()` is 95 lines, both over the 80-line threshold

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:137-283` (`dashboard()`, 147 lines) and `:36-130` (`children()`, 95 lines) |
| **Root cause** | Each method assembles several independent blocks (children identity, subjects, attendance, timetable, homework, exams, fee, leave, notifications) and the JSON response in one body. `dashboard()` is one line under the 150-line H threshold. |
| **Consequence** | Harder to read and risky to edit in place; no user-visible defect. The fee block is rewritten by MPC-08 anyway, which shrinks `dashboard()`. |
| **Reproduce** | Static only — `grep -nE "^    public function |^}"` shows the method spans. |
| **Fix approach** | Deferred (D3): extracting private helpers is cosmetic and overlaps the MPC-08 rewrite. Recorded, not applied. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
    public function dashboard(): JsonResponse
    {
        $user = auth()->user();
        $child = $this->context->resolveChild(request());
```

**Evidence**
```
$ grep -nE "^    public function |^}" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
36:    public function children(): JsonResponse
137:    public function dashboard(): JsonResponse
284:}

$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
M  CTL-02   …MobileParentController.php:36  children — children() is 95 lines
M  CTL-02   …MobileParentController.php:137  dashboard — dashboard() is 147 lines
```

#### MPC-05 · M · CTL-05 — `children()` rebuilds the service's accessible-children query and the set is resolved twice per request

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same loader repeated*. This is the `module-finalization.md` §3.4.3 shape: a caller keeps a private copy of a shared service loader, so a later fix to the service does not reach it. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:40-67`, method `children()` |
| **Root cause** | Lines 40-67 duplicate `ParentContextService::getAccessibleChildren()` (guardian lookup, `StudentGuardianJnt` filter, `Student` query). The first fence block is a comment that marks the copy: "same logic as ParentContextService". Because `children()` builds its own set and then calls `resolveChild()` (which calls `getAccessibleChildren()`), the accessible-children query runs twice per request. |
| **Consequence** | A future correction to `getAccessibleChildren()` (for example a soft-delete or `is_active` change) will not reach this endpoint, and every child-list load pays one extra query set. |
| **Reproduce** | Static only — compare the two blocks; `grep -n "getAccessibleChildren"` shows the service defines it and this controller never calls it. |
| **Fix approach** | Call `$this->context->getAccessibleChildren($user)` (the service memoises it, so `resolveChild()` reuses the same set) and add the one missing eager load with `->load('currentSession.academicSession')`. |
| **Plan item** | MPC-05 in `02-fix-plan.md` §5 |

```php
        $studentIds = StudentGuardianJnt::where('guardian_id', $guardian->id)
            ->where('can_access_parent_portal', true)
            ->pluck('student_id');
```

**Evidence**
```
$ grep -n "getAccessibleChildren\|StudentGuardianJnt::\|Student::whereIn" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php Modules/ParentPortal/app/Services/ParentContextService.php
Modules/ParentPortal/app/Services/ParentContextService.php:55:    public function getAccessibleChildren(User $parent): Collection
Modules/ParentPortal/app/Services/ParentContextService.php:67:        $studentIds = StudentGuardianJnt::where('guardian_id', $guardian->id)
Modules/ParentPortal/app/Services/ParentContextService.php:75:        return $this->childrenMemo[$parent->id] = Student::whereIn('id', $studentIds)
Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:49:        $studentIds = StudentGuardianJnt::where('guardian_id', $guardian->id)
Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:60:        $children = Student::whereIn('id', $studentIds)
```

#### MPC-06 · H · MDL-07 — the "today's schedule" break filter reads `is_break`, an attribute `TimetableCell` does not have, so it removes nothing

| Field | Value |
|---|---|
| **Rule** | MDL-07 (B) — *code that names a column/schema object that does not exist; the DDL wins* (`module-finalization.md` §1.4, catalogue family "App disagrees with its own schema", check §3.4.2 #17). Severity set to **H** with reason: it produces a wrong result on the endpoint's main screen (break periods are not removed); no 500 occurs. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:193-196`, method `dashboard()` |
| **Root cause** | `tt_timetable_cells` has no `is_break` column (the migration lists `day_of_week`, `period_ord`, `source`, `is_locked`, `has_conflict`, `is_active`, the FKs, timestamps and `deleted_at`), `TimetableCell` declares no `is_break` in `$fillable`/`$casts` and has no accessor for it. Eloquent therefore returns `null` for `$c->is_break` on every row, so `! $c->is_break` is always `true` and the `->filter(...)` keeps every cell. The flag actually lives on `tt_period_types.is_break`, reached by the chain `PeriodSetPeriod → PeriodConfig → PeriodType`. |
| **Consequence** | Any break/assembly-period cell present in the timetable is returned in `today_schedule`, so the mobile "today" list can show a row whose subject is `—` instead of omitting the break. |
| **Reproduce** | Static only — the column absence is proved by the migration query in Evidence; a live timetable cell is not needed to prove the filter is inert. |
| **Fix approach** | Filter on the real chain and eager-load it: `->filter(fn ($c) => ! ($c->period?->periodConfig?->periodType?->is_break))`, with `'period.periodConfig.periodType'` in `with([...])`. |
| **Plan item** | MPC-06 in `02-fix-plan.md` §5 |

```php
                ->with(['activity.subject', 'activity.teachers.teacher.user', 'period', 'room'])
                ->orderBy('period_ord')
                ->get())
                ->filter(fn ($c) => ! $c->is_break);
```

**Evidence**
```
$ grep -n "is_break" database/migrations/tenant/2026_06_16_152645_create_tt_timetable_cell_table.php
(no output — no is_break column on tt_timetable_cells)

$ grep -n "is_break" Modules/TimetableFoundation/app/Models/TimetableCell.php
(no output — no is_break in $fillable/$casts and no accessor)

$ grep -n "is_break" Modules/TimetableFoundation/app/Models/PeriodType.php
33:        'is_break',
51:        'is_break' => 'boolean',
```

### F7 — Models

No new model defect is owned here. Model-level scanner hits on the linked models (`Homework`/`HomeworkSubmission` `MDL-05` `InteractsWithMedia` without `getMediaModel()`, `MDL-04` relation return types, `STY-01`) belong to their owner reports (scope rows 4-13). The only model-schema defect this controller *uses* is `TimetableCell::$is_break`, reported as MPC-06. The `Student::currentFeeAssignemnt()` null-risk and duplicate relation are recorded in §7.

### F8 — Services and jobs

#### MPC-07 · M · SVC-02 — `SnapshotContext` is resolved with `app()` inside the method instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `app(Foo::class)` mid-method* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:186`, method `dashboard()` |
| **Root cause** | `app(SnapshotContext::class)->run($timetableId, fn () => ...)` pulls the service from the container at call time, while the only other service used by this controller (`ParentContextService`) is correctly constructor-injected at line 26-28. |
| **Consequence** | The dependency is hidden from the class signature, `SnapshotContext` cannot be swapped in a test, and the call site reads as if a global were being used. |
| **Reproduce** | Static only — `grep -n "app(" <file>` finds the single call. |
| **Fix approach** | Add `private readonly SnapshotContext $snapshot` to the constructor and call `$this->snapshot->run(...)`. |
| **Plan item** | MPC-07 in `02-fix-plan.md` §5 |

```php
            $todayCells = $timetableId === null ? collect() : app(SnapshotContext::class)->run($timetableId, fn () => TimetableCell::whereHas('activity', fn ($q) => $q
                ->where('class_id', $classId)
                ->where('section_id', $sectionId))
```

**Evidence**
```
$ grep -n "app(" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
186:            $todayCells = $timetableId === null ? collect() : app(SnapshotContext::class)->run($timetableId, fn () => TimetableCell::whereHas('activity', fn ($q) => $q
```

### F9 — Queries and performance

#### MPC-08 · M · QRY-05 — the fee card loads every invoice and sums in PHP instead of aggregating in SQL

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate in SQL: `withSum`, `selectRaw`, not `->get()->sum()` over a whole table* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:232-237`, method `dashboard()` |
| **Root cause** | `$feeAssignment->invoices` materialises every invoice row (all columns) into a Collection, then PHP sums `balance_amount` and filters by status. The `?? collect()` guard is dead code — a `hasMany` relation always returns a Collection. |
| **Consequence** | One fat query per dashboard load where a `sum()` and a `count()` would do; the cost grows with the invoice count and is paid on every app open. |
| **Reproduce** | Static only — the collection is loaded at line 234 and summed at line 235. |
| **Fix approach** | Use the relation query: `$feeAssignment->invoices()->sum('balance_amount')` and a `->whereNotIn('status', [...])->count()`. The same rewrite applies MPC-09. |
| **Plan item** | MPC-08 in `02-fix-plan.md` §6 |

```php
        $feeAssignment = $child->currentFeeAssignemnt ?? null;
        if ($feeAssignment) {
            $invoices = $feeAssignment->invoices ?? collect();
            $feeDue = (float) $invoices->sum('balance_amount');
            $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
        }
```

**Evidence**
```
$ grep -n "->sum(\|->whereNotIn(\|->invoices" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
234:            $invoices = $feeAssignment->invoices ?? collect();
235:            $feeDue = (float) $invoices->sum('balance_amount');
236:            $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
```

#### MPC-09 · M · MDL-09 — the fee "pending" filter uses status literals that never match, so `Cancelled` invoices count as pending

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L default) — *status/type strings are PHP enums or model constants, not literals repeated across files*. Severity raised to **M** with reason: it produces a wrong count on a real card (the same defect the sibling `ParentDashboardApiController` report raised as PDAS-03). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:236`, method `dashboard()` |
| **Root cause** | The filter is `whereNotIn('status', ['paid', 'PAID', 'Paid'])`, but `fee_invoices.status` is `['Cancelled', 'Draft', 'Overdue', 'Paid', 'Partially Paid', 'Published']` — Title Case only. The literals `paid` and `PAID` can never match, and `Cancelled` is not excluded, so every cancelled invoice is counted as pending. The model exposes `FeeInvoice::STATUS_PAID` and `FeeInvoice::STATUS_CANCELLED` for exactly this. |
| **Consequence** | The mobile fee card can show "N pending invoices" when some of them were cancelled, disagreeing with the fee screens. |
| **Reproduce** | Cancel an invoice for the active child, then open `GET /api/mobile/v1/parent/dashboard`: the cancelled invoice still counts in `fee_pending_invoices`. |
| **Fix approach** | Use the model constants and exclude `STATUS_PAID` and `STATUS_CANCELLED`. Applied inside MPC-08's After block (same lines). |
| **Plan item** | none — see `02-fix-plan.md` §10 (fixed inside MPC-08's After) |

```php
            $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();
```

**Evidence**
```
$ grep -n "whereNotIn('status'" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
236:            $feePendingInvoices = $invoices->whereNotIn('status', ['paid', 'PAID', 'Paid'])->count();

$ grep -n "enum('status'" database/migrations/tenant/2026_06_16_092641_create_fee_invoices_table.php
26:            $table->enum('status', ['Cancelled', 'Draft', 'Overdue', 'Paid', 'Partially Paid', 'Published'])->default('Draft');

$ grep -n "STATUS_PAID\|STATUS_CANCELLED" Modules/StudentFee/app/Models/FeeInvoice.php
71:    public const STATUS_PAID = 'Paid';
73:    public const STATUS_CANCELLED = 'Cancelled';
```

#### MPC-10 · H · MDL-09 — attendance "present" matches values that do not exist, so the parent's percentage disagrees with the school's attendance pages

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L default) — *status/type strings are PHP enums or model constants, not literals repeated across files*. Severity raised to **H** with reason: it produces a wrong number on the dashboard, and it is the same defect already raised as PAT-05 / PDAS-02. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:155-158`, method `dashboard()` |
| **Root cause** | The present-count matches `['Present', 'P', 'present']`, but the `std_student_attendance.status` enum is `['Present', 'Absent', 'Late', 'Half Day', 'Short Leave', 'Leave']`. `P` and `present` never occur, and `Half Day` / `Short Leave` are excluded from "present". A `Leave` day is also counted in the denominator but not the numerator. |
| **Consequence** | A parent whose child has any `Half Day` or `Short Leave` day sees a lower attendance percentage on mobile than the attendance page and the student portal show for the same child. |
| **Reproduce** | Mark a student `Half Day` for one day, then open `GET /api/mobile/v1/parent/dashboard`: `attendance_pct` is lower than the `ParentAttendanceController` summary for the same child. |
| **Fix approach** | DECISION — how `Half Day` / `Short Leave` should count toward the parent's percentage, consistent with the PAT-05 decision. See MPC-10 in `02-fix-plan.md` §9. |
| **Plan item** | MPC-10 in `02-fix-plan.md` §9 (DECISION) |

```php
        if ($session?->academic_session_id) {
            $attendanceTotal = StudentAttendance::where('student_id', $child->id)
                ->where('academic_session_id', $session->academic_session_id)
                ->count();
            $attendancePresent = StudentAttendance::where('student_id', $child->id)
                ->where('academic_session_id', $session->academic_session_id)
                ->whereIn('status', ['Present', 'P', 'present'])
                ->count();
```

**Evidence**
```
$ grep -n "whereIn('status'" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
157:                ->whereIn('status', ['Present', 'P', 'present'])

$ grep -n "enum('status'" database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php
21:            $table->enum('status', ['Present', 'Absent', 'Late', 'Half Day', 'Short Leave', 'Leave']);
```

### F10 — Views

clean — this is an API controller: both methods return `response()->json(...)` and no Blade view is rendered, so VIEW-01..03 and the UI standards do not apply.

### F11 — Security and tenancy

clean — `grep -nE "env\(|cache|asset\(|storage|?? 1" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php` → no output. No `env()` outside `config/`; no hard-coded ids or `?? 1`; the JSON is a hand-mapped array of the parent's own child (id, name, class, section, roll, admission number, age, date of birth, gender, counts) and never a whole model, so SEC-02 holds; no secrets are logged and no cache is used. Tenancy: the route carries `tenant.mobile` (`InitializeTenancyByMobileHeader`) and every query runs on the tenant connection; the only central-table touch (`glb_academic_sessions` via `Student::currentFeeAssignemnt()`) is the `Student` model's own doing and is recorded in §7. The subject query at lines 84-92 uses the query builder with bound values (no interpolated raw SQL), so QRY-11 does not apply.

### F12 — Style

#### MPC-11 · L · STY-04 — comments use emoji and box-drawing markers

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:146, 163, 173, 228, 239, 249`, method `dashboard()` |
| **Root cause** | Section separators use box-drawing characters (`// ── Attendance ──`) and the timetable comment opens with the `⛔` marker. |
| **Consequence** | Fails the project's comment style; no functional effect. |
| **Reproduce** | Static only — `grep -nE "⛔|──" <file>`. |
| **Fix approach** | Replace the markers with plain English section comments (`// Attendance`, `// Timetable, homework and exams`) and drop the `⛔`. One item touches this file only. |
| **Plan item** | MPC-11 in `02-fix-plan.md` §8 |

```php
            | ⛔ PUBLISHED ONLY, PINNED BY ID — see PublishedTimetable.
```

**Evidence**
```
$ grep -nE "⛔|⚠|──|│" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
146:        // ── Attendance ──
163:        // ── Timetable / Homework / Exams ──
173:            | ⛔ PUBLISHED ONLY, PINNED BY ID — see PublishedTimetable.
228:        // ── Fee summary ──
239:        // ── Leave ──
249:        // ── Notifications ──
```

#### MPC-12 · L · CTL-08 — the `request()` helper is used instead of an injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; do not call the `request()` helper inside controller methods* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php:73` (`children()`), `:140` (`dashboard()`) |
| **Root cause** | Neither method declares a `Request` parameter; they call the global `request()` helper and `auth()->user()` directly. |
| **Consequence** | Minor consistency issue; the methods read as if they need no request, while they do. |
| **Reproduce** | Static only — `grep -n "request()" <file>`. |
| **Fix approach** | Add `Request $request` to both signatures and use `$request->user()`; import `Illuminate\Http\Request`. Deferred to §10 because it edits the same `children()` line as MPC-01, and only one item may own a line. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
                $activeChildId = $this->context->resolveChild(request())->id;
```

**Evidence**
```
$ grep -n "request()\|auth()->user()" Modules/ParentPortal/app/Http/Controllers/Mobile/MobileParentController.php
38:        $user = auth()->user();
73:                $activeChildId = $this->context->resolveChild(request())->id;
139:        $user = auth()->user();
140:        $child = $this->context->resolveChild(request());
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Neither method mutates its own tables; the only reachable mutation is indirect, through `ParentContextService::resolveChild()` (service lines 93-124) which can `create()`/`update()` `ppt_parent_sessions`. The questions are answered for both methods against that call.

| # | Question | `children()` (via `resolveChild()`) | `dashboard()` (via `resolveChild()`) |
|---|---|---|---|
| 1 | Can a write overwrite data it should not? | ok — only this guardian's `active_student_id` / `last_active_at` is touched | ok — same |
| 2 | Is anything deleted before its replacement is stored? | ok — nothing is deleted | ok — same |
| 3 | Are there duplicate implementations of one operation? | MPC-05 — `children()` duplicates `getAccessibleChildren()` | §7 — `Student` has `feeAssignment()` and `currentFeeAssignemnt()` for the same fact |
| 4 | Is there a soft-delete × unique-index trap? | ok — no create/restore on this controller's data | ok — same |
| 5 | Is there a race? | §7 — `getOrCreateSession()` is check-then-act (`where → first → create`) with no lock | §7 — same |
| 6 | Is there an authorization hole? | MPC-02 — no parent gate; record-level scope is correct | MPC-02 — same |
| 7 | Does any message lie? | ok — the payload matches the columns it names (`roll_no`, `admission_no`, `dob`) | MPC-06, MPC-08, MPC-09, MPC-10 — schedule, fee and attendance output is wrong |
| 8 | Is there a dead feature? | ok — the child picker consumes the payload | MPC-06 — the break filter can never remove a cell |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` (owned by ParentDashboardController report) | `resolveChild()` writes on a read path: `getOrCreateSession()` can `create()` a `ppt_parent_sessions` row and `resolveChild()` `update()`s `active_student_id` / `last_active_at` while called from a GET (lines 119-121, 202-222). It also touches HTTP inside a service by throwing `abort(redirect()->route('parent-portal.no-access'))` (lines 103-105), which on a JSON API returns a 302 HTML redirect, not a JSON 403 (ERR-04). `getOrCreateSession()` makes two writes with no `DB::transaction` (TXN-01) and is check-then-act with no lock (TXN-06). The method also returns early with `activeChildMemo[$parentId]` where `$parentId` is `null` for an unauthenticated user but keys a memo, and the file uses emoji comment markers (STY-04). | SVC-01, SVC-03, TXN-01, TXN-06, ERR-04 | ParentDashboardController report |
| `Modules/StudentProfile/app/Models/Student.php` (owned by gaurav/StudentProfile/StudentReportController report) | `currentFeeAssignemnt()` (lines 315-319) runs `AcademicSession::current()->first()->id` inside the relation: if `glb_academic_sessions` has no `is_current` row, `->id` on null throws and every `dashboard` load 500s. It is also a duplicate of `feeAssignment()` (SVC-04) and a bare `hasOne` with no `latestOfMany`, so a student with two current-session assignments gets an arbitrary row. Scanner also flags MDL-05 (`InteractsWithMedia` without `getMediaModel()`, line 21). ⚠ UNVERIFIED whether a tenant can lack a current session. | MDL-05, SVC-04, null-safe relation | gaurav/StudentProfile/StudentReportController report |
| `Modules/LmsHomework/app/Models/Homework.php` and `HomeworkSubmission.php` (owned by ParentHomeworkController report) | No defect in how this controller uses them: `Homework::status` is a `belongsTo(Dropdown, 'status_id')` and the literal `'PUBLISHED'` matches the seeded dropdown `value` (`LmsHomeworkSeeder.php:243`, `HomeworkSchedulingTest.php:97`), so the pending count is correct. Model-level scanner hits (MDL-05 `InteractsWithMedia` without `getMediaModel()`, MDL-04 relation return types, STY-01) belong to the owner report. | MDL-05, MDL-04, STY-01 | ParentHomeworkController report |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php` (owned by TimetableFoundation/TimetableController report) | `teachers()` is a `belongsToMany` over `tt_timetable_cell_teachers` (which has `deleted_at`) without `wherePivotNull('deleted_at')` (MDL-03). This controller reads `activity.teachers.teacher.user`, not the cell's own pivot, so it does not hit this here. Emoji comment markers (STY-04) also belong to the owner. | MDL-03, STY-04 | TimetableFoundation/TimetableController report |
| `Modules/StudentProfile/app/Models/StudentAttendance.php`, `LeaveApplication.php`, `Guardian.php`, `StudentGuardianJnt.php`, `Modules/LmsExam/app/Models/ExamAllocation.php`, `Modules/TimetableFoundation/app/Services/PublishedTimetable.php`, `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` (owners in scope rows 3-14) | No defect in how this controller uses them. Scanner-level hits (STY-01 missing `strict_types`, MDL-04 relation return types, MDL-05 on `Guardian`, STY-04 emoji, and `PublishedTimetable::idFor()` at 113 lines — CTL-02) belong to the owner reports. `LeaveApplication::STATUS_*` constants are used correctly. | STY-01, MDL-04, MDL-05, CTL-02 | the reports named in §3 |

## 8. Not covered, and why

- Live row counts for §0 were not measured — a tenant DB connection was not opened in this read-only audit (D4).
- The endpoints were not exercised end-to-end — no parent Sanctum token, tenant mobile header or app key was available, so every payload claim comes from reading the code and the tenant migration schema.
- The indirect write to `ppt_parent_sessions` and the 302-redirect behaviour of `resolveChild()` were not reproduced at runtime; they are proved by reading `ParentContextService.php` (scope row 3, owned elsewhere).
- Whether break-period cells are actually generated for a class timetable was not measured; MPC-06 proves the filter is inert, and the visible effect depends on break cells existing.
- The linked models and services were not re-audited — each is owned by another report (scope rows 3-14); only how this controller uses them was checked.
