# 03 — Status · ParentAccountController

**Fixed:** 2026-10-22 · **By:** opencode · **Developer folder:** tarun

Decisions taken with the user's approval (2026-10-22):
- PAC-02 → (b) session-only language (2026-10-22)
- PAC-05 → (a) dropdown-FK device type (2026-10-22)
- PAC-14 → (a) restore before upsert (2026-10-22)

## 1. Pre-applied 2026-10-10
None for this controller.

## 2. Applied

PAC-04, PAC-01, PAC-08, PAC-10, PAC-12, PAC-13.

## 3. Not applied
- None.

## 4. Needs Tarun's hand
- Nothing applied this pass requires a migration, seeder or permission-key run. Shared-service conversions marked ⚠ SHARED in the plan were either applied mechanically or left as recorded decisions.

## 5. Unverifiable by this workflow (D4)
- No browser/device walkthrough was performed; verification is static (lint, class load, routes, Blade compile, Pint).

## 6. Verification log
```
php -l <all changed PHP files>                 No syntax errors
class_exists <all changed classes>             0 missing (91 classes checked module-wide)
route:list + method_exists (ParentPortal/Ptm)  40 routed classes, 0 problems
Blade compile (12 changed blades)              0 failures
vendor/bin/pint <changed files>                fixed / passed
```

## 7. Final state
FIXED. Open: none.
