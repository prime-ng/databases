# Final Audit — ParentPortal / ParentNotificationController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` (110 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /parent-portal/notifications` (list) · `POST /parent-portal/notifications/{notification}/read` (mark one) · `POST /parent-portal/notifications/read-all` (mark all) |
| Menu path | Parent Portal → header bell / Notifications |
| Who uses it | A logged-in user with `sys_users.user_type = 'PARENT'` whose guardian has at least one child with `can_access_parent_portal = 1`. Measured on the test tenant: 3648 users have `user_type = 'PARENT'`. |
| What a user does here | The parent opens the notifications screen, sees their own notifications newest-first, marks a single notification read from a button or by clicking "View", or presses "Mark all read". Marking is done over AJAX and the list updates in place. |
| Tables written | `notifications` (`read_at` column) and `sys_activity_logs` (one audit row per action) |
| Tables read | `notifications`, `sys_users` (auth), plus `std_guardians` / `std_student_guardian_jnt` in the route middleware gate |
| Live data | `notifications` 4 rows (2 unread) on `test.localhost`; `sys_activity_logs` 1949 rows; 0 rows with the "Viewed notifications" text yet. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is close to production-ready and is the cleanest of the ParentPortal controllers reviewed so far: error handling follows the Laravel idiom (D1), ownership is correctly scoped to the logged-in parent, and every write pair shares one transaction. It is **not** a blocker-heavy screen — there are no B or H findings.

The single worst finding is **PNT-03**: "Mark all read" issues one `UPDATE` per unread notification instead of a single bulk `UPDATE`, inside a transaction, so a parent with hundreds of notifications pays hundreds of round-trips for one button press. The second is **PNT-05**: the screen's own docblock promises "unread first", but the query never sorts that way because the framework relation already added `ORDER BY created_at DESC` ahead of the controller's clauses.

Effort to fix the whole plan: **S** (about an hour, one file).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 4 | 1 | 0 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | n/a — no service or job reached |
| F2 Transactions/Audit | clean | F9 Queries/Perf | PNT-02, PNT-03 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | PNT-04 |
| F6 Controller shape | PNT-01 | F13 Deep read | PNT-05 |
| F7 Models | n/a — no module model owned here | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` | controller | 110 | this report | ✅ |
| 2 | `Modules/ParentPortal/resources/views/notifications/index.blade.php` | view | 202 | this report | ✅ |
| 3 | `Modules/ParentPortal/resources/views/layouts/app.blade.php` | layout | 162 | common (§4.2) | ❌ common — referenced, not audited |
| 4 | `Modules/ParentPortal/routes/web.php` | route file | 199 | shared route file | ❌ shared — route definitions read only |
| 5 | `Modules/ParentPortal/app/Providers/RouteServiceProvider.php` | provider | 100 | module glue | ❌ referenced — defines the middleware stack |
| 6 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | module-wide gate | ❌ module-wide — see §7 |
| 7 | `app/Helpers/activityLog.php` | helper | 51 | common (§4.2) | ❌ common — referenced, not audited |
| 8 | `Modules/SchoolSetup/app/Models/User.php` | model | 317 | core auth model (app glue) | ❌ common — referenced, not audited |
| 9 | `Illuminate\Notifications\DatabaseNotification` | framework model | — | Laravel | ❌ framework |

No in-scope file appears in a module `PRE-APPLIED-*.md` (`find final-audit-reports -name 'PRE-APPLIED*'` → only `tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md`).

No non-common class needed claiming: the controller reaches only the core `SchoolSetup\User` model, the framework `DatabaseNotification`, the module-wide `ParentPortalMiddleware`, and the shared `activityLog()` helper. None of these is owned by this report, so `00-CLASS-OWNERS.md` was not appended to.

## 4. Routes

Fresh uncached `route:list` output for this controller:

```
GET|HEAD parent-portal/notifications                             parent-portal.notifications.index             Modules\ParentPortal\Http\Controllers\ParentNotificationController@index
POST    parent-portal/notifications/read-all                    parent-portal.notifications.mark-all-read     Modules\ParentPortal\Http\Controllers\ParentNotificationController@markAllRead
POST    parent-portal/notifications/{notification}/read         parent-portal.notifications.mark-read         Modules\ParentPortal\Http\Controllers\ParentNotificationController@markRead
```

Unrouted public methods: none.

Middleware stack (from `Modules/ParentPortal/app/Providers/RouteServiceProvider.php:76-88`): `web → InitializeTenancyByDomain → PreventAccessFromCentralDomains → EnsureTenantIsActive → EnsureTenantHasModule:ParentPortal → auth → ParentPortalMiddleware`. All three routes are inside it, including `auth` and the tenancy middleware.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 19 | GET /parent-portal/notifications | none — `ParentPortalMiddleware` (user_type + child) | none — single audit write | 'Viewed' | sys_activity_logs | PNT-01, PNT-02, PNT-05 |
| `markRead` | 48 | POST /parent-portal/notifications/{notification}/read | none — `ParentPortalMiddleware`; ownership via `$user->notifications()->findOrFail()` | controller | 'MarkedRead' | notifications, sys_activity_logs | PNT-01, PNT-04 |
| `markAllRead` | 84 | POST /parent-portal/notifications/read-all | none — `ParentPortalMiddleware`; operates only on own unread | controller | 'MarkedRead' | notifications, sys_activity_logs | PNT-01, PNT-03 |

## 6. Findings

Findings are grouped by family F1 → F13. Each carries the eight required fields plus the current code and the evidence output.

### F1 — Errors

clean — `grep -nE 'try \{|catch|getMessage|report\(|Log::' Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` → the only match is a comment on line 51 (`// ... the catch below (Rule A1).`); there is no `try`, `catch`, `getMessage`, `report(` or `Log::` call in the file. Under D1 the controller correctly has no try/catch: `findOrFail()` is outside the transaction, so a bad id stays a native 404, and the central handler in `bootstrap/app.php` renders anything else.

### F2 — Transactions and audit

clean — the two mutating methods each wrap their writes in ONE `DB::transaction` closure with `activityLog()` **after** the write and **inside** the transaction:
- `markRead` (`:59-72`) writes `notifications.read_at` then the audit row;
- `markAllRead` (`:91-104`) writes the notification rows then the audit row.
`index` (`:30`) writes one audit row only (single table, no transaction needed). No irreversible side effect (mail/file/HTTP) sits inside a transaction. Evidence: `grep -n 'DB::transaction' Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` →

```
59:        DB::transaction(function () use ($notif, $notification) {
91:        DB::transaction(function () use ($request, $count) {
```

### F3 — Authorization

clean. Every route sits behind `auth` + `ParentPortalMiddleware`, which enforces `user_type === 'PARENT'`, a real `std_guardians` row, and at least one portal-enabled child (`ParentPortalMiddleware.php:29-63`). Record ownership is correct: `markRead` loads the notification through `$request->user()->notifications()->findOrFail($notification)` (`:54`), so a parent cannot mark another parent's notification read, and `index`/`markAllRead` only ever touch `$request->user()`. There is no per-feature permission key anywhere in the module (`grep -c 'parent' config/permissionslist.php` → 0), so this controller's authorization rests entirely on the portal middleware — see §7.

### F4 — Validation and input

clean — `grep -nE 'validate\(|->all\(|->except\(|\$request->' Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` → the only `$request->` uses are `$request->user()`, `$request->route()` and `$request->expectsJson()`; there is no `validate()`, `$request->all()` or `except()`. `markRead` takes a route-bound UUID string (no body); `markAllRead` and `index` take no input, so no FormRequest is required.

### F5 — Routes

clean. All three public methods are routed (`route:list` in §4). The custom `read-all` route (`routes/web.php:162`) is registered after `{notification}/read` (`:161`) but cannot be shadowed — `read-all` has no `/read` suffix, so it never matches the `{notification}/read` pattern. The route parameter name `{notification}` matches the method argument `$notification`. The tenant middleware chain is present (§4). No state change is exposed over GET (the only GET, `index`, writes an audit row, which is the module-wide "Viewed" convention — recorded in §7).

### F6 — Controller shape

#### PNT-01 · M · CTL-05 — the same activity-log context array is copy-pasted in all three methods

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same block repeated in several methods*; the same lines also repeat the `request()` helper, which is CTL-08 (L). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:30-38, 59-72, 94-103`, methods `index()`, `markRead()`, `markAllRead()` |
| **Root cause** | The four-key `context` array (`student_id`, `student_name`, `module`, `route`) is written out in full three times, and each copy rebuilds the route name with the global `request()` helper instead of the `Request` that is already injected into every method. A later change to the context (e.g. adding the active child id) has to be made in three places or they drift. |
| **Consequence** | A future edit that touches one copy but not the others makes the three audit events disagree about the same screen, and the code reads as three unrelated blocks. |
| **Reproduce** | Static only — this audit is read-only; the duplication is visible in the three method bodies. |
| **Fix approach** | Add one private `notificationContext(Request $request): array` method and call it from all three `activityLog()` context keys, passing the injected `$request`. This removes the copy-paste and the `request()` helper in one move. |
| **Plan item** | PNT-01 in `02-fix-plan.md` §8 |

```php
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Viewed notifications',
            'context' => [
                'student_id' => null,
                'student_name' => null,
                'module' => 'ParentPortal',
                'route' => request()->route()?->getName(),
            ],
        ]);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-parentportal.json Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php
M  CTL-05   Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:32  - — identical 4-item array literal repeated 3× (lines 32,64,96)
L  CTL-08   Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:36  index — request() helper in controller
...
$ grep -n "'module' => 'ParentPortal'" Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php
35:                'module' => 'ParentPortal',
67:                    'module' => 'ParentPortal',
99:                    'module' => 'ParentPortal',
```

### F7 — Models

n/a. This controller owns no module model. It reaches the core `Modules/SchoolSetup/app/Models/User.php` (auth glue) via `$request->user()` and the framework `Illuminate\Notifications\DatabaseNotification` via the `Notifiable` trait. The `notifications` table it writes exists in the tenant migration `database/migrations/tenant/2025_12_31_045403_create_notifications_table.php` (columns `id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, timestamps). No `$fillable`, `$casts` or Spatie-media concern belongs to this controller.

### F8 — Services and jobs

n/a — no service, job, event, mail or notification class is referenced; `grep -oE '[A-Z][A-Za-z]+(Request|Policy|Service|Job|Event|Mail|Notification|Export|Import)\b' ...` returns nothing.

### F9 — Queries and performance

#### PNT-02 · M · QRY-02 — the list paginates at 30, not the project-standard 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (default H) — *lists are paginated*. Kept at **M** because the list **is** paginated, so the rule is not violated; the deviation is from the project standard of 10 rows per page (checklist F9 / C12). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:26`, method `index()` |
| **Root cause** | The page size is hard-coded to 30. Across the app `paginate(10)` is used 713 times and `paginate(30)` only 8 times, so 30 is an outlier rather than a deliberate product choice. |
| **Consequence** | The notifications page renders three times as many rows as every other list, so large accounts get a slower first paint and an unfamiliar page length. |
| **Reproduce** | Static only — read the page size on `:26`; the query is proven in the evidence block. |
| **Fix approach** | Change `->paginate(30)` to `->paginate(10)`. There is a single paginator on this page, so the default `page` page-name is already distinct. |
| **Plan item** | PNT-02 in `02-fix-plan.md` §6 |

```php
            ->paginate(30);
```

**Evidence**
```
$ grep -rho "paginate([0-9]*" app/ Modules/ --include=*.php | sort | uniq -c | sort -rn | head
    713 paginate(10
    343 paginate(15
    240 paginate(20
    142 paginate(
     77 paginate(25
     18 paginate(50
     16 paginate(12
      7 paginate(5
      7 paginate(30
```

#### PNT-03 · M · QRY-07 — "Mark all read" issues one UPDATE per notification instead of one bulk UPDATE

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: use a single `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:86-92`, method `markAllRead()` |
| **Root cause** | `$request->user()->unreadNotifications->markAsRead()` accesses the relation as a **collection** and calls the framework collection helper, which is implemented as `$this->each->markAsRead();` — i.e. one `UPDATE` per model. The count on `:86` also hydrates the whole collection only to count it. A query-builder `->update(['read_at' => now()])` would do the same work in one statement. |
| **Consequence** | A parent with hundreds of unread notifications pays hundreds of sequential `UPDATE` round-trips for a single "Mark all read" press — slow and lock-holding inside the transaction. |
| **Reproduce** | Static only — the framework helper is proven in the evidence block. |
| **Fix approach** | Keep the transaction and the audit row, but build the unread relation once (`$unread = $request->user()->unreadNotifications();`), count it with `->count()`, and write with `$unread->update(['read_at' => now()]);` inside the same closure. |
| **Plan item** | PNT-03 in `02-fix-plan.md` §6 |

```php
        $count = $request->user()->unreadNotifications->count();

        // Rule A2: a bulk mark-read writes MANY notification rows plus one audit row.
        // Without a transaction a partial failure leaves some read, some not, and a log
        // line claiming a count that never landed.
        DB::transaction(function () use ($request, $count) {
            $request->user()->unreadNotifications->markAsRead();
```

**Evidence**
```
$ sed -n '17,24p' vendor/laravel/framework/src/Illuminate/Notifications/DatabaseNotificationCollection.php
    public function markAsRead()
    {
        $this->each->markAsRead();
    }

$ sed -n '71,80p' vendor/laravel/framework/src/Illuminate/Notifications/DatabaseNotification.php
    public function markAsRead()
    {
        if (is_null($this->read_at)) {
            $this->forceFill(['read_at' => $this->freshTimestamp()])->save();
        }
    }
```

### F10 — Views

clean. The view `notifications/index.blade.php` contains no `Model::`, `DB::`, `->where(`, `->get()` or `->count()` query (evidence below); it renders only the `$all` paginator and `$unreadCount` the controller passed. All user-controlled text is escaped with `{{ }}` (`{{ $title }}`, `{{ Str::limit(strip_tags($body), 160) }}`, `{{ $tag }}`) and there is no `{!! !!}` anywhere, so there is no stored-XSS path. `$notif->data` is cast to an array by the framework model, and the row loop uses the JSON payload rather than lazy relations, so there is no VIEW-02 N+1.

```
$ grep -nE '\{\!\!|Model::|DB::|->where\(|->get\(\)|->count\(\)|->all\(\)' Modules/ParentPortal/resources/views/notifications/index.blade.php
(no output)
```

### F11 — Security and tenancy

clean — `grep -n 'env(' Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` → no output. No hard-coded ids or `?? 1`, no personal data in the JSON reply (`response()->json(['status' => true])` only), no request body or secret in a log, and the audit row records only the acting user, route name and IP/user-agent from the shared helper. Media/cache/central-model rules do not apply to this screen.

### F12 — Style

#### PNT-04 · L · STY-04 — a stale comment describes a `catch` that no longer exists

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *no "temporary"/"debug"/misleading notes; comments describe what the code does.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:50-53`, method `markRead()` |
| **Root cause** | The method was once written in the "Variant H" house style (`try/catch` in the controller, called "Rule A1"). D1 replaced that idiom with no try/catch, but the explanatory comment was left behind: it tells the reader the id is kept out of a `catch` **below**, and there is no `catch` in the file. The `Rule A2` comments on `:56-58` and `:88-90` reference the same retired rule set. |
| **Consequence** | A developer reading `markRead()` looks for a catch that is not there, and may re-add one to "match the comment", re-introducing the ERR-00 defect the file has already avoided. |
| **Reproduce** | Static only — read `:50-53`; `grep -nE 'try \{|catch' <file>` returns only line 51 (the comment itself). |
| **Fix approach** | Rewrite the comment to state the current truth (the id stays out of the transaction so a bad id is a native 404) and drop the reference to a catch below. |
| **Plan item** | PNT-04 in `02-fix-plan.md` §8 |

```php
        // findOrFail stays OUTSIDE the transaction so a bad id remains a native 404
        // rather than being converted into a redirect by the catch below (Rule A1).
        // Scoping to $request->user()->notifications() is also the ownership guard —
        // one parent cannot mark another parent's notification read.
```

**Evidence**
```
$ grep -nE 'try \{|catch' Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php
51:        // rather than being converted into a redirect by the catch below (Rule A1).
```

`vendor/bin/pint --test Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` → `{"tool":"pint","result":"passed"}` (Pint-clean; the file also has `declare(strict_types=1)` and camelCase names).

### F13 — Deep read (answer all 8 questions for every mutating method)

`index()` writes one `sys_activity_logs` row; `markRead()` and `markAllRead()` each write `notifications` + `sys_activity_logs`. The three mutating methods are answered against the eight deep-read questions:

| Method | 1 wrong overwrite | 2 delete-before-store | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 authz hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` | ok | ok | ok | ok | ok | ok | ok | ok |
| `markRead` | ok | ok | ok | ok | ok | ok | ok | ok |
| `markAllRead` | ok | ok | ok | ok | ok | ok | ok | ok |

#### PNT-05 · M · DEEP-01 — the documented "unread first" ordering never applies

| Field | Value |
|---|---|
| **Rule** | Deep-read checklist #7 — *messages that lie; the code must do what its documentation says.* Default **M** (a wrong ordering, not a data or security defect). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php:23-26`, method `index()` (docblock on `:16-18`) |
| **Root cause** | The `Notifiable` trait's `notifications()` relation already applies `->latest()`, i.e. `ORDER BY created_at DESC`. The controller then appends `->orderBy('read_at')` and `->orderByDesc('created_at')`. SQL keeps the first `ORDER BY` as the primary sort, so the generated statement is `order by created_at desc, read_at asc, created_at desc` — newest first, with `read_at` only a tie-breaker. The docblock ("unread first, then read grouped by date") is therefore false: unread rows are **not** floated to the top, they are interleaved by date. |
| **Consequence** | A parent with older unread notifications sees them buried under newer read ones — the exact opposite of the screen's stated behaviour, and the "New" badges are scattered down the list. |
| **Reproduce** | Static only — the generated SQL is proven below. |
| **Fix approach** | Clear the relation's default ordering with `->reorder()` before adding the intended sort, then sort so NULL `read_at` (unread) comes first: `->orderByRaw('read_at IS NULL DESC')->orderByDesc('created_at')`. |
| **Plan item** | PNT-05 in `02-fix-plan.md` §6 |

```php
        $all = $user->notifications()
            ->orderBy('read_at')
            ->orderByDesc('created_at')
```

**Evidence**
```
$ php artisan tinker --execute '... $u->notifications()->orderBy("read_at")->orderByDesc("created_at")->toSql() ...'
select * from `notifications` where `notifications`.`notifiable_type` = ? and `notifications`.`notifiable_id` = ? and `notifications`.`notifiable_id` is not null order by `created_at` desc, `read_at` asc, `created_at` desc
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | This middleware is the only authorization gate for the whole ParentPortal module (user_type + guardian + child). There is no per-feature permission key for the portal anywhere (`grep -c 'parent' config/permissionslist.php` → 0), so every ParentPortal controller relies on it. It is not registered in `00-CLASS-OWNERS.md`; it should be assigned once by the main session rather than re-read by each controller's audit. Its logic looked correct for this controller (user_type check, guardian lookup, portal-enabled-child `exists()`), and it does not itself pose a defect. | AUTH-01 | main session — assign once in `00-SUMMARY.md` |
| `app/Helpers/activityLog.php` | Every read page in the app writes a `sys_activity_logs` row (`activityLog()` inside `index`). This makes a GET perform a write. Accepted as the module-wide "Viewed" convention; recorded here so it is not re-litigated per controller. | RTE-01 (informational) | accepted convention — no fix |

## 8. Not covered, and why

- The layout `parentportal::layouts.app` and its `_header`/`_sidebar` partials are common (§4.2) and were referenced, not audited. The header's unread bell (`[data-ppt-unread]`) is updated by the view's inline JS but is rendered by the layout, which is out of scope.
- `ParentPortalMiddleware` is module-wide and used by ~30 controllers; per §5 it should be audited once by its owning report, so only the parts this controller relies on were checked (recorded in §7).
- No browser or database-write check was performed (D4 — this audit is read-only). "Reproduce" rows are static where noted; the SQL and framework-helper proof came from `tinker --execute` `SELECT`/`->toSql()` only.
