# Fix Plan — ParentPortal / ParentNotificationController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/resources/views/layouts/app.blade.php` | common layout (§4.2) |
| `Modules/ParentPortal/resources/views/notifications/index.blade.php` | audited and clean — no change needed |
| `Modules/ParentPortal/routes/web.php` | shared route file |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | module-wide gate, audited once elsewhere (§7 of the report) |
| `Modules/SchoolSetup/app/Models/User.php` | core auth model |
| `app/Helpers/activityLog.php` | common helper |
| `config/permissionslist.php` | shared config |

## 1. Blockers reachable today

None — no B or H findings.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

None — error handling and both transactions are already correct.

## 4. Authorization (F3)

None.

## 5. Validation, routes, models (F4/F5/F7)

None.

## 6. Queries & performance (F9)

- [x] **PNT-02** · M · QRY-02 · `ParentNotificationController.php:26` — paginate the notifications list at the project standard of 10 rows, not 30.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Before** (`ParentNotificationController.php:26`):
    ```php
                ->paginate(30);
    ```
  - **After:**
    ```php
                ->paginate(10);
    ```
  - **Verify:** `grep -n "paginate(" Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Expect:** `26:            ->paginate(10);`
  - **Effort:** S

- [x] **PNT-03** · M · QRY-07 · `ParentNotificationController.php:86-92` — "Mark all read" must issue ONE bulk UPDATE, not one UPDATE per notification.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Before** (`ParentNotificationController.php:86-92`):
    ```php
            $count = $request->user()->unreadNotifications->count();

            // Rule A2: a bulk mark-read writes MANY notification rows plus one audit row.
            // Without a transaction a partial failure leaves some read, some not, and a log
            // line claiming a count that never landed.
            DB::transaction(function () use ($request, $count) {
                $request->user()->unreadNotifications->markAsRead();
    ```
  - **After:**
    ```php
            // QRY-07 (final-audit 2026-10-13): one bulk UPDATE for every unread row; the
            // collection's markAsRead() issues one UPDATE per row instead.
            $unread = $request->user()->unreadNotifications();
            $count = $unread->count();

            DB::transaction(function () use ($request, $unread, $count) {
                $unread->update(['read_at' => now()]);
    ```
  - **Verify:** `grep -n "markAsRead()\|unreadNotifications" Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Expect:** no line matching `unreadNotifications->markAsRead()`; the new lines `$unread = $request->user()->unreadNotifications();` and `$unread->update(['read_at' => now()]);` are present.
  - **Effort:** S

- [x] **PNT-05** · M · DEEP-01 · `ParentNotificationController.php:23-25` — clear the relation's default `latest()` ordering so "unread first" actually happens.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Before** (`ParentNotificationController.php:23-25`):
    ```php
            $all = $user->notifications()
                ->orderBy('read_at')
                ->orderByDesc('created_at')
    ```
  - **After:**
    ```php
            $all = $user->notifications()
                ->reorder()
                ->orderByRaw('read_at IS NULL DESC')
                ->orderByDesc('created_at')
    ```
  - **Verify:** `sed -n '23,27p' Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Expect:** the printed lines contain `->reorder()` and `->orderByRaw('read_at IS NULL DESC')`.
  - **Effort:** S

## 7. Views (F10)

None — the view is clean.

## 8. Style and controller shape (F6/F12)

- [x] **PNT-01** · M · CTL-05 · `ParentNotificationController.php:30-38, 59-72, 94-103` — remove the three copies of the activity-log context array and the `request()` helper by extracting one private method.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Before** — occurrence 1, `index()` (`:30-38`):
    ```php
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed notifications',
                'context' => [
                    'student_id' => null,
                    'student_name' => null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
    ```
  - **After:** occurrence 1, `index()`:
    ```php
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed notifications',
                'context' => $this->notificationContext($request),
            ]);
    ```
  - **Before** — occurrence 2, `markRead()` (`:59-72`):
    ```php
            DB::transaction(function () use ($notif, $notification) {
                $notif->markAsRead();

                activityLog(auth()->user(), 'MarkedRead', [
                    'message' => 'Marked notification as read',
                    'context' => [
                        'student_id' => null,
                        'student_name' => null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'notification_id' => $notification,
                ]);
            });
    ```
  - **After** — occurrence 2, `markRead()`:
    ```php
            DB::transaction(function () use ($request, $notif, $notification) {
                $notif->markAsRead();

                activityLog(auth()->user(), 'MarkedRead', [
                    'message' => 'Marked notification as read',
                    'context' => $this->notificationContext($request),
                    'notification_id' => $notification,
                ]);
            });
    ```
  - **Before** — occurrence 3, `markAllRead()` (`:94-103`):
    ```php
                activityLog(auth()->user(), 'MarkedRead', [
                    'message' => 'Marked all notifications as read',
                    'context' => [
                        'student_id' => null,
                        'student_name' => null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                    'count' => $count,
                ]);
    ```
  - **After** — occurrence 3, `markAllRead()`:
    ```php
                activityLog(auth()->user(), 'MarkedRead', [
                    'message' => 'Marked all notifications as read',
                    'context' => $this->notificationContext($request),
                    'count' => $count,
                ]);
    ```
  - **Before** — add the method before the closing brace (`:106-110`):
    ```php
            return redirect()
                ->route('parent-portal.notifications.index')
                ->with('success', 'All notifications marked as read.');
        }
    }
    ```
  - **After** — add the method before the closing brace:
    ```php
            return redirect()
                ->route('parent-portal.notifications.index')
                ->with('success', 'All notifications marked as read.');
        }

        /**
         * Shared activity-log context for the notification screen.
         *
         * @return array<string, mixed>
         */
        private function notificationContext(Request $request): array
        {
            return [
                'student_id' => null,
                'student_name' => null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ];
        }
    }
    ```
  - **Verify:** `grep -n "notificationContext\|request()->route()" Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Expect:** one `private function notificationContext` definition and three `$this->notificationContext($request)` call sites; no `request()->route()` line remains.
  - **Effort:** M

- [x] **PNT-04** · L · STY-04 · `ParentNotificationController.php:50-53` — the comment tells the reader about a `catch` that no longer exists; state the current truth.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Before** (`ParentNotificationController.php:50-53`):
    ```php
            // findOrFail stays OUTSIDE the transaction so a bad id remains a native 404
            // rather than being converted into a redirect by the catch below (Rule A1).
            // Scoping to $request->user()->notifications() is also the ownership guard —
            // one parent cannot mark another parent's notification read.
    ```
  - **After:**
    ```php
            // findOrFail stays OUTSIDE the transaction so a bad id remains a native 404.
            // Scoping to $request->user()->notifications() is also the ownership guard:
            // one parent cannot mark another parent's notification read.
    ```
  - **Verify:** `grep -n "the catch below" Modules/ParentPortal/app/Http/Controllers/ParentNotificationController.php`
  - **Expect:** no output.
  - **Effort:** S

## 9. Deferred / decisions

None.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| — | Every finding (PNT-01 to PNT-05) has a plan item above. |
