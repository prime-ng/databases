# Fix Plan — ParentPortal / ParentConsentFormController

**From:** `01-report.md` (2026-10-13) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/ParentPortal/routes/web.php` | shared route file (system) |
| `Modules/ParentPortal/app/Services/ParentContextService.php` | owned by tarun/ParentPortal-done/ParentDashboardController |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | owned by tarun/ParentPortal-done/ParentPtmController |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | owned by tarun/ParentPortal-done/ParentComplaintController |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | owned by tarun/ParentPortal-done/ParentHealthController |
| `Modules/StudentProfile/app/Models/Guardian.php` | owned by gaurav/StudentProfile/StudentController |
| `Modules/ParentPortal/app/Providers/ParentPortalServiceProvider.php` | shared provider (policy registration) |
| `Modules/Feedback/app/Providers/FeedbackServiceProvider.php` | shared provider (policy registration) |
| `database/migrations/tenant/2026_06_16_105228_create_ppt_consent_form_responses_table.php` | existing migration — never edited |

## 1. Blockers reachable today

- [x] **CONSENT-10** · B · MDL-01 · `Modules/ParentPortal/app/Models/ConsentFormResponse.php:18-23` — add `response` to `$fillable` so the mutator runs and `response_option_id` is written.
  - **Touches:** `Modules/ParentPortal/app/Models/ConsentFormResponse.php`
  - **Before** (`ConsentFormResponse.php:18-23`):
    ```php
    protected $fillable = [
        'consent_form_id', 'student_id', 'guardian_id',
        'response_option_id', 'decline_reason', 'signer_name',
        'signed_ip', 'signed_at',
        'is_active', 'created_by',
    ];
    ```
  - **After:**
    ```php
    protected $fillable = [
        'consent_form_id', 'student_id', 'guardian_id',
        'response_option_id', 'response', 'decline_reason', 'signer_name',
        'signed_ip', 'signed_at',
        'is_active', 'created_by',
    ];
    ```
  - **Verify:** `grep -n "'response'" Modules/ParentPortal/app/Models/ConsentFormResponse.php`
  - **Expect:** one line containing `'response',`.
  - **Effort:** S

- [x] **CONSENT-13** · H · SVC-04 · `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:46-55` — make the list filter match `isFormEligible()` (honour section targeting) and eager-load `statusOption` for CONSENT-11.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php`
  - **Before** (`ParentConsentFormController.php:46-55`):
    ```php
    $forms = ConsentForm::where('is_active', true)
        ->whereIn('status_option_id', array_filter([$publishedId, $closedId]))
        ->where(function ($q) use ($classId, $sectionId) {
            $q->whereNull('class_id')
              ->orWhere('class_id', $classId)
              ->orWhere(fn ($q2) => $q2->where('class_id', $classId)
                                        ->where('section_id', $sectionId));
        })
        ->orderByDesc('deadline')
        ->get();
    ```
  - **After:**
    ```php
    $forms = ConsentForm::where('is_active', true)
        ->whereIn('status_option_id', array_filter([$publishedId, $closedId]))
        ->where(function ($q) use ($classId, $sectionId) {
            $q->whereNull('class_id');

            if (! is_null($classId)) {
                $q->orWhere(function ($q2) use ($classId, $sectionId) {
                    $q2->where('class_id', $classId)
                        ->where(function ($q3) use ($sectionId) {
                            $q3->whereNull('section_id')
                                ->orWhere('section_id', $sectionId);
                        });
                });
            }
        })
        ->with('statusOption')
        ->orderByDesc('deadline')
        ->get();
    ```
  - **Verify:** `grep -n "whereNull('section_id')\|with('statusOption')" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php`
  - **Expect:** two matching lines (one with `whereNull('section_id')`, one with `with('statusOption')`).
  - **Effort:** S

## 2. Fixes that arm a latent defect (sequenced)

None. CONSENT-10 must be applied before CONSENT-01; that ordering is stated on CONSENT-01.

## 3. Errors & transactions (F1/F2)

- [x] **CONSENT-01** · M · ERR-00 · `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:7-22, 68-84, 94-139, 144-230` — remove the three try/catch blocks and restore the D1 idiom. ⚠ APPLY CONSENT-10 FIRST: without it a failed write now surfaces as a 500 instead of the old redirect.
  - **Touches:** `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php`
  - **Before** (imports, `7-22`):
    ```php
    use Illuminate\Database\Eloquent\ModelNotFoundException;

    use Illuminate\Support\Facades\Log;

    use Illuminate\Support\Facades\DB;

    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Modules\ParentPortal\Http\Requests\SignParentConsentFormRequest;
    use Illuminate\View\View;
    use Modules\ParentPortal\Models\ConsentForm;
    use Modules\ParentPortal\Models\ConsentFormResponse;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\StudentProfile\Models\Guardian;
    use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
    ```
  - **After:** (imports)
    ```php
    use App\Http\Controllers\Controller;
    use Illuminate\Http\RedirectResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use Illuminate\View\View;
    use Modules\ParentPortal\Http\Requests\SignParentConsentFormRequest;
    use Modules\ParentPortal\Models\ConsentForm;
    use Modules\ParentPortal\Models\ConsentFormResponse;
    use Modules\ParentPortal\Services\ParentContextService;
    use Modules\StudentProfile\Models\Guardian;
    use Modules\StudentProfile\Models\Student;
    ```
  - **Before** (`index()` try/catch, `68-84`):
    ```php
            // Rule A1, scoped to the audit write. Everything else in this method is a read, so
            // the only thing that can fail destructively is the log itself — and a failed
            // audit row must never take a parent's page down with it. Rule A2 does not
            // apply: one row, one table, which is the exception §3 names.
            try {
                activityLog(auth()->user(), 'Viewed', [
                    'message' => 'Viewed consent forms',
                    'context' => [
                        'student_id' => $child?->id,
                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                        'module' => 'ParentPortal',
                        'route' => request()->route()?->getName(),
                    ],
                ]);
            } catch (\Throwable $e) {
                Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
            }
    ```
  - **After:** (`index()` audit call, replaces `68-84`)
    ```php
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed consent forms',
                'context' => $this->activityContext($child, $request),
            ]);
    ```
  - **Before** (`show()` body, `94-139`):
    ```php
        public function show(Request $request, ConsentForm $consentForm): View|RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request, $consentForm) {
                    $child = $this->context->resolveChild($request);
                    abort_unless($this->isFormEligible($child, $consentForm), 403, 'You do not have access to this consent form.');

                    $existing = ConsentFormResponse::where('consent_form_id', $consentForm->id)
                        ->where('student_id', $child->id)
                        ->first();

                    activityLog(auth()->user(), 'Viewed', [
                        'message' => 'Viewed consent form',
                        'context' => [
                            'student_id' => $child?->id,
                            'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                        'consent_form_id' => $consentForm->id,
                    ]);

                    return view('parentportal::consent-forms.show', compact('child', 'consentForm', 'existing'));

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (HttpExceptionInterface $e) {
                // abort()/abort_unless() throw an HttpException. Without this the generic
                // catch below swallows it and a deliberate 403 becomes a redirect reading
                // "The operation could not be completed." — the guard still refuses, but the
                // parent is told the wrong thing and the log records an application failure
                // instead of an access denial. Matches the AuthorizationException|Validation
                // Exception|HttpExceptionInterface pattern already used in ParentLeaveController.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentConsentFormController::show failed', ['error' => $e->getMessage()]);

                // The declared return type is widened to View|RedirectResponse rather than
                // forcing a JSON body here: this renders a page, and its error path has always
                // been a redirect. Declared `: View` alone, that redirect was a TypeError.
                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** (`show()` body)
    ```php
        public function show(Request $request, ConsentForm $consentForm): View
        {
            $child = $this->context->resolveChild($request);
            abort_unless($this->isFormEligible($child, $consentForm), 403, 'You do not have access to this consent form.');

            $existing = ConsentFormResponse::where('consent_form_id', $consentForm->id)
                ->where('student_id', $child->id)
                ->first();

            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed consent form',
                'context' => $this->activityContext($child, $request),
                'consent_form_id' => $consentForm->id,
            ]);

            return view('parentportal::consent-forms.show', compact('child', 'consentForm', 'existing'));
        }
    ```
  - **Before** (`sign()` body, `144-230`):
    ```php
        public function sign(SignParentConsentFormRequest $request, ConsentForm $consentForm): RedirectResponse
        {
            try {
                return DB::transaction(function () use ($request, $consentForm) {
                    $child = $this->context->resolveChild($request);
                    abort_unless($this->isFormEligible($child, $consentForm), 403, 'You do not have access to this consent form.');

                    // Already responded?
                    $exists = ConsentFormResponse::where('consent_form_id', $consentForm->id)
                        ->where('student_id', $child->id)
                        ->exists();

                    if ($exists) {
                        return back()->with('error', 'You have already responded to this form.');
                    }

                    if ($consentForm->isClosed()) {
                        return back()->with('error', 'This consent form is closed and can no longer be signed.');
                    }

                    $validated = $request->validated();

                    if ($validated['response'] === 'Declined') {
                        if (! $consentForm->allow_decline) {
                            return back()->with('error', 'This form does not allow declining.');
                        }
                        if (empty($validated['decline_reason'])) {
                            return back()->withErrors(['decline_reason' => 'Decline reason is required.']);
                        }
                    }

                    $guardianId = Guardian::where('user_id', auth()->id())->value('id');
                    abort_if($guardianId === null, 403);

                    ConsentFormResponse::create([
                        'consent_form_id' => $consentForm->id,
                        'student_id'      => $child->id,
                        'guardian_id'     => $guardianId,
                        'response'        => $validated['response'],
                        'decline_reason'  => $validated['decline_reason'] ?? null,
                        'signer_name'     => $validated['signer_name'],
                        'signed_ip'       => $request->ip(),
                        'signed_at'       => now(),
                        'is_active'       => true,
                        'created_by'      => auth()->id(),
                    ]);

                    $eventName = $validated['response'] === 'Signed' ? 'Signed' : 'Declined';
                    $msg = $validated['response'] === 'Signed'
                        ? 'Consent recorded. Thank you for signing.'
                        : 'Decline recorded. The school has been notified.';

                    activityLog(auth()->user(), $eventName, [
                        'message' => $validated['response'] === 'Signed' ? 'Signed consent form' : 'Declined consent form',
                        'context' => [
                            'student_id' => $child?->id,
                            'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                            'module' => 'ParentPortal',
                            'route' => request()->route()?->getName(),
                        ],
                        'consent_form_id' => $consentForm->id,
                        'response' => $validated['response'],
                    ]);

                    return redirect()
                        ->route('parent-portal.consent-forms.index')
                        ->with('success', $msg);

                });
            } catch (ModelNotFoundException $e) {
                // Rule A1: a missing record must stay a 404. Without this the generic
                // catch below swallows it and the user gets a redirect instead.
                throw $e;
            } catch (HttpExceptionInterface $e) {
                // abort()/abort_unless() throw an HttpException. Without this the generic
                // catch below swallows it and a deliberate 403 becomes a redirect reading
                // "The operation could not be completed." — the guard still refuses, but the
                // parent is told the wrong thing and the log records an application failure
                // instead of an access denial. Matches the AuthorizationException|Validation
                // Exception|HttpExceptionInterface pattern already used in ParentLeaveController.
                throw $e;
            } catch (\Throwable $e) {
                Log::error('ParentConsentFormController::sign failed', ['error' => $e->getMessage()]);

                return back()->with('error', 'The operation could not be completed.');
            }
        }
    ```
  - **After:** (`sign()` body)
    ```php
        public function sign(SignParentConsentFormRequest $request, ConsentForm $consentForm): RedirectResponse
        {
            $child = $this->context->resolveChild($request);
            abort_unless($this->isFormEligible($child, $consentForm), 403, 'You do not have access to this consent form.');

            $alreadyResponded = ConsentFormResponse::where('consent_form_id', $consentForm->id)
                ->where('student_id', $child->id)
                ->exists();

            if ($alreadyResponded) {
                return back()->with('error', 'You have already responded to this form.');
            }

            if ($consentForm->isClosed()) {
                return back()->with('error', 'This consent form is closed and can no longer be signed.');
            }

            $validated = $request->validated();

            if ($validated['response'] === 'Declined') {
                if (! $consentForm->allow_decline) {
                    return back()->with('error', 'This form does not allow declining.');
                }
                if (empty($validated['decline_reason'])) {
                    return back()->withErrors(['decline_reason' => 'Decline reason is required.']);
                }
            }

            $guardianId = Guardian::where('user_id', auth()->id())->value('id');
            abort_if($guardianId === null, 403);

            DB::transaction(function () use ($request, $consentForm, $child, $guardianId, $validated) {
                ConsentFormResponse::create([
                    'consent_form_id' => $consentForm->id,
                    'student_id'      => $child->id,
                    'guardian_id'     => $guardianId,
                    'response'        => $validated['response'],
                    'decline_reason'  => $validated['decline_reason'] ?? null,
                    'signer_name'     => $validated['signer_name'],
                    'signed_ip'       => $request->ip(),
                    'signed_at'       => now(),
                    'is_active'       => true,
                    'created_by'      => auth()->id(),
                ]);

                $eventName = $validated['response'] === 'Signed' ? 'Signed' : 'Declined';

                activityLog(auth()->user(), $eventName, [
                    'message' => $validated['response'] === 'Signed' ? 'Signed consent form' : 'Declined consent form',
                    'context' => $this->activityContext($child, $request),
                    'consent_form_id' => $consentForm->id,
                    'response' => $validated['response'],
                ]);
            });

            $msg = $validated['response'] === 'Signed'
                ? 'Consent recorded. Thank you for signing.'
                : 'Decline recorded. The school has been notified.';

            return redirect()
                ->route('parent-portal.consent-forms.index')
                ->with('success', $msg);
        }
    ```
  - **After:** (add this private helper between `sign()` and `isFormEligible()`)
    ```php
        /**
         * Shared audit context for the consent-form activity log entries.
         */
        private function activityContext(?Student $child, Request $request): array
        {
            return [
                'student_id' => $child?->id,
                'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                'module' => 'ParentPortal',
                'route' => $request->route()?->getName(),
            ];
        }
    ```
  - **Verify:** `grep -n "catch (" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php`
  - **Expect:** no output.
  - **Effort:** M

## 4. Authorization (F3)

- [x] **CONSENT-05** · M · DECISION · AUTH-06 — the registered `ConsentFormPolicy` is never consulted; decide how parent-portal consent forms are authorised.
  - **Why it is a decision:** options (b)/(c) need a new permission key, a provider change, or a policy change — each is out of a mechanical fix.
  - (a) ⭐ Accept — parents are gated by `ParentPortalMiddleware` (`user_type = 'PARENT'` + guardian + accessible child) plus the per-record `isFormEligible()` check; leave the policy to the Feedback admin module.
  - (b) Add a parent-specific permission (for example `parent-portal.consent-forms.sign`) and gate `sign()` with `Gate::authorize(...)`; needs a new key in `config/permissionslist.php` and a `/system-config/sync-permissions` run.
  - (c) Remove the unused `Gate::policy(ConsentForm::class, ConsentFormPolicy::class)` registration from both providers — but the Feedback admin screens may later consult it, so not recommended.
  - ➜ Choice: (a) — accept middleware + per-record eligibility 2026-10-22

## 5. Validation, routes, models (F4/F5/F7)

- [x] **CONSENT-06** · M · DECISION · VAL-07 — move the "already responded / closed / declining not allowed / decline reason required" checks into `SignParentConsentFormRequest`.
  - **Why it is a decision:** the checks depend on the resolved child and the bound `ConsentForm`, which the request does not currently load; moving them changes which layer owns the rule.
  - (a) ⭐ Keep them inline — they need the resolved child and the bound form, which the FormRequest does not have without extra plumbing.
  - (b) Move to `SignParentConsentFormRequest::after()` using `$this->route('consentForm')` plus a `ParentContextService` call; keeps the controller thin but adds a service dependency to the request.
  - (c) Extract them to a consent-form domain service used by both the request and the controller.
  - ➜ Choice: (a) — keep the cross-checks inline 2026-10-22

## 6. Queries & performance (F9)

- [x] **CONSENT-11** · H · QRY-01 · `Modules/ParentPortal/app/Models/ConsentForm.php:59-62` — stop the `status` accessor querying once (or twice) per form; prefer the eager-loaded `statusOption`. ⚠ DEPENDS ON CONSENT-13, which adds `->with('statusOption')`. This is a linked-class edit: `ConsentForm` is owned by THIS report, so it is in scope.
  - **Touches:** `Modules/ParentPortal/app/Models/ConsentForm.php`
  - **Before** (`ConsentForm.php:59-62`):
    ```php
    public function getStatusAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
    }
    ```
  - **After:**
    ```php
    public function getStatusAttribute(): ?string
    {
        if ($this->relationLoaded('statusOption')) {
            return $this->statusOption?->value;
        }

        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
    }
    ```
  - **Verify:** `grep -n "relationLoaded('statusOption')" Modules/ParentPortal/app/Models/ConsentForm.php`
  - **Expect:** one matching line.
  - **Effort:** S

## 7. Views (F10)

None. Both blades are clean; the only unescaped echo is sanitised by `SanitizesRichText`.

## 8. Style (F12) — one item per file

- [x] **CONSENT-14** · L · STY-01 · `Modules/ParentPortal/app/Http/Requests/SignParentConsentFormRequest.php:1-3` — add `declare(strict_types=1)`.
  - **Touches:** `Modules/ParentPortal/app/Http/Requests/SignParentConsentFormRequest.php`
  - **Before** (`SignParentConsentFormRequest.php:1-3`):
    ```php
    <?php

    namespace Modules\ParentPortal\Http\Requests;
    ```
  - **After:**
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\ParentPortal\Http\Requests;
    ```
  - **Verify:** `grep -n "declare(strict_types=1)" Modules/ParentPortal/app/Http/Requests/SignParentConsentFormRequest.php`
  - **Expect:** one matching line.
  - **Effort:** S

## 9. Deferred / decisions

None beyond the two DECISION items in §4 and §5.

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CONSENT-02 | Removed with CONSENT-01: the hand-rolled `Log::error(..., getMessage())` calls disappear when the catches are removed. |
| CONSENT-03 | Handled inside CONSENT-01: `show()` drops the single-table transaction and `sign()` builds its redirect after the transaction. |
| CONSENT-04 | Accepted: the DB unique index `uq_ppt_consent_response` prevents duplicate rows; the race window is a fraction of a second. |
| CONSENT-07 | Resolved by CONSENT-01: removing the catches brings `sign()` below 80 lines. |
| CONSENT-08 | Handled inside CONSENT-01: the repeated context array becomes a single `activityContext()` helper. |
| CONSENT-09 | Handled inside CONSENT-01: the helper uses `$request->route()` instead of the `request()` global. |
| CONSENT-12 | Accepted: the list is bounded to one child's class/section and the three-tab split needs the full set. |
| CONSENT-15 | Handled inside CONSENT-01: the import block is replaced with a sorted, blank-line-free block and unused imports are dropped. |
