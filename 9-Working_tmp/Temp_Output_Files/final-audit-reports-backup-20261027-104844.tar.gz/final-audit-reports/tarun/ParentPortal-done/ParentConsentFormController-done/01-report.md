# Final Audit — ParentPortal / ParentConsentFormController

**Audited:** 2026-10-13 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php` (259 lines, 3 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/parent-portal/consent-forms` (list) · `http://test.localhost:8000/parent-portal/consent-forms/{id}` (read + sign) |
| Menu path | Parent Portal → Communication → Forms & Consents |
| Who uses it | Any authenticated user whose `user_type = 'PARENT'` with a `std_guardians` row and at least one linked child (`can_access_parent_portal = 1`). There is no per-permission key for parents; access is granted by `ParentPortalMiddleware`. |
| What a user does here | A parent opens Forms & Consents to see the consent forms their child's class/section received. A form is either pending, already answered (signed/declined) or closed. Opening a pending form (show) lets the parent read the body and either Sign or (when the form allows it) Decline with a reason; submitting writes one immutable response row. |
| Tables written | `ppt_consent_form_responses` (INSERT) and the tenant activity log (via `activityLog()`, one table). Indirectly `ppt_parent_sessions` may be written by `ParentContextService::resolveChild()` when the active child changes. |
| Tables read | `ppt_consent_forms`, `ppt_consent_form_responses`, `sys_dropdown_table`, `std_students`, `std_student_class_sessions`, `sch_classes`, `sch_sections`, `std_guardians`, `std_student_guardian_jnt`, `sys_users`, `ppt_parent_sessions`. |
| Live data | Tenant `00000000-0000-4000-8000-000000000001`: `ppt_consent_forms` 5 live / 0 trashed; `ppt_consent_form_responses` 5, of which 0 have a null `response_option_id`; 3,648 guardians and 1,824 students. Dropdown key `ppt_consent_form_responses.response` has values `Signed, Declined`; `ppt_consent_forms.status` has `Closed, Draft, Published`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — not production-ready. The headline defect is CONSENT-10: `sign()` writes the attribute `response`, but `ConsentFormResponse::$fillable` does not contain `response` and the table has no `response` column — it stores `response_option_id` (NOT NULL). Mass assignment therefore silently drops the value and the INSERT can never populate the required column, so **no consent form can ever be signed or declined**. This was proven without writing to the database (`fill()` shows only `signer_name` survives). Beyond that the controller is small and its routing, binding and tenancy are sound; the rest is the rejected try/catch error style (D1), two write-path/transaction sloppiness items, a dead policy, a list filter that disagrees with the eligibility check, and an N+1 accessor. Rough effort: the blocker and the correctness fixes are S each; the error-style rewrite is M. All items together are well under a day.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 9 | 3 | 2 | 15 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CONSENT-01, CONSENT-02 | F8 Services/Jobs | clean (linked) |
| F2 Transactions/Audit | CONSENT-03, CONSENT-04 | F9 Queries/Perf | CONSENT-11, CONSENT-12, CONSENT-13 |
| F3 Authorization | CONSENT-05 | F10 Views | clean |
| F4 Validation | CONSENT-06 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | CONSENT-14, CONSENT-15 |
| F6 Controller shape | CONSENT-07, CONSENT-08, CONSENT-09 | F13 Deep read | table in §6 |
| F7 Models | CONSENT-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php` | controller | 259 | this report | ✅ |
| 2 | `Modules/ParentPortal/app/Http/Requests/SignParentConsentFormRequest.php` | FormRequest | 20 | this report | ✅ |
| 3 | `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` | FormRequest (base) | 26 | ↗ [tarun/ParentPortal-done/ParentComplaintController](../ParentComplaintController-done/01-report.md) | ↗ linked |
| 4 | `Modules/ParentPortal/app/Models/ConsentForm.php` | model | 100 | this report | ✅ |
| 5 | `Modules/ParentPortal/app/Models/ConsentFormResponse.php` | model | 61 | this report | ✅ |
| 6 | `Modules/ParentPortal/app/Policies/ConsentFormPolicy.php` | policy | 67 | this report | ✅ |
| 7 | `Modules/ParentPortal/app/Services/ParentContextService.php` | service | 223 | ↗ [tarun/ParentPortal-done/ParentDashboardController](../ParentDashboardController-done/01-report.md) | ↗ linked |
| 8 | `Modules/ParentPortal/app/Services/PptDropdownResolver.php` | service | 41 | ↗ [tarun/ParentPortal-done/ParentPtmController](../ParentPtmController-done/01-report.md) | ↗ linked |
| 9 | `Modules/StudentProfile/app/Models/Guardian.php` | model | 152 | ↗ [gaurav/StudentProfile/StudentController](../../../gaurav/StudentProfile/StudentController/01-report.md) | ↗ linked |
| 10 | `Modules/ParentPortal/resources/views/consent-forms/index.blade.php` | view | 271 | this report | ✅ |
| 11 | `Modules/ParentPortal/resources/views/consent-forms/show.blade.php` | view | 144 | this report | ✅ |
| 12 | `Modules/ParentPortal/routes/web.php` | routes | 199 | ↗ shared route file (system) | ↗ linked |
| 13 | `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` | middleware | 65 | ↗ [tarun/ParentPortal-done/ParentHealthController](../ParentHealthController-done/01-report.md) | ↗ linked |

Linked owner reports that are still `CLAIMED` may not be finished yet: ParentDashboardController (row 7) and ParentPtmController (row 8) are `CLAIMED` in `tarun/ParentPortal-done/00-INDEX.md` at the time of writing.

No pre-applied files: no `PRE-APPLIED-2026-10-10.md` exists for `ParentPortal`.

## 4. Routes

```
GET|HEAD parent-portal/consent-forms                             parent-portal.consent-forms.index                  Modules\ParentPortal\Http\Controllers\ParentConsentFormController@index
GET|HEAD parent-portal/consent-forms/{consentForm}               parent-portal.consent-forms.show                   Modules\ParentPortal\Http\Controllers\ParentConsentFormController@show
POST    parent-portal/consent-forms/{consentForm}/sign          parent-portal.consent-forms.sign                   Modules\ParentPortal\Http\Controllers\ParentConsentFormController@sign
```

Unrouted public methods: none (`index`, `show`, `sign` are all routed; `isFormEligible` is private).

Route middleware (from `Modules/ParentPortal/app/Providers/RouteServiceProvider.php:68-79`): `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:ParentPortal`, `auth`, `ParentPortalMiddleware`. No `can:` middleware and no `verified`.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 33 | GET parent-portal/consent-forms | none (middleware only) | none (single-table write) | `Viewed` | activity log; indirect `ppt_parent_sessions` | CONSENT-01, CONSENT-02, CONSENT-09, CONSENT-11, CONSENT-12, CONSENT-13 |
| `show` | 94 | GET parent-portal/consent-forms/{consentForm} | none (middleware + `abort_unless` eligibility) | controller `DB::transaction` | `Viewed` | activity log; indirect `ppt_parent_sessions` | CONSENT-03, CONSENT-05, CONSENT-11 |
| `sign` | 144 | POST parent-portal/consent-forms/{consentForm}/sign | `SignParentConsentFormRequest::authorize()` (base: auth + resolveChild) | controller `DB::transaction` | `Signed` / `Declined` | `ppt_consent_form_responses`, activity log; indirect `ppt_parent_sessions` | CONSENT-01, CONSENT-04, CONSENT-05, CONSENT-06, CONSENT-07, CONSENT-08, CONSENT-10 |

Mutations this controller SHOULD touch, named before counting: `sign` must write `ppt_consent_form_responses` **and** an activity-log row (2 tables) → 1 transaction, activityLog after the write (present today). `index`/`show` write only the activity-log row (1 table, no transaction required).

## 6. Findings

### F1 — Errors

#### CONSENT-01 · M · ERR-00 — the controller uses the rejected Variant-H try/catch style in all three methods

| Field | Value |
|---|---|
| **Rule** | ERR-00 (see D1) — *the Laravel idiom: no try/catch in controllers; `DB::transaction()` rolls back by itself and the central handler in `bootstrap/app.php` renders errors.* Also ERR-07 (M) — *read-only methods need no try/catch* (index and show are reads). |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:72-84` (`index`), `:96-138` (`show`), `:146-229` (`sign`) |
| **Root cause** | The module was written under house rule A1 (Variant H). D1 settles that for final audit the controller must not catch; `abort_unless`, `ModelNotFoundException` and `QueryException` are all rendered by the central exception handler. Each catch is a place to get ERR-01..04 wrong, and the four nested catches per method are pure duplication. |
| **Consequence** | A genuine failure in show/sign is converted into a generic "The operation could not be completed." redirect and logged by hand, instead of the standard 500/403/404 handling; the extra code hides the real cause and makes the methods harder to maintain. |
| **Reproduce** | Static only — reaching a failure would require a broken write (see CONSENT-10). |
| **Fix approach** | Remove the `try`/`catch` wrappers; keep the `DB::transaction` in `sign`, drop the pointless transaction in `show`, and let `abort_unless`/the central handler do their job. Apply CONSENT-10 first, or a failed write will surface as a 500. |
| **Plan item** | CONSENT-01 in `02-fix-plan.md` §3 |

```php
        // lines 72-84 — index(): the catch that A1 added
        try {
            activityLog(auth()->user(), 'Viewed', [
                'message' => 'Viewed consent forms',
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -n "catch (" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
82:        } catch (\Throwable $e) {
119:        } catch (ModelNotFoundException $e) {
123:        } catch (HttpExceptionInterface $e) {
131:        } catch (\Throwable $e) {
213:        } catch (ModelNotFoundException $e) {
217:        } catch (HttpExceptionInterface $e) {
225:        } catch (\Throwable $e) {
```

#### CONSENT-02 · M · ERR-05 — logging `$e->getMessage()` loses the stack trace

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`. `getMessage()` alone loses the trace.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:83`, `:132`, `:226` |
| **Root cause** | Each catch records only the message string. The exception object (class, file, line, trace) is discarded, so a production failure cannot be located from the log. |
| **Consequence** | When an error is recorded, an operator sees a bare message with no file/line and cannot diagnose the failure. |
| **Reproduce** | Static only — inspect the log format in the three catch blocks. |
| **Fix approach** | Handled by CONSENT-01: once the catches are removed the hand-rolled logging disappears and the central handler records the full exception. |
| **Plan item** | none — see plan §10 (removed with CONSENT-01) |

```php
            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
83:            Log::error('view log failed', ['method' => 'index', 'error' => $e->getMessage()]);
132:            Log::error('ParentConsentFormController::show failed', ['error' => $e->getMessage()]);
226:            Log::error('ParentConsentFormController::sign failed', ['error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CONSENT-03 · M · TXN-05 — the transaction closure returns HTTP responses

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()`/`response()` after it.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:97-118` (`show`), `:147-212` (`sign`) |
| **Root cause** | `show()` returns `view(...)` from inside `DB::transaction`, and `sign()` returns `back()`/`redirect()` from inside the closure. The response object is built while the transaction is still open. |
| **Consequence** | No user-visible failure today, but the pattern couples response construction to the transaction and makes error handling fragile if the closure is later changed. |
| **Reproduce** | Static only. |
| **Fix approach** | Addressed inside CONSENT-01: `show()` drops the single-table transaction; `sign()` keeps the transaction for the two-table write and builds the `redirect()` after it. |
| **Plan item** | none — see plan §10 (handled in CONSENT-01) |

```php
                return view('parentportal::consent-forms.show', compact('child', 'consentForm', 'existing'));

            });
        } catch (ModelNotFoundException $e) {
```

**Evidence**
```
$ grep -n "return view(\|return back(\|return redirect()" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
86:        return view('parentportal::consent-forms.index', compact(
116:                return view('parentportal::consent-forms.show', compact('child', 'consentForm', 'existing'));
137:            return back()->with('error', 'The operation could not be completed.');
157:                    return back()->with('error', 'You have already responded to this form.');
161:                    return back()->with('error', 'This consent form is closed and can no longer be signed.');
168:                        return back()->with('error', 'This form does not allow declining.');
171:                        return back()->withErrors(['decline_reason' => 'Decline reason is required.']);
208:                return redirect()
228:            return back()->with('error', 'The operation could not be completed.');
```

#### CONSENT-04 · M · TXN-06 — check-then-act on responses has no lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M) — *check-then-act needs a lock or a unique index: `exists()` then `create()` … rely on a DB unique index and catch the duplicate.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:152-158` (`sign`), insert at `:178-189` |
| **Root cause** | The "already responded" test runs before the transaction that inserts, with no `lockForUpdate()`. Two concurrent submissions can both pass the test. |
| **Consequence** | A double-clicked Submit can race; the table's unique index `uq_ppt_consent_response` rejects the second row, which surfaces as a generic error rather than a clean "already responded". No duplicate data can be created because the index exists. |
| **Reproduce** | Static only — a concurrent-submit race cannot be triggered from a single browser session. |
| **Fix approach** | Accepted risk: the DB unique index is the guard and the window is a fraction of a second. Recorded so it is a conscious decision, not an oversight. |
| **Plan item** | none — see plan §10 (accepted; unique index protects) |

```php
                // Already responded?
                $exists = ConsentFormResponse::where('consent_form_id', $consentForm->id)
                    ->where('student_id', $child->id)
                    ->exists();

                if ($exists) {
                    return back()->with('error', 'You have already responded to this form.');
                }
```

**Evidence**
```
$ grep -n "exists()\|->first()" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
37:        $session   = $child->currentSession()->with('classSection')->first();
103:                    ->first();
154:                    ->exists();
241:        $session   = $child->currentSession()->with('classSection')->first();

$ grep -n "uq_ppt_consent_response" database/migrations/tenant/2026_06_16_105228_create_ppt_consent_form_responses_table.php
38:            $table->unique(['consent_form_id', 'student_id', 'guardian_id'], 'uq_ppt_consent_response');
```

### F3 — Authorization

#### CONSENT-05 · M · AUTH-06 — the ConsentFormPolicy is registered but nothing consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy or constants; report every Policy that nothing consults.* The controller has no `Gate::authorize`/`$this->authorize` at all. |
| **Where** | `Modules/ParentPortal/app/Policies/ConsentFormPolicy.php:15-18` (and the other five abilities) |
| **Root cause** | `Gate::policy(ConsentForm::class, ConsentFormPolicy::class)` is registered in two providers, but every caller (the Feedback admin controller and this parent controller) authorises with a raw permission string or with middleware only. `Gate::authorize('string')` never reaches a policy, so all six policy methods are dead code. |
| **Consequence** | The policy appears to protect consent forms but protects nothing; a reader believes authorisation is centralised when it is in fact scattered as string literals. |
| **Reproduce** | Static only. |
| **Fix approach** | DECISION: keep middleware-only gating for parents (recommended), or introduce a parent permission and consult it. |
| **Plan item** | CONSENT-05 in `02-fix-plan.md` §4 (DECISION) |

```php
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.feedback.consent-forms.viewAny');
    }
```

**Evidence**
```
$ grep -rn "authorize\|Gate::\|can(" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
(no output)

$ grep -rn "ConsentFormPolicy" Modules/ParentPortal/app/Providers Modules/Feedback/app/Providers
Modules/ParentPortal/app/Providers/ParentPortalServiceProvider.php:10:use Modules/ParentPortal\Policies\ConsentFormPolicy;
Modules/ParentPortal/app/Providers/ParentPortalServiceProvider.php:38:        Gate::policy(ConsentForm::class, ConsentFormPolicy::class);
Modules/Feedback/app/Providers/FeedbackServiceProvider.php:9:use Modules\ParentPortal\Policies\ConsentFormPolicy;
Modules/Feedback/app/Providers/FeedbackServiceProvider.php:144:        Gate::policy(ConsentForm::class, ConsentFormPolicy::class);
```

### F4 — Validation and input

#### CONSENT-06 · M · VAL-07 — business rules are hand-written in the controller, not the FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field / business checks go in the FormRequest's `after()` hook, not hand-written in the controller.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:156-173` (`sign`) |
| **Root cause** | "already responded", "closed", "declining not allowed" and "decline reason required" are checked inline. The last two depend on the bound `ConsentForm` model, which the FormRequest does not currently load. |
| **Consequence** | The sign rules are split across two files; a change to the rules in one place can silently disagree with the other. |
| **Reproduce** | Static only. |
| **Fix approach** | DECISION: keep inline (needs the resolved child + bound form) or move to `SignParentConsentFormRequest::after()` using `$this->route('consentForm')`. |
| **Plan item** | CONSENT-06 in `02-fix-plan.md` §5 (DECISION) |

```php
                if ($consentForm->isClosed()) {
                    return back()->with('error', 'This consent form is closed and can no longer be signed.');
                }

                $validated = $request->validated();

                if ($validated['response'] === 'Declined') {
                    if (! $consentForm->allow_decline) {
                        return back()->with('error', 'This form does not allow declining.');
                    }
                    if (empty($validated['decline_reason'])) {
                        return back()->withErrors(['decline_reason' => 'Decline reason is required.']);
                    }
                }
```

**Evidence**
```
$ sed -n '156,173p' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
(see quoted block above — printed verbatim by this command)
```

### F5 — Routes

clean — all three public methods are routed (`route:list` in §4), no state change over GET, custom `sign` route does not collide with `{consentForm}` because the `sign` segment follows the parameter, the route parameter `{consentForm}` matches the `ConsentForm $consentForm` argument, and the tenant middleware group is present (`RouteServiceProvider.php:68-79`).

### F6 — Controller shape

#### CONSENT-07 · M · CTL-02 — `sign()` is 87 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:144-230`, method `sign()` |
| **Root cause** | The method mixes guard clauses, validation fallbacks, the guardian lookup, the write, the audit write and the response. The A1 try/catch adds ~17 more lines. |
| **Consequence** | The method is hard to read and review; the same logic is harder to change safely. |
| **Reproduce** | Static only. |
| **Fix approach** | The CONSENT-01 rewrite removes the catches and the request-local duplication, bringing `sign()` to roughly 65 lines; a further extraction is not required by this pass. |
| **Plan item** | none — see plan §10 (resolved by CONSENT-01) |

```php
    public function sign(SignParentConsentFormRequest $request, ConsentForm $consentForm): RedirectResponse
    {
        try {
            return DB::transaction(function () use ($request, $consentForm) {
```

**Evidence**
```
$ sed -n '144,230p' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php | wc -l
87
```

#### CONSENT-08 · M · CTL-05 — the same four-line activity context is copied three times

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same payload repeated.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:74-80` (`index`), `:106-112` (`show`), `:197-203` (`sign`) |
| **Root cause** | The `context` sub-array (`student_id`, `student_name`, `module`, `route`) is written out identically in all three methods. |
| **Consequence** | A change to the audit context (e.g. adding a field) must be made in three places; missing one produces inconsistent logs. |
| **Reproduce** | Static only. |
| **Fix approach** | Addressed in CONSENT-01's rewrite via a private `activityContext()` helper used by all three methods. |
| **Plan item** | none — see plan §10 (handled in CONSENT-01) |

```php
                'context' => [
                    'student_id' => $child?->id,
                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
                    'module' => 'ParentPortal',
                    'route' => request()->route()?->getName(),
                ],
```

**Evidence**
```
$ grep -n "student_name' => \$child?->user?->name" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
77:                    'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
109:                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
200:                        'student_name' => $child?->user?->name ?? $child?->full_name ?? null,
```

#### CONSENT-09 · L · CTL-08 — `request()` helper used inside controller methods

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; don't call the `request()` helper inside controller methods.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:79`, `:111`, `:202` |
| **Root cause** | All three methods already receive `Request $request` but call the global `request()` helper for the route name. |
| **Consequence** | Inconsistent with the injected dependency; a reader must check which request object is used. |
| **Reproduce** | Static only. |
| **Fix approach** | Addressed in CONSENT-01's rewrite, which uses `$request->route()` in the shared helper. |
| **Plan item** | none — see plan §10 (handled in CONSENT-01) |

```php
                    'route' => request()->route()?->getName(),
```

**Evidence**
```
$ grep -n "request()" Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
79:                    'route' => request()->route()?->getName(),
111:                        'route' => request()->route()?->getName(),
202:                        'route' => request()->route()?->getName(),
```

### F7 — Models

#### CONSENT-10 · B · MDL-01 — `response` is not fillable, so a consent response can never be saved

| Field | Value |
|---|---|
| **Rule** | MDL-01 (H, raised to B) — *`$fillable` declared; the list must match how the model is written.* Raised to **B** because the mismatch kills the only write path: every Sign/Decline fails. |
| **Where** | `Modules/ParentPortal/app/Models/ConsentFormResponse.php:18-23` ($fillable), consumed at `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:178-189` |
| **Root cause** | `ppt_consent_form_responses` has no `response` column; it stores `response_option_id` (NOT NULL, FK to `sys_dropdown_table`). The model offers `setResponseAttribute()`/`getResponseAttribute()` to map `response` ⇄ `response_option_id`, but `'response'` is absent from `$fillable`. Eloquent's mass assignment therefore drops `response` from `create([...])`, the mutator never runs, and `response_option_id` is never set — the INSERT violates the NOT NULL column and throws. The catch in `sign()` then shows "The operation could not be completed." |
| **Consequence** | A parent who opens a pending consent form and clicks Submit can never record a Sign or a Decline; the form stays pending forever and the school receives no response. |
| **Reproduce** | `http://test.localhost:8000/parent-portal/consent-forms/{id}` → choose Sign → Submit. Expected "Consent recorded"; actual redirect with "The operation could not be completed." and no new row in `ppt_consent_form_responses`. |
| **Fix approach** | Add `'response'` to `ConsentFormResponse::$fillable` so the existing `setResponseAttribute()` mutator runs and writes `response_option_id`. |
| **Plan item** | CONSENT-10 in `02-fix-plan.md` §1 |

```php
    protected $fillable = [
        'consent_form_id', 'student_id', 'guardian_id',
        'response_option_id', 'decline_reason', 'signer_name',
        'signed_ip', 'signed_at',
        'is_active', 'created_by',
    ];
```

**Evidence**
```
$ grep -n "'response'" Modules/ParentPortal/app/Models/ConsentFormResponse.php
(no output)

$ php artisan tinker --execute '$m = new Modules\ParentPortal\Models\ConsentFormResponse(); $m->fill(["response" => "Signed", "signer_name" => "Test"]); echo json_encode($m->getAttributes()); echo PHP_EOL; var_export($m->isFillable("response"));'
{"signer_name":"Test"}
false

$ sed -n '14,20p' database/migrations/tenant/2026_06_16_105228_create_ppt_consent_form_responses_table.php
        Schema::create('ppt_consent_form_responses', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('response_option_id');
            $table->foreign('response_option_id', 'fk_ppt_consent_response_option')
                ->references('id')
                ->on('sys_dropdown_table')
                ->onDelete('restrict');
```

### F8 — Services and jobs

clean — this controller injects one service (`ParentContextService`, owner `ParentDashboardController`, ↗ linked) and calls one static resolver (`PptDropdownResolver`, owner `ParentPtmController`, ↗ linked). How it uses them is noted in §7; neither service is audited here (D7). No jobs, events, mail or notifications are dispatched by this controller.

### F9 — Queries and performance

#### CONSENT-11 · H · QRY-01 — the `status` accessor fires a Dropdown query; the list pays it twice per form

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops. Lazy relation/accessor access inside `->filter()`/`->reject()` is a query per item.* |
| **Where** | `Modules/ParentPortal/app/Models/ConsentForm.php:59-62` (accessor) used at `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:64-66` and in `show.blade.php:27,74` |
| **Root cause** | `getStatusAttribute()` calls `PptDropdownResolver::value()`, which runs `Dropdown::find()` on every read; the resolver is not memoised. `index()` calls `isClosed()` (which reads `status`) once in `reject` and again in `filter`, so a list of N forms issues up to 2N dropdown queries plus the two id lookups. |
| **Consequence** | The Forms & Consents page slows down linearly as more forms are targeted at a class; on a busy tenant this is dozens of unnecessary queries per page load. |
| **Reproduce** | Open `http://test.localhost:8000/parent-portal/consent-forms` with several published forms and watch the query count in the debug bar. |
| **Fix approach** | Eager-load `statusOption` in the controller (CONSENT-13) and make the accessor prefer the loaded relation, falling back to the resolver when it is not loaded. |
| **Plan item** | CONSENT-11 in `02-fix-plan.md` §6 |

```php
    public function getStatusAttribute(): ?string
    {
        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
    }
```

**Evidence**
```
$ grep -n "getStatusAttribute\|PptDropdownResolver::value\|isClosed" Modules/ParentPortal/app/Models/ConsentForm.php
59:    public function getStatusAttribute(): ?string
61:        return PptDropdownResolver::value($this->attributes['status_option_id'] ?? null);
79:    public function isClosed(): bool

$ sed -n '64,66p' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
        $pending = $forms->reject(fn ($f) => $responses->has($f->id) || $f->isClosed())->values();
        $closed  = $forms->filter(fn ($f) => $f->isClosed() && ! $responses->has($f->id))->values();
        $signed  = $forms->filter(fn ($f) => $responses->has($f->id))->values();
```

#### CONSENT-12 · M · QRY-02 — the list is unpaginated

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H, lowered to M) — *lists are paginated.* Lowered because the result is bounded to a single child's class/section and is a small set in practice. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:46-55` (`index`) |
| **Root cause** | The query ends in `->get()` with no `paginate()`. Because the page splits the result into three tabs in PHP, classic pagination would break the tab counts. |
| **Consequence** | If a tenant ever has many forms for one class, the page loads all of them into memory. |
| **Reproduce** | Static only. |
| **Fix approach** | Accepted: the list is bounded by class/section and the three-tab split needs the full set. Recorded so it is a conscious decision. |
| **Plan item** | none — see plan §10 (accepted; bounded set) |

```php
        $forms = ConsentForm::where('is_active', true)
            ->whereIn('status_option_id', array_filter([$publishedId, $closedId]))
            ->where(function ($q) use ($classId, $sectionId) {
                $q->whereNull('class_id')
                  ->orWhere('class_id', $classId)
                  ->orWhere(fn ($q2) => $q2->where('class_id', $classId)
                                            ->where('section_id', $sectionId));
            })
            ->orderByDesc('deadline')
            ->get();
```

**Evidence**
```
$ grep -n -- '->get();' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
55:            ->get();
```

#### CONSENT-13 · H · SVC-04 — the list filter disagrees with the eligibility check, so section-targeted forms appear that the parent cannot open

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M, raised to H) — *one implementation per business operation; two copies that disagree are a bug source.* Raised to **H** because the disagreement produces a wrong, reachable result. |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:46-55` (`index` query) vs `:235-258` (`isFormEligible`) |
| **Root cause** | The index query's `->orWhere('class_id', $classId)` already matches every form for the class regardless of section, making the third clause (which alone checks `section_id`) redundant. `isFormEligible()`, used by `show()` and `sign()`, correctly requires `section_id` to be null or equal. The two copies of the targeting rule therefore disagree. |
| **Consequence** | A parent in class 5 section B sees a consent form targeted to class 5 section A in their Pending list; clicking it returns 403 "You do not have access to this consent form." The list shows a form the parent can never open. |
| **Reproduce** | As a parent in a section other than the form's target section, open `http://test.localhost:8000/parent-portal/consent-forms` — the form appears under Pending; open it and get 403. |
| **Fix approach** | Rewrite the `where` closure to mirror `isFormEligible()`: all-classes, **or** (class matches **and** section is null or matches). |
| **Plan item** | CONSENT-13 in `02-fix-plan.md` §1 |

```php
        $forms = ConsentForm::where('is_active', true)
            ->whereIn('status_option_id', array_filter([$publishedId, $closedId]))
            ->where(function ($q) use ($classId, $sectionId) {
                $q->whereNull('class_id')
                  ->orWhere('class_id', $classId)
                  ->orWhere(fn ($q2) => $q2->where('class_id', $classId)
                                            ->where('section_id', $sectionId));
            })
            ->orderByDesc('deadline')
            ->get();
```

**Evidence**
```
$ sed -n '46,55p' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
(see quoted block above — printed verbatim by this command)

$ sed -n '245,257p' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
        if (is_null($consentForm->class_id)) {
            return true;
        }

        if ($consentForm->class_id === $classId && is_null($consentForm->section_id)) {
            return true;
        }

        if ($consentForm->class_id === $classId && $consentForm->section_id === $sectionId) {
            return true;
        }

        return false;
```

### F10 — Views

clean — no `Model::`/`DB::`/`->where(`/`->count()` queries in either blade. The one unescaped echo, `show.blade.php:42` `{!! $consentForm->content !!}`, is sanitised on save and on fill by the `SanitizesRichText` trait (`ConsentForm` declares `protected array $sanitizable = ['content' => 'full_math']`), so it is trusted HTML and VIEW-03 does not apply. Both blades compile and there is no query inside an `@foreach` (the only relation access, `$r->response`, is a loaded keyed collection plus an accessor — see CONSENT-11).

### F11 — Security and tenancy

clean — no `env()` outside `config/` (`grep -n "env(" …` → no output), no hard-coded ids or `?? 1`, no secrets or request bodies logged, no raw interpolated SQL. Tenant middleware is present on the route group and `activityLog()` routes to the tenant log when tenancy is initialised.

### F12 — Style

#### CONSENT-14 · L · STY-01 — `SignParentConsentFormRequest` has no `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1)` in PHP files; old files when touched.* |
| **Where** | `Modules/ParentPortal/app/Http/Requests/SignParentConsentFormRequest.php:1-5` |
| **Root cause** | The file was created without the strict-types declaration; sibling requests such as the parent service use it. |
| **Consequence** | Scalar type coercion is enabled in this file, so loose values are accepted where the rules intend strict typing. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag. |
| **Plan item** | CONSENT-14 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\ParentPortal\Http\Requests;
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/ParentPortal/app/Http/Requests/SignParentConsentFormRequest.php
(no output)
```

#### CONSENT-15 · L · STY-02 — controller imports are unsorted with stray blank lines

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, no stray blank lines between imports.* |
| **Where** | `Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php:7-22` |
| **Root cause** | The imports are grouped by hand with blank lines and are not alphabetically sorted; Pint would collapse and reorder them. |
| **Consequence** | The file is not Pint-clean, so a later `pint --dirty` would produce unrelated churn. |
| **Reproduce** | Static only. |
| **Fix approach** | Addressed in CONSENT-01's rewrite, which replaces the import block with a sorted, blank-line-free block (and drops the three now-unused imports). |
| **Plan item** | none — see plan §10 (handled in CONSENT-01) |

```php
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
```

**Evidence**
```
$ sed -n '7,22p' Modules/ParentPortal/app/Http/Controllers/ParentConsentFormController.php
(see quoted block above — printed verbatim by this command)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong data | 2 delete-before-replace | 3 duplicate impl | 4 soft-delete × unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` | CONSENT-13 | ok (no delete) | CONSENT-13 | ok (no pivot) | ok (read) | CONSENT-05 | ok | ok |
| `show` | ok | ok | ok | ok | ok (read) | CONSENT-05 | ok | ok |
| `sign` | CONSENT-10 | ok (INSERT only) | CONSENT-13 | ok (`uq_ppt_consent_response` has no `deleted_at`; this table is not soft-deleted) | CONSENT-04 | CONSENT-05 | CONSENT-10 (success message is unreachable; the parent is told the operation failed) | CONSENT-10 (the entire sign feature cannot write) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/ParentPortal/app/Services/ParentContextService.php` (↗ ParentDashboardController) | `resolveChild()` can write `ppt_parent_sessions` (create/update) from read paths, and `getOrCreateSession()` makes two writes without a transaction; `abort(redirect()->route(...))` is HTTP inside a service. This controller calls `resolveChild()` in all three methods, so the index/show reads can write session rows. | SVC-01, SVC-03, TXN-01 | ParentDashboardController report |
| `Modules/ParentPortal/app/Services/PptDropdownResolver.php` (↗ ParentPtmController) | `id()`/`value()` are not memoised, so every call is a query; this is the root of CONSENT-11's N+1. | SVC-05, QRY-12 | ParentPtmController report |
| `Modules/ParentPortal/app/Http/Requests/ParentPortalBaseRequest.php` (↗ ParentComplaintController) | `authorize()` wraps `resolveChild()` in `catch (\Exception) { return false; }`, swallowing the 403/redirect exceptions and turning them into a plain authorization failure; also missing `declare(strict_types=1)`. | ERR-06, STY-01 | ParentComplaintController report |
| `Modules/StudentProfile/app/Models/Guardian.php` (↗ gaurav/StudentProfile/StudentController) | `InteractsWithMedia` without `getMediaModel()` (B, TEN-01/MDL-05); no cast for `is_active`; relation methods without return types; no `declare(strict_types=1)`. This controller only reads `Guardian::where('user_id', ...)->value('id')`. | MDL-05, MDL-02, MDL-04, STY-01 | gaurav/StudentProfile/StudentController report |
| `Modules/ParentPortal/app/Http/Middleware/ParentPortalMiddleware.php` (↗ ParentHealthController) | It is the only gate for this controller (`user_type = 'PARENT'` + guardian + accessible child). | AUTH-01 | ParentHealthController report |
| `ConsentFormPolicy` registration | `Gate::policy(ConsentForm::class, ConsentFormPolicy::class)` is registered in two providers (`ParentPortalServiceProvider:38` and `FeedbackServiceProvider:144`), a duplicate registration (BUG-002); and nothing consults the policy. | AUTH-06 | Framework/providers owner |

## 8. Not covered, and why

- The linked services (`ParentContextService`, `PptDropdownResolver`), `Guardian`, `ParentPortalBaseRequest`, `ParentPortalMiddleware` and the shared route file are audited by their own report owners (D7); only this controller's usage of them is in scope.
- The Feedback admin consent-form screens (`Modules/Feedback`) call the same model and policy but are outside this controller's scope.
- No test or browser run was performed (D4). The CONSENT-10 failure is proven statically and by an in-memory `fill()` (no database write) plus the migration's NOT NULL `response_option_id`.
- Live row counts were read with `tenancy()->initialize()` against tenant `00000000-0000-4000-8000-000000000001` (the first tenant returned). They may differ on other tenants.
