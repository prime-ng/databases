# Final Audit — TenantCore / ActivityLogController

**Audited:** 2026-10-15 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` (142 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/system-config/activity-log` — one page, two tabs (`?tab=all`, `?tab=student-parent`) |
| Menu path | System Config → Activity Log (route name `system-config.activity-log.index`) |
| Who uses it | Roles granted `tenant.system-config.activity-log.viewAny`. `config/permissionslist.php` auto-grants the tenant key to `Super Admin` and `School Admin` (AUTO_GRANT_ROLES); other roles are granted by hand in the UI. Exact per-role rows were not read from `sys_role_has_permissions_jnt` (see §8). |
| What a user does here | A school administrator opens the audit trail. The **All Logs** tab lists every `sys_activity_logs` row (who, event, IP, user-agent, changes). The **Student & Parent** tab lists only rows whose user holds the `Student` or `Parent` role, grouped into one accordion card per student, with class/section filters. There is no create/edit/delete on this page. |
| Tables written | none — the page is read-only |
| Tables read | `sys_activity_logs` (main); `sys_model_has_roles_jnt`, `sys_roles` (role subquery); `sch_class_section_jnt`; `std_students`; `std_student_academic_sessions`; `sch_classes`; `sch_sections`; `sys_users` (via the `user` relation) |
| Live data | not measured — the tenant database was not queried in this read-only audit (see §8) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is production-ready after one visible fix. It is a small, read-only listing screen with a correct four-part permission gate, one route, no writes, no transactions, distinct paginator page keys (`all_page` / `sp_page`), and eager-loaded relations. The single worst finding is a swapped count: the **All Logs** pane prints the Student & Parent total and the **Student & Parent** pane prints the All Logs total (`index.blade.php:77` and `:272`), so both headers show a wrong number on every load. The remaining items are one authorization-maintainability choice, one method-length choice, one query-index choice, a long search method and the model's missing return types and style. Rough effort: S (well under an hour for the mechanical fixes).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 4 | 3 | 3 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | n/a — no service or job |
| F2 Transactions/Audit | clean | F9 Queries/Perf | ALC-05 |
| F3 Authorization | ALC-01 | F10 Views | ALC-06 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | ALC-07 |
| F6 Controller shape | ALC-02, ALC-03 | F13 Deep read | clean — read-only page, answered in §6 |
| F7 Models | ALC-04 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` | controller | 142 | this report | ✅ |
| 2 | `Modules/TenantCore/app/Models/ActivityLog.php` | model | 42 | this report | ✅ |
| 3 | `Modules/TenantCore/resources/views/activity-log/index.blade.php` | view | 481 | this report | ✅ |
| 4 | `Modules/SchoolSetup/app/Models/ClassSection.php` | model (other module) | 162 | common §4.2 | ❌ common |
| 5 | `Modules/SchoolSetup/app/Models/SchoolClass.php` | model (other module) | 94 | common §4.2 | ❌ common |
| 6 | `Modules/SchoolSetup/app/Models/Section.php` | model (other module) | 60 | common §4.2 | ❌ common |
| 7 | `Modules/StudentProfile/app/Models/Student.php` | model (other module) | 476 | ↗ [gaurav/StudentProfile/StudentReportController](../../../gaurav/StudentProfile/StudentReportController/01-report.md) | ↗ linked |

Files 4-6 are the models of a **different module** (SchoolSetup). Three earlier reports already classified the same three models as `common (other module)` and audited them elsewhere:
`gaurav/StudentProfile/AttendanceController-Done/01-report.md:57-60`,
`gaurav/StudentProfile/StudentReportController-Done/01-report.md:62-64`,
`tarun/StandardTimetable/StandardTimetableController-done/01-report.md:75`. They are therefore recorded here as **cross-cutting notes** (§7), not re-audited. File 7 (`Student`) is owned by `gaurav/StudentProfile/StudentReportController` and is linked: this report only checks **how this controller uses it**.

Common files walked and **not** audited (§4.2): `resources/views/components/backend/layouts/app`, `…/components/breadcrum`, `…/tab/nav-tab`, `…/tab/search-bar` (shared backend components), and `Modules/TenantCore/resources/views/components/export-buttons.blade.php` (shared TenantCore UI). The view pulls in no further module partials — the list stops at the `x-tenantcore::export-buttons` component.

No in-scope file appears in a `PRE-APPLIED-*.md` list.

## 4. Routes

```
$ php -r '$r=json_decode(file_get_contents("/tmp/fa-routes.json"),true); foreach($r as $x) if(str_contains($x["action"]??"","TenantCore\\Http\\Controllers\\ActivityLogController@")) printf("%-7s %-40s %-45s %s\n",$x["method"],$x["uri"],$x["name"]??"-",$x["action"]);'
GET|HEAD system-config/activity-log               system-config.activity-log.index              Modules\TenantCore\Http\Controllers\ActivityLogController@index
```

Unrouted public methods: none — the one public method `index()` (line 21) is the routed method above.

Registered in `routes/tenant.php:105`, inside the outer group at `routes/tenant.php:89` (`['web', InitializeTenancyByDomain, SetTenantAuthGuard, PreventAccessFromCentralDomains, EnsureTenantIsActive]`) and the inner group at `routes/tenant.php:103` (`['auth', 'verified']`, prefix `system-config`). Tenant middleware is present (F5).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 21 | GET `system-config/activity-log` | `tenant.system-config.activity-log.viewAny` | none — read-only | none | none | ALC-01, ALC-02, ALC-03, ALC-05, ALC-06 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try\s*\{|catch\s*\(|->getMessage\(|withErrors|Log::(error|warning|info|debug)' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` → no output. No `try`/`catch` in the controller (D1 satisfied), no exception text, no `$request->all()` and no write path.

### F2 — Transactions and audit

clean — `grep -nE 'DB::transaction|activityLog\(|->save\(|->update\(|->create\(|->delete\(|insert\(|upsert\(|->increment\(' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` → no output. `index()` performs no INSERT/UPDATE/DELETE, so there is no multi-table write to wrap and no `activityLog()` call to audit.

### F3 — Authorization

#### ALC-01 · M · AUTH-06 — the same permission name is a literal in five places

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php:23`, method `index()` |
| **Root cause** | The gate string is written inline in the controller, and the same two abilities (`…viewAny`, `…export`) are written again as raw strings in the view's tab array and export config. There is no constant, config accessor or policy holding the name. |
| **Consequence** | Renaming the permission requires edits in two files (five literals); a missed one silently disables a tab or the export gate. |
| **Reproduce** | static only — the defect is the repetition, not a runtime behaviour; the page renders correctly today. |
| **Fix approach** | Centralise the two ability names in one place (recommended: constants on `Modules\TenantCore\Models\ActivityLog`) and reference them from both the controller and the view. Because the view builds its tab array and export config itself, where to centralise is a design choice — this is a DECISION item (ALC-01 in `02-fix-plan.md` §4). |
| **Plan item** | ALC-01 in `02-fix-plan.md` §4 (DECISION) |
| **Evidence** | `grep -rn "tenant.system-config.activity-log" Modules/TenantCore/app/Http/Controllers/ActivityLogController.php Modules/TenantCore/resources/views/activity-log/index.blade.php` → five hits (below) |

```php
// ActivityLogController.php:23 — CURRENT
        Gate::authorize('tenant.system-config.activity-log.viewAny');
```

**Evidence**
```
$ grep -rn "tenant.system-config.activity-log" Modules/TenantCore/app/Http/Controllers/ActivityLogController.php Modules/TenantCore/resources/views/activity-log/index.blade.php
Modules/TenantCore/app/Http/Controllers/ActivityLogController.php:23:        Gate::authorize('tenant.system-config.activity-log.viewAny');
Modules/TenantCore/resources/views/activity-log/index.blade.php:6:            ['id' => 'all', 'label' => 'All Logs', 'icon' => 'fa-solid fa-list', 'permission' => 'tenant.system-config.activity-log.viewAny'],
Modules/TenantCore/resources/views/activity-log/index.blade.php:7:            ['id' => 'student-parent', 'label' => 'Student & Parent', 'icon' => 'fa-solid fa-user-graduate', 'permission' => 'tenant.system-config.activity-log.viewAny'],
Modules/TenantCore/resources/views/activity-log/index.blade.php:57:                                'permission' => 'tenant.system-config.activity-log.export',
Modules/TenantCore/resources/views/activity-log/index.blade.php:237:                                'permission' => 'tenant.system-config.activity-log.export',
```

Authorization itself is otherwise correct: `Gate::authorize` runs on line 23, before any record is loaded; the name is the four-part `scope.module.feature.action` shape; it is declared in `config/permissionslist.php:1699` (`'system-config.activity-log' => array_merge($crud, ['export'])`, and `$crud` at line 176 contains `viewAny`), and it matches the view surface exactly. Seeding is exact-name, not `LIKE` — `database/seeders/TenantRolePermissionSeeder.php:141` uses `Permission::firstOrCreate(['name' => $permission, ...])`.

### F4 — Validation and input

clean — the method is read-only and every request value reaches the query as a **bound parameter**, never as interpolated SQL: `$request->input('search')`/`('event')`/`('class_id')`/`('section_id')` become `where(...)`/`whereIn(...)` bindings. There is no FormRequest because there is nothing to store. Method: `sed -n '44,127p' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php`.

### F5 — Routes

clean — `php -r '...' /tmp/fa-routes.json` (see §4) shows exactly one route pointing at the controller, `GET system-config/activity-log` → `index`, and `grep -nE 'public function' …ActivityLogController.php` returns only line 21. One method, one route, no state change over GET, tenant + auth middleware present.

### F6 — Controller shape

#### ALC-02 · M · CTL-02 — `index()` is 121 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines → extract; over 150 lines is H* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php:21-141`, method `index()` |
| **Root cause** | One method builds two paginators, a role subquery, an optional class/section resolver, two export clones, a student-card eager load and two dropdown plucks — all inline. |
| **Consequence** | The method is hard to read and to change safely; a fix to one tab risks the other (which is exactly the class of bug AL-01 already hit here). |
| **Reproduce** | static only — no runtime effect; the method works today. |
| **Fix approach** | Extract the Student & Parent student-id resolution (lines 92-110) and the two dropdown loads into private methods. This is a structural change on a working screen, so per D3 it is sequenced as a DECISION (ALC-02 in `02-fix-plan.md` §9). |
| **Plan item** | ALC-02 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `sed -n '21,141p' …ActivityLogController.php \| wc -l` → 121 (below) |

```php
// ActivityLogController.php:21-22 — CURRENT (method opens here)
    public function index(Request $request)
    {
```

**Evidence**
```
$ sed -n '21,141p' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php | wc -l
121
$ grep -n 'public function' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php
21:    public function index(Request $request)
```

The controller is **not** a god controller: 142 lines, 1 public method, so CTL-01 does not apply.

#### ALC-03 · L · CTL-04 — `index()` has no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php:21`, method `index()` |
| **Root cause** | The method signature declares no return type; the body returns `view(...)` (an `Illuminate\View\View`). |
| **Consequence** | Maintainability only — static analysis cannot verify the return contract. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: View` (with the `use Illuminate\View\View;` import) to the signature. |
| **Plan item** | ALC-03 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n 'public function index' …ActivityLogController.php` → line 21, no return type (below) |

```php
// ActivityLogController.php:21 — CURRENT
    public function index(Request $request)
```

**Evidence**
```
$ grep -n 'public function index' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php
21:    public function index(Request $request)
```

### F7 — Models

#### ALC-04 · L · MDL-04 — `ActivityLog` relations have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/TenantCore/app/Models/ActivityLog.php:29-41`, methods `subject()` and `user()` |
| **Root cause** | Both relationship methods are declared without a return type. |
| **Consequence** | Maintainability only; the relations resolve correctly at runtime (the `user()` relation correctly switches between the tenant and central user model on `tenancy()->initialized`). |
| **Reproduce** | static only. |
| **Fix approach** | Add `: \Illuminate\Database\Eloquent\Relations\MorphTo` to `subject()` and `: \Illuminate\Database\Eloquent\Relations\BelongsTo` to `user()` (fully-qualified, so this item needs no change to the `use` block and stays independent of ALC-07). |
| **Plan item** | ALC-04 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -nE 'public function (subject\|user)\(' …ActivityLog.php` → lines 29 and 34 (below) |

```php
// ActivityLog.php:29-41 — CURRENT
    public function subject()
    {
        return $this->morphTo();
    }

    public function user()
    {
        if (tenancy()->initialized) {
            return $this->belongsTo(TenantUser::class);
        }

        return $this->belongsTo(CentralUser::class);
    }
```

**Evidence**
```
$ grep -nE 'public function (subject|user)\(' Modules/TenantCore/app/Models/ActivityLog.php
29:    public function subject()
34:    public function user()
```

`ActivityLog` is otherwise sound: `$fillable` is declared (MDL-01), `properties` is cast to `array` (MDL-02), its `$table = 'sys_activity_logs'` exists in `database/migrations/tenant/2026_06_16_071024_create_activity_logs_table.php:13` (MDL-07), and the table has no soft-delete column so the model correctly omits `SoftDeletes`.

### F8 — Services and jobs

n/a — the controller names no service, job, event or listener.

### F9 — Queries and performance

#### ALC-05 · M · QRY-08 — three leading-wildcard `LIKE` filters on the activity log

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M) — *leading-wildcard `LIKE '%x%'` can't use an index; acceptable on small tables, on large ones use a prefix match, FULLTEXT, or a search column* |
| **Where** | `Modules/TenantCore/app/Http/Controllers/ActivityLogController.php:49-51`, method `index()` |
| **Root cause** | The search box builds three `LIKE "%{$search}%"` clauses over `subject_type`, `event` and `ip_address`. A leading `%` prevents any index use; `event` and `ip_address` are not indexed by the activity-log migration. |
| **Consequence** | On a school with a large `sys_activity_logs` table, every search does a full scan of all three columns. The table size was not measured in this read-only audit (see §8). |
| **Reproduce** | Open `/system-config/activity-log` and type a value in the search box; the resulting query is a full scan. |
| **Fix approach** | Either accept it (admin log) or replace the leading wildcard with a prefix match / FULLTEXT index. Because a prefix match changes search semantics and FULLTEXT needs a migration, this is a DECISION item (ALC-05 in `02-fix-plan.md` §6). |
| **Plan item** | ALC-05 in `02-fix-plan.md` §6 (DECISION) |
| **Evidence** | `grep -n "like" …ActivityLogController.php` → three leading-wildcard clauses (below) |

```php
// ActivityLogController.php:49-51 — CURRENT
                    $q->where('subject_type', 'like', "%{$search}%")
                        ->orWhere('event', 'like', "%{$search}%")
                        ->orWhere('ip_address', 'like', "%{$search}%");
```

**Evidence**
```
$ grep -n "like" Modules/TenantCore/app/Http/Controllers/ActivityLogController.php
49:                    $q->where('subject_type', 'like', "%{$search}%")
50:                        ->orWhere('event', 'like', "%{$search}%")
51:                        ->orWhere('ip_address', 'like', "%{$search}%");
```

The rest of F9 is clean. No N+1: the base query eager-loads `with('user')` (line 44) and the student cards eager-load their nested relations (lines 121). The 4,118-id role lookup is a **subquery**, not an inlined `whereIn` (lines 85-90). Both paginators are distinct and bounded (`all_page` / `sp_page`, `withQueryString()` — QRY-13 satisfied), and the dropdown loads are single `pluck()` calls (lines 126-127). The export clones are taken **before** `paginate()`, and `clone` on an Eloquent builder deep-copies the underlying query (`vendor/laravel/framework/src/Illuminate/Database/Eloquent/Builder.php:2327` defines `__clone()`), so the export data is the full filtered set, not one page.

### F10 — Views

#### ALC-06 · M · VIEW-02 — the two tab headers show each other's record counts

| Field | Value |
|---|---|
| **Rule** | VIEW-02 (M) — *relations/data used inside a template must be the right data for that template; a blade reading the wrong variable shows a wrong value* |
| **Where** | `Modules/TenantCore/resources/views/activity-log/index.blade.php:77` and `:272` |
| **Root cause** | The "All Logs" card header prints `$studentParentLogs->total()` (line 77) and the "Student & Parent" card header prints `$activityLogs->total()` (line 272) — the two paginator variables are swapped, a copy-paste slip of the same kind the file's own AL-01 note describes. |
| **Consequence** | Both badges show the wrong number on every load: the All Logs pane reports the Student & Parent count, and vice-versa. |
| **Reproduce** | Open `/system-config/activity-log`; the "All Logs" badge above the table shows the Student & Parent total. |
| **Fix approach** | Swap the two variables back: All Logs → `$activityLogs->total()`, Student & Parent → `$studentParentLogs->total()`. |
| **Plan item** | ALC-06 in `02-fix-plan.md` §7 |
| **Evidence** | `grep -n "records" …index.blade.php` → the two swapped badges (below) |

```php
// index.blade.php:74-78 — CURRENT (All Logs header shows the SP total)
                        <h3 class="card-title mb-0">
                            <i class="fa-solid fa-clock-rotate-left me-2"></i>Activity Log
                        </h3>
                        <span class="badge bg-secondary">{{ $studentParentLogs->total() }} records</span>
```

**Evidence**
```
$ grep -n "records" Modules/TenantCore/resources/views/activity-log/index.blade.php
77:                        <span class="badge bg-secondary">{{ $studentParentLogs->total() }} records</span>
272:                        <span class="badge bg-secondary">{{ $activityLogs->total() }} records</span>
```

No other view defect was found. There are no queries in the blade (VIEW-01 — the only `->count()` calls at lines 314 and 419 are on already-loaded collections); `{!! !!}` is absent (VIEW-03); relations used in `@foreach` (`$log->user`, `$student->currentAcademicSession->classSection->…`) are eager-loaded by the controller (VIEW-02 otherwise clean); the breadcrumb correctly passes `:links="[]"` per `breadcrumb-standard.md` §1.2 rule 8; and the blade **compiles**: `compileString()` output passes `php -l` with no stray directive (see §8 of the evidence log below).

### F11 — Security and tenancy

clean — `grep -nE '\benv\(|tenant_asset|asset\(' Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` → no `env()` call outside `config/` (SEC-01), no hard-coded id or `?? 1` (SEC-03), no logged request body (SEC-04). The model resolves `user()` through `tenancy()->initialized` (TEN-03 pattern for the central/tenant user split), and no cache or static state is used (TEN-02 n/a).

### F12 — Style

#### ALC-07 · L · STY-01 — `ActivityLog.php` has no `strict_types` and is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)*; also STY-02 (Pint-clean) |
| **Where** | `Modules/TenantCore/app/Models/ActivityLog.php:1-13` |
| **Root cause** | The file omits `declare(strict_types=1);`, and Pint reports two fixers: `ordered_imports` (the framework `HasFactory` import sits after the `Modules\…` imports) and `class_attributes_separation` (no blank line after `use HasFactory;`). |
| **Consequence** | Style/consistency only. |
| **Reproduce** | `vendor/bin/pint --test Modules/TenantCore/app/Models/ActivityLog.php` reports `fail`. |
| **Fix approach** | Add `declare(strict_types=1);`, sort the imports, and add the blank line after the trait use. |
| **Plan item** | ALC-07 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n "declare(strict_types" …ActivityLog.php` → no output; `vendor/bin/pint --test …ActivityLog.php` → fail (below) |

```php
// ActivityLog.php:1-13 — CURRENT
<?php

namespace Modules\TenantCore\Models;

use App\Models\BaseModel;
use Modules\Prime\Models\User as CentralUser;
use Modules\SchoolSetup\Models\User as TenantUser;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ActivityLog extends BaseModel
{
    use HasFactory;
    protected $table = 'sys_activity_logs';
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/TenantCore/app/Models/ActivityLog.php
(no output)
$ vendor/bin/pint --test Modules/TenantCore/app/Models/ActivityLog.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/TenantCore\/app\/Models\/ActivityLog.php","fixers":["class_attributes_separation","ordered_imports"]}]}
```

The controller itself is clean: it has `declare(strict_types=1);` (line 3), and `vendor/bin/pint --test Modules/TenantCore/app/Http/Controllers/ActivityLogController.php` reported no failure.

### F13 — Deep read (answer all 8 questions for every mutating method)

There are **no mutating methods** on this controller, so the eight deep-read questions are answered once for the whole page. The table below records the evidence.

| Question (rulebook deep-read) | `index()` | Evidence |
|---|---|---|
| 1. A write overwriting data it should not | ok | no write statements — `grep -nE 'save\|update\|create\|delete\|insert'` → no output |
| 2. Delete before replacement is stored | ok | no delete statements |
| 3. Duplicate implementations of one operation | ok | two builders share one `$applyCommon` closure (line 46) and one `$base` closure (line 44) |
| 4. Soft-delete × unique index trap | ok | no writes; `ActivityLog` table has no `deleted_at` |
| 5. Race | ok | read-only page, no check-then-act |
| 6. Authorization hole | ok | `Gate::authorize` is the first statement (line 23) |
| 7. Messages that lie | ALC-06 | the two count badges show the other pane's total |
| 8. Dead feature | ok | every column the view reads is written by the app's `activityLog()` helper; the Student & Parent tab reads real role-scoped rows (seeded by `Modules/TenantCore/database/seeders/TenantActivityLogStudentParentSeeder.php`) |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SchoolSetup/app/Models/Section.php:43-46` | `studentAcademicAessions()` (note the typo in the name) calls `StudentAcademicSession::class` with **no import** in the file, so it resolves to `Modules\SchoolSetup\Models\StudentAcademicSession`, which does not exist — calling the relation throws a "class not found" error. | MDL-04 | SchoolSetup module owner |
| `Modules/SchoolSetup/app/Models/Section.php:30-35` | A `booted()` global scope adds `orderBy('name', 'asc')` to **every** `Section` query. The controller's `Section::where('is_active', true)->orderBy('ordinal')` (line 127) therefore runs `ORDER BY name, ordinal`, so the Section dropdown lists alphabetically instead of by `ordinal`. | MDL-08 | SchoolSetup module owner |
| `Modules/TenantCore/resources/views/activity-log/index.blade.php:43-46` (comment) | The export buttons render on **view permission only**; the comment states `ExportController has no Gate:: call`. Export of the whole activity trail is thus gated in the UI but not in the controller that serves the file. | AUTH-01 | `tarun/TenantCore-done/ExportController` (already CLAIMED in this module's index) |

Scanner note: the scan flagged `Modules/StudentProfile/app/Models/Student.php:403` as TEN-04. Confirmed in source it is a **false positive** — line 405 is `asset('assets/images/avatar.png')`, a static fallback avatar, not a tenant file; line 403 correctly uses `tenant_asset(...)`. Not reported.

## 8. Not covered, and why

- **Live row counts** for `sys_activity_logs` (and therefore the true impact of ALC-05) were not measured: the tenant database was not queried in this read-only audit. To settle it, count rows per tenant with `Sys Activity Logs` and decide ALC-05's option from that number.
- **Per-role permission rows** in `sys_role_has_permissions_jnt` were not read; the allowed roles are inferred from the `AUTO_GRANT_ROLES` note in `config/permissionslist.php` (Super Admin, School Admin).
- **The view was not rendered in a browser.** It was only compiled: `app('blade.compiler')->compileString()` on the file produced output that passes `php -l`, with no `@push` mismatch (`src @push( = 0`, compiled `startPush = 0`). Wrapping/JS behaviour of the client-side tab strip was not exercised.
- **Whether the shared `search`/`event` filters should apply to both tabs independently** is not reported as a finding: `$applyCommon` (line 46) is applied to both builders unconditionally (lines 63 and 84), so the two tabs currently share those two filters, while `class_id`/`section_id` are applied to the Student & Parent builder only. ⚠ UNVERIFIED — a rendered side-by-side of the two tabs (or a product decision on intended behaviour) would settle whether the shared filters are a defect or by design.
- `Modules/TenantCore/resources/views/components/export-buttons.blade.php` and the backend layout/tab components are common (§4.2) and were not audited.
- No queue, job, command, service or event is in scope.
