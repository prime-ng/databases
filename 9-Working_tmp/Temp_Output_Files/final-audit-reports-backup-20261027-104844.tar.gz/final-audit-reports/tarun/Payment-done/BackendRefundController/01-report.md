# Final Audit — Payment / Backend\RefundController

**Audited:** 2026-10-19 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/Payment/app/Http/Controllers/Backend/RefundController.php` (43 lines, 1 public method)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://SCHOOL-HOST/payment/refunds` — the only page this controller renders. Registered route name is `payment.payment.backend.refunds.index` (the source declares `payment.backend.refunds.index`, but the module provider prepends its own `payment.` name prefix; see §7). |
| Menu path | Finance. `app/Services/Breadcrumbs/registry.php:2687` lists it as a sibling of `dashboard.finance`; no dedicated sidebar entry was found in the repo's `glb_menus` seeders. |
| Who uses it | Any role that holds `tenant.payment.payment.viewAny`. Measured on the live tenant (`xyz_school_00000000000040008000_202627`, id `00000000-0000-4000-8000-000000000001`): granted to **2 roles — Super Admin and School Admin**. |
| What a user does here | Reads a plain, read-only list of every refund recorded across the school: the refund ULID, the payment it belongs to, the gateway name, the amount in rupees, the status, the free-text reason and the date. There is no create, edit, delete, restore or row action on this page. |
| Tables written | none — the page is read-only. |
| Tables read | `ptm_payment_refunds` (the list), `ptm_payment_payments` (the payment ULID) and `ptm_payment_gateways` (the gateway name), both via the eager load `payment.gateway`. |
| Live data | tenant `xyz_school_00000000000040008000_202627`: `ptm_payment_refunds` **0 rows** (0 trashed), `ptm_payment_payments` **60 rows**, `ptm_payment_gateways` **6 rows**. The refund list has never had a row on this tenant. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready — the page does not open at all.** The controller body itself is small and correct in shape: it authorizes before querying, it eager-loads the relations the view reads, it has no `try`/`catch`, and it returns a typed `View`. But the view it renders extends a layout that does not exist (`prime::layouts.master`), so `GET /payment/refunds` throws a 500 before the controller's output is ever shown (**BRF-01**). The single worst finding is BRF-01. Behind it sit two medium items (a copy-pasted permission literal instead of the existing PaymentPolicy, and a pagination-standard miss) and three low items (a missing breadcrumb, Pint debt, and a class comment that names a permission that does not exist). Rough effort to work the plan: **S — about half a day**, with the layout item held as one DECISION for Tarun.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 0 | 2 | 3 | 1 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | BRF-02 |
| F3 Authorization | BRF-03 | F10 Views | BRF-01, BRF-04 |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | BRF-05, BRF-06 |
| F6 Controller shape | clean | F13 Deep read | none — no mutating method |
| F7 Models | clean (linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Payment/app/Http/Controllers/Backend/RefundController.php` | controller | 43 | this report | ✅ |
| 2 | `Modules/Payment/resources/views/refunds/index.blade.php` | view (used only here) | 49 | this report | ✅ |
| 3 | `Modules/Payment/routes/web.php` | route file (the one refund route) | 38 | this report (routes only) | ✅ |
| 4 | `Modules/Payment/app/Models/PaymentRefund.php` | model | 49 | ↗ [tarun/Payment-done/RefundController](../../RefundController/01-report.md) | ↗ linked |
| 5 | `Modules/Payment/app/Models/Payment.php` | model | 101 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 6 | `Modules/Payment/app/Models/PaymentGateway.php` | model | 76 | ↗ [tarun/ParentPortal-done/ParentFeePaymentController](../../ParentPortal-done/ParentFeePaymentController-done/01-report.md) | ↗ linked |
| 7 | `Modules/Payment/app/Policies/PaymentPolicy.php` | policy | 46 | ↗ [tarun/Payment-done/PaymentController](../PaymentController/01-report.md) | ↗ linked (usage checked, not re-audited) |
| 8 | `Modules/Payment/app/Providers/PaymentServiceProvider.php` | provider | 212 | common module glue (§4.2) | ❌ inspected only — confirms `PaymentPolicy` is registered for `Payment` at line 41 and no policy is registered for `PaymentRefund` |
| 9 | `Modules/Payment/app/Policies/PaymentRefundPolicy.php` | (does not exist) | — | — | ❌ absent — confirms the controller's comment; a policy-form check on `PaymentRefund` has no policy to reach |

No pre-applied files for this controller (only TimetableFoundation has a `PRE-APPLIED-2026-10-10.md`).

The refund route is mounted by `Modules/Payment/app/Providers/RouteServiceProvider.php::mapWebRoutes()` (lines 42-56) inside `web`, tenancy (`InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`), `EnsureTenantIsActive`, `EnsureTenantHasModule:Payment`, `auth` and `verified`.

## 4. Routes

```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '... refunds ...'
GET|HEAD  payment/refunds   payment.payment.backend.refunds.index   Modules\Payment\Http\Controllers\Backend\RefundController@index
middleware: web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,
            Stancl\Tenancy\Middleware\InitializeTenancyByDomain,
            App\Http\Middleware\EnsureTenantIsActive,
            App\Http\Middleware\EnsureTenantHasModule:Payment,
            Illuminate\Auth\Middleware\Authenticate,
            Illuminate\Auth\Middleware\EnsureEmailIsVerified
```

Unrouted public methods: none. `index` is the only public method; it is routed. There is no constructor.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 28 | GET `payment/refunds` (name `payment.payment.backend.refunds.index`) | `tenant.payment.payment.viewAny` | none (read) | none | none — read-only | BRF-01, BRF-02, BRF-03, BRF-04, BRF-05, BRF-06 |

## 6. Findings

### F1 — Errors

clean — `grep -nE "try \{|catch \(|getMessage|withErrors|Log::" Modules/Payment/app/Http/Controllers/Backend/RefundController.php` → no output. The only method is a read path with no error handling to get wrong.

### F2 — Transactions and audit

clean — the controller has no write path: `grep -nE "DB::|create\(|update\(|delete\(|activityLog|save\(" Modules/Payment/app/Http/Controllers/Backend/RefundController.php` → no output.

### F3 — Authorization

#### BRF-03 · M · AUTH-06 — the refund list is gated by a copy-pasted *payment* permission literal, not the existing PaymentPolicy

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:30-35`, method `index()` |
| **Root cause** | There is no `PaymentRefundPolicy`, so the controller authorizes the page with the raw string `'tenant.payment.payment.viewAny'`. The same literal is copy-pasted in the API `PaymentController::index`, the API `RefundController::index` and the model `PaymentPolicy::viewAny` — four sites. The permission *already has a single home* (`PaymentPolicy`), and the sibling page `Backend/PaymentController::index` already authorizes through it with `Gate::authorize('viewAny', Payment::class)`. This controller instead duplicates the literal, so a rename of the permission means editing four places and the policy is bypassed. |
| **Consequence** | No user-visible defect today: both forms resolve to the same seeded permission, held by Super Admin and School Admin. It is a maintenance trap — the string is one rename away from silently disagreeing across the refund list, the payment list and the policy. |
| **Reproduce** | Static only — the permission is seeded and granted, so both forms succeed together; the divergence is a rename, which this read-only audit cannot stage (D4). |
| **Fix approach** | Authorize through the existing `PaymentPolicy` instead of the literal: `Gate::authorize('viewAny', Payment::class)`. This resolves to the identical permission (`PaymentPolicy::viewAny` returns `$user->can('tenant.payment.payment.viewAny')`) and matches the sibling `Backend/PaymentController::index`, but there is now one source — the policy — not four literals. No new permission key, so this is a mechanical item, not a DECISION. |
| **Plan item** | BRF-03 in `02-fix-plan.md` §4 |
| **Evidence** | `grep -n "Gate::authorize\|can(" ...` and the `PermissionHelper::flatten` probe (output below) |

```php
// RefundController.php:30-35 — CURRENT
        // NOT Gate::authorize('viewAny', PaymentRefund::class): there is no PaymentRefundPolicy
        // and PaymentServiceProvider registers one only for Payment and PaymentGateway, so a
        // policy-form check on this model is satisfiable by nothing except the super-admin
        // Gate::before bypass. tenant.payment.viewAny is seeded, and it is what the module's
        // own RefundController::index already uses for the same list.
        Gate::authorize('tenant.payment.payment.viewAny');
```

**Evidence**
```
$ grep -rn "tenant.payment.payment.viewAny" --include=*.php Modules/ | grep -v "Policies/"
Modules/Payment/app/Http/Controllers/RefundController.php:67:        Gate::authorize('tenant.payment.payment.viewAny');
Modules/Payment/app/Http/Controllers/PaymentController.php:122:        Gate::authorize('tenant.payment.payment.viewAny');
Modules/Payment/app/Http/Controllers/Backend/RefundController.php:35:        Gate::authorize('tenant.payment.payment.viewAny');

$ grep -n "viewAny" Modules/Payment/app/Policies/PaymentPolicy.php Modules/Payment/app/Http/Controllers/Backend/PaymentController.php
Modules/Payment/app/Policies/PaymentPolicy.php:14:        return $user->can('tenant.payment.payment.viewAny');
Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:30:        Gate::authorize('viewAny', Payment::class);

$ sed -n '1129,1130p' config/permissionslist.php
        'payment.payment-gateway' => $crud,
        'payment.payment' => array_merge($crud, ['cancel', 'refund']),
# flatten() prepends the scope: payment.payment.viewAny -> tenant.payment.payment.viewAny (declared + seeded)
```

### F4 — Validation and input

clean — the method takes no input. `grep -nE "Request|validate|all\(\)|except\(" Modules/Payment/app/Http/Controllers/Backend/RefundController.php` → no output.

### F5 — Routes

clean — one route (GET `payment/refunds`) points at the existing `index()`, the method is routed, there is no state change over GET, the route sits inside the tenancy + `auth` + `verified` group (§4), and there is no `Route::resource` prefix to collide with. Evidence: §4 route output and `grep -nE "public function" Modules/Payment/app/Http/Controllers/Backend/RefundController.php` → `index` at line 28. (The source route name is doubled by the provider prefix — recorded in §7, not a defect here.)

### F6 — Controller shape

clean — 43 lines and 1 public method (thresholds 1,000 lines / 25 methods), the method is 14 lines (threshold 80), it returns the declared `: View`, it has no `compact()` over-run (one variable), no `request()` helper, no `dd()`/`dump()`, no dead code. Evidence: `wc -l` 43 and `grep -nE "public function|compact|request\(\)|dd\(|dump\(" Modules/Payment/app/Http/Controllers/Backend/RefundController.php`.

### F7 — Models

clean — the controller's own model usage is a simple `PaymentRefund::with(['payment.gateway'])->latest()->paginate(20)`. `PaymentRefund` and `Payment` are owned elsewhere and audited there; the eager-load chain `payment.gateway` resolves because `PaymentRefund::payment()` is a return-typed `BelongsTo` and `Payment::gateway()` is a return-typed `BelongsTo`. No `InteractsWithMedia`, no `$guarded = []`. See §3 rows 4-6.

### F8 — Services and jobs

clean — the controller uses no service, job, event or listener; it queries the model directly. `grep -nE "Service|Job|event\(|dispatch|app\(" Modules/Payment/app/Http/Controllers/Backend/RefundController.php` → no output. (The module's `RefundService` exists for the API refund path and is owned by another report; this read-only list does not call it.)

### F9 — Queries and performance

#### BRF-02 · M · QRY-13 — the list paginates 20, not the house standard of 10, and has no distinct page name

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L default, raised to M here to match the sibling `Backend/PaymentController` report BPA-04 and the protocol F9 note on C12 — *filtered paginators keep filters; multiple paginators use distinct page names*, and the house list standard is 10) — *lists paginate at 10 with a distinct `pageName` per list* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:37-39`, method `index()` |
| **Root cause** | The query calls `paginate(20)` with no page name. The Payment module's local norm is mixed (4 uses of 20, 2 of 15, 1 of 10) while the house/estate standard is 10 with a distinct page name per list (C12). Only one paginator appears on this page, so the missing `pageName` is latent rather than active today; the count of 20 is the actual deviation. |
| **Consequence** | A larger page loads 20 refund rows where the estate standard loads 10 — more work per request on the finance list and an inconsistent page size next to the `PaymentGatewayController` lists. No wrong result. |
| **Reproduce** | Static only — the live tenant has 0 refund rows, so there is no populated page to measure; the deviation is in the code. |
| **Fix approach** | Change `paginate(20)` to `paginate(10, ['*'], 'refundsPage')`. The distinct page name costs nothing and keeps the page safe if a second list is ever added beside it. |
| **Plan item** | BRF-02 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -rn "paginate(" Modules/Payment/` (output below) |

```php
// RefundController.php:37-39 — CURRENT
        $refunds = PaymentRefund::with(['payment.gateway'])
            ->latest()
            ->paginate(20);
```

**Evidence**
```
$ grep -rn "paginate(" Modules/Payment/app/Http/Controllers/
Modules/Payment/app/Http/Controllers/PaymentReconciliationController.php:37:            ->paginate(20);
Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:48:            ->paginate(15, ['*'], 'gateway_page')
Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:65:            ->paginate(15, ['*'], 'history_page')
Modules/Payment/app/Http/Controllers/PaymentGatewayController.php:245:            ->paginate(10);
Modules/Payment/app/Http/Controllers/Backend/RefundController.php:39:            ->paginate(20);
Modules/Payment/app/Http/Controllers/Backend/WebhookController.php:23:            ->paginate(20);
Modules/Payment/app/Http/Controllers/Backend/PaymentController.php:34:            ->paginate(20);
```

### F10 — Views

#### BRF-01 · B · VIEW-04 — the refund list page 500s: it extends a layout that does not exist

| Field | Value |
|---|---|
| **Rule** | VIEW-04 (B) — no rulebook line; from protocol F10 (`final-audit.md` §6): *"Blades must compile."* An `@extends` whose target does not resolve throws `ViewException` — a crash on a normal user path, so **B**. (Same rule ID and root cause as BPA-01 in the sibling `Backend/PaymentController` report.) |
| **Where** | `Modules/Payment/resources/views/refunds/index.blade.php:1`, the view rendered by `index()` at line 41 |
| **Root cause** | The `prime` view namespace resolves only to `Modules/Prime/resources/views` (verified from the view finder hints). There is no `layouts/` directory there, so `prime::layouts.master` cannot be resolved. Only `prime::components.layouts.master` exists, and it is the untouched nwidart stub (no `@yield('content')`). The same broken `@extends` sits in five other Payment backend views (see §7). |
| **Consequence** | Opening `/payment/refunds` throws `View [layouts.master] not found` — a 500 before any refund row is shown. The refund page is completely down. |
| **Reproduce** | Open `http://SCHOOL-HOST/payment/refunds` as a role holding `tenant.payment.payment.viewAny`; Laravel reports `View [layouts.master] not found`. Static proof below (D4 — no browser/tenant session was opened). |
| **Fix approach** | Point the view at a layout that resolves (see BRF-01 in the plan — a DECISION, because the layout target is shared and the same break is owned by the sibling Payment reports). Recommended: the one-line change to `@extends('backend.layouts.master')` for this view, matching BPA-01 option (a). |
| **Plan item** | BRF-01 in `02-fix-plan.md` §1 (DECISION) |
| **Evidence** | `view()->exists()` probes and a CLI render attempt (output below) |

```blade
@extends('prime::layouts.master')

@section('title', 'Refunds')
```

**Evidence**
```
$ php artisan tinker --execute '
echo "prime::layouts.master => "; var_export(view()->exists("prime::layouts.master")); echo PHP_EOL;
echo "prime::components.layouts.master => "; var_export(view()->exists("prime::components.layouts.master")); echo PHP_EOL;
echo "backend.layouts.master => "; var_export(view()->exists("backend.layouts.master")); echo PHP_EOL;'
prime::layouts.master => false
prime::components.layouts.master => true
backend.layouts.master => true

$ php artisan tinker --execute 'try { view("payment::refunds.index", ["refunds" => collect()])->render(); echo "OK"; } catch (\Throwable $e) { echo get_class($e).": ".$e->getMessage(); }'
Illuminate\View\ViewException: View [layouts.master] not found. (View: .../Modules/Payment/resources/views/refunds/index.blade.php)

$ php artisan tinker --execute 'var_export(view()->getFinder()->getHints()["prime"]);'
array ( 0 => '/home/.../prime_ai/Modules/Prime/resources/views', )
```

#### BRF-04 · L · UI-STD — the refunds page renders no breadcrumb

| Field | Value |
|---|---|
| **Rule** | UI-STD (L) — Breadcrumb Standard §1: every backend page renders `<x-backend.components.breadcrum>`. (Same rule and shape as BPA-08 in the sibling report.) |
| **Where** | `Modules/Payment/resources/views/refunds/index.blade.php:5-9` |
| **Root cause** | The view defines only `content_header` (a plain heading) and `content`; it never includes the breadcrumb component. Even once BRF-01 is fixed, the layout it would extend (`backend.layouts.master`) does not inject a breadcrumb either, so the trail is absent by construction. The registry already carries an entry for this route (`app/Services/Breadcrumbs/registry.php:2687`, parent `dashboard.finance`), so the trail is ready to render. |
| **Consequence** | A user cannot see where the Refunds page sits in the module tree; only the browser back button leaves the page. |
| **Reproduce** | Once BRF-01 is fixed, open `/payment/refunds` — no breadcrumb trail is rendered. |
| **Fix approach** | Add `<x-backend.components.breadcrum title="Refunds" :links="[]" />` as the first line of `@section('content')`. The parent links are resolved by the registry entry, so no extra data is needed. |
| **Plan item** | BRF-04 in `02-fix-plan.md` §7 |
| **Evidence** | `grep -n "breadcrum" ...` and the registry entry (output below) |

```blade
// refunds/index.blade.php:5-9 — CURRENT
@section('content_header')
    <h5 class="mb-0">Refunds</h5>
@endsection

@section('content')
```

**Evidence**
```
$ grep -n "breadcrum" Modules/Payment/resources/views/refunds/index.blade.php
(no output)

$ sed -n '2686,2690p' app/Services/Breadcrumbs/registry.php
    // S3_SIBLING
    'payment.payment.backend.refunds.index' => [
        'parent' => 'dashboard.finance',
    ],
```

### F11 — Security and tenancy

clean — no `env()` (`grep -n "env(" ...` → no output), no hard-coded ids or `?? 1`, no logging of request data, no service locator. The route sits inside the tenancy middleware group (§4), so the query runs against the tenant connection. The view prints only scalar columns through `{{ }}` (no `{!! !!}`). The one over-exposure question — the list shows refund amounts and free-text reasons to every role holding `tenant.payment.payment.viewAny` (measured: Super Admin, School Admin, the same two roles that can already read the payment list) — is recorded under BRF-03; no *additional* role sees refunds that cannot already see payments.

### F12 — Style

#### BRF-05 · L · STY-02 — `RefundController.php` is not Pint-clean (import order)

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines between imports* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:7-10` |
| **Root cause** | The imports are not alphabetically ordered: `Illuminate\Support\Facades\Gate` sits before `App\Http\Controllers\Controller`. Pint's `ordered_imports` wants the `App\` import first. |
| **Consequence** | No runtime effect; it fails the repository's Pint gate and makes later diffs noisier. |
| **Reproduce** | `vendor/bin/pint --test Modules/Payment/app/Http/Controllers/Backend/RefundController.php` → `result: fail`. |
| **Fix approach** | Run Pint on this file only. |
| **Plan item** | BRF-05 in `02-fix-plan.md` §8 |
| **Evidence** | Pint output below |

```php
// RefundController.php:7-10 — CURRENT
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use Illuminate\View\View;
use Modules\Payment\Models\PaymentRefund;
```

**Evidence**
```
$ vendor/bin/pint --test Modules/Payment/app/Http/Controllers/Backend/RefundController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\/Payment\/app\/Http\/Controllers\/Backend\/RefundController.php","fixers":["ordered_imports"]}]}
```

#### BRF-06 · L · STY-04 — the class comment carries an emoji marker and names a permission that does not exist

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no stale/wrong descriptions* |
| **Where** | `Modules/Payment/app/Http/Controllers/Backend/RefundController.php:13` (emoji) and `:33` (wrong permission) |
| **Root cause** | Line 13 opens the class comment with a `⚠` emoji marker. Line 33 states *"tenant.payment.viewAny is seeded"*, but no permission of that name exists; the seeded name is `tenant.payment.payment.viewAny` (`config/permissionslist.php:1130` declares `payment.payment`, and `PermissionHelper::flatten()` prepends `tenant.`). A developer following the comment searches for the wrong key. |
| **Consequence** | No runtime effect, but the comment misdirects anyone tracing the permission, and the emoji breaks the "English, no emoji markers" style rule. |
| **Reproduce** | Static only — read lines 13 and 33 of the controller. |
| **Fix approach** | Remove the `⚠` marker from line 13 and correct `tenant.payment.viewAny` to `tenant.payment.payment.viewAny` on line 33. |
| **Plan item** | BRF-06 in `02-fix-plan.md` §8 |
| **Evidence** | the scanner row and the permission probe (output below) |

```php
// RefundController.php:13 — CURRENT
 * ⚠ Gate::authorize(...), NOT $this->authorize(...).
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-brf.json Modules/Payment/app/Http/Controllers/Backend/RefundController.php Modules/Payment/resources/views/refunds/index.blade.php
L  STY-04   Modules/Payment/app/Http/Controllers/Backend/RefundController.php:13  - — emoji in comment

$ grep -c "tenant.payment.viewAny" config/permissionslist.php
0
$ grep -n "'payment.payment'" config/permissionslist.php
1130:        'payment.payment' => array_merge($crud, ['cancel', 'refund']),
```

### F13 — Deep read (answer all 8 questions for every mutating method)

No mutating methods — `index()` is the only method and it is read-only (no `save`, `update`, `create`, `delete`, `activityLog`). The eight questions (wrong-data overwrite, delete-before-store, duplicate implementation, soft-delete × unique index, race, authorization hole, lying message, dead feature) are therefore `n/a` for every method. The one question that can apply to a read — **authorization** — is captured as BRF-03: no role reads refunds that cannot already read the payment list, and the refund *action* remains separately gated by `tenant.payment.payment.refund`.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Payment/resources/views/webhooks/index.blade.php`, `reconciliation/index.blade.php`, `reconciliation/show.blade.php` | All three extend the same missing `prime::layouts.master` as BRF-01, so they also 500. | VIEW-04 | the respective Payment controller reports |
| `Modules/Payment/resources/views/payments/index.blade.php`, `payments/show.blade.php` | Same missing-layout break, already reported. | VIEW-04 | `tarun/Payment-done/BackendPaymentController` (BPA-01) |
| `Modules/Billing/resources/views/index.blade.php` | Also extends the missing `prime::layouts.master`. | VIEW-04 | `tarun` / Billing module owner |
| `Modules/Payment/routes/web.php:18` | Declares the name `payment.backend.refunds.index`, but the module provider's own `payment.` name prefix (`RouteServiceProvider.php:54`) doubles it, so the registered name is `payment.payment.backend.refunds.index`. The breadcrumb registry already uses the doubled form. Any consumer must use the doubled name. | RTE-02 | module owner (route file is shared) |
| `Modules/Payment/app/Http/Controllers/PaymentController.php:122` and `RefundController.php:67` | Repeat the same `tenant.payment.payment.viewAny` literal this report flags in BRF-03, bypassing `PaymentPolicy`. | AUTH-06 | the respective Payment controller reports |

## 8. Not covered, and why

- **The rendered page in a browser** — the route sits behind `auth` + tenancy middleware, so no tenant session was opened (D4). The 500 was proved with `view()->exists()` and a CLI render attempt, not by loading the page.
- **A populated refund table** — the live tenant has 0 refund rows, so the table's appearance and pagination behaviour could not be observed; the findings are static.
- **The six sibling views' breadcrumbs and rows** — owned by other reports (§7).
- **`PaymentRefund`/`Payment`/`PaymentGateway`/`PaymentPolicy` internals** — owned elsewhere and linked in §3; only this controller's *usage* of them was checked.
