# Final Audit — TeacherPortal / TeacherPortalController

**Audited:** 2026-10-14 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php` (871 lines, 15 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `https://test.localhost:8000/teacher-portal/dashboard`, `.../my-timetable`, `.../my-profile`, `.../chat`, `.../my-classes`, `.../my-classes/student/{student}`, `.../my-meetings`, `.../my-notifications`, `.../my-notifications/{notification}`, `.../my-leave`, `.../attendance` — all prefixed `teacher-portal/` |
| Menu path | The module sidebar is intentionally empty (`module.json` description). Teachers reach the pages by URL, the sidebar links in `resources/views/layouts/_sidebar.blade.php`, and the dashboard tabs. |
| Who uses it | The `Teacher` role. Measured on tenant `TEST_SCHOOL`: 85 users hold `Teacher`, all 85 have a `sch_teachers` row, and the role holds **zero** permissions (`sys_role_has_permissions_jnt` is empty for it). Access is decided by the `role:Teacher` route middleware. |
| What a user does here | A teacher opens their own landing page, timetable, classes, meetings, notifications and profile (all read-only). They take the daily attendance register for a section they manage, decide a student's leave application for that section, and file their own leave application. Opening a notification marks it read. |
| Tables written | `notifications` (`read_at`), `std_student_attendance`, `std_leave_applications`, `std_leave_application_remarks`, `sch_employee_leave_applications`, `sch_employee_leave_approvals`, `sys_activity_logs` |
| Tables read | `sch_teachers`, `sch_employees`, `sch_class_section_jnt`, `sch_classes`, `sch_sections`, `std_students`, `std_student_academic_sessions`, `sch_employee_leave_balance`, `sch_employee_leave_applications`, `sch_staff_leave_types`, `sch_annual_leave_sessions`, `sch_employee_attendance`, `lms_homework`, `lms_exams`, `lms_exam_results`, `lms_quizzes`, `lms_quests`, `ptm_events`, `ptm_slots`, `ptm_slot_bookings`, `ptm_assignments`, `tt_school_days`, `sys_dropdown_table`, `sys_users`, `glb_languages` |
| Live data | Measured 2026-10-14 on tenant `TEST_SCHOOL` (domain `test.localhost`): `sch_employees` 139 · `sch_employee_leave_applications` 356 · `sch_employee_leave_balance` 623 · `sch_staff_leave_types` 7 · `sch_annual_leave_sessions` 1 · `sch_employee_attendance` 890 · `sch_class_section_jnt` 43 · `std_students` 1824 · `std_student_academic_sessions` 9752 · `std_leave_applications` 4 · `sch_teacher_profile` 89 · `notifications` 4 · `sys_users` 5630 · `ptm_events` 2 · `lms_homework` 558 · `lms_exam_results` 413 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready: one Blocker** stands in the way. `Modules/TeacherPortal/routes/api.php` registers a REST resource for five methods (`index`, `store`, `show`, `update`, `destroy`) that do not exist on the controller, so every `/api/v1/teacherportals` request fatals; the module is display-only and these routes should not be there. The second-worst finding is a data-integrity gap: a leave application filed from this portal never debits the employee's `total_pending` balance, while the same application filed from the admin screen does, so the portal's balances drift and a later cancellation drives them negative. After the Blocker, the error-handling rework (four controller `try`/`catch` blocks that D1 forbids) and two inline-validation extractions, the remaining work is mechanical: two unbounded/lazy-looked-up query paths and style. Rough effort for the whole plan: **M** (roughly one developer-day), dominated by the error-handling and FormRequest extractions.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 3 | 4 | 6 | 2 | 14 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | TPC-01 | F8 Services/Jobs | TPC-12 |
| F2 Transactions/Audit | TPC-02, TPC-03, TPC-04 | F9 Queries/Perf | TPC-13 |
| F3 Authorization | TPC-05 | F10 Views | clean |
| F4 Validation | TPC-06, TPC-07 | F11 Security/Tenancy | clean |
| F5 Routes | TPC-08, TPC-09 | F12 Style | TPC-14 |
| F6 Controller shape | TPC-10 | F13 Deep read | TPC-02 |
| F7 Models | TPC-11 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php` | controller | 871 | this report | ✅ |
| 2 | `Modules/TeacherPortal/app/Http/Requests/ApplyLeaveRequest.php` | form request | 100 | this report | ✅ |
| 3 | `Modules/TeacherPortal/app/Services/TeacherClassesService.php` | service | 396 | this report | ✅ |
| 4 | `Modules/TeacherPortal/app/Services/TeacherLeaveService.php` | service | 415 | this report | ✅ |
| 5 | `Modules/TeacherPortal/app/Services/TeacherNotificationService.php` | service | 378 | this report | ✅ |
| 6 | `Modules/TeacherPortal/app/Services/TeacherProfileService.php` | service | 134 | this report | ✅ |
| 7 | `Modules/TeacherPortal/app/Services/TeacherPtmService.php` | service | 162 | this report | ✅ |
| 8 | `Modules/SchoolSetup/app/Models/Employee.php` | model | 968 | this report | ✅ |
| 9 | `Modules/SchoolSetup/app/Models/EmployeeLeaveApplication.php` | model | 107 | this report | ✅ |
| 10 | `Modules/SchoolSetup/app/Models/StaffLeaveType.php` | model | 77 | this report | ✅ |
| 11 | `Modules/SchoolSetup/app/Services/StaffLeaveService.php` | service | 333 | this report | ✅ |
| 12 | `Modules/TeacherPortal/resources/views/**` (21 blades) | views | 5728 | this report | ✅ |
| 13 | `Modules/TeacherPortal/app/Services/TeacherContext.php` | service | 227 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 14 | `Modules/TeacherPortal/app/Services/TeacherDashboardService.php` | service | 259 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 15 | `Modules/TeacherPortal/app/Services/TeacherScheduleService.php` | service | 936 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 16 | `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` | service | 240 | ↗ [tarun/TeacherPortal-done/MobileTeacherAttendanceController](MobileTeacherAttendanceController/01-report.md) | ↗ linked |
| 17 | `Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php` | service | 234 | ↗ [tarun/TeacherPortal-done/MobileTeacherAttendanceController](MobileTeacherAttendanceController/01-report.md) | ↗ linked |
| 18 | `Modules/SchoolSetup/app/Models/Teacher.php` | model | 511 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 19 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | 516 | ↗ [tarun/TeacherPortal-done/MobileTeacherDashboardController](MobileTeacherDashboardController/01-report.md) | ↗ linked |
| 20 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | 126 | ↗ [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md) | ↗ linked |

No pre-applied files — `final-audit-reports/tarun/TimetableFoundation/PRE-APPLIED-2026-10-10.md` exists but names no TeacherPortal file.

## 4. Routes

```
GET|HEAD api/v1/teacherportals                                   api.teacherportal.index                            Modules\TeacherPortal\Http\Controllers\TeacherPortalController@index
POST    api/v1/teacherportals                                   api.teacherportal.store                            Modules\TeacherPortal\Http\Controllers\TeacherPortalController@store
GET|HEAD api/v1/teacherportals/{teacherportal}                  api.teacherportal.show                             Modules\TeacherPortal\Http\Controllers\TeacherPortalController@show
PUT|PATCH api/v1/teacherportals/{teacherportal}                 api.teacherportal.update                           Modules\TeacherPortal\Http\Controllers\TeacherPortalController@update
DELETE  api/v1/teacherportals/{teacherportal}                   api.teacherportal.destroy                          Modules\TeacherPortal\Http\Controllers\TeacherPortalController@destroy
GET|HEAD teacher-portal/attendance                              teacher-portal.attendance                          Modules\TeacherPortal\Http\Controllers\TeacherPortalController@attendance
POST    teacher-portal/attendance                               teacher-portal.attendance.store                    Modules\TeacherPortal\Http\Controllers\TeacherPortalController@storeAttendance
POST    teacher-portal/attendance/leave/{application}           teacher-portal.attendance.leave.review             Modules\TeacherPortal\Http\Controllers\TeacherPortalController@reviewStudentLeave
GET|HEAD teacher-portal/chat                                    teacher-portal.chat                                Modules\TeacherPortal\Http\Controllers\TeacherPortalController@chat
GET|HEAD teacher-portal/dashboard                               teacher-portal.dashboard                           Modules\TeacherPortal\Http\Controllers\TeacherPortalController@dashboard
GET|HEAD teacher-portal/my-classes                              teacher-portal.my-classes                          Modules\TeacherPortal\Http\Controllers\TeacherPortalController@classes
GET|HEAD teacher-portal/my-classes/student/{student}            teacher-portal.my-classes.student                  Modules\TeacherPortal\Http\Controllers\TeacherPortalController@student
GET|HEAD teacher-portal/my-leave                                teacher-portal.my-leave                            Modules\TeacherPortal\Http\Controllers\TeacherPortalController@leave
POST    teacher-portal/my-leave/apply                           teacher-portal.my-leave.apply                      Modules\TeacherPortal\Http\Controllers\TeacherPortalController@applyLeave
GET|HEAD teacher-portal/my-meetings                             teacher-portal.my-meetings                         Modules\TeacherPortal\Http\Controllers\TeacherPortalController@meetings
GET|HEAD teacher-portal/my-notifications                        teacher-portal.my-notifications                    Modules\TeacherPortal\Http\Controllers\TeacherPortalController@notifications
POST    teacher-portal/my-notifications/read-all                teacher-portal.my-notifications.read-all           Modules\TeacherPortal\Http\Controllers\TeacherPortalController@markNotificationsRead
GET|HEAD teacher-portal/my-notifications/{notification}         teacher-portal.my-notifications.show               Modules\TeacherPortal\Http\Controllers\TeacherPortalController@notification
GET|HEAD teacher-portal/my-profile                              teacher-portal.my-profile                          Modules\TeacherPortal\Http\Controllers\TeacherPortalController@profile
GET|HEAD teacher-portal/my-timetable                            teacher-portal.my-timetable                        Modules\TeacherPortal\Http\Controllers\TeacherPortalController@timetable
```

Unrouted public methods: none — all 15 public methods are routed. The reverse is the problem: five **routes** point at methods that do not exist (finding TPC-08).

The web routes sit inside the full tenancy + auth stack from `Modules/TeacherPortal/Providers/RouteServiceProvider.php`: `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `EnsureTenantHasModule:teacher-portal`, `auth`, `verified`, `role:Teacher`. The API routes sit only inside `api` + `auth:sanctum` — no tenancy middleware (part of finding TPC-08).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `dashboard` | 60 | GET teacher-portal/dashboard | `role:Teacher` (middleware) | none | none | none | — |
| `timetable` | 163 | GET teacher-portal/my-timetable | `role:Teacher` (middleware) | none | none | none | TPC-06 |
| `profile` | 246 | GET teacher-portal/my-profile | `role:Teacher` (middleware) | none | none | none | — |
| `chat` | 292 | GET teacher-portal/chat | `role:Teacher` (middleware) | none | `'Viewed'` | sys_activity_logs | TPC-10 |
| `classes` | 317 | GET teacher-portal/my-classes | `role:Teacher` (middleware) | none | none | none | TPC-12 |
| `student` | 382 | GET teacher-portal/my-classes/student/{student} | `role:Teacher` + service ownership (404) | none | none | none | — |
| `meetings` | 404 | GET teacher-portal/my-meetings | `role:Teacher` (middleware) | none | none | none | — |
| `notifications` | 446 | GET teacher-portal/my-notifications | `role:Teacher` (middleware) | none | none | none | TPC-13 |
| `notification` | 490 | GET teacher-portal/my-notifications/{notification} | `role:Teacher` + relation ownership (404) | none | none | notifications (read_at) | TPC-09 |
| `markNotificationsRead` | 520 | POST teacher-portal/my-notifications/read-all | `role:Teacher` (middleware) | none | none | notifications (read_at) | — |
| `leave` | 543 | GET teacher-portal/my-leave | `role:Teacher` (middleware) | none | none | none | TPC-06 |
| `applyLeave` | 615 | POST teacher-portal/my-leave/apply | `ApplyLeaveRequest::authorize()` true + `role:Teacher` | `TeacherLeaveService::apply()` | `'Submitted'` / `'Created'` | sch_employee_leave_applications, sch_employee_leave_approvals, sys_activity_logs | TPC-01, TPC-02, TPC-05 |
| `attendance` | 658 | GET teacher-portal/attendance | `role:Teacher` + `abort_if(..., 403)` | none | none | none | TPC-01, TPC-06 |
| `storeAttendance` | 738 | POST teacher-portal/attendance | `role:Teacher` + `abort_unless(..., 403)` | `TeacherAttendanceService::save()` | none | std_student_attendance | TPC-01, TPC-07 |
| `reviewStudentLeave` | 806 | POST teacher-portal/attendance/leave/{application} | `role:Teacher` + `abort_unless(..., 403)` | `TeacherStudentLeaveService::review()` | `'Reviewed'` | std_leave_applications, std_leave_application_remarks, std_student_attendance, sys_activity_logs | TPC-01, TPC-07 |

## 6. Findings

### F1 — Errors

#### TPC-01 · M · ERR-00 — a controller try/catch that D1 forbids, in four places

| Field | Value |
|---|---|
| **Rule** | ERR-00 (severity set by D1 of the protocol) — *under D1 the Laravel idiom applies: no try/catch in a controller; `DB::transaction()` rolls back and the central handler in `bootstrap/app.php` renders the error. A controller try/catch is a finding unless it is one of the D2 shapes.* |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:620-635` (method `applyLeave`), and the same shape at `:676-678` (`attendance`), `:762-776` (`storeAttendance`), `:834-843` (`reviewStudentLeave`) |
| **Root cause** | Four `try` blocks were added to convert any failure into a page-specific red flash. None is a D2 shape (`\DomainException`, a truncate-then-rebuild catch, or `SnapshotProtectionException`). Three duplicate what the central exception renderer already does; the fourth (`attendance`) guards a `Carbon::parse()` that can be guarded without an exception. |
| **Consequence** | A genuine bug on a write path (a DB constraint, a service fault) is swallowed into a generic "Please try again." message and the developer loses the framework's error page; the code carries a second, divergent error policy the rest of the estate does not use. |
| **Reproduce** | static only — the catches only fire on a fault, which cannot be triggered from the UI without breaking the data. Verified by grep, below. |
| **Fix approach** | Remove all four `try`/`catch` blocks. `applyLeave`, `storeAttendance` and `reviewStudentLeave` let the service exception propagate (a `ValidationException` from `TeacherLeaveService::apply()` still redirects back with the field error because the framework handles it). Replace the `attendance` parse guard with a `Carbon::hasFormat()` check that cannot throw. Then drop the now-unused `Log` and `ValidationException` imports. |
| **Plan item** | TPC-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -nE 'try \{|\} catch' <controller>` (output below) |

```php
// TeacherPortalController.php:620-635 — CURRENT
        try {
            $this->leaveService->apply($ctx, $validated);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('Teacher portal leave application failed', [
                'user_id' => $ctx->user->id,
                'employee_id' => $ctx->employeeId,
                'exception' => $e,
            ]);

            return redirect()
                ->route('teacher-portal.my-leave', ['tab' => 'apply'])
                ->withInput()
                ->with('error', 'Your leave application could not be filed. Please try again.');
        }
```

**Evidence**
```
$ grep -nE 'try \{|\} catch' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php
620:        try {
622:        } catch (ValidationException $e) {
624:        } catch (\Throwable $e) {
676:            try {
678:            } catch (\Throwable) {
762:        try {
768:        } catch (\Throwable $e) {
834:        try {
836:        } catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### TPC-02 · H · TXN-01 — a portal leave application never debits the balance

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row, a model + pivot) runs inside one `DB::transaction`*, read with `controller-alignment.md` §0.1: count across the controller AND the service, and name the tables the mutation SHOULD touch, not the ones it does. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherLeaveService.php:372-389` (method `apply`), compared with the admin path `Modules/SchoolSetup/app/Http/Controllers/EmployeeLeaveApplicationController.php:380-391` |
| **Root cause** | The admin store path, when an application becomes `Submitted` and the leave type is paid, increments `sch_employee_leave_balance.total_pending` inside the same transaction. `TeacherLeaveService::apply()` writes the application, the approval records and the audit row, but omits the balance write entirely, so the two front doors produce different balance state. |
| **Consequence** | Leave filed in the portal is invisible to the "available balance" arithmetic (`available = entitled - used - pending`), the admin's own balance check over-allows the same teacher, and because `StaffLeaveService::cancelApplication()` still decrements `total_pending` on a `Submitted` application, cancelling a portal-filed application pushes the balance below its true value. |
| **Reproduce** | static only — reproduced by reading the two code paths; a live reproduction needs a real application write, which the audit does not perform (D4). |
| **Fix approach** | Inside the existing transaction in `apply()`, when `status === 'Submitted'` and `$leaveType->is_paid`, increment `total_pending` by `total_days` on the matching `sch_employee_leave_balance` row. |
| **Plan item** | TPC-02 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "total_pending\|increment" Modules/TeacherPortal/app/Services/TeacherLeaveService.php` and the admin-path read (outputs below) |

```php
// TeacherLeaveService.php:372-389 — CURRENT (no balance write inside the transaction)
        return DB::transaction(function () use ($payload, $policy, $ctx): int {
            $application = EmployeeLeaveApplication::create($payload);

            if ($payload['status'] === 'Submitted' && $policy) {
                $this->staffLeave->createApprovalRecords($application, $policy, $ctx->user->id);
            }

            activityLog($application, $payload['status'] === 'Submitted' ? 'Submitted' : 'Created', [
                'message' => 'Leave application '
                    .($payload['status'] === 'Submitted' ? 'submitted' : 'saved as draft')
                    .' from the Teacher Portal.',
                'from_date' => $payload['from_date'],
                'to_date' => $payload['to_date'],
                'total_days' => $payload['total_days'],
            ]);

            return (int) $application->id;
        });
```

**Evidence**
```
$ grep -n "total_pending\|increment" Modules/TeacherPortal/app/Services/TeacherLeaveService.php
65:                'b.total_pending', 'b.available_balance', 'b.manual_adjustment',

$ grep -n "increment('total_pending'" Modules/SchoolSetup/app/Http/Controllers/EmployeeLeaveApplicationController.php
389:                        $balanceRecord->increment('total_pending', (float)$application->total_days);
```

#### TPC-03 · H · TXN-01 — `storeDocuments()` makes two writes with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside one `DB::transaction`*. |
| **Where** | `Modules/SchoolSetup/app/Services/StaffLeaveService.php:279-292` (method `storeDocuments`) |
| **Root cause** | The method creates an `EmployeeLeaveApplicationDoc` row, then writes the media file and `update()`s the same row with the returned `media_id`, with no transaction and no compensating cleanup. |
| **Consequence** | If `addMedia()` fails (missing disk, mime rejection, disk full), a document row is left pointing at no media, and the leave application shows an attachment that does not exist. |
| **Reproduce** | static only — the method is not reachable from `TeacherPortalController` (its callers are the admin and mobile leave controllers); the audit cannot trigger a media failure. |
| **Fix approach** | Reaching it from this controller is impossible, and the correct fix (ordering the DB writes against `addMedia()`'s file write, per TXN-03) is an admin-path decision. Recorded here because `StaffLeaveService` is in this report's scope; not planned by this report. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `sed -n '279,292p' Modules/SchoolSetup/app/Services/StaffLeaveService.php` (quoted below) |

```php
// StaffLeaveService.php:279-292 — CURRENT
            $doc = EmployeeLeaveApplicationDoc::create([
                'leave_application_id' => $application->id,
                'document_name'        => $docName,
                'document_type_id'     => $docTypeId,
                'description'          => $description,
                'file_name'            => $file->getClientOriginalName(),
                'uploaded_by'          => $authId,
                'created_by'           => $authId,
                'is_active'            => true,
            ]);

            $media = $doc->addMedia($file)->toMediaCollection('leave_documents');
            $doc->update(['media_id' => $media->id]);
        }
```

**Evidence**
```
$ grep -n "DB::transaction\|addMedia\|::create\|->update(" Modules/SchoolSetup/app/Services/StaffLeaveService.php
240:            EmployeeLeaveApproval::create([
279:            $doc = EmployeeLeaveApplicationDoc::create([
290:            $media = $doc->addMedia($file)->toMediaCollection('leave_documents');
291:            $doc->update(['media_id' => $media->id]);
320:            EmployeeLeaveApplicationRemark::create([
(no DB::transaction anywhere in this method)
```

#### TPC-04 · L · QRY-07 — approval records are created one row per level in a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (default M; lowered to L — a policy has one or two levels on this tenant, so the loop runs once or twice) — *bulk writes use `insert()`/`upsert()`/`whereIn(...)->update()` instead of `create()` per row in a loop*. |
| **Where** | `Modules/SchoolSetup/app/Services/StaffLeaveService.php:240-251` (method `createApprovalRecords`) |
| **Root cause** | The method loops `$policy->levels` and calls `EmployeeLeaveApproval::create()` for each, so N levels means N INSERT statements and N model instantiations. It also touches `$level->approvers()` inside the loop (a query per level). |
| **Consequence** | Negligible on today's data (an approval policy has 1–2 levels), but it is the exact idiom QRY-07 asks to avoid and it scales with policy depth. |
| **Reproduce** | static only — correctness is unaffected; a query count is the observable. |
| **Fix approach** | Collect the rows and `EmployeeLeaveApproval::insert($rows)` once, supplying `created_at`/`updated_at` manually. Not planned by this report because the gain is disproportionate to the risk of touching a shared service for a 1–2 row loop; reported for the SchoolSetup leave audit. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `sed -n '228,251p' Modules/SchoolSetup/app/Services/StaffLeaveService.php` (quoted below) |

```php
// StaffLeaveService.php:240-251 — CURRENT
            EmployeeLeaveApproval::create([
                'leave_application_id' => $application->id,
                'policy_level_id'      => $level->id,
                'level_number'         => $level->level_number,
                'level_name'           => $level->level_name,
                'approver_user_id'     => $approverUserId,
                'action'               => 'Pending',
                'escalation_deadline'  => $escalationDeadline,
                'created_by'           => $authId,
                'is_active'            => true,
            ]);
        }
```

**Evidence**
```
$ grep -n "foreach (\$policy->levels\|EmployeeLeaveApproval::create" Modules/SchoolSetup/app/Services/StaffLeaveService.php
228:        foreach ($policy->levels as $level) {
240:            EmployeeLeaveApproval::create([
```

### F3 — Authorization

#### TPC-05 · M · AUTH-01 — no permission check on any method; access is role middleware plus ownership

| Field | Value |
|---|---|
| **Rule** | AUTH-01 (default B; lowered to M with reason — the role middleware and the service ownership checks do gate access, and a literal permission requirement is currently unsatisfiable: the `Teacher` role holds zero permissions and `config/permissionslist.php` has no `teacher-portal` key at all, so adding a `Gate::authorize` would lock out all 85 teachers) — *every routed controller method authorizes via `Gate::authorize`, `$this->authorize`, a `can:` route middleware, or a Form Request whose `authorize()` checks a permission*. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:47-52` (the `dashboard` docblock explains the decision); all 15 methods |
| **Root cause** | The module deliberately gates on `role:Teacher` (RouteServiceProvider) plus per-record ownership inside the services, not on a Spatie permission, because the role holds none on this tenant. That is defensible for the read methods and for the ownership-checked writes, but it means AUTH-01's "a permission check" is unmet everywhere, and `ApplyLeaveRequest::authorize()` returns `true` unconditionally. |
| **Consequence** | A grant of the `Teacher` role is the only thing between a user and every portal page; there is no ability to grant a non-teaching account read-only portal access, and no audit-friendly permission name for these routes. |
| **Reproduce** | static only — the effect is an authorization model, not a single URL. `grep -c "teacher-portal" config/permissionslist.php` returns 0. |
| **Fix approach** | A DECISION, not a mechanical fix: either (a) accept the documented `role:Teacher` gate as the module's model, or (b) add a `tenant.teacher-portal.*` permission set, seed it to the Teacher role, and add `Gate::authorize` to each method. A new permission key must be added to `config/permissionslist.php` and seeded by Tarun's hand. |
| **Plan item** | TPC-05 in `02-fix-plan.md` §4 (DECISION) |
| **Evidence** | `grep -n "teacher-portal" config/permissionslist.php` → no output; `sed -n '45,48p' Modules/TeacherPortal/app/Http/Requests/ApplyLeaveRequest.php` (shown below) |

```php
// TeacherPortalController.php:47-52 — the decision, quoted verbatim
     * ⛔ NO Gate::authorize() HERE, AND THAT IS NOT AN OVERSIGHT.
     * The `Teacher` role holds ZERO permissions on this tenant (measured 2026-09-11:
     * sys_role_has_permissions_jnt returns an empty set for it), so any permission check
     * would deny all 85 teachers their own portal. Access is decided by `role:Teacher` in
     * the route middleware, exactly as StudentPortal decides it with `role:Student`.
```

**Evidence**
```
$ grep -n "teacher-portal" config/permissionslist.php
(no output)

$ sed -n '45,48p' Modules/TeacherPortal/app/Http/Requests/ApplyLeaveRequest.php
    public function authorize(): bool
    {
        return true;
    }
```

### F4 — Validation and input

#### TPC-06 · H · VAL-05 — a junk query-string date reaches `Carbon::parse()` and 500s the page

| Field | Value |
|---|---|
| **Rule** | VAL-05 (H) — *every field is typed; write paths with no validation at all (for example `Carbon::parse($request->x)`) are H*. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:168-170` (method `timetable`, `?week=`) and `:547-549` (method `leave`, `?month=`) |
| **Root cause** | Both values arrive from the query string and are handed straight to `Carbon::parse()`. There is no validation and no guard, so any non-date string (`?week=abc`) raises `InvalidFormatException` and returns a 500. |
| **Consequence** | A teacher with a corrupted bookmark, or a link from an old email, gets the 500 error page instead of the page falling back to the current week or month. |
| **Reproduce** | Open `https://test.localhost:8000/teacher-portal/my-timetable?week=abc` — expected the current week; the route throws before the view renders. |
| **Fix approach** | Replace `Carbon::parse()` with a `Carbon::hasFormat($value, 'Y-m-d')` guard that returns the fallback date (today / this month) when the value is not a `Y-m-d` date. `hasFormat()` returns a boolean and does not throw. |
| **Plan item** | TPC-06 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "Carbon::parse(\$request" <controller>` (output below) |

```php
// TeacherPortalController.php:168-170 — CURRENT (timetable)
        $anchor = $request->filled('week')
            ? Carbon::parse($request->string('week')->toString())
            : Carbon::today();
```

**Evidence**
```
$ grep -n 'Carbon::parse($request' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php
169:            ? Carbon::parse($request->string('week')->toString())
548:            ? Carbon::parse($request->string('month')->toString())->startOfMonth()
677:                $date = Carbon::parse($request->string('date')->toString())->startOfDay();
(677 is guarded by a try/catch, removed by TPC-01 and replaced with the same hasFormat guard)
```

#### TPC-07 · M · VAL-02 — inline `$request->validate()` instead of Form Requests

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request; inline `$request->validate()` is allowed only for a one-field AJAX toggle*. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:742-749` (method `storeAttendance`) and `:813-832` (method `reviewStudentLeave`) |
| **Root cause** | Both methods validate a multi-field payload inline. `storeAttendance` validates six keys; `reviewStudentLeave` validates three keys including a conditional `Rule::requiredIf` and a max derived from the bound model. Neither is a one-field toggle. |
| **Consequence** | The validation rules are not reusable and not unit-testable in isolation, and they drift from the request layer convention the rest of the estate uses (the `applyLeave` method already uses `ApplyLeaveRequest`). |
| **Reproduce** | static only — the validation itself behaves correctly; this is a placement/convention defect. |
| **Fix approach** | Extract `StoreAttendanceRequest` and `ReviewStudentLeaveRequest` under `Modules/TeacherPortal/app/Http/Requests/`, move the rules and the custom message across, and type-hint the controller methods with them. |
| **Plan item** | TPC-07 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n '$request->validate(' <controller>` (output below) |

```php
// TeacherPortalController.php:742-749 — CURRENT (storeAttendance)
        $validated = $request->validate([
            'class_section' => ['required', 'integer'],
            'date' => ['required', 'date'],
            'status' => ['required', 'array'],
            'status.*' => ['required', 'string', Rule::in(TeacherAttendanceService::STATUSES)],
            'remarks' => ['nullable', 'array'],
            'remarks.*' => ['nullable', 'string', 'max:255'],
        ]);
```

**Evidence**
```
$ grep -n '$request->validate(' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php
742:        $validated = $request->validate([
813:        $validated = $request->validate([
```

### F5 — Routes

#### TPC-08 · B · RTE-02 — five API routes point at methods that do not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists*. |
| **Where** | `Modules/TeacherPortal/routes/api.php:5-7` |
| **Root cause** | The nwidart module scaffold left `Route::apiResource('teacherportals', TeacherPortalController::class)` in `routes/api.php`. The controller is display-only and implements none of the resource methods (`index`, `store`, `show`, `update`, `destroy`), so the five generated routes resolve to undefined controller methods. |
| **Consequence** | Any request to `/api/v1/teacherportals` (list, create, single, update, delete) fatals with "Call to undefined method" and returns 500, not 404. The routes are also outside the tenancy middleware, so even if stubs existed they would run without a tenant context. |
| **Reproduce** | Open `https://test.localhost:8000/api/v1/teacherportals` with a valid Sanctum token — expected 404 (a route that is not offered) or a valid list; actual 500. |
| **Fix approach** | A DECISION, because removing or reshaping routes is a route change. The module is described as display-only in `module.json` and `routes/web.php`; the two clean options are (a) remove `routes/api.php` from the provider (or empty the file) so the dead routes disappear, or (b) keep them and add read-only `index`/`show` methods. Option (a) is recommended. |
| **Plan item** | TPC-08 in `02-fix-plan.md` §9 (DECISION) |
| **Evidence** | `php artisan route:list --json` filtered for the controller (route list in §4) and the `method_exists` probe (output below) |

```php
// Modules/TeacherPortal/routes/api.php:5-7 — CURRENT
Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('teacherportals', TeacherPortalController::class)->names('teacherportal');
});
```

**Evidence**
```
$ php -r '...method_exists(TeacherPortalController::class, $m)...'
index                    MISSING
store                    MISSING
show                     MISSING
update                   MISSING
destroy                  MISSING
dashboard                EXISTS
timetable                EXISTS
profile                  EXISTS
chat                     EXISTS
classes                  EXISTS
student                  EXISTS
meetings                 EXISTS
notifications            EXISTS
notification             EXISTS
markNotificationsRead    EXISTS
leave                    EXISTS
applyLeave               EXISTS
attendance               EXISTS
storeAttendance          EXISTS
reviewStudentLeave       EXISTS
```

#### TPC-09 · L · RTE-01 — opening a notification changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (default H; lowered to L with reason — the write is idempotent, scoped to the caller's own row, and its only effect is to clear a bell badge they are already looking at) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it*. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:500` (method `notification`) |
| **Root cause** | The read action for a notification is "open its detail page", so the GET handler flips `read_at` through `markAsRead()`. |
| **Consequence** | A browser or mail-client link prefetch, or a crawler following the URL, can mark a notification read without the teacher ever seeing it. |
| **Reproduce** | Open `https://test.localhost:8000/teacher-portal/my-notifications/{uuid}` and then the bell — the badge drops without any explicit action. |
| **Fix approach** | Accepted as designed (the docblock at `:484-488` argues the case and `markAsRead()` is idempotent). Recorded so the decision is visible; not planned. If the estate ever wants strict GET semantics, move the flip to the existing `read-all` POST or add a POST toggle. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `sed -n '498,500p' <controller>` (quoted below) |

```php
// TeacherPortalController.php:498-500 — CURRENT
        // Read the row again off the same relation to flip it — find() hands back a plain
        // presentation object, which has no markAsRead().
        $ctx->user->notifications()->whereKey($notification)->first()?->markAsRead();
```

**Evidence**
```
$ grep -n "markAsRead" Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php
500:        $ctx->user->notifications()->whereKey($notification)->first()?->markAsRead();
$ grep -n "Route::get('/my-notifications/{notification}'" Modules/TeacherPortal/routes/web.php
Route::get('/my-notifications/{notification}', [TeacherPortalController::class, 'notification'])
```

### F6 — Controller shape

#### TPC-10 · L · CTL-08 — the `request()` helper is used inside a controller method

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *inject `Request`; do not call the `request()` helper inside controller methods*. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:298` (method `chat`) |
| **Root cause** | `chat()` takes no `Request` parameter and reaches for the global `request()` to read the current route name for the audit context. |
| **Consequence** | No user-visible effect; it is the convention violation the rulebook records, and it makes the method harder to call with an explicit request in a test. |
| **Reproduce** | static only — `grep -n 'request()' <controller>` returns the single call. |
| **Fix approach** | Add a `Request $request` parameter to `chat()` and use `$request->route()?->getName()`. The route already passes one through the container. |
| **Plan item** | TPC-10 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n 'request()' <controller>` (output below) |

```php
// TeacherPortalController.php:292-300 — CURRENT
    public function chat(): View
    {
        activityLog(auth()->user(), 'Viewed', [
            'message' => 'Teacher viewed the chat page.',
            'context' => [
                'module' => 'TeacherPortal',
                'route' => request()->route()?->getName(),
            ],
        ]);
```

**Evidence**
```
$ grep -nE '\brequest\(\)' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php
298:                'route' => request()->route()?->getName(),
```

### F7 — Models

#### TPC-11 · L · MDL-04 — the three in-scope models declare no relationship return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods are return-typed*. Paired here with STY-01 (L) — *`declare(strict_types=1);` in PHP files*. |
| **Where** | `Modules/SchoolSetup/app/Models/Employee.php:127` (method `user`, and 36 further relations), `Modules/SchoolSetup/app/Models/EmployeeLeaveApplication.php:58` (method `employee`, and 9 further relations), `Modules/SchoolSetup/app/Models/StaffLeaveType.php:64` (method `leaveConfigs`, and 2 further relations) |
| **Root cause** | All three models predate the return-type convention and were never typed. None of the three files declares `strict_types`. |
| **Consequence** | No runtime effect; a static-analysis blind spot and an inconsistency with the typed relations the newer models carry. |
| **Reproduce** | static only — `scanfilter.py` reported 49 MDL-04 rows across the three files. |
| **Fix approach** | Add the concrete `BelongsTo`/`HasMany`/`HasOne`/`HasManyThrough` return type to each relation and add `declare(strict_types=1);` at the top of each file. Not planned by this report: it touches three shared SchoolSetup models (high blast radius for an L-severity change) and belongs in a typed-relations sweep. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-teacherportal.json <files>` (excerpt below) |

```php
// Employee.php:127-130 — CURRENT
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
```

**Evidence**
```
$ python3 .../scanfilter.py /tmp/fa-teacherportal.json Modules/SchoolSetup/app/Models/Employee.php ...
L  STY-01   Modules/SchoolSetup/app/Models/Employee.php:1  - — missing declare(strict_types=1)
L  MDL-04   Modules/SchoolSetup/app/Models/Employee.php:127  user — relation user() has no return type
L  MDL-04   Modules/SchoolSetup/app/Models/Employee.php:132  photoMedia — relation photoMedia() has no return type
... 36 further MDL-04 rows in Employee.php; 10 in EmployeeLeaveApplication.php; 3 in StaffLeaveType.php
```

### F8 — Services and jobs

#### TPC-12 · M · SVC-05 — `classSections()` is not memoised and runs six times per page

| Field | Value |
|---|---|
| **Rule** | SVC-05 (M) — *repeated lookups inside a request (status ids, settings) are memoised or cached once*; the same defect is QRY-12 (M). |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherClassesService.php:36-72` (method `classSections`) |
| **Root cause** | `classSections()` builds its result from a fresh `DB::table('sch_class_section_jnt')` query on every call, and every consumer calls it: `students()` and `results()` via `allowedIds()`, and `homework()`, `exams()` and `assessments()` via `scopeSections()`. The `classes()` action calls all of them, so one page load issues the same class-section query six times. |
| **Consequence** | Six identical full scans of `sch_class_section_jnt` per My Classes page load (43 rows today, so cheap, but the pattern is a fixed multiple of a table that only grows) and the same shape repeats for `managedSections()` on the attendance page. |
| **Reproduce** | static only — count the call graph; the observable is the query count, not a rendered difference. |
| **Fix approach** | Memoise `classSections()` on the instance, keyed by the context's user id, and return the cached collection on later calls. The service is constructor-injected into the controller once, so one instance serves the whole request. |
| **Plan item** | TPC-12 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n "classSections(\$ctx)\|allowedIds(\|scopeSections(" <service>` (output below) |

```php
// TeacherClassesService.php:36-41 — CURRENT (rebuilds every call)
    public function classSections(TeacherContext $ctx): Collection
    {
        if ($ctx->classSections->isEmpty()) {
            return collect();
        }

        $rows = collect(DB::table('sch_class_section_jnt as cs')
```

**Evidence**
```
$ grep -n "classSections(\|allowedIds(\|scopeSections(" Modules/TeacherPortal/app/Services/TeacherClassesService.php
36:    public function classSections(TeacherContext $ctx): Collection
75:    public function allowedIds(TeacherContext $ctx): array
77:        return $this->classSections($ctx)->pluck('id')->map(fn ($i) => (int) $i)->all();
89:        $allowed = $this->allowedIds($ctx);
149:        $sections = $this->scopeSections($ctx, $classSectionId);
188:        $classIds = $this->scopeSections($ctx, $classSectionId)->pluck('class_id')->unique()->values();
231:        $allowed = $this->allowedIds($ctx);
286:        $classIds = $this->scopeSections($ctx, $classSectionId)->pluck('class_id')->unique()->values();
387:        $all = $this->classSections($ctx);
```

### F9 — Queries and performance

#### TPC-13 · L · QRY-02 — the notification list is fetched unbounded

| Field | Value |
|---|---|
| **Rule** | QRY-02 (default M; lowered to L with reason — the query is scoped to the signed-in user's own notifications and the live table holds 4 rows; changing this changes the tab-bin UI, which is a design decision) — *lists are paginated; no unbounded `->get()` feeding a list page*. |
| **Where** | `Modules/TeacherPortal/app/Services/TeacherNotificationService.php:108-115` (method `all`) |
| **Root cause** | `all()` calls `$ctx->user->notifications()->get()` with no `limit`/`paginate`, and `categorised()` bins the whole result. A long-lived account accumulates rows over time. |
| **Consequence** | On a tenant where a teacher has thousands of notifications, the page loads and renders every one before the category tabs are computed. Today the table holds 4 rows, so there is no live impact. |
| **Reproduce** | static only — measured `notifications` = 4 rows on `TEST_SCHOOL`; the risk is the unbounded pattern, not a present failure. |
| **Fix approach** | Either `->limit(...)` with a "showing the latest N" note, or real pagination. Both change what the tab-badge counts mean, so it is recorded rather than planned here. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `sed -n '108,115p' .../TeacherNotificationService.php` (quoted below) |

```php
// TeacherNotificationService.php:108-115 — CURRENT
    public function all(TeacherContext $ctx): Collection
    {
        return $ctx->user->notifications()
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (DatabaseNotification $n) => $this->present($n))
            ->values();
    }
```

**Evidence**
```
$ tinker: DB::table('notifications')->count()  (tenant TEST_SCHOOL)
4
$ grep -n "->get()" Modules/TeacherPortal/app/Services/TeacherNotificationService.php
112:            ->get()
```

Clean notes for this family:
- **No N+1 in the write/read paths.** The list services resolve their rows with joins and map them to plain objects; the attendance blade's relations are eager-loaded by `TeacherStudentLeaveService::forSection()` (`with(['student.user','leaveType','appliedBy','reviewedBy','remarks.remarkedBy','documents'])`). Proved with `grep -n "->with(" Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php` → line 158.
- **QRY-11 is a false positive.** `TeacherClassesService.php:305-306` interpolates `$kind`, `$allocTable` and `$fk` into `DB::raw()`/`selectRaw()`, but all three are literal constants passed from the two internal calls at `:310-311` (`'Quiz'`, `'lms_quiz_allocations'`, `'quiz_id'`; `'Quest'`, `'lms_quest_allocations'`, `'quest_id'`). No user input reaches the string. Command: `grep -n "build('lms_quizzes'\|build('lms_quests'" Modules/TeacherPortal/app/Services/TeacherClassesService.php`.

### F10 — Views

Clean — every check below was run and produced the stated result.

- **No queries in Blade.** `grep -rnE '\b(App\\\\Models|Modules\\\\[A-Za-z]+\\\\Models|DB::|::where|::find|::query\(|::select)' Modules/TeacherPortal/resources/views --include=*.blade.php` → no model/DB access; the only `::` hits are constant references (`TeacherStudentLeaveService::OPEN_STATUSES`).
- **No `{!! !!}` on user text.** The three hits are: a comment in `notifications/show.blade.php`, a comment in `components/field-list.blade.php`, and `index.blade.php:4` `{!! config('teacherportal.name') !!}` — a config value, and the nwidart default landing blade is not rendered by this controller. Command: `grep -rnE '\{!!' Modules/TeacherPortal/resources/views --include=*.blade.php`.
- **Relations are eager-loaded.** Attendance rows load `student.user`, `leaveType`, `appliedBy`, `reviewedBy`, `remarks.remarkedBy`, `documents` via `forSection()`; the profile page's `addresses`, `emergencyContacts`, `bankDetails`, `documents` and `teacherProfiles.designation/department` are eager-loaded by `TeacherProfileService::for()`. No `$model->relation` dumps the row as JSON. Command: `grep -rnE '\{\{ ?\$[a-zA-Z_]+->[a-zA-Z_]+->[a-zA-Z_]+' Modules/TeacherPortal/resources/views --include=*.blade.php` → only Carbon accessors (`->created_at->diffForHumans()`), no relation objects.
- **All 21 blades compile.** `php /tmp/fa-bladecheck.php` compiled every file via `Blade::compileString()` with no `COMPILE-ERROR`, and `@push(` counts matched `startPush` counts (`attendance` and `leave` each 1/1; the `chat` hit was the word `@push` inside a `{{-- --}}` comment). No `{{-- --}}` sits inside `@php`.
- **Breadcrumb.** Each page renders a hand-written `<ol class="breadcrumb">` whose only link is `route('teacher-portal.dashboard')`. Against `breadcrumb-standard.md` §1 (a chain of route names, every crumb URL from `route()`) the two-level portal trail resolves correctly; the backend `x-backend.components.breadcrum` component is not used here.
- **Table-action, modal and export/import standards are not applicable** — this module renders no backend data tables, has no admin create form (the leave form is a portal tab, not a modal), and offers no export or import.

### F11 — Security and tenancy

Clean — every check below was run and produced the stated result.

- **No `env()` in scope.** `grep -rnE '\benv\(' Modules/TeacherPortal/app Modules/SchoolSetup/app/Services/StaffLeaveService.php Modules/SchoolSetup/app/Models/Employee.php Modules/SchoolSetup/app/Models/EmployeeLeaveApplication.php Modules/SchoolSetup/app/Models/StaffLeaveType.php` → no output.
- **No hard-coded ids or `?? 1`.** `grep -rnE '\?\? 1\b|user_id.?=>.?1\b|employee_id.?=>.?1\b' Modules/TeacherPortal/app` → no output.
- **PII is masked or omitted.** `profile/index.blade.php:248-249` masks the bank account to its last four digits; `:123-125` records that `aadhaar_number`, `pan_number`, `pf_number`, `esi_number` and `uan_number` are deliberately not rendered. `Employee` encrypts Aadhaar and PAN with `App\Casts\SafeEncrypted` (`Employee.php:81-82`).
- **No secrets in logs.** The three `Log::error()` calls log `$e` (the exception object), never a request body.
- **Private files through authorised routes.** `Employee::registerMediaCollections()` puts `form16` on the `local` (tenant-scoped) disk and documents the ownership-checked download route (`Employee.php:896-898`).
- **Media is tenant-bound.** `Employee::getMediaModel()` returns `Modules\Prime\Models\TenantMedia` (`Employee.php:915-918`), satisfying MDL-05/TEN-01.
- **No caching to key.** None of the in-scope classes caches; `glb_languages` (a central/global-master table) is guarded with `Schema::hasTable()` before use (`TeacherProfileService.php:97`).

### F12 — Style

#### TPC-14 · L · STY-04 — emoji/symbol markers in comments across the module

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers*. |
| **Where** | `Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:47` (and the other files below) |
| **Root cause** | The module's documentation style uses the warning symbols ⚠ and ⛔ and the arrow → as severity markers in every docblock. |
| **Consequence** | Cosmetic and convention-only; the markers are readable and deliberate, but they are not plain English and the rulebook records them as L. |
| **Reproduce** | static only — `scanfilter.py` reported 100+ STY-04 rows across the controller, the request, six services and `Employee.php`. |
| **Fix approach** | Replace the symbols with words ("Note", "Never", "then") in every touched file. Not planned by this report: it is a cosmetic sweep across 11 files for an L-severity convention difference, and the markers are the module's chosen documentation voice. |
| **Plan item** | none — see plan §10 |
| **Evidence** | `python3 .../scanfilter.py /tmp/fa-teacherportal.json <files>` (excerpt below) |

```php
// TeacherPortalController.php:47 — CURRENT
     * ⛔ NO Gate::authorize() HERE, AND THAT IS NOT AN OVERSIGHT.
```

**Evidence**
```
$ python3 .../scanfilter.py /tmp/fa-teacherportal.json <11 in-scope files>
L  STY-04   Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:47  - — emoji in comment
L  STY-04   Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php:53  - — emoji in comment
... (100+ STY-04 rows across the controller, ApplyLeaveRequest, the six TeacherPortal services, and Employee.php)
```

Other style facts, so the whole family is covered: `declare(strict_types=1);` is present in the controller, the FormRequest and all six TeacherPortal services (only the three SchoolSetup models lack it — TPC-11). No commented-out code beyond explanatory prose; no `dd()`/`dump()`/`var_dump()`/`print_r()` (confirmed by `grep -nE 'dd\(|dump\(|var_dump\(|print_r\(|ray\(' Modules/TeacherPortal/app | head` → clean). One import per class (`grep -n '^use ' Modules/TeacherPortal/app/Http/Controllers/TeacherPortalController.php` → no duplicates).

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete × unique? | 5 race? | 6 auth hole? | 7 lying message? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `chat` (activityLog only) | ok | ok | ok | ok | ok | ok | ok | ok |
| `notification` (writes `read_at`) | ok | ok | ok | ok | ok | ok | ok | ok |
| `markNotificationsRead` (writes `read_at`) | ok | ok | ok | ok | ok | ok | ok | ok |
| `applyLeave` → `TeacherLeaveService::apply()` | ok | ok | **TPC-02** | ok | **TPC-02** | ok | ok | **TPC-02** |
| `storeAttendance` → `TeacherAttendanceService::save()` | ok | ok | ok | ok (revives trashed by design) | ok | ok | ok | ok |
| `reviewStudentLeave` → `TeacherStudentLeaveService::review()` | ok | ok | ok | ok | ok | ok | ok | ok |

Notes on the two cells that need prose:

- **`applyLeave` / `TeacherLeaveService::apply()` — Q1, Q5, Q8 (TPC-02).** Q1: the balance is not overwritten but is under-written, so the stored balance no longer reflects the applications that exist. Q5: there is no race inside `apply()` itself (single transaction), but the omitted increment is what makes a later cancellation (`StaffLeaveService::cancelApplication()`, which decrements `total_pending` for a `Submitted` application) drive the value negative. Q8: the balance columns the admin screen maintains are, for portal-filed leave, a feature nothing keeps correct.
- **`storeAttendance` / `TeacherAttendanceService::save()` — Q4.** The register intentionally revives a soft-deleted `std_student_attendance` row rather than colliding with `uq_std_att_student_date`, because that index does not include `deleted_at`; the service documents and handles the trap at `TeacherAttendanceService.php:133-140` and `:189`. No finding.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SchoolSetup/app/Http/Controllers/EmployeeLeaveApplicationController.php` | The admin store path increments `total_pending` for a paid, submitted application — the behaviour the portal's `apply()` is missing (TPC-02). It is the reference implementation, not itself wrong. | TXN-01 | SchoolSetup leave audit; cited here as the reference |
| `Modules/StudentProfile/Services/LeaveService.php` | `review()` opens its own transaction (nested as a savepoint inside `TeacherStudentLeaveService::review()`'s) and upserts `std_student_attendance` rows on approval. Working as designed; nothing to change. | TXN-01 | gaurav/StudentProfile/StdLeaveController report (linked) |
| `Modules/SchoolSetup/app/Models/Employee.php` | Missing relationship return types and `strict_types` (TPC-11). A shared model reached from many controllers. | MDL-04/STY-01 | a typed-relations sweep, not this report |

## 8. Not covered, and why

- **No test was run and no test was written** (D4). The findings are proved by reading source, `grep`, `sed` and static analysis; the two findings whose effect needs a live write (TPC-02, TPC-03) are marked "static only" and are unverified by execution.
- **The linked classes were not re-audited**: `TeacherContext`, `TeacherDashboardService`, `TeacherScheduleService`, `TeacherAttendanceService`, `TeacherStudentLeaveService`, `Teacher`, `Timetable` and `LeaveApplication` are owned by the MobileTeacherDashboardController, MobileTeacherAttendanceController and gaurav's StdLeaveController reports. This report checked only how `TeacherPortalController` calls them (arguments, guards, eager loads).
- **The API routes were probed by `method_exists()` and `route:list`, not by an HTTP request**, because a live call would need a Sanctum token and would only confirm the 500.
- **No browser render was performed.** Blade correctness is established by `Blade::compileString()` for all 21 views, not by loading the pages.
- **Live row counts were read from tenant `TEST_SCHOOL` only.** No other tenant exists in the local `prm_tenant` table.
