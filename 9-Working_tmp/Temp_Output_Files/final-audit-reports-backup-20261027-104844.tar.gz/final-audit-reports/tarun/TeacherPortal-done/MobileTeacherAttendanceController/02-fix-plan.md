# Fix Plan — TeacherPortal / MobileTeacherAttendanceController

**From:** `01-report.md` (2026-10-14) · **Developer folder:** tarun · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php` for developer `tarun`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `config/permissionslist.php` | shared permission registry; this plan adds no permission |
| `database/migrations/**` | no migration is proposed; existing migrations are never edited |
| `Modules/TeacherPortal/app/Services/TeacherContext.php` | owned by [tarun/TeacherPortal-done/MobileTeacherDashboardController](../MobileTeacherDashboardController/01-report.md) |
| `Modules/StudentProfile/app/Models/LeaveApplication.php`, `LeaveApplicationRemark.php`, `LeaveType.php`, `Student.php`, `LeaveApplicationDocument.php`, `StudentAttendance.php` | owned by gaurav's StudentProfile reports |
| `Modules/StudentProfile/app/Services/LeaveService.php` | owned by [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md) — the earlier registry claim wins (duplicate reconciled 2026-10-14). Touch it ONLY for MTA-03 or MTA-09, and only if that ⚠ SHARED item is ticked explicitly |
| `Modules/TeacherPortal/routes/mobile_api.php` | a route file — touch it ONLY for MTA-04 option (a), if that DECISION is ticked with choice (a) |

## 1. Blockers reachable today

None — no finding reaches B severity, and no page-killer or data leak was found.

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

- [ ] **MTA-01** · M · ERR-00 (D1) / ERR-05 · `MobileTeacherAttendanceController.php:130-140, 203-213` — remove the controller `try/catch` from `store()` and `review()` so the central handler renders, and drop the unused `Log` import.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php`
  - **Before** (`MobileTeacherAttendanceController.php:130-140`):
    ```php
        try {
            $result = $this->attendance->save($ctx, $csId, $date, $validated['status'], $validated['remarks'] ?? []);
        } catch (\Throwable $e) {
            Log::error('Mobile teacher attendance save failed', [
                'user_id'       => Auth::id(),
                'class_section' => $csId,
                'error'         => $e->getMessage(),
            ]);

            return response()->json(['status' => 'error', 'message' => 'Could not save attendance.'], 500);
        }
    ```
  - **After:** (`store()` — replace the block above with these two lines):
    ```php
        $result = $this->attendance->save($ctx, $csId, $date, $validated['status'], $validated['remarks'] ?? []);
    ```
  - **After:** (`review()` — replace the block below, currently at lines 203-213, with the single service call):
    ```php
        $this->studentLeave->review($ctx, $application, $validated);
    ```
  - **After:** (imports — delete the `Log` line):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Validation\Rule;
    use Modules\StudentProfile\Models\LeaveApplication;
    use Modules\TeacherPortal\Services\TeacherAttendanceService;
    use Modules\TeacherPortal\Services\TeacherContext;
    use Modules\TeacherPortal\Services\TeacherStudentLeaveService;
    ```
  - **Note:** after this item the API's failure body becomes the central handler's `application/json` 500 (`bootstrap/app.php:140-148`) instead of `{"status":"error","message":"Could not save attendance."}`. The mobile client must read `message` from either shape. The `resolveDate()` `try/catch` at line 256 is a read-path defensive parse and stays.
  - **Verify:** `grep -n "Log::error" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **MTA-03** · M · TXN-01 · `Modules/StudentProfile/app/Services/LeaveService.php:180-184` — wrap the two writes in `deleteLeaveType()` in one transaction. ⚠ SHARED — `LeaveService.php` is owned by [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md); tick explicitly.
  - **Touches:** `Modules/StudentProfile/app/Services/LeaveService.php`
  - **Before** (`LeaveService.php:180-184`):
    ```php
        public function deleteLeaveType(LeaveType $leaveType): void
        {
            $leaveType->update(['is_active' => false]);
            $leaveType->delete();
        }
    ```
  - **After:**
    ```php
        public function deleteLeaveType(LeaveType $leaveType): void
        {
            DB::transaction(function () use ($leaveType) {
                $leaveType->update(['is_active' => false]);
                $leaveType->delete();
            });
        }
    ```
  - **Verify:** `grep -n "DB::transaction" Modules/StudentProfile/app/Services/LeaveService.php | head -1`
  - **Expect:** the first hit is inside `deleteLeaveType` (near line 182). `DB` is already imported at line 11.
  - **Effort:** S

## 4. Authorization (F3)

- [ ] **MTA-04** · M · DECISION · AUTH-01 / AUTH-02 — no gate before the record is loaded on any of the five mobile routes.
  - **Why it is a decision:** option (a) edits a route file and re-scopes access; option (c) needs a new permission grant (migration/seeder). Both are outside a code-only fix.
  - (a) ⭐ Add `->middleware('role:Teacher')` to the `teacher/attendance` group in `Modules/TeacherPortal/routes/mobile_api.php` (a ⚠ SHARED route file), matching the web stack. This stops non-teachers at the middleware and closes the 404-vs-403 probe on `review`. Keeps the inline `canMark()`/`canReview()` checks.
  - (b) Leave the routes as `auth:sanctum` only. The inline `managedSections()` ownership check already denies every non-class-teacher with a 403; record the design as accepted and no route change.
  - (c) Add a permission gate (`student-profile.student-attendance` / `student-profile.student-leave.review`) — but the `Teacher` role holds zero permissions today, so this also needs a grant migration and a seeding step (`/system-config/sync-permissions`), which migrations cannot do reliably.
  - ➜ Choice: ____

## 5. Validation, routes, models (F4/F5/F7)

- [ ] **MTA-05** · M · VAL-02 · `MobileTeacherAttendanceController.php:107-114, 185-201` — move both inline validation blocks into Form Requests.
  - **Touches:** `Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php`, `Modules/TeacherPortal/app/Http/Requests/MobileAttendanceStoreRequest.php` (new file), `Modules/TeacherPortal/app/Http/Requests/MobileLeaveReviewRequest.php` (new file)
  - **Before** (`MobileTeacherAttendanceController.php:107-114`, `store()`):
    ```php
            $validated = $request->validate([
                'class_section' => ['required', 'integer'],
                'date'          => ['required', 'date'],
                'status'        => ['required', 'array'],
                'status.*'      => ['required', 'string', Rule::in(TeacherAttendanceService::STATUSES)],
                'remarks'       => ['nullable', 'array'],
                'remarks.*'     => ['nullable', 'string', 'max:255'],
            ]);
    ```
  - **After:** (new file `Modules/TeacherPortal/app/Http/Requests/MobileAttendanceStoreRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TeacherPortal\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\TeacherPortal\Services\TeacherAttendanceService;

    class MobileAttendanceStoreRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        /** @return array<string, mixed> */
        public function rules(): array
        {
            return [
                'class_section' => ['required', 'integer'],
                'date'          => ['required', 'date'],
                'status'        => ['required', 'array'],
                'status.*'      => ['required', 'string', Rule::in(TeacherAttendanceService::STATUSES)],
                'remarks'       => ['nullable', 'array'],
                'remarks.*'     => ['nullable', 'string', 'max:255'],
            ];
        }
    }
    ```
  - **After:** (new file `Modules/TeacherPortal/app/Http/Requests/MobileLeaveReviewRequest.php`):
    ```php
    <?php

    declare(strict_types=1);

    namespace Modules\TeacherPortal\Http\Requests;

    use Illuminate\Foundation\Http\FormRequest;
    use Illuminate\Validation\Rule;
    use Modules\StudentProfile\Models\LeaveApplication;
    use Modules\TeacherPortal\Services\TeacherStudentLeaveService;

    class MobileLeaveReviewRequest extends FormRequest
    {
        public function authorize(): bool
        {
            return true;
        }

        /** @return array<string, mixed> */
        public function rules(): array
        {
            $application = $this->route('application');

            return [
                'status'         => ['required', 'string', Rule::in(TeacherStudentLeaveService::REVIEW_STATUSES)],
                'review_remarks' => [
                    Rule::requiredIf(fn () => in_array(
                        $this->input('status'),
                        array_keys(TeacherStudentLeaveService::REQUEST_REMARK_TYPE),
                        true,
                    )),
                    'nullable', 'string', 'max:1000',
                ],
                'approved_days'  => [
                    'nullable', 'integer', 'min:0',
                    'max:' . (int) ($application instanceof LeaveApplication ? $application->total_days : 0),
                ],
            ];
        }

        /** @return array<string, string> */
        public function messages(): array
        {
            return [
                'review_remarks.required' => 'Say what you need from the student — they can only reply to a question that was actually asked.',
            ];
        }
    }
    ```
  - **After:** (controller imports — add the two request imports and drop `Rule`; this is written assuming MTA-01 already removed the `Log` import; `Request` stays, it is still used by `register()` and `leaves()`):
    ```php
    use Illuminate\Http\JsonResponse;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Modules\StudentProfile\Models\LeaveApplication;
    use Modules\TeacherPortal\Http\Requests\MobileAttendanceStoreRequest;
    use Modules\TeacherPortal\Http\Requests\MobileLeaveReviewRequest;
    use Modules\TeacherPortal\Services\TeacherAttendanceService;
    use Modules\TeacherPortal\Services\TeacherContext;
    use Modules\TeacherPortal\Services\TeacherStudentLeaveService;
    ```
  - **After:** (controller `store()` — full replacement, shown on top of MTA-01's result):
    ```php
        public function store(MobileAttendanceStoreRequest $request): JsonResponse
        {
            [$ctx, $sections, $error] = $this->context();
            if ($error) {
                return $error;
            }

            $validated = $request->validated();

            $csId = (int) $validated['class_section'];
            $date = Carbon::parse($validated['date'])->startOfDay();

            if (! $this->attendance->canMark($ctx, $csId)) {
                return response()->json(['status' => 'error', 'message' => 'Not your class.'], 403);
            }

            if (! $this->attendance->isEditable($date)) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Attendance can only be changed on the day it is taken.',
                ], 422);
            }

            $result = $this->attendance->save($ctx, $csId, $date, $validated['status'], $validated['remarks'] ?? []);

            return response()->json([
                'status'  => 'ok',
                'saved'   => $result['saved'],
                'skipped' => $result['skipped'],
            ]);
        }
    ```
  - **After:** (controller `review()` — full replacement, shown on top of MTA-01's result):
    ```php
        public function review(MobileLeaveReviewRequest $request, LeaveApplication $application): JsonResponse
        {
            $ctx = TeacherContext::for(Auth::user());

            if (! $this->studentLeave->canReview($ctx, (int) $application->class_section_id)) {
                return response()->json(['status' => 'error', 'message' => 'Not your class.'], 403);
            }

            $validated = $request->validated();

            $this->studentLeave->review($ctx, $application, $validated);

            return response()->json([
                'status'      => 'ok',
                'application' => $this->application($application->fresh()),
            ]);
        }
    ```
  - **Verify:** `grep -n "request->validate" Modules/TeacherPortal/app/Http/Controllers/Mobile/MobileTeacherAttendanceController.php`
  - **Expect:** no output.
  - **Effort:** M

- [ ] **MTA-09** · H · VAL-04 / QRY-07 · `Modules/StudentProfile/app/Services/LeaveService.php:605-619` — approval marks attendance with keys that do not mirror the unique index. ⚠ SHARED — `LeaveService.php` is owned by [gaurav/StudentProfile/StdLeaveController](../../../gaurav/StudentProfile/StdLeaveController/01-report.md); tick explicitly.
  - **Touches:** `Modules/StudentProfile/app/Services/LeaveService.php`
  - **Before** (`LeaveService.php:605-619`):
    ```php
            foreach ($period as $day) {
                \Modules\StudentProfile\Models\StudentAttendance::updateOrCreate(
                    [
                        'student_id'          => $application->student_id,
                        'attendance_date'     => $day->format('Y-m-d'),
                        'academic_session_id' => $application->academic_session_id,
                    ],
                    [
                        'class_section_id' => $application->class_section_id,
                        'status'           => 'Leave',
                        'remarks'          => "Leave approved — Application #{$application->id}",
                        'marked_by'        => auth()->id(),
                    ]
                );
            }
    ```
  - **After:**
    ```php
            $rows = [];
            $now = now();

            foreach ($period as $day) {
                $rows[] = [
                    'student_id'          => $application->student_id,
                    'attendance_date'     => $day->format('Y-m-d'),
                    'attendance_period'   => 0,
                    'academic_session_id' => $application->academic_session_id,
                    'class_section_id'    => $application->class_section_id,
                    'status'              => 'Leave',
                    'remarks'             => "Leave approved — Application #{$application->id}",
                    'marked_by'           => auth()->id(),
                    'marked_at'           => $now,
                    'created_at'          => $now,
                    'updated_at'          => $now,
                    'deleted_at'          => null,
                ];
            }

            if ($rows !== []) {
                DB::table('std_student_attendance')->upsert(
                    $rows,
                    ['student_id', 'attendance_date', 'attendance_period'],
                    ['academic_session_id', 'class_section_id', 'status', 'remarks', 'marked_by', 'marked_at', 'updated_at', 'deleted_at'],
                );
            }
    ```
  - **Why the keys change:** the table's real unique index is `uq_std_att_student_date (student_id, attendance_date, attendance_period)` (`database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php:32`), and `attendance_period` defaults to `0`. Matching on `academic_session_id` instead let a same-day row with a different session collide (SQLSTATE 23000, rolling back the whole review) and let a trashed row be updated without being revived.
  - **Verify:** `grep -n "updateOrCreate\|attendance_period" Modules/StudentProfile/app/Services/LeaveService.php | sed -n '1,6p'`
  - **Expect:** no `updateOrCreate` in `markAttendanceOnApproval`; the only `attendance_period` hit is the new `0` in the rows array.
  - **Effort:** S

## 6. Queries & performance (F9)

- [ ] **MTA-07** · M · SVC-05 / QRY-12 · `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php:58-80` — memoise `managedSections()` so `context()` and `canMark()` resolve it once per request.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php`
  - **Before** (`TeacherAttendanceService.php:58-80`):
    ```php
        public function managedSections(TeacherContext $ctx): Collection
        {
            $uid = $ctx->user->id;

            return collect(DB::table('sch_class_section_jnt as cs')
                ->leftJoin('sch_classes as c', 'c.id', '=', 'cs.class_id')
                ->leftJoin('sch_sections as s', 's.id', '=', 'cs.section_id')
                ->where('cs.is_active', true)      // ⚠ no deleted_at on this table
                ->where(fn ($q) => $q->where('cs.class_teacher_id', $uid)
                    ->orWhere('cs.assistance_class_teacher_id', $uid))
                ->orderBy('cs.class_id')->orderBy('cs.section_id')
                ->get([
                    'cs.id', 'cs.class_id', 'cs.section_id',
                    'cs.class_teacher_id', 'cs.assistance_class_teacher_id',
                    'c.name as class_name', 's.name as section_name',
                ]))
                ->map(function ($r) use ($uid) {
                    $r->label = trim(($r->class_name ?? '?').' '.($r->section_name ?? ''));
                    $r->is_primary = (int) $r->class_teacher_id === (int) $uid;

                    return $r;
                });
        }
    ```
  - **After:**
    ```php
        /** @var array<int, Collection> */
        private array $managedSectionsCache = [];

        public function managedSections(TeacherContext $ctx): Collection
        {
            $uid = $ctx->user->id;

            return $this->managedSectionsCache[$uid] ??= collect(DB::table('sch_class_section_jnt as cs')
                ->leftJoin('sch_classes as c', 'c.id', '=', 'cs.class_id')
                ->leftJoin('sch_sections as s', 's.id', '=', 'cs.section_id')
                ->where('cs.is_active', true)      // ⚠ no deleted_at on this table
                ->where(fn ($q) => $q->where('cs.class_teacher_id', $uid)
                    ->orWhere('cs.assistance_class_teacher_id', $uid))
                ->orderBy('cs.class_id')->orderBy('cs.section_id')
                ->get([
                    'cs.id', 'cs.class_id', 'cs.section_id',
                    'cs.class_teacher_id', 'cs.assistance_class_teacher_id',
                    'c.name as class_name', 's.name as section_name',
                ]))
                ->map(function ($r) use ($uid) {
                    $r->label = trim(($r->class_name ?? '?').' '.($r->section_name ?? ''));
                    $r->is_primary = (int) $r->class_teacher_id === (int) $uid;

                    return $r;
                });
        }
    ```
  - **Note:** the memo is keyed by user id, so it stays correct if one process ever serves two users. The service provider's sidebar composer also calls `managedSections()`; it runs against a fresh request, so it is unaffected.
  - **Verify:** `grep -n "managedSectionsCache" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php`
  - **Expect:** three hits (declaration, `??=`, none else).
  - **Effort:** S

- [ ] **MTA-08** · H · QRY-01 / TXN-06 · `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php:171-211` — replace the per-student select-then-insert with one `upsert()`.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php`
  - **Before** (`TeacherAttendanceService.php:171-211`):
    ```php
            DB::transaction(function () use ($marks, $remarks, $enrolled, $classSectionId, $date, $ctx, $now, &$saved, &$skipped) {
                foreach ($marks as $studentId => $status) {
                    $studentId = (int) $studentId;

                    if (! $enrolled->has($studentId) || ! in_array($status, self::STATUSES, true)) {
                        $skipped++;

                        continue;
                    }

                    $payload = [
                        'academic_session_id' => $ctx->academicSessionId,
                        'class_section_id' => $classSectionId,
                        'status' => $status,
                        'remarks' => $remarks[$studentId] ?? null,
                        'marked_by' => $ctx->user->id,
                        'marked_at' => $now,
                        'updated_at' => $now,
                        'deleted_at' => null,          // revives a trashed row rather than colliding
                    ];

                    $existing = DB::table('std_student_attendance')
                        ->where('student_id', $studentId)
                        ->where('attendance_date', $date->toDateString())
                        ->where('attendance_period', self::DAILY_PERIOD)
                        ->first(['id']);

                    if ($existing) {
                        DB::table('std_student_attendance')->where('id', $existing->id)->update($payload);
                    } else {
                        DB::table('std_student_attendance')->insert($payload + [
                            'student_id' => $studentId,
                            'attendance_date' => $date->toDateString(),
                            'attendance_period' => self::DAILY_PERIOD,
                            'created_at' => $now,
                        ]);
                    }

                    $saved++;
                }
            });
    ```
  - **After:**
    ```php
            $rows = [];

            DB::transaction(function () use ($marks, $remarks, $enrolled, $classSectionId, $date, $ctx, $now, &$rows, &$skipped) {
                foreach ($marks as $studentId => $status) {
                    $studentId = (int) $studentId;

                    if (! $enrolled->has($studentId) || ! in_array($status, self::STATUSES, true)) {
                        $skipped++;

                        continue;
                    }

                    $rows[] = [
                        'student_id' => $studentId,
                        'attendance_date' => $date->toDateString(),
                        'attendance_period' => self::DAILY_PERIOD,
                        'academic_session_id' => $ctx->academicSessionId,
                        'class_section_id' => $classSectionId,
                        'status' => $status,
                        'remarks' => $remarks[$studentId] ?? null,
                        'marked_by' => $ctx->user->id,
                        'marked_at' => $now,
                        'created_at' => $now,
                        'updated_at' => $now,
                        'deleted_at' => null,
                    ];
                }

                if ($rows !== []) {
                    DB::table('std_student_attendance')->upsert(
                        $rows,
                        ['student_id', 'attendance_date', 'attendance_period'],
                        ['academic_session_id', 'class_section_id', 'status', 'remarks', 'marked_by', 'marked_at', 'updated_at', 'deleted_at'],
                    );
                }
            });

            $saved = count($rows);
    ```
  - **Also change** the two lines just above the closure (currently lines 167-168): delete `$saved = 0;` and keep `$skipped = 0;`, because `$saved` is now `count($rows)` after the transaction.
    ```php
            $skipped = 0;
            $now = now();
    ```
  - **Note:** the unique index `uq_std_att_student_date (student_id, attendance_date, attendance_period)` exists (`database/migrations/tenant/2026_06_15_151309_create_std_student_attendance_table.php:32`), so `upsert()` updates the existing row and revives a trashed one (`deleted_at => null` in the update list). `attendance_period` is `0` (the service's `DAILY_PERIOD`).
  - **Verify:** `grep -n "DB::table('std_student_attendance')" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php`
  - **Expect:** one hit, the `upsert()`.
  - **Effort:** M

## 7. Views (F10)

None — the controller renders no Blade.

## 8. Style (F12) — one item per file

- [ ] **MTA-10** · L · STY-04 · `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php` — remove the `⛔`/`⚠` marker characters from the 11 comment lines (17, 26, 39, 50, 55, 65, 90, 133, 142, 146, 217), keeping the words.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherAttendanceService.php`
  - **Before** (`TeacherAttendanceService.php:17`):
    ```php
     * ⛔ THREE RULES, ENFORCED HERE RATHER THAN IN THE CONTROLLER OR THE VIEW:
    ```
  - **After:**
    ```php
     * THREE RULES, ENFORCED HERE RATHER THAN IN THE CONTROLLER OR THE VIEW:
    ```
  - **Apply the same edit to** lines 26, 39, 50, 55, 65, 90, 133, 142, 146, 217 (drop the leading `⛔ ` or `⚠ `, keep the sentence).
  - **Verify:** `grep -cP "[\x{26D4}\x{26A0}]" Modules/TeacherPortal/app/Services/TeacherAttendanceService.php`
  - **Expect:** `0`.
  - **Effort:** S

- [ ] **MTA-11** · L · STY-04 · `Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php` — remove the `⛔`/`⚠` marker characters from the 14 comment lines (16, 20, 26, 41, 46, 61, 74, 117, 127, 131, 135, 143, 190, 196), keeping the words.
  - **Touches:** `Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php`
  - **Before** (`TeacherStudentLeaveService.php:16`):
    ```php
     * ⛔ THIS IS THE PORTAL'S SECOND WRITE PATH. Until 2026-09-11 the attendance register was
    ```
  - **After:**
    ```php
     * THIS IS THE PORTAL'S SECOND WRITE PATH. Until 2026-09-11 the attendance register was
    ```
  - **Apply the same edit to** lines 20, 26, 41, 46, 61, 74, 117, 127, 131, 135, 143, 190, 196 (drop the leading `⛔ ` or `⚠ `, keep the sentence).
  - **Verify:** `grep -cP "[\x{26D4}\x{26A0}]" Modules/TeacherPortal/app/Services/TeacherStudentLeaveService.php`
  - **Expect:** `0`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **MTA-02** · M · DECISION · TXN-04 — the register save writes no `activityLog` row.
  - **Why it is a decision:** it is an audit-policy choice that also applies to the web register path (`TeacherPortalController::storeAttendance`, which is equally unlogged); adding it is a behaviour change, not a bug fix.
  - (a) ⭐ Leave as is: attendance is a high-volume write, the web path is also unlogged, and the leave-review path already provides the audited trail; add one comment above the transaction recording this as accepted.
  - (b) Add one `activityLog(...)` per register save inside the transaction after the write (event 'Marked'), accepting one audit row per save.
  - (c) Add audit rows per student — rejected: it multiplies the log by the class size.
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| MTA-06 | CTL-05, L. The 4-line `context()` guard is repeated in four methods, but each is an explicit early-return; extracting it would hide that flow for no gain while the block is this small. Recorded, not planned. |
| MTA-12 | CTL-10, L. `sections()` still returns `primary_statuses`, which `TeacherAttendanceService` documents as unused since 2026-09-11. Removing the constant is a product call (a mobile caller may want the split later), not a bug fix. Recorded, not planned. |
