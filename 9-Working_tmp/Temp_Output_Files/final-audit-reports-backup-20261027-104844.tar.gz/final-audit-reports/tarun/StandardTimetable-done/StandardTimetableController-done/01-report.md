# Final Audit — StandardTimetable / StandardTimetableController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php` (4950 lines, 27 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `/standard-timetable` (dashboard), `/standard-timetable/manual-placement` (the drag-and-drop grid), `/standard-timetable/timetable/{id}` (view), `/standard-timetable/timetable/{id}/edit`, `/standard-timetable/timetable/trash/view`, `/standard-timetable/class-view/{timetableId}/{classGroupId}`, `/standard-timetable/teacher-view/{timetableId}/{teacherId}`, `/standard-timetable/room-view/{timetableId}/{roomId}` |
| Menu path | Timetable Mgmt. → Standard Timetable → Manual Placement |
| Who uses it | Super Admin and School Admin (both roles hold every one of the 16 `tenant.standard-timetable.timetable.*` permissions; measured below) |
| What a user does here | A timetabler builds a timetable by hand: pick a class-section, drag a subject card onto a day x period square, choose the teacher and the room for that period, lock squares that must not move, then publish the finished timetable or send it for approval. Separate read-only views show the grid by class, by teacher and by room. |
| Tables written | `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_conflict_detection` (hard-delete cascade only), `sys_activity_logs` (through the `activityLog()` helper) |
| Tables read | `tt_timetables`, `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_activities`, `tt_sub_activities`, `tt_activity_teachers`, `tt_class_timetable_types_jnt`, `tt_period_set_periods_jnt`, `tt_period_types`, `tt_period_configs`, `tt_timetable_types`, `sch_class_groups_jnt`, `sch_class_section_jnt`, `sch_class_requirement_subgroups` (via a model), `sch_rooms`, `sch_teachers`, `sch_teacher_profile`, `sch_classes`, `sch_sections`, `sch_subjects`, `sch_academic_term`, `sys_users` |
| Live data | The `test.localhost` domain currently resolves to tenant DB `xyz_school_00000000000040008000_202627`, which is EMPTY: 0 timetables, 0 cells, 0 activities. The populated sibling tenant DB `..._full89` holds 15 timetables, 447,142 cells, 33,666 cell-teacher rows and 597 activities. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. The single worst finding is `STT-01`: fifteen mutating endpoints return the raw exception text (SQL, table and column names) to the browser on any write failure, which is both a data-leak and a support problem. Two further blockers sit beside it — four API routes point at methods that do not exist (`STT-07`, guaranteed 500s) and every one of the nineteen catches is a try/catch the Laravel idiom (D1) forbids (`STT-02`), none of which logs the failure (`report()` appears zero times). The rest is serious maintainability debt: a 4,950-line, 27-method god class (`STT-09`), a manual `beginTransaction`/`commit` pattern in sixteen controller methods plus two service methods (`STT-03`), duplicated authorization (`STT-05`), an unconsulted policy (`STT-06`) and several queries inside loops (`STT-17`). Rough effort: **L** — the mechanical fixes (`STT-01`, `STT-02`, `STT-03`) are a few hours; the god-controller split is a separate, deferred piece of work (D3).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 4 | 10 | 8 | 6 | 24 |

(DECISION is a subset of B/H/M/L — 6 of the 24 findings become DECISION items; it is not added to the total.)

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | STT-01, STT-02 | F8 Services/Jobs | STT-16 |
| F2 Transactions/Audit | STT-03 | F9 Queries/Perf | STT-17, STT-18, STT-19 |
| F3 Authorization | STT-04, STT-05, STT-06 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | STT-20 |
| F5 Routes | STT-07, STT-08 | F12 Style | STT-21, STT-22, STT-23 |
| F6 Controller shape | STT-09, STT-10, STT-11, STT-12, STT-13, STT-14, STT-15 | F13 Deep read | STT-24 |
| F7 Models | all linked | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php` | controller | 4950 | this report | ✅ |
| 2 | `Modules/StandardTimetable/app/Services/ManualTimetableService.php` | service | 236 | this report | ✅ |
| 3 | `Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php` | policy | 51 | this report | ✅ |
| 4 | `Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php` | form request | 71 | this report | ✅ |
| 5 | `Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php` | form request | 67 | this report | ✅ |
| 6 | `Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php` | form request | 47 | this report | ✅ |
| 7 | `Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php` | form request | 93 | this report | ✅ |
| 8 | `Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php` | form request | 81 | this report | ✅ |
| 9 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | 342 | this report (claimed) | ✅ |
| 10 | `Modules/StandardTimetable/resources/views/index.blade.php` | blade | 198 | this report | ✅ |
| 11 | `Modules/StandardTimetable/resources/views/pages/manual-placement.blade.php` | blade | 2297 | this report | ✅ |
| 12 | `Modules/StandardTimetable/resources/views/pages/manual-placement-trash.blade.php` | blade | 92 | this report | ✅ |
| 13 | `Modules/StandardTimetable/resources/views/pages/partials/_insights-body.blade.php` | blade | 169 | this report | ✅ |
| 14 | `Modules/StandardTimetable/resources/views/views/class-view.blade.php` | blade | 145 | this report | ✅ |
| 15 | `Modules/StandardTimetable/resources/views/views/teacher-view.blade.php` | blade | 135 | this report | ✅ |
| 16 | `Modules/StandardTimetable/resources/views/views/room-view.blade.php` | blade | 139 | this report | ✅ |
| 17 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | - | ↗ [TimetableFoundation/TimetableController](../TimetableController/01-report.md) | ↗ linked |
| 18 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | - | ↗ [TimetableFoundation/TimetableController](../TimetableController/01-report.md) | ↗ linked |
| 19 | `Modules/TimetableFoundation/app/Models/TimetableCellTeacher.php` | model | - | ↗ [TimetableFoundation/TimetableController](../TimetableController/01-report.md) | ↗ linked |
| 20 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model | - | ↗ [TimetableFoundation/AcademicTermController](../AcademicTermController/01-report.md) | ↗ linked |
| 21 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | - | ↗ [TimetableFoundation/ActivityController](../ActivityController-done/01-report.md) | ↗ linked |
| 22 | `Modules/TimetableFoundation/app/Models/ActivityTeacher.php` | model | - | ↗ [TimetableFoundation/ActivityController](../ActivityController-done/01-report.md) | ↗ linked |
| 23 | `Modules/TimetableFoundation/app/Models/SubActivity.php` | model | - | ↗ [TimetableFoundation/ActivityController](../ActivityController-done/01-report.md) | ↗ linked |
| 24 | `Modules/TimetableFoundation/app/Models/ClassTimetableType.php` | model | - | ↗ [TimetableFoundation/ClassTimetableTypeController](../ClassTimetableTypeController-done/01-report.md) | ↗ linked |
| 25 | `Modules/TimetableFoundation/app/Models/PeriodSet.php` | model | - | ↗ [TimetableFoundation/PeriodSetController](../PeriodSetController-done/01-report.md) | ↗ linked |
| 26 | `Modules/TimetableFoundation/app/Models/SchoolDay.php` | model | - | ↗ [TimetableFoundation/SchoolDayController](../SchoolDayController-done/01-report.md) | ↗ linked |
| 27 | `Modules/TimetableFoundation/app/Models/TimetableType.php` | model | - | ↗ [TimetableFoundation/TimetableTypeController](../TimetableTypeController-done/01-report.md) | ↗ linked |
| 28 | `Modules/SchoolSetup/app/Models/ClassSection.php` | common model | - | common (other module) | ↗ common |
| 29 | `Modules/SchoolSetup/app/Models/Room.php` | common model | - | common (other module) | ↗ common |
| 30 | `Modules/SchoolSetup/app/Models/Teacher.php` | common model | - | common (other module) | ↗ common |
| 31 | `Modules/SchoolSetup/app/Models/TeacherProfile.php` | common model | - | common (other module) | ↗ common |

No pre-applied files (the module's `PRE-APPLIED-2026-10-10.md` is the TimetableFoundation one, not this module).

## 4. Routes

```
GET|HEAD  standard-timetable                                        standard-timetable.index             StandardTimetableController@index
POST      standard-timetable/approve/{id}                            standard-timetable.approve           StandardTimetableController@approve
POST      standard-timetable/assign-room                             standard-timetable.assignRoom        StandardTimetableController@assignRoom
POST      standard-timetable/assign-teacher                          standard-timetable.assignTeacher     StandardTimetableController@assignTeacher
GET|HEAD  standard-timetable/class-view/{timetableId}/{classGroupId} standard-timetable.classView         StandardTimetableController@classView
POST      standard-timetable/copy-timetable/{id}                     standard-timetable.copyTimetable     StandardTimetableController@copyTimetable
POST      standard-timetable/create-timetable                        standard-timetable.createTimetable   StandardTimetableController@createTimetable
DELETE    standard-timetable/delete-timetable/{id}                   standard-timetable.deleteTimetable   StandardTimetableController@deleteTimetable
POST      standard-timetable/lock-all/{timetableId}                  standard-timetable.lockAll           StandardTimetableController@lockAll
POST      standard-timetable/lock-cell/{cellId}                      standard-timetable.lockCell          StandardTimetableController@lockCell
GET|HEAD  standard-timetable/manual-placement                        standard-timetable.menu.manualPlacement StandardTimetableController@manualPlacement
POST      standard-timetable/move-cell                               standard-timetable.moveCell          StandardTimetableController@moveCell
POST      standard-timetable/place-cell                              standard-timetable.placeCell         StandardTimetableController@placeCell
POST      standard-timetable/publish/{id}                            standard-timetable.publish           StandardTimetableController@publish
POST      standard-timetable/remove-cell                             standard-timetable.removeCell        StandardTimetableController@removeCell
GET|HEAD  standard-timetable/room-view/{timetableId}/{roomId}        standard-timetable.roomView          StandardTimetableController@roomView
POST      standard-timetable/submit-for-approval/{id}                standard-timetable.submitForApproval StandardTimetableController@submitForApproval
GET|HEAD  standard-timetable/teacher-view/{timetableId}/{teacherId}  standard-timetable.teacherView       StandardTimetableController@teacherView
GET|HEAD  standard-timetable/timetable/trash/view                    standard-timetable.timetable.trashed StandardTimetableController@trashedTimetables
GET|HEAD  standard-timetable/timetable/{id}                          standard-timetable.timetable.show    StandardTimetableController@showTimetable
DELETE    standard-timetable/timetable/{id}                          standard-timetable.timetable.destroy StandardTimetableController@destroyTimetable
GET|HEAD  standard-timetable/timetable/{id}/edit                     standard-timetable.timetable.edit    StandardTimetableController@editTimetable
DELETE    standard-timetable/timetable/{id}/force-delete             standard-timetable.timetable.forceDelete StandardTimetableController@forceDeleteTimetable
GET|HEAD  standard-timetable/timetable/{id}/restore                  standard-timetable.timetable.restore StandardTimetableController@restoreTimetable
POST      standard-timetable/unlock-all/{timetableId}                standard-timetable.unlockAll         StandardTimetableController@unlockAll
POST      standard-timetable/unlock-cell/{cellId}                    standard-timetable.unlockCell        StandardTimetableController@unlockCell
POST      standard-timetable/unpublish/{id}                          standard-timetable.unpublish         StandardTimetableController@unpublish
GET|HEAD  api/v1/standardtimetables                                  api.standardtimetable.index          StandardTimetableController@index
POST      api/v1/standardtimetables                                  api.standardtimetable.store          StandardTimetableController@store
GET|HEAD  api/v1/standardtimetables/{standardtimetable}              api.standardtimetable.show           StandardTimetableController@show
PUT|PATCH api/v1/standardtimetables/{standardtimetable}              api.standardtimetable.update         StandardTimetableController@update
DELETE    api/v1/standardtimetables/{standardtimetable}              api.standardtimetable.destroy        StandardTimetableController@destroy
```

Unrouted public methods: none — all 27 public methods are routed. However four routes (`api.standardtimetable.store`, `.show`, `.update`, `.destroy`) point at methods that do not exist (STT-07).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 42 | GET standard-timetable | `tenant.standard-timetable.timetable.viewAny` | none (read) | none | reads only | STT-12 |
| `manualPlacement` | 96 | GET standard-timetable/manual-placement | `tenant.standard-timetable.timetable.manualPlace` | none (read) | none | reads only | STT-10, STT-17 |
| `placeCell` | 1982 | POST standard-timetable/place-cell | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 2132 | `Placed` | tt_timetable_cells, tt_timetable_cell_teachers, sys_activity_logs | STT-01, STT-02, STT-03, STT-05, STT-17 |
| `removeCell` | 2359 | POST standard-timetable/remove-cell | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 2437 | `Removed` | tt_timetable_cells, tt_timetable_cell_teachers, sys_activity_logs | STT-02, STT-03, STT-05, STT-17 |
| `moveCell` | 2551 | POST standard-timetable/move-cell | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 2607 | `Moved` | tt_timetable_cells, sys_activity_logs | STT-01, STT-02, STT-03, STT-05 |
| `createTimetable` | 2774 | POST standard-timetable/create-timetable | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 2805 | `Created` | tt_timetables, sys_activity_logs | STT-01, STT-02, STT-03, STT-05 |
| `deleteTimetable` | 2846 | DELETE standard-timetable/delete-timetable/{id} | `tenant.standard-timetable.timetable.delete` | controller `DB::beginTransaction` 2856 | `Deleted` | tt_timetables, tt_timetable_cells, tt_timetable_cell_teachers, tt_conflict_detection, sys_activity_logs | STT-01, STT-02, STT-03 |
| `showTimetable` | 2898 | GET standard-timetable/timetable/{id} | delegates to `classView` (`viewClass`) | none (read) | none | reads only | STT-04 |
| `editTimetable` | 2931 | GET standard-timetable/timetable/{id}/edit | delegates to `manualPlacement` (`manualPlace`) | none (read) | none | reads only | STT-04 |
| `destroyTimetable` | 2954 | DELETE standard-timetable/timetable/{id} | `tenant.standard-timetable.timetable.delete` | controller `DB::transaction` 2965 | `Trashed` | tt_timetables, sys_activity_logs | STT-02 |
| `trashedTimetables` | 2987 | GET standard-timetable/timetable/trash/view | `tenant.standard-timetable.timetable.restore` | none (read) | none | reads only | STT-19 |
| `restoreTimetable` | 3011 | GET standard-timetable/timetable/{id}/restore | `tenant.standard-timetable.timetable.restore` | controller `DB::transaction` 3020 | `Restored` | tt_timetables, sys_activity_logs | STT-02, STT-08 |
| `forceDeleteTimetable` | 3047 | DELETE standard-timetable/timetable/{id}/force-delete | `tenant.standard-timetable.timetable.forceDelete` | controller `DB::transaction` 3058 | `Deleted` | tt_timetables, tt_timetable_cells, tt_timetable_cell_teachers, tt_conflict_detection, sys_activity_logs | STT-02 |
| `assignTeacher` | 3177 | POST standard-timetable/assign-teacher | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 3230 | `TeacherAssigned` | tt_timetable_cells, tt_timetable_cell_teachers, sys_activity_logs | STT-01, STT-02, STT-03, STT-05 |
| `assignRoom` | 3423 | POST standard-timetable/assign-room | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 3496 | `RoomAssigned` | tt_timetable_cells, sys_activity_logs | STT-01, STT-02, STT-03, STT-05 |
| `copyTimetable` | 4395 | POST standard-timetable/copy-timetable/{id} | `tenant.standard-timetable.timetable.manualPlace` | controller `DB::beginTransaction` 4409 wrapping service `DB::transaction` 113 | `Copied` | tt_timetables, tt_timetable_cells, tt_timetable_cell_teachers, sys_activity_logs | STT-01, STT-02, STT-03, STT-17 |
| `lockCell` | 4428 | POST standard-timetable/lock-cell/{cellId} | `tenant.standard-timetable.timetable.lock` | controller `DB::beginTransaction` 4446 | `Locked` | tt_timetable_cells, sys_activity_logs | STT-01, STT-02, STT-03 |
| `unlockCell` | 4471 | POST standard-timetable/unlock-cell/{cellId} | `tenant.standard-timetable.timetable.lock` | controller `DB::beginTransaction` 4485 | `Unlocked` | tt_timetable_cells, sys_activity_logs | STT-01, STT-02, STT-03 |
| `lockAll` | 4510 | POST standard-timetable/lock-all/{timetableId} | `tenant.standard-timetable.timetable.lock` | controller `DB::beginTransaction` 4523 | `LockAll` | tt_timetable_cells, sys_activity_logs | STT-01, STT-02, STT-03 |
| `unlockAll` | 4558 | POST standard-timetable/unlock-all/{timetableId} | `tenant.standard-timetable.timetable.lock` | controller `DB::beginTransaction` 4568 | `UnlockAll` | tt_timetable_cells, sys_activity_logs | STT-01, STT-02, STT-03 |
| `submitForApproval` | 4598 | POST standard-timetable/submit-for-approval/{id} | `tenant.standard-timetable.timetable.submit` | controller `DB::beginTransaction` 4614 | `Submitted` | tt_timetables, sys_activity_logs | STT-01, STT-02, STT-03 |
| `approve` | 4633 | POST standard-timetable/approve/{id} | `tenant.standard-timetable.timetable.approve` | controller `DB::beginTransaction` 4649 | `Published` | tt_timetables, sys_activity_logs | STT-01, STT-02, STT-03, STT-24 |
| `publish` | 4691 | POST standard-timetable/publish/{id} | `tenant.standard-timetable.timetable.publish` | controller `DB::beginTransaction` 4704 | `Published` | tt_timetables, sys_activity_logs | STT-01, STT-02, STT-03, STT-24 |
| `unpublish` | 4757 | POST standard-timetable/unpublish/{id} | `tenant.standard-timetable.timetable.unpublish` | controller `DB::beginTransaction` 4770 | `Unpublished` | tt_timetables, sys_activity_logs | STT-01, STT-02, STT-03 |
| `classView` | 4792 | GET standard-timetable/class-view/{timetableId}/{classGroupId} | `tenant.standard-timetable.timetable.viewClass` | none (read) | none | reads only | STT-12 |
| `teacherView` | 4861 | GET standard-timetable/teacher-view/{timetableId}/{teacherId} | `tenant.standard-timetable.timetable.viewTeacher` | none (read) | none | reads only | STT-12 |
| `roomView` | 4911 | GET standard-timetable/room-view/{timetableId}/{roomId} | `tenant.standard-timetable.timetable.viewRoom` | none (read) | none | reads only | STT-12 |

## 6. Findings

### F1 — Errors

#### STT-01 · B · ERR-01 — Fifteen write failures send the raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user. No `$e->getMessage()` in `withErrors`, `with('error')`, `response()->json`, or `back()`. SQL, table and column names leak.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2288-2292`, method `placeCell()`; the same shape at 2751 `moveCell`, 2838 `createTimetable`, 2883 `deleteTimetable`, 3264 `assignTeacher`, 3531 `assignRoom`, 4424 `copyTimetable`, 4465 `lockCell`, 4504 `unlockCell`, 4540 `lockAll`, 4587 `unlockAll`, 4627 `submitForApproval`, 4685 `approve`, 4740 `publish`, 4788 `unpublish`. |
| **Root cause** | Every mutating method has its own `catch` and each one concatenates `$e->getMessage()` into the JSON `message`. A `QueryException` message contains the full SQL statement, the table name and the column names. |
| **Consequence** | A user who hits any write error sees the database schema and SQL in a toast, and none of the fifteen catches calls `report()`, so the exception is never written to the log either. |
| **Reproduce** | Log in as School Admin, open `/standard-timetable/manual-placement`, and trigger a DB error on any write (for example stop the DB or violate a constraint). Expected a friendly message; actual the raw SQLSTATE text. Static proof is enough to confirm the code path. |
| **Fix approach** | Remove the controller `catch` (D1); let `DB::transaction()` roll back and the central handler render a friendly 500. If a page-specific message is ever wanted, use the D2 service shape. |
| **Plan item** | STT-01 in `02-fix-plan.md` §1 |

```php
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json(['success' => false, 'message' => 'Failed to place cell: '.$e->getMessage()], 500);
        }
```

**Evidence**
```
$ grep -n 'getMessage()' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
2291:            return response()->json(['success' => false, 'message' => 'Failed to place cell: '.$e->getMessage()], 500);
2751:            return response()->json(['success' => false, 'message' => 'Move failed: '.$e->getMessage()], 500);
2838:                'message' => 'Failed to create timetable: '.$e->getMessage(),
2883:            return response()->json(['success' => false, 'message' => 'Delete failed: '.$e->getMessage()], 500);
3264:            return response()->json(['success' => false, 'message' => 'Could not assign the teacher: '.$e->getMessage()], 500);
3531:            return response()->json(['success' => false, 'message' => 'Could not assign the room: '.$e->getMessage()], 500);
4424:            return response()->json(['success' => false, 'message' => 'Copy failed: '.$e->getMessage()], 500);
4465:            return response()->json(['success' => false, 'message' => 'Failed to lock cell: '.$e->getMessage()], 500);
4504:            return response()->json(['success' => false, 'message' => 'Failed to unlock cell: '.$e->getMessage()], 500);
4540:            return response()->json(['success' => false, 'message' => 'Failed to lock all cells: '.$e->getMessage()], 500);
4587:            return response()->json(['success' => false, 'message' => 'Failed to unlock all cells: '.$e->getMessage()], 500);
4627:            return response()->json(['success' => false, 'message' => 'Failed to submit timetable: '.$e->getMessage()], 500);
4685:            return response()->json(['success' => false, 'message' => 'Failed to approve timetable: '.$e->getMessage()], 500);
4740:            return response()->json(['success' => false, 'message' => 'Failed to publish timetable: '.$e->getMessage()], 500);
4788:            return response()->json(['success' => false, 'message' => 'Unpublish failed: '.$e->getMessage()], 500);
```

#### STT-02 · M · ERR-00 — Controller try/catch violates the Laravel idiom and logs nothing (D1)

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, lowered from the open-decision default — D1 settles it as the Laravel idiom; no crash, so not a blocker) — *no try/catch in controllers unless a D2 shape allows it*. The same code also breaks ERR-05 (M) — *log the exception, not the message*. |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2964-2977`, method `destroyTimetable()`; the same pattern at 19 catch blocks across the controller. |
| **Root cause** | Each mutating method wraps its transaction in `try { … } catch (\Throwable|\Exception $e) { … }`. Under D1 `DB::transaction()` already rolls back and rethrows, and `bootstrap/app.php` already renders a friendly error, so the catch is redundant. None of the 19 catches calls `report($e)`, so the failure is silently discarded. |
| **Consequence** | Every write failure is invisible in the logs and produces a generic (or leaked, see STT-01) response; support has no trace to debug from. |
| **Reproduce** | static only — the catch has no user-visible path beyond STT-01; the missing trace is visible in `storage/logs/laravel.log` after any failed write. |
| **Fix approach** | Delete the `try`/`catch`; run the work in a single `DB::transaction(fn () => …)` closure (this fix overlaps STT-03) so a failure rolls back, is reported by the framework and rendered by the central handler. |
| **Plan item** | STT-02 in `02-fix-plan.md` §3 |

```php
        try {
            DB::transaction(function () use ($timetable) {
                $timetable->is_active = false;
                $timetable->save();
                $timetable->delete();

                activityLog($timetable, 'Trashed', [
                    'message' => "Timetable '{$timetable->name}' was moved to trash.",
                    'performed_by' => auth()->user()?->name,
                ]);
            });
        } catch (\Throwable $e) {
            return back()->with('error', 'The operation could not be completed.');
        }
```

**Evidence**
```
$ grep -cE '^\s*\} catch \(' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
19
$ grep -rn 'report(' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php Modules/StandardTimetable/app/Services/ManualTimetableService.php | wc -l
0
```

### F2 — Transactions and audit

#### STT-03 · M · TXN-02 — Sixteen controller methods and two service methods use manual beginTransaction/commit

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`. Never `return` between `beginTransaction` and `commit`.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:4446-4461`, method `lockCell()`; the pattern repeats at 2132 `placeCell`, 2437 `removeCell`, 2607 `moveCell`, 2805 `createTimetable`, 2856 `deleteTimetable`, 3230 `assignTeacher`, 3496 `assignRoom`, 4409 `copyTimetable`, 4485 `unlockCell`, 4523 `lockAll`, 4568 `unlockAll`, 4614 `submitForApproval`, 4649 `approve`, 4704 `publish`, 4770 `unpublish`; and `Modules/StandardTimetable/app/Services/ManualTimetableService.php:22` and `:67`. |
| **Root cause** | The controller opens transactions by hand and manually rolls back inside `catch`. Several of these methods `return` a JSON response between `beginTransaction` and a later `commit` path when a guard fails — for example `placeCell` returns from inside the loop at 2199 after already having called `DB::rollBack()`. The closure form removes the possibility of leaving a transaction open. |
| **Consequence** | On any path where an early `return` slips past the matching `rollBack()`, the request leaves a transaction open on the connection; and the manual form is exactly the code the fix in STT-02 has to rewrite. |
| **Reproduce** | static only — verified by counting `DB::beginTransaction()` (16) against `DB::transaction(function …)` (3). |
| **Fix approach** | Convert each to one `DB::transaction(function () { … })` closure; build the response after the closure returns. This is the same edit as STT-02 in most methods, so the two items are applied together. |
| **Plan item** | STT-03 in `02-fix-plan.md` §3 |

```php
        DB::beginTransaction();
        try {
            $cell->update([
                'is_locked' => true,
                'locked_at' => now(),
                'locked_by' => auth()->id(),
            ]);

            activityLog($cell, 'Locked', [
                'message' => "Cell locked at day {$cell->day_of_week}, period {$cell->period_ord}.",
                'performed_by' => auth()->user()?->name,
            ]);

            DB::commit();
```

**Evidence**
```
$ grep -c 'DB::beginTransaction()' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
16
$ grep -c 'DB::transaction(function' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
3
$ grep -n 'DB::beginTransaction()' Modules/StandardTimetable/app/Services/ManualTimetableService.php
22:        DB::beginTransaction();
67:        DB::beginTransaction();
```

### F3 — Authorization

#### STT-04 · M · AUTH-02 — showTimetable/editTimetable load records before the delegated authorization runs

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H default, lowered to M — the delegated method still denies the action; what leaks is only whether an id exists) — *authorize first, before loading records and outside any try. Loading first leaks whether an id exists (404 vs 403).* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2931-2939`, method `editTimetable()`. Also `showTimetable()` at 2898-2911. |
| **Root cause** | `editTimetable()` runs `Timetable::…->findOrFail($id)` and `showTimetable()` runs a `ClassSection` query before either delegates to `manualPlacement()`/`classView()`, which is the only place the Gate runs. A caller without the permission therefore gets a 404 (id absent) or a 403 (id present) — an existence oracle. |
| **Consequence** | A user who holds no timetable permission can enumerate which MANUAL timetable ids exist by watching 404 vs 403. |
| **Reproduce** | As a user without `tenant.standard-timetable.timetable.manualPlace`, request `/standard-timetable/timetable/1/edit` (403) and `/standard-timetable/timetable/999999/edit` (404). |
| **Fix approach** | Authorize at the top of `showTimetable()`/`editTimetable()` with the same permission the delegated method uses, before the `findOrFail`. |
| **Plan item** | STT-04 in `02-fix-plan.md` §4 |

```php
        // Scoped to MANUAL and not withTrashed(): a generated or soft-deleted timetable
        // has no business opening in the manual editor, and 404 is the honest answer.
        Timetable::where('generation_method', 'MANUAL')->findOrFail($id);

        $request->merge(['timetable_id' => $id]);

        return $this->manualPlacement($request);
```

**Evidence**
```
$ grep -nE 'function (editTimetable|showTimetable|manualPlacement|classView)|Gate::authorize' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php | sed -n '1,6p'
96:    public function manualPlacement(Request $request): mixed
98:        Gate::authorize('tenant.standard-timetable.timetable.manualPlace');
2898:    public function showTimetable(int $id, Request $request): mixed
2931:    public function editTimetable(int $id, Request $request): mixed
4792:    public function classView(int $timetableId, int $classSectionId)
4794:        Gate::authorize('tenant.standard-timetable.timetable.viewClass');
```

#### STT-05 · L · AUTH-04 — Authorization is checked twice for six endpoints

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`). Keep one.* |
| **Where** | `Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php:9-12`. The same double check exists in `AssignRoomRequest`, `AssignTeacherRequest`, `CreateTimetableRequest`, `RemoveCellRequest`, each pairing its `authorize()` with a `Gate::authorize('tenant.standard-timetable.timetable.manualPlace')` in the controller. |
| **Root cause** | The FormRequest already denies the request by returning false from `authorize()`, then the controller checks the same string ability again. |
| **Consequence** | No user-visible harm; it is maintenance debt — two places to keep in step, and the second check can never add anything. |
| **Reproduce** | static only — read the five `authorize()` methods and the six controller gates. |
| **Fix approach** | Keep the controller `Gate::authorize()` (the page’s canonical gate) and drop the duplicate from each FormRequest `authorize()`, or the reverse — one per concern. |
| **Plan item** | STT-05 in `02-fix-plan.md` §4 |

```php
    public function authorize(): bool
    {
        return auth()->user()->can('tenant.standard-timetable.timetable.manualPlace');
    }
```

**Evidence**
```
$ grep -n 'manualPlace' Modules/StandardTimetable/app/Http/Requests/*.php
Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php:11:        return auth()->user()->can('tenant.standard-timetable.timetable.manualPlace');
Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php:11:        return auth()->user()->can('tenant.standard-timetable.timetable.manualPlace');
Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php:12:        return auth()->user()->can('tenant.standard-timetable.timetable.manualPlace');
Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php:11:        return auth()->user()->can('tenant.standard-timetable.timetable.manualPlace');
Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php:11:        return auth()->user()->can('tenant.standard-timetable.timetable.manualPlace');
```

#### STT-06 · M · AUTH-06 — The registered StandardTimetablePolicy is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place; report every Policy that nothing consults.* |
| **Where** | `Modules/StandardTimetable/app/Providers/StandardTimetableServiceProvider.php:38-41`, class `StandardTimetablePolicy`. |
| **Root cause** | `registerPolicies()` maps `Timetable::class` to `StandardTimetablePolicy`, but every check in this controller is a string ability (`Gate::authorize('tenant.standard-timetable.timetable.…')`), never a model-ability call such as `$this->authorize('manualPlace', $timetable)`. No call site for the policy exists in the StandardTimetable, TimetableFoundation or SmartTimetable modules. |
| **Consequence** | The policy’s eight methods are dead code; a developer reading it believes permissions are enforced through it when they are not. |
| **Reproduce** | static only — search the modules for a model-ability call on `Timetable`; there is none. |
| **Fix approach** | Decide: keep the policy and wire model-ability checks, or delete the policy and its registration (a behaviour-neutral cleanup). This is a product/architecture choice, so it is a DECISION item. |
| **Plan item** | STT-06 in `02-fix-plan.md` §9 (DECISION) |

```php
        \Illuminate\Support\Facades\Gate::policy(
            \Modules\TimetableFoundation\Models\Timetable::class,
            \Modules\StandardTimetable\Policies\StandardTimetablePolicy::class
        );
```

**Evidence**
```
$ grep -rn 'StandardTimetablePolicy' Modules/ app/
Modules/StandardTimetable/tests/Feature/AuthorizationTest.php:10:test('StandardTimetablePolicy is instantiable', function () {
Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php:8:class StandardTimetablePolicy
Modules/StandardTimetable/app/Providers/StandardTimetableServiceProvider.php:40:            \Modules\StandardTimetable\Policies\StandardTimetablePolicy::class
$ grep -rn "->authorize('viewAny'" Modules/TimetableFoundation Modules/StandardTimetable Modules/SmartTimetable | wc -l
0
```

### F4 — Validation and input

clean — every write goes through a FormRequest and no method reads `$request->all()` or `except()`:
```
$ grep -rnE '\$request->all\(|->except\(|request\(\)->all' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
(no output)
$ grep -n 'extends FormRequest' Modules/StandardTimetable/app/Http/Requests/*.php
Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php:7:class AssignRoomRequest extends FormRequest
Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php:7:class AssignTeacherRequest extends FormRequest
Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php:8:class CreateTimetableRequest extends FormRequest
Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php:7:class PlaceCellRequest extends FormRequest
Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php:7:class RemoveCellRequest extends FormRequest
```
(The `moveCell` extra fields `from_day_of_week` / `from_period_ord` are not in `PlaceCellRequest`; they are cast and guarded with `< 1`, which is adequate but untested — noted under F13.)

### F5 — Routes

#### STT-07 · B · RTE-02 — Four API routes point at methods that do not exist

| Field | Value |
|---|---|
| **Rule** | RTE-02 (B) — *every route points to a method that exists.* |
| **Where** | `Modules/StandardTimetable/routes/api.php:6-8`, via `Route::apiResource('standardtimetables', StandardTimetableController::class)`. |
| **Root cause** | The module scaffold registers an API resource, but the controller only implements the web methods. `apiResource` expects `index`, `store`, `show`, `update`, `destroy`; `store`/`show`/`update`/`destroy` are absent. The one that does resolve, `index`, returns a Blade view, not JSON. |
| **Consequence** | `POST /api/v1/standardtimetables`, `GET /api/v1/standardtimetables/{id}`, `PUT|PATCH …/{id}` and `DELETE …/{id}` all fail with a 500 (method does not exist); the `GET /api/v1/standardtimetables` collection endpoint returns an HTML page to an API client. |
| **Reproduce** | `curl -s -o /dev/null -w "%{http_code}" -H "Accept: application/json" https://test.localhost/api/v1/standardtimetables/1` (with a Sanctum token) returns 500. |
| **Fix approach** | Either remove the unused `apiResource` registration (the app does not call these routes) or implement the four methods as JSON. Both are route changes, so this is a DECISION item. |
| **Plan item** | STT-07 in `02-fix-plan.md` §9 (DECISION) |

```php
Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('standardtimetables', StandardTimetableController::class)->names('standardtimetable');
});
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json 2>/dev/null | php -r '$r=json_decode(stream_get_contents(STDIN),true); foreach($r as $x){ $a=is_array($x["action"])?implode("|",$x["action"]):$x["action"]; if(str_contains($a,"StandardTimetableController") && str_contains($x["uri"],"api/")) printf("%-7s %-45s %s\n",$x["method"],$x["uri"],$a); }'
POST    api/v1/standardtimetables                  Modules\StandardTimetable\Http\Controllers\StandardTimetableController@store
GET|HEAD api/v1/standardtimetables/{standardtimetable} Modules\StandardTimetable\Http\Controllers\StandardTimetableController@show
PUT|PATCH api/v1/standardtimetables/{standardtimetable} Modules\StandardTimetable\Http\Controllers\StandardTimetableController@update
DELETE  api/v1/standardtimetables/{standardtimetable} Modules\StandardTimetable\Http\Controllers\StandardTimetableController@destroy
$ grep -nE 'function (store|show|update|destroy)\b' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
(no output)
```

#### STT-08 · H · RTE-01 — restoreTimetable changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`). GET has no CSRF protection, and link prefetchers trigger it.* |
| **Where** | `Modules/StandardTimetable/routes/web.php:25`, method `restoreTimetable()`. |
| **Root cause** | The restore action is registered as `Route::get`, so restoring a soft-deleted timetable — a database write plus an audit row — can be fired by any GET, including a prefetch or an `<img>` tag, without a CSRF token. |
| **Consequence** | A trashed timetable can be restored by a crafted link or a browser prefetch; the action appears in the audit log with no deliberate user intent. |
| **Reproduce** | While logged in, open `/standard-timetable/timetable/{id}/restore` in a new tab; the timetable is restored. |
| **Fix approach** | Change the route to POST and make the trash page’s action a form/button that issues a POST (the shared `x-backend.table.action-trashed` component must support it). A route change is a stop-and-ask, so this is a DECISION item. |
| **Plan item** | STT-08 in `02-fix-plan.md` §9 (DECISION) |

```php
Route::get('timetable/{id}/restore', [StandardTimetableController::class, 'restoreTimetable'])->name('timetable.restore');
```

**Evidence**
```
$ grep -n 'timetable/{id}/restore' Modules/StandardTimetable/routes/web.php
25:Route::get('timetable/{id}/restore', [StandardTimetableController::class, 'restoreTimetable'])->name('timetable.restore');
$ grep -n 'function restoreTimetable' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
3011:    public function restoreTimetable(int $id): mixed
```

### F6 — Controller shape

#### STT-09 · H · CTL-01 — God controller: 4,950 lines and 27 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-01 (H — over 2,500 lines) — *no god controllers. Over 1,000 lines or 25 public methods is M; over 2,500 lines is H. Split by resource/responsibility.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:37`, class declaration. |
| **Root cause** | One class owns five responsibilities at once: the dashboard, the manual-placement grid builder, the grid serialiser, the placement write endpoints, and the lifecycle/CRUD/traversal endpoints. |
| **Consequence** | Every change to any of those areas touches a file too large to review; merge conflicts and regressions are near-certain. |
| **Reproduce** | static only — measured by line and method count. |
| **Fix approach** | Split by responsibility (CRUD, workflow, grid reads, grid writes) per D3. This is a deferred decision, not applied in this pass. |
| **Plan item** | STT-09 in `02-fix-plan.md` §9 (DECISION) |

```php
class StandardTimetableController extends Controller
{
```

**Evidence**
```
$ wc -l Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
4950 Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
$ grep -cE 'public function ' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
27
```

#### STT-10 · H · CTL-02 — Eleven methods exceed the length limit; seven exceed 150 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H — several methods over 150 lines) — *over 80 lines is M; over 150 lines is H.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:96`, method `manualPlacement()` (755 lines); also `gridStateFor` 405, `buildInsights` 382, `placeCell` 377, `moveCell` 223, `removeCell` 192, `checkActivityRules` 160. |
| **Root cause** | Page data assembly, serialisation and per-placement validation are written inline rather than extracted into small collaborators. |
| **Consequence** | These methods cannot be unit-read; the same edits carry a high regression risk. |
| **Reproduce** | static only — measured by method span. |
| **Fix approach** | Extracted only as part of the CTL-01 split (deferred, D3). |
| **Plan item** | none — see plan §10 |

```php
    public function manualPlacement(Request $request): mixed
    {
        Gate::authorize('tenant.standard-timetable.timetable.manualPlace');
```

**Evidence**
```
$ python3 -c "import re;p='Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php';l=open(p).read().splitlines();f=[(i+1,re.match(r'\s+(?:public|private|protected) function ([a-zA-Z_]+)',x).group(1)) for i,x in enumerate(l) if re.match(r'\s+(?:public|private|protected) function ([a-zA-Z_]+)',x)];
[print(f'{n:<26}{f[k][0]:>5}-{(f[k+1][0]-1) if k+1<len(f) else len(l):<5}= {(f[k+1][0]-1 if k+1<len(f) else len(l))-f[k][0]}') for k,n in enumerate([y for _,y in f])]" | sort -t= -k2 -rn | head -12
manualPlacement              96-850  = 755
gridStateFor                851-1255 = 405
buildInsights              1466-1847 = 382
placeCell                  1982-2358 = 377
moveCell                   2551-2773 = 223
removeCell                 2359-2550 = 192
checkActivityRules         4107-4266 = 160
assignRoom                 3423-3562 = 140
checkConflicts             4267-4394 = 128
resolvePlacementTargets    3879-3998 = 120
assignTeacher              3177-3289 = 113
teacherLoadMap             1256-1337 = 82
```

#### STT-11 · M · CTL-03 — No route model binding; 35 findOrFail calls

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2850`, method `deleteTimetable()`; repeated in `deleteTimetable`, `editTimetable`, `destroyTimetable`, `restoreTimetable`, `forceDeleteTimetable`, `copyTimetable`, `lockCell`, `unlockCell`, `lockAll`, `unlockAll`, `submitForApproval`, `approve`, `publish`, `unpublish`, `classView`, `teacherView`, `roomView`. |
| **Root cause** | Each method receives a scalar id and looks the model up itself. |
| **Consequence** | No user-visible harm; it is boilerplate that a binding would remove. Some methods scope the lookup (`generation_method = MANUAL`, `onlyTrashed()`), so a naive binding would change behaviour — hence this must move with the split. |
| **Reproduce** | static only. |
| **Fix approach** | Introduce scoped bindings that preserve the `MANUAL`/`onlyTrashed` scope. Part of the deferred CTL-01 split. |
| **Plan item** | none — see plan §10 |

```php
        $timetable = Timetable::where('generation_method', 'MANUAL')->findOrFail($id);
```

**Evidence**
```
$ grep -c 'findOrFail' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
35
```

#### STT-12 · L · CTL-04 — Four public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:42`, method `index()`; also `classView()` 4792, `teacherView()` 4861, `roomView()` 4911. These four return `View`. |
| **Root cause** | The methods were written without a return type where the others declare `mixed` or `JsonResponse`. |
| **Consequence** | No runtime harm; the signature is less self-describing and inconsistent with the rest of the class. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: View` (import `Illuminate\View\View`) to the four, or `: mixed` to match the class convention. |
| **Plan item** | STT-12 in `02-fix-plan.md` §5 |

```php
    public function index()
    {
```

**Evidence**
```
$ grep -nE '^\s*public function [a-zA-Z_]+\([^)]*\)\s*$' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
42:    public function index()
4792:    public function classView(int $timetableId, int $classSectionId)
4861:    public function teacherView(int $timetableId, int $teacherId)
4911:    public function roomView(int $timetableId, int $roomId)
```

#### STT-13 · L · CTL-07 — compact() passes 22 and 37 variables

| Field | Value |
|---|---|
| **Rule** | CTL-07 (L) — *no `compact()` of more than ~15 variables (build a view model / array).* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:785-791` (22 variables into `gridStateFor()`) and `793-831` (37 variables into the view). |
| **Root cause** | The page is assembled as one giant `compact()` rather than an explicit view-model array. |
| **Consequence** | No runtime harm; the view contract is implicit and easy to break silently. |
| **Reproduce** | static only. |
| **Fix approach** | Build an associative array (the blade already reads variables by name) and rework with the split. Deferred with CTL-01. |
| **Plan item** | none — see plan §10 |

```php
        $gridState = $this->gridStateFor(compact(
            'days', 'gridPeriods', 'gridWidth', 'classPeriodSet', 'activities', 'existingCells',
            'roomsByType', 'rememberedTeachers', 'rememberedRooms', 'slotTeachers', 'lockedSlots',
            'allLocked', 'busySlots', 'busyRooms', 'teacherLoads', 'classHouseRoom',
            'houseRoomUsable', 'selectedTimetableId', 'selectedClassSection',
            'groupCards', 'companionGrids', 'classTeacherTeacherId',
        ));
```

**Evidence**
```
$ grep -n 'compact(' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
90:        return view('standardtimetable::index', compact('stats', 'recentTimetables', 'timetableCoverage', 'menuPages'));
785:        $gridState = $this->gridStateFor(compact(
793:        return view('standardtimetable::pages.manual-placement', compact(
848:     * @param  array<string, mixed>  $ctx  the compact() of manualPlacement()'s locals
3004:        return view('standardtimetable::pages.manual-placement-trash', compact('trashedTimetables'));
4858:            compact('timetable', 'cells', 'classSection', 'days', 'periods', 'options'));
```

#### STT-14 · M · CTL-10 — Dead private method periodIsPlaceable()

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:1338-1341`, method `periodIsPlaceable()`. |
| **Root cause** | The method was superseded by `periodBlockReason()`, which callers use directly, and the old wrapper was left behind. |
| **Consequence** | No user-visible harm; a future reader may believe it is on a live path. |
| **Reproduce** | static only — the name appears only at its declaration. |
| **Fix approach** | Delete the method. |
| **Plan item** | STT-14 in `02-fix-plan.md` §5 |

```php
    private function periodIsPlaceable(?object $period): bool
    {
        return $this->periodBlockReason($period) === null;
    }
```

**Evidence**
```
$ grep -n 'periodIsPlaceable' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
1338:    private function periodIsPlaceable(?object $period): bool
```

#### STT-15 · M · CTL-05 — The Activity eager-load array is copy-pasted in placeCell and moveCell

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: the same 30-line payload in `store` and `update`.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:1993-2000` (`placeCell`) and `2569-2572` (`moveCell`). |
| **Root cause** | The identical six-relation eager-load of `Activity` was written twice in two different formats. |
| **Consequence** | A relation added to one call is silently missing in the other, so the two write paths can resolve teacher/room data differently. |
| **Reproduce** | static only. |
| **Fix approach** | Extract one private `activityWith()` helper and call it from both. Part of the deferred split; recorded here. |
| **Plan item** | none — see plan §10 |

```php
        $activity = Activity::with([
            'subject',
            'studyFormat',
            'subjectType',
            'teachers.teacher.user',
            'teachers.assignmentRole',
            'requiredRoomType',
        ])->findOrFail($validated['activity_id']);
```

**Evidence**
```
$ grep -n "Activity::with(\[" Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
1993:        $activity = Activity::with([
2569:        $activity = Activity::with([
```

### F7 — Models

No model is owned by this report: every model it reaches is claimed by a TimetableFoundation report (scope §3 rows 17-27) and the four SchoolSetup models are common. Model-level checks were therefore not run here. Usage-level observations from this controller:

clean — the relations it eager-loads are used in the same iteration (`activity.subject`, `teachers.user`, `room`, `requiredRoomType`), so no lazy-load N+1 was found in the reads; soft-deleted rows are respected (`whereNull('deleted_at')`, `onlyTrashed()`/`withTrashed()` correctly paired in the trash paths). Proof command and real output:
```
$ grep -nE 'with\(\[|onlyTrashed|withTrashed|whereNull\(.deleted_at' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php | wc -l
23
```

### F8 — Services and jobs

#### STT-16 · M · SVC-04 — ManualTimetableService keeps a second, unreachable implementation of placeCell/removeCell/checkConflicts

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation. Copies that disagree are a bug source.* |
| **Where** | `Modules/StandardTimetable/app/Services/ManualTimetableService.php:157-162`, method `checkConflicts()`; the whole `placeCell()` (13) / `removeCell()` (65) / `checkConflicts()` (162) group. |
| **Root cause** | The service holds a full second implementation of placement and conflict detection, while the controller calls only `copyTimetable()`. The two conflict implementations already disagree: the service still has `CLASS_DOUBLE_BOOKING` and matches in-memory on `teacher_id`, both of which the controller deliberately removed/fixed. The service’s own docblock admits it is unreachable. |
| **Consequence** | A future caller who wires the service by mistake gets the old, wrong conflict behaviour; meanwhile the dead code is read as authoritative. |
| **Reproduce** | static only — the only caller of `ManualTimetableService` is `copyTimetable()` at controller line 4411. |
| **Fix approach** | Delete the unreachable `placeCell()`, `removeCell()`, `checkConflicts()` and `persistConflicts()` (plus the now-unused `ConflictDetection` import), or make them `@deprecated` and document why. Deleting a public service method is a decision. |
| **Plan item** | STT-16 in `02-fix-plan.md` §9 (DECISION) |

```php
     * ⚠ This method is currently UNREACHABLE: it is called only by this class's own
     * placeCell(), and nothing calls that — the controller uses this service for
     * copyTimetable() alone. Kept in step rather than deleted, because deleting a public
     * service method is a separate decision.
     */
    public function checkConflicts(int $timetableId, Activity $activity, int $dayOfWeek, int $periodOrd): array
```

**Evidence**
```
$ grep -rn 'ManualTimetableService' Modules/StandardTimetable/app
Modules/StandardTimetable/app/Services/ManualTimetableService.php:11:class ManualTimetableService
Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:24:use Modules\StandardTimetable\Services\ManualTimetableService;
Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:4402:        $service = app(ManualTimetableService::class);
Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:4411:            $copy = $service->copyTimetable($source);
```

### F9 — Queries and performance

#### STT-17 · H · QRY-01 — Queries run inside loops (N+1) in four read/write paths

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops. No `Model::where/find/create/update`, `->save()` or lazy relation access inside `foreach`/`->map()`. Eager-load, pre-fetch into a keyed collection, or bulk-write.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:407-417`, method `manualPlacement()` (a `DB::table('tt_timetable_cells')` query per group card). Also `buildInsights()` at 1737-1746 (one query per shared group), `removeCell()` at 2488 (one delete per sibling), and in `Modules/StandardTimetable/app/Services/ManualTimetableService.php:44-53` and `128-142` (one insert/query per row). |
| **Root cause** | The placed-slot count for a shared group is computed inside the `->map()` that builds the cards, and the shared-group completion count inside a `foreach`, instead of resolving all groups with one grouped query. |
| **Consequence** | Opening the manual-placement grid for a class with many shared groups issues one extra query per group on every page load; each drop then repeats the pattern. |
| **Reproduce** | Load `/standard-timetable/manual-placement?timetable_id=15&class_section_id=8` and count queries; the query count grows with the number of shared groups rather than staying constant. |
| **Fix approach** | Pre-fetch the `sub_activity_id => DISTINCT day,period` map in one grouped query keyed by `sub_activity_id`, then read it inside the map. Same for `buildInsights`. Bulk-insert the pivot rows in the service. |
| **Plan item** | STT-17 in `02-fix-plan.md` §6 |

```php
                    $placedSlots = $selectedTimetableId
                        ? DB::table('tt_timetable_cells')
                            ->where('timetable_id', $selectedTimetableId)
                            ->where('sub_activity_id', $group->id)
                            ->whereNull('deleted_at')
                            ->where('is_active', true)
                            ->selectRaw('DISTINCT day_of_week, period_ord')
                            ->get()
                            ->map(fn ($c) => $c->day_of_week.'-'.$c->period_ord)
                            ->values()
                        : collect();
```

**Evidence**
```
$ grep -n 'DB::table(' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php | wc -l
22
$ grep -n 'DB::table(' Modules/StandardTimetable/app/Services/ManualTimetableService.php
43:            DB::table('tt_timetable_cell_teachers')->where('cell_id', $cell->id)->delete();
45:                DB::table('tt_timetable_cell_teachers')->insert([
69:            DB::table('tt_timetable_cell_teachers')->where('cell_id', $cell->id)->delete();
131:                $teachers = DB::table('tt_timetable_cell_teachers')
134:                    DB::table('tt_timetable_cell_teachers')->insert([
```

#### STT-18 · L · QRY-07 — Per-row writes in small loops

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M default, lowered to L — every affected loop is bounded to one or two rows: targets are 1-2 class-sections and teachers per cell are a handful) — *bulk writes: `insert()`, `upsert()`, `whereIn(...)->update()` instead of `create()`/`update()` per row in a loop.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:2242-2251`, method `placeCell()`; also `writeCellTeachers()` 3154-3163, `moveCell()` 2702-2708, `recomputeConflictsAtSlot()` 4077-4080, `removeCell()` 2488-2489, and service 44-53/128-142. |
| **Root cause** | Each target/sibling/teacher is written with a separate Eloquent call. |
| **Consequence** | Negligible at today’s cardinality (1-2 rows); it is the same pattern as STT-17 and would matter if a group ever spans many classes. |
| **Reproduce** | static only. |
| **Fix approach** | Leave as-is for now; if STT-17’s batching is applied, batch these at the same time. |
| **Plan item** | none — see plan §10 |

```php
                if ($cell) {
                    $cell->restore();
                    $cell->fill($attributes)->save();
                } else {
                    $cell = TimetableCell::create($attributes + [
                        'timetable_id' => $validated['timetable_id'],
                        'day_of_week' => $validated['day_of_week'],
                        'period_ord' => $validated['period_ord'],
                    ]);
                }
```

**Evidence**
```
$ grep -nE '->save\(\)|::create\(|->update\(|->delete\(\)' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php | wc -l
28
```

#### STT-19 · L · QRY-02 — List screens paginate at 15, not the house standard of 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M default, lowered to L — the lists are short and the difference is cosmetic) / final-audit F9 — *lists paginate at 10, with a distinct `pageName` per list.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:173`, method `manualPlacement()`; also `trashedTimetables()` at 3001. |
| **Root cause** | Both list screens call `paginate(15)` instead of the project’s page size. |
| **Consequence** | Cosmetic: the manual-timetable list and trash list render 15 rows where the rest of the product renders 10. |
| **Reproduce** | Open `/standard-timetable/manual-placement` with more than 10 timetables and count rows per page. |
| **Fix approach** | Change both `paginate(15)` to `paginate(10)`. |
| **Plan item** | STT-19 in `02-fix-plan.md` §6 |

```php
            ->when($listStatus !== '', fn ($q) => $q->where('status', $listStatus))
            ->orderByDesc('created_at')
            ->paginate(15)
            ->withQueryString();
```

**Evidence**
```
$ grep -n 'paginate(15)' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
173:            ->paginate(15)
3001:            ->paginate(15)
```

### F10 — Views

clean — no Blade query, no raw echo, correct action components:
```
$ grep -rnE '(\b[A-Z][A-Za-z]+::|DB::|->where\(|->get\(\)|->count\(\))' Modules/StandardTimetable/resources/views/ | grep -vE 'Route::has|route\(|Carbon::parse|->count\(\)' 
(no output)
$ grep -rn '{!!' Modules/StandardTimetable/resources/views/
(no output)
$ grep -rn 'x-backend.table.action' Modules/StandardTimetable/resources/views/
Modules/StandardTimetable/resources/views/pages/manual-placement.blade.php:184:                                    <x-backend.table.action :id="$tt->id" url="standard-timetable.timetable"
Modules/StandardTimetable/resources/views/pages/manual-placement-trash.blade.php:70:                                <x-backend.table.action-trashed :id="$tt->id" url="standard-timetable.timetable"
```
The `Route::has()` guards and `Carbon::parse()` calls in the three view blades are not database access. The shared components reached by `@include`/`x-` (`x-backend.layouts.app`, `x-backend.table.action`, `x-backend.table.action-trashed`, `x-backend.tab.search-bar`, `x-backend.tab.modal`, `x-backend.components.breadcrum`) are common classes (protocol §4.2) and are listed under §7. `@can` gates in `manual-placement.blade.php` (643, 651, 661, 671) use the same permission strings as the controller and config, so the four-surface check passes.

### F11 — Security and tenancy

#### STT-20 · M · TEN-02 — Process-static caches are keyed on snapshot but not on tenant

| Field | Value |
|---|---|
| **Rule** | TEN-02 (H default, lowered to M — this app runs under a standard request-per-process setup today; raise to H if Octane or a queue worker ever serves multiple tenants) — *cache keys and static/in-memory caches include the tenant.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:3845-3852`, method `classGroupIdsFor()`; also `dayLabels()` at 3756-3765. |
| **Root cause** | Both use a process-lifetime `static` cache. `classGroupIdsFor()` keys on `(snapshot id, class, section)` and `dayLabels()` on nothing; neither includes the tenant database name. In a long-lived process that switches tenant connections, tenant A’s class-group ids or day labels would be served to tenant B. |
| **Consequence** | Under Octane/a queue worker, a shared/group cell could be keyed with another tenant’s `sch_class_groups_jnt` ids, dropping or misplacing cells; day short-names could come from the wrong school. |
| **Reproduce** | static only — static fields outlive a single request by definition. |
| **Fix approach** | Prefix both cache keys with `DB::connection()->getDatabaseName()` (or clear the static on `TenantChanged`). |
| **Plan item** | STT-20 in `02-fix-plan.md` §6 |

```php
    private function classGroupIdsFor(int $classId, int $sectionId): array
    {
        static $cache = [];
        // Snapshot id in the key: inside a snapshot the table is a tt_snap_* mirror
        // with ENCODED ids, and a long-lived process (queue worker) can serve both a
        // live and a snapshot read. A class:section-only key leaked live ids into a
        // snapshot read and would drop shared cells (Phase 2, 2026-10-08).
        $key = (app(SnapshotContext::class)->snapshotId() ?? 0).':'.$classId.':'.$sectionId;
```

**Evidence**
```
$ grep -n 'static \$' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
3758:        static $labels = null;
3847:        static $cache = [];
```

### F12 — Style

#### STT-21 · L · STY-01 — Seven files lack declare(strict_types=1)

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *declare(strict_types=1) in PHP files (new files mandatory; old files when touched).* |
| **Where** | `Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php:1`; also `Modules/StandardTimetable/app/Services/ManualTimetableService.php`, and the five requests `AssignRoomRequest`, `AssignTeacherRequest`, `CreateTimetableRequest`, `PlaceCellRequest`, `RemoveCellRequest`. The controller already declares it (line 3). |
| **Root cause** | These classes were created before the rule and not updated when the controller was. |
| **Consequence** | Coercive type juggling stays on in these files; the controller’s comment about form-encoded ints reaching a typed helper is exactly the class of trap strict types makes loud. |
| **Reproduce** | static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag in all seven files. |
| **Plan item** | STT-21 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\StandardTimetable\Policies;
```

**Evidence**
```
$ for f in Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php Modules/StandardTimetable/app/Services/ManualTimetableService.php Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php; do printf "%s: " "$f"; grep -c 'declare(strict_types' "$f"; done
Modules/StandardTimetable/app/Policies/StandardTimetablePolicy.php: 0
Modules/StandardTimetable/app/Services/ManualTimetableService.php: 0
Modules/StandardTimetable/app/Http/Requests/AssignRoomRequest.php: 0
Modules/StandardTimetable/app/Http/Requests/AssignTeacherRequest.php: 0
Modules/StandardTimetable/app/Http/Requests/CreateTimetableRequest.php: 0
Modules/StandardTimetable/app/Http/Requests/PlaceCellRequest.php: 0
Modules/StandardTimetable/app/Http/Requests/RemoveCellRequest.php: 0
```

#### STT-22 · L · STY-04 — Emoji markers in comments (91 in the controller) and one orphan docblock

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no copy-pasted docblocks that describe another resource.* |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:114`, comment markers such as the warning glyph; 91 occurrences across the controller (also in `AssignRoomRequest`, `AssignTeacherRequest`, `CreateTimetableRequest`, `PlaceCellRequest` and `ManualTimetableService`). Additionally the docblock at lines 3596-3604 describes `classGroupIdsFor()` but sits above `companionGrid()`’s docblock, leaving `classGroupIdsFor()` (line 3845) with no docblock of its own. |
| **Root cause** | Comments use warning/stop emoji as visual markers, which the STY-04 rule forbids; and one docblock was displaced when `companionGrid()` was inserted between its comment and its method. |
| **Consequence** | No runtime effect; the style drifts from the codebase standard and the orphan docblock misleads a reader about which method it documents. |
| **Reproduce** | static only. |
| **Fix approach** | Remove the leading emoji glyph from each marker comment (keep the prose), and move the 3596-3604 docblock down to sit immediately above `classGroupIdsFor()` at 3845. |
| **Plan item** | STT-22 in `02-fix-plan.md` §8 |

```php
        // ⚠ CAST AT THE BOUNDARY. A query string is always STRINGS, and this class
        // declares strict_types=1, so handing "13" to a typed ?int helper is a TypeError
        // and a 500 on a page that is otherwise fine. Kept as null (not 0) when absent, so
        // `if ($selectedTimetableId)` and every route() that echoes it back behave as
        // before. Same family as the form-encoded-int trap in placeCell.
        $selectedTimetableId = $request->filled('timetable_id')
            ? (int) $request->input('timetable_id')
            : null;
```

**Evidence**
```
$ grep -c '⚠\|⛔' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
91
```

#### STT-23 · L · STY-02 — ManualTimetableService is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines.* |
| **Where** | `Modules/StandardTimetable/app/Services/ManualTimetableService.php:92-103`, method `uniqueCopyName()`. |
| **Root cause** | The service was never run through Pint: the reported fixers are `function_declaration`, `fully_qualified_strict_types`, `concat_space`, `not_operator_with_successor_space`, `blank_line_before_statement`, `ordered_imports`. |
| **Consequence** | No runtime effect; the file fails the repo’s formatter. |
| **Reproduce** | `vendor/bin/pint Modules/StandardTimetable/app/Services/ManualTimetableService.php --test`. |
| **Fix approach** | Run Pint on the file after the hand edits (strict types, emoji removal). The fix is a formatter run, not a hand edit. |
| **Plan item** | none — see plan §10 |

```php
        $base = $source->name . ' (Copy)';
        $candidate = $base;
        $suffix = 1;

        while (
            Timetable::query()
                ->where('name', $candidate)
                ->where('academic_term_id', $source->academic_term_id)
                ->where('timetable_type_id', $source->timetable_type_id)
                ->exists()
        ) {
            $candidate = $base . ' ' . (++$suffix);
        }
```

**Evidence**
```
$ vendor/bin/pint Modules/StandardTimetable/app/Services/ManualTimetableService.php --test
{"tool":"pint","result":"fail","files":[{"path":"Modules\/StandardTimetable\/app\/Services\/ManualTimetableService.php","fixers":["function_declaration","fully_qualified_strict_types","concat_space","not_operator_with_successor_space","blank_line_before_statement","ordered_imports"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Columns: 1 overwrite data it should not · 2 delete before replace · 3 duplicate implementation · 4 soft-delete x unique · 5 race · 6 auth hole · 7 lying message · 8 dead feature.

| Method | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| `placeCell` | ok | ok | STT-16 (service twin) | ok | ok (`lockForUpdate` 2177) | ok | ok | STT-16 |
| `removeCell` | ok | ok | ok | ok | ok | ok | ok | ok |
| `moveCell` | ok | ok | ok | ok | ok | ok | ok | ok |
| `createTimetable` | ok | ok | ok | ok (unique mirrors index) | ok | ok | ok | ok |
| `deleteTimetable` | ok | ok | ok | na (hard delete) | ok | ok | ok | ok |
| `destroyTimetable` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restoreTimetable` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDeleteTimetable` | ok | ok | ok | na (hard delete) | ok | ok | ok | ok |
| `assignTeacher` | ok | ok | STT-16 (service twin) | ok | ok | ok | ok | STT-16 |
| `assignRoom` | ok | ok | ok | ok | ok | ok | ok | ok |
| `copyTimetable` | ok | ok | ok | ok (`uniqueCopyName`) | ok | ok | ok | STT-16 |
| `lockCell` | ok | na | ok | ok | ok | ok | ok | ok |
| `unlockCell` | ok | na | ok | ok | ok | ok | ok | ok |
| `lockAll` | ok | na | ok | ok | ok | ok | ok | ok |
| `unlockAll` | ok | na | ok | ok | ok | ok | ok | ok |
| `submitForApproval` | ok | na | ok | ok | ok | ok | ok | ok |
| `approve` | ok | na | STT-24 | ok | ok | STT-24 (bypasses `approve` gate via `publish`) | ok | ok |
| `publish` | ok | na | STT-24 | ok | ok | STT-24 | ok | ok |
| `unpublish` | ok | na | ok | ok | ok | ok | ok | ok |

Two answers need a finding: question 3 (duplicate publish implementation) is STT-24; question 8 (dead service feature) is STT-16. Question 5 is `ok` throughout because `placeCell` locks the slot inside its transaction and the other writes are idempotent single-row updates.

#### STT-24 · M · SVC-04 — approve() and publish() are two implementations of the same publish operation

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation. Two copies that disagree are a bug source.* (detect D) |
| **Where** | `Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php:4649-4654`, method `approve()`; duplicated at `publish()` 4704-4709. |
| **Root cause** | Both methods write `status = PUBLISHED`, `published_at = now()`, `is_active = true`, call `archiveOthersInScope()` and log the identical `Published` event. `publish()` additionally accepts `DRAFT` as a start state, so a caller holding `.publish` can reach the published state without ever holding `.approve`. |
| **Consequence** | The submit/approve workflow can be bypassed by the shortcut endpoint, and the archive/publish side effect is maintained in two places that can drift. |
| **Reproduce** | As a role holding only `.publish`, POST `/standard-timetable/publish/{draftId}` — it succeeds, producing the same state `approve()` would and logging `Published`. |
| **Fix approach** | Decide whether the shortcut is intended: keep one implementation (have `publish()` delegate to `approve()` or a shared private method), or document the shortcut and split the permissions deliberately. This is a product/behaviour choice, so it is a DECISION item. |
| **Plan item** | STT-24 in `02-fix-plan.md` §9 (DECISION) |

```php
            $timetable->update(['status' => 'PUBLISHED', 'published_at' => now(), 'is_active' => true]);

            // One published timetable per scope (snapshot v5, T3.3).
            $timetable->archiveOthersInScope();
```

**Evidence**
```
$ sed -n '4651,4653p;4706,4708p' Modules/StandardTimetable/app/Http/Controllers/StandardTimetableController.php
            $timetable->update(['status' => 'PUBLISHED', 'published_at' => now(), 'is_active' => true]);

            // One published timetable per scope (snapshot v5, T3.3).
            $timetable->archiveOthersInScope();
            $timetable->update(['status' => 'PUBLISHED', 'published_at' => now(), 'is_active' => true]);

            // One published timetable per scope (snapshot v5, T3.3).
            $timetable->archiveOthersInScope();
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SchoolSetup/app/Models/ClassSection.php`, `Room.php`, `Teacher.php`, `TeacherProfile.php` | Common models of another module; this controller reads them (`is_active`, `classHouseRoom`, `roomType`, `active()` scope, `max_available_periods_weekly`). No defect found in this controller’s use of them. | - | SchoolSetup owner |
| `x-backend.table.action`, `x-backend.table.action-trashed`, `x-backend.tab.search-bar`, `x-backend.tab.modal`, `x-backend.components.breadcrum`, `x-backend.layouts.app` | Shared Blade components used by the module’s blades. Not audited here (protocol §4.2). | - | shared-components owner |
| `Modules/TimetableFoundation/app/Support/Snapshot/*` (`SnapshotTables`, `SnapshotSchema`, `SnapshotQueryGrammar`) | Collaborators of `SnapshotContext`; outside this controller’s direct reach. Only `snapshotId()` is used. | - | TimetableFoundation snapshot owner |

## 8. Not covered, and why

- **The god-controller split (STT-09/CTL-02/CTL-03)** is a deferred decision (D3). This report measures it but does not plan the extraction.
- **The populated tenant’s real UI** was not exercised: `test.localhost` currently points at an empty tenant DB, so the populated sibling DB was measured read-only for row counts only. No HTTP requests were made (D4, no tests).
- **`ManualTimetableService::copyTimetable()`** was audited statically; its `uniqueCopyName()` race (two simultaneous copies could pick the same suffix) was not reproduced against a live DB because no writes were permitted.
- **Queue/Octane behaviour** of the process-static caches (STT-20) is inferred from the code, not measured, because no worker was run.
- **`archiveOthersInScope()` and the `Timetable` model internals** belong to `TimetableFoundation/TimetableController` and are ↗ linked, not audited here.
