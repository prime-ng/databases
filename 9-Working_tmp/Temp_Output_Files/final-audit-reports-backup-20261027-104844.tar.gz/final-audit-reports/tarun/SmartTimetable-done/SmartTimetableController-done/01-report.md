# Final Audit — SmartTimetable / SmartTimetableController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php` (1784 lines, 32 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/smart-timetable-management` (index, one tabbed page per resource) · `.../smart-timetable-management/{id}/edit` (edit form) · `PUT .../smart-timetable-management/{id}` (save) · `DELETE .../smart-timetable-management/{id}` (delete) · `GET/POST` variants under `api/v1/smarttimetables` (Sanctum API) |
| Menu path | Smart Timetable → Smart Timetable Management (the resource group; the menu's other pages were moved to `TimetableMenuController`, `TimetablePageController` and `TimetableGenerationController`) |
| Who uses it | Roles 1 (Super Admin) and 2 (School Admin) — the only roles holding all six `tenant.smart-timetable.*` permissions this controller checks (verified in `sys_role_has_permissions_jnt`) |
| What a user does here | Opens the Smart Timetable Management hub, page by page tab: school days, shifts, day types, working days, period types, period sets, constraint types, constraints, teacher unavailability, room unavailability, assignment roles, activities, timetable types, timetables, teachers, rooms. Edits a timetable's descriptive fields (name, description, effective dates, status — including publishing through a readiness gate). Deletes a timetable. `create` and `store` respond 403 on purpose. |
| Tables written | `tt_timetables` (update/soft-delete), `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_generation_runs`, `tt_conflict_detection`, `tt_change_logs`, `tt_teacher_workloads`, `tt_constraint_violations` (hard-purged via `TimetableStorageService::purgeChildrenOf` on delete), `sys_activity_logs` |
| Tables read | `tt_school_days`, `tt_shifts`, `tt_day_types`, `tt_working_days`, `glb_academic_sessions` (central), `tt_period_types`, `tt_period_sets`, `tt_constraint_types`, `tt_constraints`, `tt_teacher_unavailabilities`, `tt_room_unavailabilities`, `tt_class_subgroup_members`, `tt_teacher_assignment_roles`, `tt_requirement_consolidations`, `tt_activities` + activity relations, `tt_timetable_types`, `tt_timetables`, `tt_period_set_periods_jnt`, `tt_teachers` (SchoolSetup), `tt_rooms` |
| Live data | test.localhost tenant `xyz_school_00000000000040008000_202627`: `tt_timetables` 0 (0 published), `tt_timetable_cells` 0, `tt_activities` 0, `tt_sub_activities` 0, `tt_constraints` 6, `tt_constraint_types` 10, `tt_teacher_unavailabilities` 0, `tt_room_unavailabilities` 0, `tt_school_days` 7, `tt_period_sets` 4, `sys_activity_logs` 396 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not** production-ready as written, but the reachable surface is small: only five methods are actually routed and live (`index`, `show`, `edit`, `update`, `destroy`); the other 27 public methods are either unrouted duplicates of screens that moved to other controllers, or already disabled with `abort(403)`. **AGENTS.md SEC-009 is REFUTED with evidence**: the controller contains 14 `Gate::authorize` calls and every routed live method authorizes before touching data — the claim of "ZERO authorization checks" is false. The single worst finding is in `destroy()`: on any database failure it flashes the raw exception text (`'Failed to delete timetable: '.$e->getMessage()`), a SQL/table-name leak to the user (ERR-01, B). The effort to fix the reachable findings is S-M (two method rewrites plus a paging fix); the big effort is the deferred split of the 1,784-line controller, which is a DECISION.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 1 | 12 | 5 | 3 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | STM-01, STM-02, STM-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | STM-04, STM-05 | F9 Queries/Perf | STM-15, STM-16, STM-17 |
| F3 Authorization | STM-06, STM-07 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | STM-08 | F12 Style | STM-18, STM-19 |
| F6 Controller shape | STM-09, STM-10, STM-11, STM-12, STM-13, STM-14 | F13 Deep read | STM-01, STM-04 |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php` | controller | 1784 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Models/SubActivity.php` | model (alias) | 11 | this report (pre-assigned) | ✅ |
| 3 | `Modules/SmartTimetable/app/Policies/SmartTimetablePolicy.php` | policy | 46 | this report (pre-assigned) | ✅ |
| 4 | `Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php` | FormRequest | 173 | this report (used only here) | ✅ |
| 5 | `Modules/SmartTimetable/resources/views/smart-timetable/index.blade.php` | view | 65 | this report | ✅ |
| 6 | `Modules/SmartTimetable/resources/views/smart-timetable/edit.blade.php` | view | 327 | this report | ✅ |
| 7 | `Modules/SmartTimetable/app/Models/Timetable.php` | model | — | ↗ [AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked |
| 8 | `Modules/SmartTimetable/app/Models/TimetableCell.php` | model | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 9 | `Modules/SmartTimetable/app/Models/Constraint.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked |
| 10 | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked |
| 11 | `Modules/SmartTimetable/app/Models/ConstraintType.php` | model | — | ↗ [ConstraintTypeController](../ConstraintTypeController-done/01-report.md) | ↗ linked |
| 12 | `Modules/SmartTimetable/app/Models/TeacherUnavailable.php` | model | — | ↗ [TeacherUnavailableController](../TeacherUnavailableController-done/01-report.md) | ↗ linked |
| 13 | `Modules/SmartTimetable/app/Models/RoomUnavailable.php` | model | — | ↗ [RoomUnavailableController](../RoomUnavailableController-done/01-report.md) | ↗ linked |
| 14 | `Modules/SmartTimetable/app/Models/SchoolDay.php` | model | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 15 | `Modules/SmartTimetable/app/Models/PeriodSetPeriod.php` | model (alias) | — | ↗ [TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked |
| 16 | `Modules/SmartTimetable/app/Models/TtGenerationStrategy.php` | model | — | ↗ [TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 17 | `Modules/SmartTimetable/app/Models/Activity.php` | model (alias) | — | ↗ [TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 18 | `Modules/SmartTimetable/app/Models/ConflictDetection.php` | model | — | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 19 | `Modules/SmartTimetable/app/Models/GenerationRun.php` | model | — | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 20 | `Modules/SmartTimetable/app/Models/SubstitutionLog.php` | model | — | ↗ [SubstitutionController](../SubstitutionController-done/01-report.md) | ↗ linked |
| 21 | `Modules/SmartTimetable/app/Models/TeacherAbsences.php` | model | — | ↗ [SubstitutionController](../SubstitutionController-done/01-report.md) | ↗ linked |
| 22 | `Modules/SmartTimetable/app/Models/TeacherAvailablity.php` | model (alias) | — | ↗ [TimetablePageController](../TimetablePageController-done/01-report.md) | ↗ linked |
| 23 | `Modules/SmartTimetable/app/Services/Publishing/TimetableReadiness.php` | service | — | ↗ [TimetablePublishController](../TimetablePublishController-done/01-report.md) | ↗ linked |
| 24 | `Modules/SmartTimetable/app/Services/Preview/PreviewGridState.php` | service | — | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 25 | `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | service | — | ↗ [TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 26 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php` + Hard/Soft constraint classes | services | — | ↗ [ConstraintController](../ConstraintController-done/01-report.md) | ↗ linked |
| 27 | TimetableFoundation models (`AcademicTerm`, `PeriodSet`, `RequirementConsolidation`, `ClassSubjectSubgroup`, `ClassRequirementGroup/Subgroup`, `TimetableType`, `SchoolShift`, `DayType`, `PeriodType`, `WorkingDay`, `TeacherAssignmentRole`, `Config`) | models | — | ↗ [TimetableFoundation/*](../TimetableFoundation/) reports | ↗ linked |
| 28 | SchoolSetup models (`ClassSection`, `Room`, `SchoolClass`, `StudyFormat`, `Subject`, `Teacher`, `User`, `OrganizationAcademicSession`), `Modules/Prime/.../AcademicSession` | models | — | common (§4.2) | ↗ common |

No pre-applied files (this module: `final-audit-reports/tarun/SmartTimetable` has no PRE-APPLIED file; no file here is on the 2026-10-10 TimetableFoundation log).

## 4. Routes

Uncached route list (each route points at this controller; generated from `/tmp/fa-routes.json`):

```
DELETE  api/v1/smarttimetables/{smarttimetable}   api.smarttimetable.destroy   ...@destroy
GET|HEAD api/v1/smarttimetables                  api.smarttimetable.index     ...@index
GET|HEAD api/v1/smarttimetables/{smarttimetable}  api.smarttimetable.show      ...@show
POST    api/v1/smarttimetables                   api.smarttimetable.store      ...@store
PUT|PATCH api/v1/smarttimetables/{smarttimetable} api.smarttimetable.update    ...@update
GET|HEAD smart-timetable/smart-timetable-management              smart-timetable.smart-timetable-management.index  ...@index
POST    smart-timetable/smart-timetable-management                smart-timetable.smart-timetable-management.store  ...@store
GET|HEAD smart-timetable/smart-timetable-management/create        smart-timetable.smart-timetable-management.create ...@create
GET|HEAD smart-timetable/smart-timetable-management/{smart_timetable_management} ...show
PUT|PATCH smart-timetable/smart-timetable-management/{smart_timetable_management} ...update
DELETE  smart-timetable/smart-timetable-management/{smart_timetable_management} ...destroy
GET|HEAD smart-timetable/smart-timetable-management/{smart_timetable_management}/edit ...edit
```

Every other public method of this controller has **no route** (verified in `Modules/SmartTimetable/routes/web.php` and `routes/api.php`: only `Route::resource('smart-timetable-management', ...)` and `Route::apiResource('smarttimetables', ...)` name this controller).

Unrouted public methods:
- **Live bodies, not disabled (16):** `generate` (226), `preview` (358), `timetableConfig` (1080), `timetableMaster` (1110), `timetableGeneration` (1302), `constraintManagement` (1496), `preRequisitesSetup` (1559), `timetableConfiguration` (1565), `timetableMasters` (1571), `timetableRequirement` (1577), `constraintEngine` (1582), `resourceAvailability` (1632), `timetablePreparation` (1638), `viewAndRefinement` (1643), `reportsAndLogs` (1708), `substituteManagement` (1733) — all STM-08.
- **Already disabled with `abort(403)` (9):** `storeTimetable` (541), `placeCell` (551), `removeCell` (561), `timetableOperation` (1103), `timetableReports` (1344), `timetableValidation` (1354), `generateWithPrime` (1361), `publishTimetable` (1716), `unpublishTimetable` (1726) — D5-compliant, no finding.
- **Routed but disabled with `abort(403)` (2):** `create` (687), `store` (692) — deliberate (the docblock at 651-686 explains why); meets RTE-03's disabled alternative.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 73 | GET/HEAD web + api | `tenant.smart-timetable.timetable.viewAny` | none (read) | — | — | STM-12, STM-14, STM-15, STM-16 |
| `generate` | 226 | unrouted | `tenant.smart-timetable.timetable.generate` | none | — | — | STM-08, STM-14 |
| `preview` | 358 | unrouted | `tenant.smart-timetable.timetable.view` | none (read) | — | — | STM-08, STM-10, STM-14 |
| `storeTimetable` | 541 | unrouted (403) | — | — | — | — | — |
| `placeCell` | 551 | unrouted (403) | — | — | — | — | — |
| `removeCell` | 561 | unrouted (403) | — | — | — | — | — |
| `create` | 687 | GET routed (403) | — | — | — | — | — |
| `store` | 692 | POST routed (403) | — | — | — | — | — |
| `show` | 700 | GET/HEAD web + api | `tenant.smart-timetable.timetable.view` | none (read) | — | — | STM-11 |
| `edit` | 801 | GET routed | `tenant.smart-timetable.timetable.update` | none (read) | — | — | STM-11 |
| `update` | 886 | PUT/PATCH web + api | `tenant.smart-timetable.timetable.update` (Gate + FormRequest, double) | controller `DB::transaction` | `'Updated'` / `'Published'` | tt_timetables, sys_activity_logs | STM-02, STM-03, STM-05, STM-07, STM-11 |
| `destroy` | 1016 | DELETE web + api | `tenant.smart-timetable.timetable.delete` | controller `DB::beginTransaction` (manual) | `'Trashed'` | tt_timetable_cells, tt_timetable_cell_teachers, tt_generation_runs, tt_conflict_detection, tt_change_logs, tt_teacher_workloads, tt_constraint_violations, tt_timetables, sys_activity_logs | STM-01, STM-02, STM-03, STM-04, STM-11 |
| `timetableConfig` | 1080 | unrouted | `tenant.smart-timetable.config.viewAny` | none (read) | — | — | STM-08, STM-14 |
| `timetableOperation` | 1103 | unrouted (403) | — | — | — | — | — |
| `timetableMaster` | 1110 | unrouted | `tenant.smart-timetable.timetable.viewAny` | none (read) | — | — | STM-08, STM-10, STM-12, STM-14, STM-17 |
| `timetableGeneration` | 1302 | unrouted | `tenant.smart-timetable.timetable.generate` | none (read) | — | — | STM-08, STM-14, STM-17 |
| `timetableReports` | 1344 | unrouted (403) | — | — | — | — | — |
| `timetableValidation` | 1354 | unrouted (403) | — | — | — | — | — |
| `generateWithPrime` | 1361 | unrouted (403) | — | — | — | — | — |
| `constraintManagement` | 1496 | unrouted | `tenant.smart-timetable.constraint.viewAny` | none (read) | — | — | STM-08, STM-14, STM-17 |
| `preRequisitesSetup` | 1559 | unrouted | — | — | — | — | STM-08 |
| `timetableConfiguration` | 1565 | unrouted | — | — | — | — | STM-08 |
| `timetableMasters` | 1571 | unrouted | — | — | — | — | STM-08 |
| `timetableRequirement` | 1577 | unrouted | — | — | — | — | STM-08 |
| `constraintEngine` | 1582 | unrouted | `tenant.smart-timetable.constraint.viewAny` | none (read) | — | — | STM-08, STM-14 |
| `resourceAvailability` | 1632 | unrouted | — | — | — | — | STM-08 |
| `timetablePreparation` | 1638 | unrouted | — | — | — | — | STM-08 |
| `viewAndRefinement` | 1643 | unrouted | `tenant.smart-timetable.timetable.viewAny` | none (read) | — | — | STM-08, STM-14 |
| `reportsAndLogs` | 1708 | unrouted | — | — | — | — | STM-08 |
| `publishTimetable` | 1716 | unrouted (403) | — | — | — | — | — |
| `unpublishTimetable` | 1726 | unrouted (403) | — | — | — | — | — |
| `substituteManagement` | 1733 | unrouted | `tenant.smart-timetable.timetable.viewAny` | none (read) | — | — | STM-08, STM-14 |

## 6. Findings

### F1 — Errors

#### STM-01 · B · ERR-01 — `destroy()` flashes the raw exception message to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:1073-1076`, method `destroy()` |
| **Root cause** | The catch builds the flash from `$e->getMessage()` directly, so a DB error's SQLState and table/column names are handed to the user verbatim. |
| **Consequence** | Any database failure while deleting a timetable shows the raw SQL error on screen (schema names leak), and the message is also written to the log with `getMessage()` only, losing the trace. |
| **Reproduce** | DELETE a timetable that has rows in a missing FK table and read the flash — it contains the SQLSTATE text. |
| **Fix approach** | Drop the catch entirely (D1): use `DB::transaction(fn () => ...)` which rolls back and rethrows, and show a fixed message. |
| **Plan item** | STM-01 in `02-fix-plan.md` §1 |

```php
            return redirect()->back()->with(
                'error',
                'Failed to delete timetable: '.$e->getMessage()
            );
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
1005:                'error' => $e->getMessage(),
1069:                'error' => $e->getMessage(),
1075:                'Failed to delete timetable: '.$e->getMessage()
```

#### STM-02 · M · ERR-05 — both write-path catches log `getMessage()` without the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message; `getMessage()` alone loses the trace* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:1003-1006` (`update()`) and `1067-1071` (`destroy()`) |
| **Root cause** | The two catch blocks pass `'error' => $e->getMessage()` (destroy also `'trace' => $e->getTraceAsString()`), which keeps the text but drops the exception object and its stack context. |
| **Consequence** | A failure record cannot be traced from the message alone — the standard Laravel log/reporting pipeline is bypassed. |
| **Reproduce** | Static only — confirmed by reading the catch blocks; the fix removes both catches so this disappears. |
| **Fix approach** | Remove both try/catch wrappers (D1); the central handler in `bootstrap/app.php` reports the exception. |
| **Plan item** | none — resolved by plan items STM-01 and STM-05, which remove both catches; see `02-fix-plan.md` §10 |

```php
        } catch (\Throwable $e) {
            Log::error('SmartTimetableController::update failed', [
                'timetable_id' => $timetable->id,
                'error' => $e->getMessage(),
            ]);
```

**Evidence**
```
$ grep -n "catch (" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
1002:        } catch (\Throwable $e) {
1062:        } catch (\Exception $e) {
```

#### STM-03 · M · ERR-00 — controller try/catch that no D2 shape allows

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M under D1) — *the Laravel idiom: no try/catch in controllers; `DB::transaction()` rolls back and rethrows* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:916` and `1036`, methods `update()` and `destroy()` |
| **Root cause** | Both mutations wrap a transaction in a controller try/catch. `update()` catches `\Throwable` around a closure that rolls itself back; `destroy()` catches `\Exception` around a manual transaction. Neither is the D2 truncate-then-rebuild shape, and the `findOrFail()` calls sit safely outside, so the catches add nothing the framework does not already do. |
| **Consequence** | Every write failure is turned into a redirect-with-prepopulated-form instead of the framework 500 page — hiding real errors and duplicating the renderer. |
| **Reproduce** | Static only — confirmed by `grep -n "try {"`. |
| **Fix approach** | Delete the wrappers; keep a plain `DB::transaction` closure in `update()` and a closure + fixed-message redirect in `destroy()`. |
| **Plan item** | none — resolved by plan items STM-01 and STM-05; see `02-fix-plan.md` §10 |

```php
        try {
            DB::beginTransaction();
```

**Evidence**
```
$ grep -n "try {" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
916:        try {
1036:        try {
```

### F2 — Transactions and audit

#### STM-04 · M · TXN-02 — `destroy()` uses manual `beginTransaction`/`commit`/`rollBack` and nests a second transaction

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => …)`, not manual begin/commit/rollBack; never return between them* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:1037-1055`, method `destroy()` |
| **Root cause** | `destroy()` opens a manual `DB::beginTransaction()`, commits manually, and on error calls `DB::rollBack()` guarded by `transactionLevel()`. Inside it, `TimetableStorageService::purgeChildrenOf()` opens its own `DB::transaction` — a nested savepoint transaction mixed with manual control. |
| **Consequence** | The manual control leaks an open transaction on any early return path, and the nesting relies on MySQL savepoint semantics that a careless future edit can break. |
| **Reproduce** | Static only — confirmed by reading lines 1036-1055. |
| **Fix approach** | Replace with one `DB::transaction(function () use ($timetable) { ... });` closure; the inner `purgeChildrenOf()` transaction then becomes a harmless savepoint. |
| **Plan item** | none — the same rewrite is plan item STM-01; see `02-fix-plan.md` §10 |

```php
        try {
            DB::beginTransaction();

            // Hard-purge every FK child row (cells, teacher pivots, generation
            // runs, conflict detections, change logs, teacher workloads,
            // constraint violations). Centralised in TimetableStorageService
            // so all three delete paths stay consistent.
            TimetableStorageService::purgeChildrenOf((int) $timetable->id);
```

**Evidence**
```
$ grep -n "DB::beginTransaction\|DB::commit\|DB::rollBack" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
1037:            DB::beginTransaction();
1055:            DB::commit();
1064:                DB::rollBack();
```

#### STM-05 · M · TXN-05 — `update()` builds the HTTP redirect inside the transaction closure

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — *the transaction closure returns data; build `redirect()`/`response()` after it* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:996-1001`, method `update()` |
| **Root cause** | The closure ends with `return redirect()->route(...)->with(...)` — the response is assembled while the transaction is still open and the closure rethrows nothing. |
| **Consequence** | Nothing breaks today, but the pattern invites rendering or flash work inside the transaction window; the rule wants the closure to return the model and the redirect built outside. |
| **Reproduce** | Static only — read lines 996-1001. |
| **Fix approach** | Closure returns `$timetable`; the redirect is built after `DB::transaction(...)`. |
| **Plan item** | STM-05 in `02-fix-plan.md` §3 |

```php
                return redirect()
                    ->route('smart-timetable.timetable.timetableGeneration', ['tab' => 'timetable'])
                    ->with('success', $isPublishing
                        ? 'Timetable published successfully.'
                        : 'Timetable updated successfully.');
```

**Evidence**
```
$ sed -n '996,1001p' Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
996:                return redirect()
997:                    ->route('smart-timetable.timetable.timetableGeneration', ['tab' => 'timetable'])
998:                    ->with('success', $isPublishing
999:                        ? 'Timetable published successfully.'
1000:                        : 'Timetable updated successfully.');
1001:            });
```

### F3 — Authorization

#### STM-06 · M · AUTH-06 — `SmartTimetablePolicy` is registered but nothing consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals; report every Policy that nothing consults* |
| **Where** | `Modules/SmartTimetable/app/Policies/SmartTimetablePolicy.php:1-46` and `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:267` |
| **Root cause** | `Gate::policy(Timetable::class, SmartTimetablePolicy::class)` registers the policy, but every method in this controller (and every other SmartTimetable controller, verified by grep) calls `Gate::authorize('tenant.smart-timetable.*')` — a permission string handled by the Spatie permission bridge, which never hits a policy. The policy's `viewAny/view/create/update/delete/generate/export` methods are unreachable. |
| **Consequence** | A second, duplicated source of truth for the same permissions: whoever edits the policy is editing code that runs nowhere, and the authorization reality lives only in string literals. |
| **Reproduce** | Static only — `grep -rn "authorize(" Modules/SmartTimetable/app/Http/Controllers/*.php` shows only string grants, never `$this->authorize('view', $timetable)`. |
| **Fix approach** | Decision: keep the string grants and remove the dead registration, or migrate the grants to policy calls during the split. |
| **Plan item** | STM-06 (DECISION) in `02-fix-plan.md` §9 |

```php
    public function viewAny(User $user): bool
    {
        return $user->hasPermissionTo('tenant.smart-timetable.timetable.viewAny');
    }
```

**Evidence**
```
$ grep -rn "SmartTimetablePolicy" --include=*.php . | grep -v finale
./Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:267:        Gate::policy(Timetable::class, SmartTimetablePolicy::class);
$ grep -noE "Gate::authorize\('[^']+'\)" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php | wc -l
14
```

#### STM-07 · L · AUTH-04 — `update()` authorizes the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice; keep one* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:888` and `Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php:24-27` |
| **Root cause** | `UpdateTimetableRequest::authorize()` already returns `auth()->user()->can('tenant.smart-timetable.timetable.update')` and FormRequests run first; the controller then calls `Gate::authorize` with the identical string. |
| **Consequence** | The Gate call is dead weight — one permission is evaluated twice per update, and the two can drift. |
| **Reproduce** | Static only. |
| **Fix approach** | Remove the controller-level `Gate::authorize(...);` line from `update()`; the FormRequest stays as the single check. |
| **Plan item** | none — removed by the plan item STM-05 rewrite; see `02-fix-plan.md` §10 |

```php
    public function update(UpdateTimetableRequest $request, $id)
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');
```

**Evidence**
```
$ grep -n "authorize" Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php
24:        return auth()->user()->can('tenant.smart-timetable.timetable.update');
```

### F4 — Validation and input

clean — `UpdateTimetableRequest` uses `validated()`, typed rules, a unique rule that mirrors the `uq_tt_name_term_type` index, and a `withValidator()` publish gate; executed in tinker against the tenant: valid payload `passes=yes errors=[]`, invalid status + bad date `badpasses=no errors=["status","effective_from"]`. `update()` consumes `$request->validated()`; optional fields are read with `?? null`. No `$request->all()` into models.

### F5 — Routes

#### STM-08 · M · RTE-03 — 16 public methods are unrouted but carry live bodies and Gate checks

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or deliberately disabled (`abort(403)`)* (final-audit.md D5) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:226, 358, 1080, 1110, 1302, 1496, 1559, 1565, 1571, 1577, 1582, 1632, 1638, 1643, 1708, 1733` |
| **Root cause** | The module was split into `TimetableMenuController`, `TimetablePageController`, `TimetableGenerationController` and others, which now own these exact screens; this controller kept full duplicated bodies (and private helpers) with no route pointing at them. `generate()` even chains to `generateWithPrime()`, which `abort(403)`s — so the method is dead twice. |
| **Consequence** | 16 dead screens (with their queries and views) stay in the codebase, untestable and drifting from the live copies; a future route addition could resurrect stale logic. |
| **Reproduce** | `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list` lists only the 12 resource/api routes. |
| **Fix approach** | Decision: D5 says each unrouted body becomes `abort(403, '...')` with a NOT ROUTED comment; folding this into the split pass is the cheaper option. |
| **Plan item** | STM-08 (DECISION) in `02-fix-plan.md` §9 |

```php
    public function timetableConfig()
    {
        Gate::authorize('tenant.smart-timetable.config.viewAny');

        $ttConfigs = TtConfig::orderBy('ordinal')->paginate(10);
```

**Evidence**
```
$ grep -c "public function" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
32
```

### F6 — Controller shape

#### STM-09 · M · CTL-01 — god controller: 1,784 lines, 32 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — *over 1,000 lines or 25 public methods → split by responsibility* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:68-1784` |
| **Root cause** | Seven responsibilities (resource CRUD, generation, preview, config, masters, constraint engine, substitute management) were consolidated in one class before the split controllers took most of them over; the file was never reduced. |
| **Consequence** | The file cannot be reviewed as one unit; the dead duplicates hide the five live methods. |
| **Reproduce** | `wc -l Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php` → `1784`. |
| **Fix approach** | Defer per D3; the split pass reduces this controller to the resource CRUD and removes the duplicates (which feeds STM-08). |
| **Plan item** | STM-09 (DECISION) in `02-fix-plan.md` §9 |

```php
class SmartTimetableController extends Controller
{
```

**Evidence**
```
$ wc -l Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
1784 Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
```

#### STM-10 · H · CTL-02 — four methods exceed the 80/150-line limits

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *methods over 150 lines are H; over 80 are M (extract)*. Severity raised to the rulebook default for the three 150+ methods. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:73` (`index` 151 lines), `:358` (`preview` 178), `:1110` (`timetableMaster` 190), `:886` (`update` 125) |
| **Root cause** | The methods load a dozen lists, build payloads and compute stats inline instead of delegating to services. |
| **Consequence** | Any behavioural change touches hundreds of lines with no unit boundary; the readability cost compounds with STM-09. |
| **Reproduce** | Static only — measured from `grep -n "public function"` line starts. |
| **Fix approach** | Defer to the split pass; extraction alone would leave the same code split across two files. |
| **Plan item** | none — deferred with STM-09; see `02-fix-plan.md` §10 |

```php
    public function index(): mixed
    {
        Gate::authorize('tenant.smart-timetable.timetable.viewAny');
```

**Evidence**
```
$ grep -nE 'public function ' Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php | grep -E 'index|preview|timetableMaster|update'
73:    public function index(): mixed
358:    public function preview(Timetable $timetable)
1110:    public function timetableMaster(): mixed
886:    public function update(UpdateTimetableRequest $request, $id)
```

#### STM-11 · M · CTL-03 — `show`/`edit`/`update`/`destroy` take `$id` + `findOrFail` instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:700, 801, 886, 1016` |
| **Root cause** | The route parameter is `{smart_timetable_management}` (web) / `{smarttimetable}` (api) while the method arguments are `$id`; the parameter-variable-name mismatch means implicit binding never fires, so each method re-resolves with `Timetable::findOrFail($id)`. |
| **Consequence** | Four extra find queries per request and a 404 that bypasses binding scoping; harmless today because `findOrFail` behaves identically. |
| **Reproduce** | Static only — compare `parameterNames()` with the method signatures. |
| **Fix approach** | Defer: switching to binding requires renaming route parameters in the shared route files, which is out of bounds for this plan; fold into the split pass. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.timetable.view');

        return redirect()->route('smart-timetable.timetable.preview', ['timetable' => $id]);
```

**Evidence**
```
$ grep -n "findOrFail" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
807:        $timetable = Timetable::findOrFail($id);
890:        $timetable = Timetable::findOrFail($id);
1023:        $timetable = Timetable::findOrFail($id);
```

#### STM-12 · M · CTL-07 — `compact()` with 28 variables in `index()`, 18 in `timetableMaster()`

| Field | Value |
|---|---|
| **Rule** | CTL-07 (M) — *no compact() of more than about 15 variables (build a view model/array)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:194-223` and `1280-1299` |
| **Root cause** | The index page hands 28 local variables to one Blade template; `timetableMaster()` hands 18. |
| **Consequence** | The view contract is invisible from the template side; a missing variable silently echoes empty. |
| **Reproduce** | Static only. |
| **Fix approach** | Build a named payload array; defer to the split pass so the dead pages do not create busywork. |
| **Plan item** | none — deferred with STM-09; see `02-fix-plan.md` §10 |

```php
        return view('smarttimetable::smart-timetable.index', compact(
            'timetableTypes',
            'classGroupRequirements',
```

**Evidence**
```
$ sed -n '194,196p' Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
194:        return view('smarttimetable::smart-timetable.index', compact(
195:            'timetableTypes',
196:            'classGroupRequirements',
```

#### STM-13 · M · CTL-10 — 9 private helpers and long commented blocks are unreachable

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods, commented-out blocks* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:263, 316, 344, 568, 591, 614, 629, 634, 1380, 1483` |
| **Root cause** | Helpers built for the generation/preview flow (`createConstraintManager`, `createConstraintManagerFromDatabase`, `resolveConstraintClass`, `loadActivities`, `loadActivitiesForActiveClassSections`, `loadHardConstraints`, `loadSchoolDays`, `loadPeriodSet`, `buildPlacementDiagnostics`, `resolveDefaultTeacherAssignmentRoleId`) lost their only callers when the generation methods became unrouted. Large commented-out constraint blocks remain (lines 270-308, 349-352). |
| **Consequence** | Dead code that still `new`s services and loads constraints — a maintenance trap and a false signal that generation lives here. |
| **Reproduce** | Static only — `grep -c` shows each name exactly once (definition) or twice (definition + one call that is itself dead). |
| **Fix approach** | Remove in the split pass; do not touch in this plan because two helpers are reachable from the same dead `generate()` chain. |
| **Plan item** | none — deferred with STM-09; see `02-fix-plan.md` §10 |

```php
    private function createConstraintManager(Collection $activities, Collection $days, Collection $periods): ConstraintManager
    {
        $constraintManager = new ConstraintManager;
```

**Evidence**
```
$ for m in createConstraintManager loadActivities loadPeriodSet buildPlacementDiagnostics; do printf "%-40s %s\n" "$m" "$(grep -c "$m" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php)"; done
createConstraintManager                 2
loadActivities                          2
loadPeriodSet                           1
buildPlacementDiagnostics               1
```

#### STM-14 · L · CTL-04 — public methods without declared return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:226, 358, 541, 551, 561, 687, 692, 700, 801, 886, 1016, 1080, 1103, 1302, 1344, 1354, 1361, 1496` |
| **Root cause** | Only 9 of 32 public methods declare a return type; the rest rely on inference. |
| **Consequence** | No static guarantee a method returns what its route expects; a wrong return silently 500s later. |
| **Reproduce** | Static only — `grep -n "public function"`. |
| **Fix approach** | Add return types; defer to the split pass so dead methods are not typed and then deleted. |
| **Plan item** | none — deferred with STM-09; see `02-fix-plan.md` §10 |

```php
    public function generate(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.timetable.generate');
```

**Evidence**
```
$ grep -n "public function" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php | grep -cE ': (mixed|JsonResponse)'
6
```

### F7 — Models

clean — `SubActivity` (owned) is an 11-line backward-compatibility alias over `Modules\TimetableFoundation\Models\SubActivity`; the real model's table `tt_sub_activities` exists (0 live rows verified in the tenant DB). `SmartTimetablePolicy` (owned) is a thin permission-mapping policy (its dead-registration problem is STM-06). All other models are linked to their owner reports; none showed a defect in how this controller uses them.

### F8 — Services and jobs

clean — the controller only `use`s constraint/generation services that are all owned by other reports; their usage here is confined to the dead generation helpers (STM-13). `TimetableReadiness::check()`/`unplacedPeriods()`, `PreviewGridState::build()`, and `TimetableStorageService::purgeChildrenOf()` are called with correct arguments. No HTTP inside any service call made by this controller.

### F9 — Queries and performance

#### STM-15 · M · QRY-13 — 11 paginators on the index page share one `page` parameter

| Field | Value |
|---|---|
| **Rule** | QRY-13 (L→M, raised) — *multiple paginators on one page use distinct page names* (rulebook default L; raised to M because a paginator click re-pages all 11 lists and changes the visible page of every tab) |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:85-90, 125-127, 139, 192`, method `index()` |
| **Root cause** | Eleven `paginate(10)` calls with no third `pageName` argument all read `?page=`, so clicking page 2 of the Constraints list also pages Teachers, Rooms, Timetables, etc. on the same response. |
| **Consequence** | A user flipping a list's paginator loses their place in every other list, and two paginators cannot be navigated independently. |
| **Reproduce** | Open `/smart-timetable/smart-timetable-management`, click page 2 on the Constraints tab, watch all other tabs' lists re-page. |
| **Fix approach** | Give each `paginate(10)` a distinct page name (`con_page`, `tu_page`, `cs_page`, ...) — the same pattern `timetableMaster()` already uses (`tu_page`, `ru_page`, `ar_page`, ...). |
| **Plan item** | STM-15 in `02-fix-plan.md` §6 |

```php
        $constraints = Constraint::paginate(10);
        $teachersUnavailable = TeacherUnavailable::paginate(10);
        $classSubgroups = ClassSubjectSubgroup::paginate(10);
        $roomsUnavailable = RoomUnavailable::paginate(10);
        $assignmentRoles = TeacherAssignmentRole::paginate(10);
        $classGroupRequirements = RequirementConsolidation::paginate(10);
```

**Evidence**
```
$ sed -n '85,90p' Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
85:        $constraints = Constraint::paginate(10);
86:        $teachersUnavailable = TeacherUnavailable::paginate(10);
87:        $classSubgroups = ClassSubjectSubgroup::paginate(10);
88:        $roomsUnavailable = RoomUnavailable::paginate(10);
89:        $assignmentRoles = TeacherAssignmentRole::paginate(10);
90:        $classGroupRequirements = RequirementConsolidation::paginate(10);
```

#### STM-16 · M · QRY-05/QRY-15 — `index()` loads and groups the whole activities table in PHP, plus two full-table dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M) — *aggregate in SQL, not `->get()->groupBy()`*; QRY-15 (M) — *don't load every row of a big table for a form* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:92-124, 162, 183`, method `index()` |
| **Root cause** | Every active activity is fetched with a deep eager load and grouped client-side by class-section key; `Subject::orderBy('name')->get()` and `RequirementConsolidation::get()` load their full tables; the requirement data is passed to the view and read by no blade (a comment at 174-182 admits this). |
| **Consequence** | On a real school (hundreds of activities), the hub page pulls every activity, subject and requirement row into memory to render a dashboard. |
| **Reproduce** | Static only — confirmed by reading the grouping block; the tenant currently has 0 activities so it is latent. |
| **Fix approach** | Defer: the page moves to the split controllers (STM-09); there it should group in SQL or paginate, and drop the unread requirements. |
| **Plan item** | none — deferred with STM-09; see `02-fix-plan.md` §10 |

```php
        $groupedActivities = Activity::with([
            'class',
            'section',
            'subject',
            'studyFormat',
            'subjectType',
            'subjectStudyFormat.subject',
```

**Evidence**
```
$ sed -n '111,112p' Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
111:            ->where('is_active', true)
112:            ->get()
113:            ->groupBy(fn ($activity) => ($activity->class->code ?? 'unknown').'-'.($activity->section->code ?? 'unknown'))
```

#### STM-17 · L · QRY-08 — 29 leading-wildcard `LIKE '%...%'` searches in three search filters

| Field | Value |
|---|---|
| **Rule** | QRY-08 (L) — *leading-wildcard LIKE can't use an index; acceptable on small tables* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:1130, 1314, 1510`, methods `timetableMaster()`, `timetableGeneration()`, `constraintManagement()` |
| **Root cause** | Each search filter wraps both `name` and `code` columns in `like "%{$s}%"`. |
| **Consequence** | Full scans on the filtered tables whenever a user searches; fine today (small/empty tables), a pinch point on big schools. |
| **Reproduce** | Static only. |
| **Fix approach** | None in this plan — the three methods are unrouted (STM-08); keep the searches as-is for the split pass. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
                $q->where('name', 'like', "%{$s}%")
                    ->orWhere('code', 'like', "%{$s}%");
```

**Evidence**
```
$ grep -c "like \"%{\$s}%\"" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
29
```

### F10 — Views

clean — `index.blade.php` and `edit.blade.php` (the two routed views) and all partials under `smart-timetable/partials/` contain no `Model::`, `DB::`, `->where(`, `->get()` or `{!!` patterns (`grep -rnE '::where|::all\(|::get\(|::count\(|DB::' Modules/SmartTimetable/resources/views/smart-timetable/` → no output).

### F11 — Security and tenancy

clean — no `env()` outside config (grep → none in the controller); no request bodies logged (`Log::error(... $request->all())` absent); no hard-coded ids or `?? 1` fallbacks; no personal data over-exposed; all six permission strings exist in `config/permissionslist.php` and are seeded (roles 1 and 2 hold all six). `AcademicSession` is explicitly on the central `global_master_mysql` connection, so reading it from tenant context is intentional, not a TEN-03 hole (cross-cutting note in §7).

### F12 — Style

#### STM-18 · L · STY-01/02/05/06 — controller style debts

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) strict_types; STY-02 (L) Pint-clean; STY-05 (L) one import per class; STY-06 (L) consistent `Log::` |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php:1, 49/52, 53/54, 1067` |
| **Root cause** | No `declare(strict_types=1);`; the same class is imported twice (`ClassSubjectSubgroup` lines 49+52, `Config` lines 53+54); `\Log::error` at line 1067 while the file imports `Log`; ~25 emoji-marker comments. |
| **Consequence** | Pint and the architecture conventions would flag the file; the duplicate `Config` import is the riskiest (two names for one class). |
| **Reproduce** | Static only — `grep -n "use Modules\\\\TimetableFoundation"`. |
| **Fix approach** | Dedupe the imports now; the messy comment scrub rides the split pass. |
| **Plan item** | none — see `02-fix-plan.md` §10 (the `\Log::` line dies with STM-01, the import dedupe is a one-line Pint-style fix the fixer agent can do with STM-05) |

```php
use Modules\TimetableFoundation\Models\ClassSubjectSubgroup;
use Modules\TimetableFoundation\Models\ClassSubjectSubgroup as ClassSubgroup;
```

**Evidence**
```
$ grep -n "use Modules\\\\TimetableFoundation" Modules/SmartTimetable/app/Http/Controllers/SmartTimetableController.php
49:use Modules\TimetableFoundation\Models\ClassSubjectSubgroup;
52:use Modules\TimetableFoundation\Models\ClassSubjectSubgroup as ClassSubgroup;
53:use Modules\TimetableFoundation\Models\Config as TimetableConfig;
54:use Modules\TimetableFoundation\Models\Config as TtConfig;
```

#### STM-19 · L · STY-04 — emoji-marker comments in `UpdateTimetableRequest`

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php:17, 58, 66, 128` |
| **Root cause** | Informative comments use `⚠` / `⛔` / `⭐` markers. |
| **Consequence** | None functional; inconsistent with the no-emoji writing convention. |
| **Reproduce** | Static only. |
| **Fix approach** | Scrub markers when the file is next touched; no dedicated pass needed. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
 * ⚠ Deliberately covers name / description / effective_from / effective_to ONLY.
```

**Evidence**
```
$ grep -n "⚠" Modules/SmartTimetable/app/Http/Requests/UpdateTimetableRequest.php | wc -l
4
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method (writes) | 1 wrong data? | 2 delete-before-store? | 3 duplicate impls? | 4 soft-delete × unique trap? | 5 race? | 6 auth hole? | 7 message lies? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `update()` — tt_timetables + sys_activity_logs (+ `archiveOthersInScope` on publish) | ok — `is_active` follows status, publish stamps only on transition (913-935) | ok — no deletes | ⚠ publish side-effects mirrored from `TimetablePublishController` by design; comment at 953-971 forbids re-adding `makeSchoolDefault()` | ok — unique rule mirrors `uq_tt_name_term_type` in the FormRequest (VAL-04) | ⚠ the readiness gate runs in the FormRequest (before tx); two concurrent publishes both pass then `archiveOthersInScope()` runs in the tx — acceptable, single-row intent | ok — Gate + FormRequest (double, STM-07) | ok — `'Published'`/`'Updated'` match the action; flash matches event | ok — `confirm_publish` bypass is logged (`readiness_bypassed`) |
| `destroy()` — 7 child tables hard-purged, tt_timetables soft-deleted, sys_activity_logs | ok — purge is scoped to the FK `timetable_id` | ⚠ header soft-delete happens AFTER children hard-purge; a Restore from trash returns an EMPTY timetable (cells already gone) — a soft-delete/FK mismatch the trash UX does not advertise (cross-cutting with `timetable.restore` in TimetableGenerationController) | ok — purge centralised in `TimetableStorageService::purgeChildrenOf` | ⚠ STM-04 + savepoint nesting | ⚠ see STM-04 | ok — Gate + status guard (1029-1034) | ⚠ STM-01 (raw error shown) | ok |

Note: `generate()` (unrouted) writes nothing — it merges inputs then calls `generateWithPrime()`, which aborts 403; no mutation is reachable from it.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` (`purgeChildrenOf`) | Opens its own `DB::transaction` inside the caller's manual transaction (savepoint nesting) and hard-purges children that a later Restore would expect under a soft-deleted header — delete/restore semantics worth a review | TXN-02, MDL-03 | TimetableGenerationController report (owner) |
| `Modules/Prime/.../AcademicSession` | Central model (`global_master_mysql`) read directly from tenant contexts across the module; intentional, but a whole-app pattern to keep consistent | TEN-03 | main session |
| `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:267` | `Gate::policy(Timetable::class, SmartTimetablePolicy::class)` registers a policy no controller consults (STM-06) — affects the whole module's authz | AUTH-06 | SmartTimetable module |
| Duplicated screens across `TimetableMenuController`, `TimetablePageController`, `TimetableGenerationController`, `TimetablePreviewController`, `TimetablePublishController` | These controllers own the live copies of the 16 unrouted methods here — the audit of each is in its own report | SVC-04 | per-owner reports |

## 8. Not covered, and why

- **Browser rendering** of `index.blade.php` / `edit.blade.php` was not exercised (audit is read-only, D4); views were checked statically for query/XSS patterns only.
- **`UpdateTimetableRequest` with a real PUBLISHED transition** — the tenant has 0 timetables, so the `withValidator()` publish gate and `TimetableReadiness` check could only be executed with an empty result; the non-PUBLISHED and invalid payload paths were executed (evidence in F4).
- **Relations on the linked models** (Timetable, Constraint, Activity, ...) were not re-proven here — they are owned by the linked reports.
- **API behaviour of `index()`** (returns an HTML view under `auth:sanctum`) was noted but not exercised; it follows from the shared controller.