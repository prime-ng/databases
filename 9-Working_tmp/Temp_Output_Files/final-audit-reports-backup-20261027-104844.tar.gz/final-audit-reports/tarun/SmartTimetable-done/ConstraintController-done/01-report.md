# Final Audit — SmartTimetable / ConstraintController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php` (540 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `GET /smart-timetable/constraint` (redirects to the engine menu) · `GET /smart-timetable/constraint-engine?tab=constraints` (page + Add dialog, owned by TimetableMenuController) · `GET /smart-timetable/constraint/create/{categoryCode}` · `GET /smart-timetable/constraint/{constraint}/edit-by-category` · `GET/POST /smart-timetable/constraint` · `GET /smart-timetable/constraint/{constraint}` (show) · `GET /smart-timetable/constraint/{constraint}/edit` · `PUT /smart-timetable/constraint/{constraint}` · `DELETE /smart-timetable/constraint/{constraint}` · `GET /smart-timetable/constraint/trash/view` · `GET /smart-timetable/constraint/{id}/restore` · `DELETE /smart-timetable/constraint/{id}/force-delete` · `POST /smart-timetable/constraint/{constraint}/toggle-status` |
| Menu path | Smart Timetable → Constraint Engine → Constraints tab |
| Who uses it | Tenant roles 1 and 2. Measured: `sys_permissions` id 1672 (`tenant.smart-timetable.constraint.create`) is granted to role_id 1 and 2. All 8 constraint permission names exist with exact names in the tenant DB. |
| What a user does here | Creates, edits, activates/deactivates, trashes, restores and permanently deletes timetable constraint rules (teacher availability, class rules, room space, global policy, inter-activity). Each rule has a type, an optional target (teacher/class/room/activity), a weight, hard/soft flag, effective dates and JSON parameters. |
| Tables written | `tt_constraints`, `sys_activity_logs` (via the `activityLog()` helper) |
| Tables read | `tt_constraint_types`, `tt_constraint_category_scopes`, `tt_constraints`, `sch_*` school-setup tables (Room/SchoolClass/Section/Teacher), `academic terms`; on the generation path also the constraint service cluster (Constraint, ConstraintType) via `DatabaseConstraintService` |
| Live data | `tt_constraints`: 6 total, 5 active, 0 trashed. `tt_constraint_types`: 10 rows. Permission rows: exactly 1 each of `viewAny/view/create/update/delete/restore/forceDelete/export`. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**. The live data was measured on `xyz_school_00000000000040008000_202627` (test.localhost).

## 1. Verdict

Not production-ready. A school operator can hit two blocker-level leaks of raw exception text — store and update print the DB driver message, table names and all, to the browser. The single worst finding is deeper: the constraint engine this screen feeds silently ignores nearly every rule the operator saves. All six live constraint types resolve to `GenericHardConstraint`/`GenericSoftConstraint` classes that cannot express the stored rule (lunch breaks, max lessons, no gaps), `ConstraintManager` only rejects a violating placement when the verbose-logging config flag happens to be on, and the factory reads model attributes that do not exist so effective dates and applicable days are always lost. Fixing that cluster is a real engine change (5 DECISION items). The controller's own transaction/audit discipline is good; the shape defects (try/catch under D1, no route model binding, duplicated form loaders) are mechanical. Rough effort: L — the controller items are a few hours, the engine cluster is a design pass plus implementation.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 4 | 4 | 12 | 3 | 5 | 23 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CST-01, CST-02, CST-03, CST-04, CST-05, CST-06, CST-20, CST-21 | F8 Services/Jobs | CST-16, CST-17, CST-18, CST-19, CST-20, CST-21, CST-22, CST-23 |
| F2 Transactions/Audit | TXN-05 folded into CST-01/02/05/06 · TXN-04 clean | F9 Queries/Perf | CST-12 (folded into CST-11) |
| F3 Authorization | CST-08, CST-14 | F10 Views | clean |
| F4 Validation | CST-09 | F11 Security/Tenancy | clean |
| F5 Routes | CST-07 | F12 Style | CST-15 |
| F6 Controller shape | CST-10, CST-11, CST-13 | F13 Deep read | CST-03, CST-04, CST-19 (table in F13) |
| F7 Models | none (Constraint linked) | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php` | controller | 540 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Http/Requests/StoreConstraintRequest.php` | FormRequest | 62 | this report | ✅ |
| 3 | `Modules/SmartTimetable/app/Http/Requests/UpdateConstraintRequest.php` | FormRequest | 59 | this report | ✅ |
| 4 | `Modules/SmartTimetable/app/Models/Constraint.php` | model | 255 | ↗ [tarun/SmartTimetable/ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked (usage checked) |
| 5 | `Modules/SmartTimetable/app/Models/ConstraintCategoryScope.php` | model | — | ↗ [ConstraintCategoryScopeController](../ConstraintCategoryScopeController-done/01-report.md) | ↗ linked |
| 6 | `Modules/SmartTimetable/app/Models/ConstraintType.php` | model | — | ↗ [ConstraintTypeController](../ConstraintTypeController-done/01-report.md) | ↗ linked |
| 7 | `Modules/SmartTimetable/app/Models/Activity.php` | model | — | ↗ [TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 8 | `Modules/TimetableFoundation/app/Models/AcademicTerm.php` | model | — | ↗ [TimetableFoundation/AcademicTermController](../../../TimetableFoundation/AcademicTermController/01-report.md) | ↗ linked |
| 9 | `Modules/SchoolSetup/Models/{Room,SchoolClass,Section,Teacher}` | models | — | common (different-module SchoolSetup models) | common |
| 10 | `Modules/SmartTimetable/resources/views/constraint/*.blade.php` (show, edit, trash, create, index) | views | 15–224 | this report | ✅ |
| 11 | `Modules/SmartTimetable/resources/views/pages/partials/constraint-engine/constraints/{_create-modal,_list}.blade.php` + `pages/constraint-engine.blade.php` | views | — | ↗ [TimetableMenuController](../TimetableMenuController-done/01-report.md) page; usage of the create modal (posts to `constraint.store`) checked | ↗ linked |
| 12 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php` | service | 250 | this report (claimed) | ✅ |
| 13 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php` | service | 179 | this report (claimed) | ✅ |
| 14 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php` | service | 242 | this report (claimed) | ✅ |
| 15 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintRegistry.php` | service | 71 | this report (claimed) | ✅ |
| 16 | `Modules/SmartTimetable/app/Services/Constraints/ConstraintContext.php` | service | 73 | this report (claimed) | ✅ |
| 17 | `Modules/SmartTimetable/app/Services/Constraints/TimetableConstraint.php` | interface | 33 | this report (claimed) | ✅ |
| 18 | `Modules/SmartTimetable/app/Services/DatabaseConstraintService.php` | service | 104 | this report (claimed) | ✅ |
| 19 | `Modules/SmartTimetable/app/Services/Constraints/Hard/*` and `Soft/*` (70 classes) | services | 0–200 each | this report (grouped claim) | ✅ (grouped) |
| 20 | `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php` (registry block only) | provider | — | common (provider) — used as evidence for CST-19 | common |

No pre-applied files (nothing for this controller in `TimetableFoundation/PRE-APPLIED-2026-10-10.md`).

## 4. Routes

```
GET|HEAD  smart-timetable/constraint                                 smart-timetable.constraint.index                 Modules\SmartTimetable\Http\Controllers\ConstraintController@index
POST      smart-timetable/constraint                                 smart-timetable.constraint.store                 Modules\SmartTimetable\Http\Controllers\ConstraintController@store
GET|HEAD  smart-timetable/constraint/create/{categoryCode}           smart-timetable.constraint.createByCategory      Modules\SmartTimetable\Http\Controllers\ConstraintController@createByCategory
GET|HEAD  smart-timetable/constraint/trash/view                      smart-timetable.constraint.trashed               Modules\SmartTimetable\Http\Controllers\ConstraintController@trashedConstraint
GET|HEAD  smart-timetable/constraint/{constraint}                    smart-timetable.constraint.show                  Modules\SmartTimetable\Http\Controllers\ConstraintController@show
PUT|PATCH smart-timetable/constraint/{constraint}                    smart-timetable.constraint.update                Modules\SmartTimetable\Http\Controllers\ConstraintController@update
DELETE    smart-timetable/constraint/{constraint}                    smart-timetable.constraint.destroy               Modules\SmartTimetable\Http\Controllers\ConstraintController@destroy
GET|HEAD  smart-timetable/constraint/{constraint}/edit               smart-timetable.constraint.edit                  Modules\SmartTimetable\Http\Controllers\ConstraintController@edit
GET|HEAD  smart-timetable/constraint/{constraint}/edit-by-category   smart-timetable.constraint.editByCategory        Modules\SmartTimetable\Http\Controllers\ConstraintController@editByCategory
POST      smart-timetable/constraint/{constraint}/toggle-status      smart-timetable.constraint.toggleStatus          Modules\SmartTimetable\Http\Controllers\ConstraintController@toggleStatus
DELETE    smart-timetable/constraint/{id}/force-delete               smart-timetable.constraint.forceDelete           Modules\SmartTimetable\Http\Controllers\ConstraintController@forceDelete
GET|HEAD  smart-timetable/constraint/{id}/restore                    smart-timetable.constraint.restore               Modules\SmartTimetable\Http\Controllers\ConstraintController@restore
```

Unrouted public methods: `create()` (line 37) — deliberately not routed (`Route::resource(...)->except(['create'])`), body is `abort(403, ...)` with a NOT ROUTED comment; D5-compliant, no finding.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 27 | GET /constraint | `tenant.smart-timetable.constraint.viewAny` | none | — | none (redirect only) | clean |
| `create` | 37 | NOT ROUTED (abort 403) | — | none | — | none | clean (D5) |
| `createByCategory` | 52 | GET /constraint/create/{categoryCode} | `tenant.smart-timetable.constraint.create` | none | — | none | CST-11, CST-12 |
| `editByCategory` | 114 | GET /constraint/{constraint}/edit-by-category | `tenant.smart-timetable.constraint.update` | none | — | none | CST-08, CST-11, CST-12 |
| `store` | 179 | POST /constraint | `tenant.smart-timetable.constraint.create` (Gate + FormRequest) | controller `DB::transaction` | 'Created' | `tt_constraints`, `sys_activity_logs` | CST-01, CST-14 |
| `show` | 254 | GET /constraint/{constraint} | `tenant.smart-timetable.constraint.view` | none | — | none | CST-10 |
| `edit` | 276 | GET /constraint/{constraint}/edit | `tenant.smart-timetable.constraint.update` | none | — | none | CST-10 |
| `update` | 296 | PUT /constraint/{constraint} | `tenant.smart-timetable.constraint.update` (Gate + FormRequest) | controller `DB::transaction` | 'Updated' | `tt_constraints`, `sys_activity_logs` | CST-02, CST-14 |
| `destroy` | 364 | DELETE /constraint/{constraint} | `tenant.smart-timetable.constraint.delete` | controller `DB::transaction` | 'Trashed' | `tt_constraints`, `sys_activity_logs` | CST-03, CST-10 |
| `trashedConstraint` | 397 | GET /constraint/trash/view | `tenant.smart-timetable.constraint.restore` | none | — | none | clean |
| `restore` | 412 | GET /constraint/{id}/restore | `tenant.smart-timetable.constraint.restore` | controller `DB::transaction` | 'Restored' | `tt_constraints`, `sys_activity_logs` | CST-04, CST-07 |
| `forceDelete` | 439 | DELETE /constraint/{id}/force-delete | `tenant.smart-timetable.constraint.forceDelete` | controller `DB::transaction` | 'Deleted' | `tt_constraints`, `sys_activity_logs` | CST-05 |
| `toggleStatus` | 472 | POST /constraint/{constraint}/toggle-status | `tenant.smart-timetable.constraint.update` | controller `DB::transaction` | 'Toggled' | `tt_constraints`, `sys_activity_logs` | CST-06, CST-08 |

All transactions live in the controller (`DB::transaction` directly). No service on the write path.

## 6. Findings

### F1 — Errors

#### CST-01 · B · ERR-01 — store() prints the raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user: no `$e->getMessage()` in `withErrors`, `with('error')`, `json()`, or `back()` — SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:246-247`, method `store()` |
| **Root cause** | The generic `catch (\Throwable $e)` builds the flash from `$e->getMessage()`. When the DB throws (column error, constraint violation), the message contains SQL and table names. D1 settles ERR-00: a controller try/catch is a finding by itself, and this catch is not a D2 shape. |
| **Consequence** | A failed save shows the raw PDO message (table and column names) on the red flash instead of a generic message — a SQL-structure leak to every operator. |
| **Reproduce** | Submit the Add-constraint dialog with a `constraint_type_id` that passes `exists` but then fails at write time (e.g. pause the DB or force a column error), or submit so the create throws; the page redirects back with the exception text in the error flash. |
| **Fix approach** | Remove the try/catch (D1); keep `DB::transaction`; let the central handler render errors; build the redirect after the closure returns the model. |
| **Plan item** | CST-01 in `02-fix-plan.md` §1 |

```php
        } catch (\Throwable $e) {
            return back()->withInput()->with('error', 'Failed to create constraint: ' . $e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
247:            return back()->withInput()->with('error', 'Failed to create constraint: ' . $e->getMessage());
357:            return back()->withInput()->with('error', 'Failed to update constraint: ' . $e->getMessage());
```

#### CST-02 · B · ERR-01 — update() prints the raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user: no `$e->getMessage()` in `withErrors`, `with('error')`, `json()`, or `back()` — SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:356-357`, method `update()` |
| **Root cause** | Same catch shape as CST-01 on the update path: `'Failed to update constraint: ' . $e->getMessage()`. |
| **Consequence** | A failed edit shows the raw PDO message in the error flash. |
| **Reproduce** | Save an edit that throws at write time (same as CST-01). |
| **Fix approach** | Remove the try/catch (D1); return the redirect after the closure; the central handler owns the failure message. |
| **Plan item** | CST-02 in `02-fix-plan.md` §1 |

```php
        } catch (\Throwable $e) {
            return back()->withInput()->with('error', 'Failed to update constraint: ' . $e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
247:            return back()->withInput()->with('error', 'Failed to create constraint: ' . $e->getMessage());
357:            return back()->withInput()->with('error', 'Failed to update constraint: ' . $e->getMessage());
```

#### CST-03 · M · ERR-00 (D1) — destroy() keeps a controller try/catch; it also destroys the pre-trash active state

| Field | Value |
|---|---|
| **Rule** | ERR-00 (settled by D1) — *no try/catch in controllers; `DB::transaction` rolls back by itself; the central handler logs and renders errors; only the D2 shapes may catch* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:377-391`, method `destroy()` |
| **Root cause** | The generic `catch (\Throwable $e)` is not a D2 shape. Additionally `$constraint->is_active = false; $constraint->save();` overwrites the active flag on every trash (deep-read Q1: a write overwrites data it should not), which is what forces `restore()` to force `is_active = true` back (CST-04). |
| **Consequence** | A soft-deleted constraint loses its pre-trash active state, so restoring it silently reactivates a rule the school had turned off. The catch itself is the wrong error shape under D1. |
| **Reproduce** | Deactivate a constraint, trash it, restore it — it comes back active. |
| **Fix approach** | Drop the try/catch (D1) and drop the `is_active` flip; trash is a soft-delete only. The findOrFail stays outside the transaction. |
| **Plan item** | CST-03 in `02-fix-plan.md` §3 |

```php
        try {
            DB::transaction(function () use ($constraint) {
                $constraint->is_active = false;
                $constraint->save();
                $constraint->delete();

                activityLog($constraint, 'Trashed', ['message' => 'Constraint moved to trash.']);
            });

            return redirect()
                ->route('smart-timetable.menu.constraintEngine')
                ->with('success', 'Constraint moved to trash.');
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to trash constraint.');
        }
```

**Evidence**
```
$ grep -nE "public function destroy|is_active = false|catch \(" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
364:    public function destroy($id)
379:                $constraint->is_active = false;
389:        } catch (\Throwable $e) {
```

#### CST-04 · M · ERR-00 (D1) — restore() keeps a controller try/catch and forces the constraint active

| Field | Value |
|---|---|
| **Rule** | ERR-00 (settled by D1) — *no try/catch in controllers; only the D2 shapes may catch*; deep-read Q1 — *does any write overwrite data it should not?* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:419-433`, method `restore()` |
| **Root cause** | The generic catch is not a D2 shape. `$constraint->is_active = true; $constraint->save();` unconditionally overwrites the stored flag — it can never restore a constraint that was inactive before it was trashed, because `destroy()` wiped the flag (CST-03). |
| **Consequence** | Restoring a rule that was deactivated before trashing re-enables it in the generator; the catch is the wrong error shape. |
| **Reproduce** | Trash an inactive constraint and restore it from the trash page — it shows Active. |
| **Fix approach** | Drop the try/catch and drop the `is_active = true` line once CST-03 stops wiping the flag. |
| **Plan item** | CST-04 in `02-fix-plan.md` §3 |

```php
        try {
            DB::transaction(function () use ($constraint) {
                $constraint->restore();
                $constraint->is_active = true;
                $constraint->save();

                activityLog($constraint, 'Restored', ['message' => 'Constraint restored successfully.']);
            });

            return redirect()
                ->route('smart-timetable.constraint.trashed')
                ->with('success', 'Constraint restored.');
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to restore constraint.');
        }
```

**Evidence**
```
$ grep -nE "public function restore|is_active = true|catch \(" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
412:    public function restore($id)
422:                $constraint->is_active = true;
431:        } catch (\Throwable $e) {
```

#### CST-05 · M · ERR-00 (D1) — forceDelete() keeps a controller try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 (settled by D1) — *no try/catch in controllers; only the D2 shapes may catch* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:454-466`, method `forceDelete()` |
| **Root cause** | The generic `catch (\Throwable $e)` around `forceDelete()` is not a D2 shape. The comment (Rule A1 heritage) anticipates the RESTRICT error from `tt_teacher_unavailabilities`/`tt_room_unavailabilities`; under D1 the central handler reports that failure instead. |
| **Consequence** | A RESTRICT violation no longer gets a tailored "Failed to permanently delete" flash; it becomes a generic error page — the correct D1 trade-off, but a visible change. |
| **Reproduce** | Permanently delete a constraint that still has a teacher-unavailability child row; today you see the red flash, under D1 you see the generic 500 page. |
| **Fix approach** | Remove the try/catch; keep `DB::transaction`; return the redirect after the closure. |
| **Plan item** | CST-05 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($constraint) {
                $constraint->forceDelete();

                activityLog($constraint, 'Deleted', ['message' => 'Constraint permanently deleted.']);

                return redirect()
                    ->route('smart-timetable.constraint.trashed')
                    ->with('success', 'Constraint permanently deleted.');
            });
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed to permanently delete constraint.');
        }
```

**Evidence**
```
$ grep -nE "public function forceDelete|catch \(" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
439:    public function forceDelete($id)
464:        } catch (\Throwable $e) {
```

#### CST-06 · M · ERR-00 (D1) — toggleStatus() keeps a controller try/catch

| Field | Value |
|---|---|
| **Rule** | ERR-00 (settled by D1) — *no try/catch in controllers; only the D2 shapes may catch; never catch `RuntimeException`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:491-516`, method `toggleStatus()` |
| **Root cause** | The generic `catch (\Throwable $e)` is not a D2 shape, and the closure throws `\RuntimeException` — D2 explicitly forbids catching `RuntimeException` (QueryException extends it). The `fresh()` re-read in the catch is a second query per failure. |
| **Consequence** | The AJAX 422 contract is custom today; under D1 failures render the central error response. The audit log ordering itself is already correct (activityLog after save inside the transaction — pass on TXN-04). |
| **Reproduce** | Toggle a status while the write path fails; today a JSON 422 arrives, under D1 a JSON error response. |
| **Fix approach** | Remove the try/catch; keep the inline one-field validation (VAL-02 allows it for a toggle); remove the RuntimeException escalation and the fresh() re-read; return the JSON after the closure. |
| **Plan item** | CST-06 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($request, $constraint) {
                $constraint->is_active = $request->boolean('is_active');

                if (!$constraint->save()) {
                    throw new \RuntimeException('Failed to persist the constraint status change.');
                }

                activityLog($constraint, 'Toggled', [
                    'message' => 'Constraint status updated.',
                    'is_active' => $constraint->is_active,
                ]);

                return response()->json([
                    'success' => true,
                    'is_active' => $constraint->is_active,
                    'message' => 'Status updated.',
                ]);
            });
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'is_active' => $constraint->fresh()?->is_active ?? $constraint->is_active,
                'message' => 'Failed to update status.',
            ], 422);
        }
```

**Evidence**
```
$ grep -nE "public function toggleStatus|RuntimeException|catch \(" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
472:    public function toggleStatus(Request $request, Constraint $constraint)
496:                    throw new \RuntimeException('Failed to persist the constraint status change.');
510:        } catch (\Throwable $e) {
```

#### CST-20 · M · ERR-06 — ConstraintEvaluator swallows every soft-constraint failure in an empty catch

| Field | Value |
|---|---|
| **Rule** | ERR-06 (H default; lowered to M because the class has no live caller) — *no swallowed failures in write paths — an empty catch, or a catch that logs and then continues as if the write succeeded* |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php:70-77`, method `scoreSoft()` |
| **Root cause** | `catch (\Throwable $e) {}` discards the exception with no log, no report, no rethrow, so any constraint that throws during scoring silently contributes zero. |
| **Consequence** | A misbehaving constraint is invisible: scores silently drop and the generator cannot know a rule failed. |
| **Reproduce** | Static only — the class has no caller in the module today (verified by grep), so this arms the moment someone wires the evaluator in. |
| **Fix approach** | Remove the try/catch and let failures surface (or log via `report($e)` if a specific guard is truly needed). |
| **Plan item** | CST-20 in `02-fix-plan.md` §3 |

```php
            try {
                $weight = $constraint->getWeight();
                if ($constraint->passes($slot, $activity, $context)) {
                    $score += $weight;
                }
            } catch (\Throwable $e) {
            }
```

**Evidence**
```
$ grep -rn "new ConstraintEvaluator\|ConstraintEvaluator" Modules/SmartTimetable --include=*.php | grep -v "app/Services/Constraints/" 
(no output — no live caller)
```

#### CST-21 · M · ERR-05 — DatabaseConstraintService logs only the message, losing the trace, and drops the constraint

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('...', ['exception' => $e]` — `getMessage()` alone loses the trace* |
| **Where** | `Modules/SmartTimetable/app/Services/DatabaseConstraintService.php:43-48`, method `loadConstraintsForGeneration()` |
| **Root cause** | `\Log::error('Failed to load constraint', ['error' => $e->getMessage()])` discards the trace, and the `continue` silently drops the constraint from the manager — the generator then runs without it (ERR-06 flavour). |
| **Consequence** | A constraint that fails to instantiate is silently absent from generation; operators cannot tell why, and the log has no stack trace. |
| **Reproduce** | Static only — the load path runs during generation; a constraint with a broken type code is skipped and only a one-line log appears. |
| **Fix approach** | `report($e)` (or `Log::error(..., ['exception' => $e])`) so the trace survives; keep the skip but make the log first-class. |
| **Plan item** | CST-21 in `02-fix-plan.md` §3 |

```php
            } catch (\Exception $e) {
                \Log::error('Failed to load constraint', [
                    'constraint_id' => $constraint->id,
                    'error' => $e->getMessage(),
                ]);
            }
```

**Evidence**
```
$ grep -n "getMessage\|Log::" Modules/SmartTimetable/app/Services/DatabaseConstraintService.php
44:                \Log::error('Failed to load constraint', [
46:                    'error' => $e->getMessage(),
```

### F2 — Transactions and audit

TXN-01/TXN-02/TXN-04 pass on every mutating method: each write path is one `DB::transaction(fn () => ...)` closure, `activityLog()` sits inside the closure after the write, and events are `'Created'`, `'Updated'`, `'Trashed'`, `'Restored'`, `'Deleted'`, `'Toggled'` — evidence: `grep -n "activityLog(" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php` shows all six calls inside their closures. TXN-03 (no irreversible side effect) passes — no mail/file/HTTP inside closures. TXN-05 — `redirect()`/`response()` built inside the closure in store/update/forceDelete/toggleStatus is folded into the CST-01/02/05/06 rewrites (the closure then returns the model/void, and the response is built after). Restore is checked under F13.

### F3 — Authorization

#### CST-08 · H · AUTH-02 — the bound constraint is loaded before Gate::authorize runs

| Field | Value |
|---|---|
| **Rule** | AUTH-02 (H) — *authorize first, before loading records; loading first leaks whether an id exists (404 vs 403)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:114-117`, method `editByCategory()` (same shape in `toggleStatus()` line 472-474) |
| **Root cause** | Route model binding (`Constraint $constraint`) resolves the record during route parameter resolution, before the controller body runs; the `Gate::authorize` line is inside the body. |
| **Consequence** | An unauthenticated-for-update user probing `/smart-timetable/constraint/999999/edit-by-category` gets 404 (no record) while `/smart-timetable/constraint/1/edit-by-category` gets 403 — exposing which constraint ids exist. |
| **Reproduce** | Sign in as a role without `constraint.update`, request the edit URL for an existing id (403) then a nonexistent id (404). |
| **Fix approach** | Move authorization ahead of the model load — the clean Laravel way is a route-level `can:` middleware on these two routes (a DECISION because it touches the shared route file); the in-method Gate is then removed. |
| **Plan item** | DECISION CST-08 in `02-fix-plan.md` §9 |

```php
    public function editByCategory(Constraint $constraint)
    {
        Gate::authorize('tenant.smart-timetable.constraint.update');
```

**Evidence**
```
$ grep -nE "public function editByCategory|public function toggleStatus|Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
114:    public function editByCategory(Constraint $constraint)
116:        Gate::authorize('tenant.smart-timetable.constraint.update');
472:    public function toggleStatus(Request $request, Constraint $constraint)
474:        Gate::authorize('tenant.smart-timetable.constraint.update');
```

#### CST-14 · L · AUTH-04 — store and update authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *don't authorize the same permission twice (Form Request authorize() + Gate::authorize); keep one* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:181` and `:298` plus `StoreConstraintRequest.php:11-14` / `UpdateConstraintRequest.php:11-14` |
| **Root cause** | Both the controller `Gate::authorize('tenant.smart-timetable.constraint.create'/'update')` and the FormRequest `authorize()` check the same permission. |
| **Consequence** | Redundant but harmless; it gives the controller more failure modes to keep in sync. |
| **Reproduce** | Static only. |
| **Fix approach** | Keep the FormRequest `authorize()` (it runs first and owns the 403) and drop the in-method Gate lines — defer as a trivial cleanup. |
| **Plan item** | none — see plan §10 (accepted, L) |

```php
        Gate::authorize('tenant.smart-timetable.constraint.create');
```

**Evidence**
```
$ grep -n "Gate::authorize\|auth()->user()->can" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php Modules/SmartTimetable/app/Http/Requests/StoreConstraintRequest.php Modules/SmartTimetable/app/Http/Requests/UpdateConstraintRequest.php
ConstraintController.php:181:        Gate::authorize('tenant.smart-timetable.constraint.create');
ConstraintController.php:298:        Gate::authorize('tenant.smart-timetable.constraint.update');
StoreConstraintRequest.php:13:        return auth()->user()->can('tenant.smart-timetable.constraint.create');
UpdateConstraintRequest.php:13:        return auth()->user()->can('tenant.smart-timetable.constraint.update');
```

### F4 — Validation and input

#### CST-09 · M · VAL-07 — a non-global constraint can be saved with no target id; cross-field rule missing

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) — *cross-field / business checks go in the Form Request's `after()` hook, not hand-written in the controller* |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/UpdateConstraintRequest.php:45-58` (same shape in StoreConstraintRequest) and `ConstraintController.php:193-195` |
| **Root cause** | The controller guards only one direction (GLOBAL must have no target_id, line 193). The reverse rule — a TEACHER/CLASS/ROOM/ACTIVITY constraint must name a target — is nowhere: `target_id` is `['nullable','integer']` in both requests, and `academic_term_id`, `class_id`, `section_id`, `activity_id`, `target_activity_id` have no `exists:` reference at all. The model's own comment says "Integrity is the application's job". |
| **Consequence** | A user can save a constraint that targets nothing real; the engine will either treat it as global or silently skip it (CST-19), and a hard-deleted target leaves a dangling `target_id`. |
| **Reproduce** | From the Add dialog pick Target Type = Teacher and leave Target ID blank — the save succeeds. |
| **Fix approach** | Add the cross-field rule to both requests' `after()` hook (non-GLOBAL target_type requires target_id); add `strict_types` to both requests in the same edit. |
| **Plan item** | CST-09 in `02-fix-plan.md` §5 |

```php
    public function withValidator($validator): void
    {
        $validator->after(function ($v) {
            foreach (['params_json', 'applicable_days'] as $field) {
                $value = $this->input($field);
                if (is_string($value) && $value !== '') {
                    json_decode($value);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        $v->errors()->add($field, "Invalid JSON format for {$field}.");
                    }
                }
            }
        });
    }
```

**Evidence**
```
$ grep -n "function withValidator\|target_id\|academic_term_id" Modules/SmartTimetable/app/Http/Requests/UpdateConstraintRequest.php
20:            'academic_term_id'   => ['nullable', 'integer'],
30:            'target_id'          => ['nullable', 'integer'],
45:    public function withValidator($validator): void
```

### F5 — Routes

#### CST-07 · H · RTE-01 — restore() changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET (`restore`, `delete`, `toggle`, `publish`, `approve`, `sync`, `generate`); GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/SmartTimetable/routes/web.php:255` (route) and `ConstraintController.php:412-434` (method) |
| **Root cause** | `Route::get('/constraint/{id}/restore', ...)` points at a method that restores the row, saves and writes an audit log. |
| **Consequence** | A pre-fetcher, crawler or a stray link click restores (and reactivates, CST-04) a trashed constraint and writes an audit row — with no CSRF token. |
| **Reproduce** | Open the trash page and let a prefetcher hit the Restore link, or paste the restore URL in an image tag in an email — the constraint comes back. |
| **Fix approach** | Convert the route to POST (and the trash-page action to POST), which touches the shared route file and the shared `action-trashed` component — a DECISION. |
| **Plan item** | DECISION CST-07 in `02-fix-plan.md` §9 |

```php
        Route::resource('constraint', ConstraintController::class)->except(['create']);
        Route::get('/constraint/trash/view', [ConstraintController::class, 'trashedConstraint'])->name('constraint.trashed');
        Route::get('/constraint/{id}/restore', [ConstraintController::class, 'restore'])->name('constraint.restore');
        Route::delete('/constraint/{id}/force-delete', [ConstraintController::class, 'forceDelete'])->name('constraint.forceDelete');
        Route::post('/constraint/{constraint}/toggle-status', [ConstraintController::class, 'toggleStatus'])->name('constraint.toggleStatus');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...'
GET|HEAD  smart-timetable/constraint/{id}/restore    smart-timetable.constraint.restore    ...ConstraintController@restore
```

RTE-02/RTE-03/RTE-05/RTE-06 clean. Route points at existing methods (all 12 targets matched). `create()` is unrouted and D5-handled. Tenant routes sit inside the module's auth+tenancy group (routes/web.php lines 162-257 are inside the group; verify with the route file). Custom routes for trash/restore/force-delete/toggle have extra path segments, so they are not captured by `Route::resource`'s `/{constraint}` — RTE-06 not triggered.

### F6 — Controller shape

#### CST-10 · M · CTL-03 — show/edit/destroy/update resolve the id by hand instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:254-268` (`show`), `:276-280` (`edit`), `:296-300` (`update`), `:364-368` (`destroy`). Also `store/restore/forceDelete` use `$id`: restore and forceDelete cannot bind without renaming the route parameter from `{id}` (routes/web.php 255-256). |
| **Root cause** | The routes already declare `{constraint}` for show/edit/update/destroy/toggle/edit-by-category; every method except `toggleStatus`/`editByCategory` re-resolves with `findOrFail($id)`. |
| **Consequence** | The `show(Constraint $constraint)` signature convention is half-applied; `findOrFail` duplicates what the router already does and makes the §3.3.1 unbound-parameter trap possible for future edits. |
| **Reproduce** | Static only — behavior is identical today. |
| **Fix approach** | Convert show/edit/destroy to `Constraint $constraint` (update is converted inside the CST-02 rewrite); restore/forceDelete stay on `$id` until their route params are renamed (a route change, deferred). |
| **Plan item** | CST-10 in `02-fix-plan.md` §5 |

```php
    public function show($id)
    {
        Gate::authorize('tenant.smart-timetable.constraint.view');

        // 'scope' was eager-loaded here while target_type held a
        // tt_constraint_category_scopes id. That relation is gone — target_type is
        // now a morph alias — and leaving it in the with() list threw
        // "Call to undefined relationship [scope]", 500-ing every show page.
        //
        // The morph relation is deliberately NOT eager-loaded in its place: a
        // GLOBAL constraint stores target_type = 'GLOBAL', which has no morph-map
        // entry, and Eloquent would try to instantiate it as a class. Read the
        // target through Constraint::resolveTarget(), which guards for that.
        $constraint = Constraint::with(['constraintType.category', 'academicTerm', 'creator'])
            ->findOrFail($id);
```

**Evidence**
```
$ grep -nE "public function (show|edit|update|destroy)\(" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
254:    public function show($id)
276:    public function edit($id)
296:    public function update(UpdateConstraintRequest $request, $id)
364:    public function destroy($id)
```

#### CST-11 · M · CTL-05 — createByCategory and editByCategory carry a 40-line copy-pasted loader block

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by create/edit, the same 30-line payload in store and update* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:56-95` vs `:120-151` |
| **Root cause** | The two category methods duplicate the same dropdown-loading block (constraintTypes/scopes/academicTerms/categoryLabel plus five conditional fetches) and the same match of category code to view name. A fix to one loader has to be repeated twice. |
| **Consequence** | The two pages can drift (one today already does: `editByCategory` orders academic terms by `start_date`, `createByCategory` does not — a silent inconsistency). |
| **Reproduce** | Static only — any future loader fix is two edits and easy to forget one. |
| **Fix approach** | Extract one private helper that returns the shared collections (with column selection for CST-12) and have both methods call it. |
| **Plan item** | CST-11 in `02-fix-plan.md` §6 |

```php
        $constraintTypes = ConstraintType::active()
            ->whereHas('category', fn($q) => $q->where('code', $categoryCode))
            ->orderBy('name')
            ->get();

        $scopes = ConstraintCategoryScope::active()->ofScope()->get();
        $academicTerms = AcademicTerm::where('is_active', 1)->limit(10)->get();
        $categoryLabel = ucwords(strtolower(str_replace('_', ' ', $categoryCode)));

        $teachers = collect();
        $classes = collect();
        $sections = collect();
        $rooms = collect();
        $activities = collect();

        if ($categoryCode === 'TEACHER_AVAILABILITY') {
            $teachers = Teacher::with('user')->active()->orderBy('id')->get();
        }

        if ($categoryCode === 'STUDENT_CLASS_RULES') {
            $classes = SchoolClass::where('is_active', true)->get();
            $sections = Section::where('is_active', true)->get();
        }

        if ($categoryCode === 'ROOM_SPACE') {
            $rooms = Room::with('building')->where('is_active', true)->get();
        }

        if ($categoryCode === 'INTER_ACTIVITY') {
            $activities = Activity::where('is_active', true)->with(['class', 'section'])->get();
        }
```

**Evidence**
```
$ sed -n '56,95p' Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
(identical block repeated at lines 120-151 — diff only the academic-terms orderBy)
$ sed -n '120,126p' Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
126:        $academicTerms = AcademicTerm::where('is_active', 1)->orderByDesc('start_date')->limit(10)->get();
```

#### CST-12 · M · QRY-15 — the category forms load whole tables for dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *don't load every row of a big table for a form: `Topic::get()`, `Student::get()` with no filter on a create/edit page* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:71-86` and `:135-150` |
| **Root cause** | `Teacher::with('user')->active()->get()`, `SchoolClass::...->get()`, `Section::...->get()`, `Room::with('building')->...->get()`, `Activity::with([...])->...->get()` — full rows of four school tables on a create/edit page, with no column selection. |
| **Consequence** | A school with thousands of teachers or activities loads all of them each time a category form opens. |
| **Reproduce** | Open `/smart-timetable/constraint/create/TEACHER_AVAILABILITY` on a populated tenant and watch the query log load `sch_teachers` (plus users) in full. |
| **Fix approach** | The CST-11 helper selects only the columns the blades render (`id`,`name`), eager-loads only `user:id,name` / `building:id,name` / `class:id,name` / `section:id,name`. |
| **Plan item** | none — folded into CST-11 (same lines, one edit) |

```php
        if ($categoryCode === 'TEACHER_AVAILABILITY') {
            $teachers = Teacher::with('user')->active()->orderBy('id')->get();
        }

        if ($categoryCode === 'STUDENT_CLASS_RULES') {
            $classes = SchoolClass::where('is_active', true)->get();
            $sections = Section::where('is_active', true)->get();
        }

        if ($categoryCode === 'ROOM_SPACE') {
            $rooms = Room::with('building')->where('is_active', true)->get();
        }

        if ($categoryCode === 'INTER_ACTIVITY') {
            $activities = Activity::where('is_active', true)->with(['class', 'section'])->get();
        }
```

**Evidence**
```
$ grep -n "->get()" Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
59:            ->get();
72:            $teachers = Teacher::with('user')->active()->orderBy('id')->get();
76:            $classes = SchoolClass::where('is_active', true)->get();
77:            $sections = Section::where('is_active', true)->get();
81:            $rooms = Room::with('building')->where('is_active', true)->get();
85:            $activities = Activity::where('is_active', true)->with(['class', 'section'])->get();
```

#### CST-13 · L · CTL-04 — no return types on the public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php` — all 13 public methods have no declared return type |
| **Root cause** | The controller predates the return-type convention; signatures were never updated. |
| **Consequence** | None today — the scanner-level debt. |
| **Reproduce** | Static only. |
| **Fix approach** | The rewritten methods in CST-01..06 adopt implicit shapes; adding return types to the read methods is cosmetic and deferred. |
| **Plan item** | none — see plan §10 (accepted, L) |

```php
    public function index()
    {
        Gate::authorize('tenant.smart-timetable.constraint.viewAny');
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+' Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
27:    public function index()
37:    public function create()
52:    public function createByCategory(string $categoryCode)
114:    public function editByCategory(Constraint $constraint)
179:    public function store(StoreConstraintRequest $request)
254:    public function show($id)
276:    public function edit($id)
296:    public function update(UpdateConstraintRequest $request, $id)
364:    public function destroy($id)
397:    public function trashedConstraint()
412:    public function restore($id)
439:    public function forceDelete($id)
472:    public function toggleStatus(Request $request, Constraint $constraint)
(no return types on any of them)
```

### F7 — Models

No model is newly audited here: `Constraint`, `ConstraintCategoryScope`, `ConstraintType`, `Activity`, `AcademicTerm` are owned by other reports (§3 links). Usage checks passed: the controller eager-loads `constraintType.category`, `academicTerm`, `creator` on show (no lazy `target` on a collection — the GLOBAL guard in `Constraint::target()` is respected, and `resolveTarget()` is used in the blade instead). SchoolSetup models are common.

### F8 — Services and jobs

The constraint service cluster was claimed per the brief and is grouped here. `ConstraintRegistry` (71 lines) and `TimetableConstraint` (33 lines) are clean: registry register/resolve/clear are straightforward and thread-safe enough for a boot-time plugin map; the interface is minimal and implemented by every concrete class. `ConstraintContext` is clean in itself but its `toArray()` and `ConstraintManager::buildContextArray()` are a duplicated, divergent context builder — see CST-22.

#### CST-16 · B · DEEP-01 — ConstraintManager rejects a failing hard constraint only when verbose_logging is enabled

| Field | Value |
|---|---|
| **Rule** | DEEP-01 (deep-read discovery; no single rulebook ID) — logic defect found by the deep-read checklist (Q7: the code's success path is a lie) |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php:75-81`, method `checkHardConstraints()` |
| **Root cause** | `return false;` is the body of `if (config('smart_timetable.verbose_logging', false))`. When verbose logging is off — the default — the `return false` is skipped, the loop continues, and the method ends with `$this->evaluationCache[$cacheKey] = true; return true;`. Hard constraints only block a placement when the debug flag is on. |
| **Consequence** | The generator places activities that violate hard rules (teacher conflict, room exclusivity, same-start) and reports success — a wrong timetable with no error. This is the single worst finding. |
| **Reproduce** | Static plus behavior: call `checkHardConstraints()` with any constraint whose `passes()` returns false and `config('smart_timetable.verbose_logging')` false — the method returns true. The live solver (`PrimeSolver`) uses this manager. |
| **Fix approach** | Make the `return false;` unconditional (delete the config guard). |
| **Plan item** | CST-16 in `02-fix-plan.md` §1 |

```php
            if (!$constraint->passes($slot, $activity, $context)) {
                $this->evaluationCache[$cacheKey] = false;

                if (config('smart_timetable.verbose_logging', false))

                return false;
            }
```

**Evidence**
```
$ grep -n "verbose_logging" Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php
78:                if (config('smart_timetable.verbose_logging', false))
```

#### CST-17 · B · DEEP-01 — ConstraintEvaluator calls a non-static factory method statically

| Field | Value |
|---|---|
| **Rule** | DEEP-01 (deep-read discovery; no single rulebook ID) — a PHP Error on a normal path; B (armed: the evaluator has no caller today, verified) |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php:96-99`, method `evaluateGroups()` |
| **Root cause** | `ConstraintFactory::createFromDatabase($m->constraint)` invokes an instance method statically; PHP 8 throws `Error: Non-static method ... cannot be called statically` the moment the code runs. |
| **Consequence** | The moment anyone calls `evaluateGroups()` (group evaluation for MUTEX/CONCURRENT/ORDERED groups), it fatals. No caller exists in the module today, so this is an armed landmine rather than a live crash. |
| **Reproduce** | Static only — `grep -rn "evaluateGroups" Modules/SmartTimetable` shows no caller; call the method from tinker to see the Error. |
| **Fix approach** | Instantiate the factory: `(new ConstraintFactory())->createFromDatabase($m->constraint)` (same namespace, no import needed). |
| **Plan item** | CST-17 in `02-fix-plan.md` §1 |

```php
            $memberConstraints = $members->map(function ($m) {
                return ConstraintFactory::createFromDatabase($m->constraint);
            })->filter();
```

**Evidence**
```
$ grep -n "ConstraintFactory::createFromDatabase" Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php
98:                return ConstraintFactory::createFromDatabase($m->constraint);
```

#### CST-18 · H · DEEP-01 — ConstraintFactory reads five model attributes that do not exist

| Field | Value |
|---|---|
| **Rule** | DEEP-01 (deep-read discovery; no single rulebook ID) — silent wrong data (the engine ignores effective windows and applicable days) |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php:47-60`, method `createFromDatabase()` |
| **Root cause** | The `_constraint_meta` array reads `$constraint->uuid`, `$constraint->effective_from_date`, `$constraint->effective_to_date`, `$constraint->applicable_days_json`. The model has no such columns/attributes — the columns are `effective_from`, `effective_to`, `applicable_days` (verified in tinker and the model's casts). Every meta value is null or `[]`. |
| **Consequence** | `checkDayApplication()` (in Generic*) always sees an empty `applies_to_days` and never filters by day; effective-date windows are dropped, so constraints apply outside their dates. |
| **Reproduce** | Static plus tinker — `Constraint::first()` returns `uuid=NULL`, `effective_from_date=NULL`, `applicable_days_json=null` for every row. |
| **Fix approach** | Read the real attributes: `effective_from`, `effective_to`, `applicable_days ?? []`, and use `id` for `uuid`. |
| **Plan item** | CST-18 in `02-fix-plan.md` §1 |

```php
        $params['_constraint_meta'] = [
            'id' => $constraint->id,
            'uuid' => $constraint->uuid,
            'name' => $constraint->name,
            'description' => $constraint->description,
            'target_type' => $constraint->target_type,
            'target_id' => $constraint->target_id,
            'effective_from' => $constraint->effective_from_date,
            'effective_to'   => $constraint->effective_to_date,
            'applies_to_days' => $constraint->applicable_days_json ?? [],
            'weight' => $constraint->weight,
            'scope' => $constraint->constraintType->scope,
            'category' => $constraint->constraintType->category,
        ];
```

**Evidence**
```
$ grep -n "effective_from_date\|effective_to_date\|applicable_days_json" Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php
54:            'effective_from' => $constraint->effective_from_date,
55:            'effective_to'   => $constraint->effective_to_date,
56:            'applies_to_days' => $constraint->applicable_days_json ?? [],

$ php artisan tinker --execute '...Constraint::first()...'
ctor model attrs: uuid=NULL effective_from_date=NULL applicable_days_json=null
```

#### CST-19 · H · DEEP-01 — every live constraint type resolves to a Generic class that cannot express the stored rule

| Field | Value |
|---|---|
| **Rule** | DEEP-01 (deep-read discovery; no single rulebook ID) — dead feature: saved data no consumer honours (deep-read Q8) |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php:12-26,67-105` plus `Modules/SmartTimetable/app/Providers/SmartTimetableServiceProvider.php:128-136` |
| **Root cause** | The six live codes (measured) are `SHORT_BREAK_FIXED`, `LUNCH_BREAK_FIXED`, `MAX_LESSONS_PER_DAY`, `NO_TEACHER_GAPS`, `NO_CONSECUTIVE_SAME_SUBJECT`, `TEACHER_FREE_PERIOD_PER_HALF`. None is registered in `ConstraintRegistry`, none matches the legacy `CONSTRAINT_CLASS_MAP` keys (they are `SHORT_BREAK`, `LUNCH_BREAK`, `MAX_DAILY_LOAD`...), and the inferred class names do not exist — so every one falls to `GenericHardConstraint`/`GenericSoftConstraint`. `GenericSoftConstraint::passes()` always returns true and its `buildActivityContext()` returns only `['ACTIVITY' => ...]` (stub), so soft constraints never differentiate placement; `GenericHardConstraint::passes()` only acts on a `period_codes` param, while the live lunch/break rows store `period_type_code`. Result: the generator runs with decorative constraints. |
| **Consequence** | A school saves "Lunch Break (No Teaching)" (hard, weight 100) and the engine does not block teaching at lunch; "Max Lessons Per Day" and "No Teacher Gaps" are never scored. The Constraint screen's data has zero effect on the timetable. |
| **Reproduce** | The live rows: constraint 1 (`SHORT_BREAK_FIXED`, params `{"period_type_code": "BREAK"}`), 2 (`LUNCH_BREAK_FIXED`, `{"period_type_code": "LUNCH"}`), 3, 4, 5, 6 — factory resolution: dedicated class → Generic. |
| **Fix approach** | Rebuild the mapping for the actual `tt_constraint_types` codes and implement real `passes()` behaviour per rule, or make the Generic classes interpret the stored param keys — a DECISION because it changes engine results. |
| **Plan item** | DECISION CST-19 in `02-fix-plan.md` §9 |

```php
        'PARALLEL_PERIODS' => ParallelPeriodConstraint::class,
        'TEACHER_CONFLICT' => TeacherConflictConstraint::class,
        // Note: LUNCH_BREAK, SHORT_BREAK, BREAK_PERIOD, ROOM_AVAILABILITY, MAX_DAILY_LOAD,
        // NO_SAME_SUBJECT_SAME_DAY, FIXED_PERIOD_HIGH_PRIORITY, HIGH_PRIORITY_FIXED_PERIOD,
        // DAILY_SPREAD, PREFERRED_TIME_OF_DAY, BALANCED_DAILY_SCHEDULE — resolved via
        // ConstraintFactory legacy CONSTRAINT_CLASS_MAP → GenericHardConstraint/GenericSoftConstraint
```

**Evidence**
```
$ php artisan tinker --execute 'foreach(DB::table("tt_constraint_types")->get() as $t){ echo $t->code."\n"; }'
TEACHER_NOT_AVAILABLE
NO_TEACHER_GAPS
MAX_LESSONS_PER_DAY
NO_CONSECUTIVE_SAME_SUBJECT
ROOM_CAPACITY_LIMIT
LUNCH_BREAK_FIXED
SHORT_BREAK_FIXED
ACTIVITY_TIME_WINDOW
PARALLEL_PERIODS
TEACHER_FREE_PERIOD_PER_HALF

$ grep -c "GenericSoftConstraint\|GenericHardConstraint" Modules/SmartTimetable/app/Services/Constraints/ConstraintFactory.php
(line 88/90 returns the generic fallbacks — deduplicated code check via sed: Step 4 at lines 87-91)
```

### F9 — Queries and performance

CST-12 (whole-table dropdown loads) is reported above and folded into CST-11. `trashedConstraint()` paginates at 10 and eager-loads `constraintType` — clean, verified (lines 401-406). `store`/`update` use `validated()` only. QRY-01..14: clean in this controller — no query inside a loop, no interpolated raw SQL (`grep -n "whereRaw\|DB::raw" Controller` → no output).

### F10 — Views

clean — the five constraint blades contain no `Model::`, `DB::`, `->get(`, `{!! !!}` or raw `->target` dumps (`rg -n "Model::|DB::|->get\(|{!!|->target\b" Modules/SmartTimetable/resources/views/constraint/` → no output). All five compile (`php -r` Blade `compileString` → `php -l` → "No syntax errors detected" for show/edit/trash/create/index). Trash rows use `x-backend.table.action-trashed` with `restorePermission`/`forceDeletePermission`; show uses `resolveTarget()` via the label guard; the create/edit forms post the morph alias `target_type` with the strict `===` select — consistent with the requests' `Rule::in`. The engine page's create modal declares `permission="tenant.smart-timetable.constraint.create"` and posts to `constraint.store` — consistent with the controller gate.

### F11 — Security and tenancy

clean — no `env()` in the controller (`grep -n "env(" ConstraintController.php` → no output). No hard-coded ids (`?? 1` absent). No personal-data JSON exposure. All 8 permission strings exist with exact names in the tenant DB (measured: count 1 each). Central models are not touched from the controller. Cache: none used here. The constraint cluster keeps a per-run in-memory `evaluationCache` keyed by class/day/period/activity — no tenant-key issue (in-memory per process).

### F12 — Style

#### CST-15 · L · STY-01 / STY-04 — missing strict_types and an emoji marker in the controller

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* · STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php:1` and `:480` |
| **Root cause** | The controller opens with `<?php` + blank + namespace (no strict_types declaration) and line 480 carries a `⚠` marker: `// ⚠ Rule A3 — activityLog now runs AFTER save()...`. |
| **Consequence** | Cosmetic; the emoji marker is a found-inhouse convention that the STY-04 rule rejects. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag and drop the `⚠` character. |
| **Plan item** | CST-15 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ sed -n '478,481p' Modules/SmartTimetable/app/Http/Controllers/ConstraintController.php
        $request->validate(['is_active' => ['required', 'boolean']]);

        // ⚠ Rule A3 — activityLog now runs AFTER save(), not before it.
```

No other STY findings: imports are sorted and single per class, comments are English, no commented-out code blocks longer than 3 lines except the D5 explanations (which are intentional).

#### CST-22 · M · SVC-04 — two evaluation engines and two context builders duplicate one operation and disagree

| Field | Value |
|---|---|
| **Rule** | SVC-04 (M) — *one implementation per business operation; three copies of "assign students" that disagree = bug source* |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php` (250 lines, `checkHardConstraints`/`evaluateSoftConstraints`/`buildContextArray`) vs `Modules/SmartTimetable/app/Services/Constraints/ConstraintEvaluator.php` (179 lines, `checkHard`/`scoreSoft`/`evaluateGroups`) vs `Modules/SmartTimetable/app/Services/Constraints/ConstraintContext.php:59-72` (`toArray`) |
| **Root cause** | Two engines implement the same hard/soft evaluation with different contracts: the manager calls `constraintApplies()` (method_exists `appliesToContext`), the evaluator calls `isRelevant()`; the manager's `buildContextArray()` puts `'TEACHER' => [ids]`, `ConstraintContext::toArray()` puts `'TEACHER' => $teacherIds[0] ?? null` (scalar). They cache with the same key shape but different buckets, and their failure behaviour now diverges (CST-16 vs CST-20). |
| **Consequence** | A constraint written for one engine behaves differently under the other; anyone wiring `ConstraintEvaluator` in later inherits a second, already-diverging behaviour. |
| **Reproduce** | Static only today (evaluator has no caller). |
| **Fix approach** | Pick ConstraintManager (the one PrimeSolver imports), retire or fully align ConstraintEvaluator, and make the context builders produce one shape — a DECISION (architecture). |
| **Plan item** | DECISION CST-22 in `02-fix-plan.md` §9 |

```php
    private function buildContextArray(Slot $slot, Activity $activity, $context): array
    {
        $contextArray = [
            'day_id' => $slot->dayId,
            'day_of_week' => $slot->dayId,
            'period_index' => $slot->startIndex,
            'class_key' => $slot->classKey,
            'activity_id' => $activity->id,
        ];
```

**Evidence**
```
$ grep -n "'TEACHER'" Modules/SmartTimetable/app/Services/Constraints/ConstraintManager.php Modules/SmartTimetable/app/Services/Constraints/ConstraintContext.php
ConstraintManager.php:161:            $contextArray['TEACHER'] = $activity->teachers
ConstraintContext.php:70:            'TEACHER' => $this->teacherIds[0] ?? null,
```

#### CST-23 · M · DEEP-01 — the individual constraint classes copy-paste their constructor and read solver internals that no audited context guarantees

| Field | Value |
|---|---|
| **Rule** | DEEP-01 (deep-read discovery; no single rulebook ID) — grouped finding for `Hard/*` and `Soft/*` (70 classes) |
| **Where** | `Modules/SmartTimetable/app/Services/Constraints/Hard/TeacherUnavailablePeriodsConstraint.php:17-27` and `Soft/TeacherMaxGapsPerDayConstraint.php:45-71` (samples; the pattern repeats) |
| **Root cause** | (1) Every concrete class re-declares `protected array $meta/$params` and a constructor that repeats `parent::__construct($params); $this->params = $params; $this->meta = $params['_constraint_meta'] ?? [];` — already done by the Generic parents. (2) Several `passes()` bodies read solver internals straight off `$context`: `$context->teacherOccupied[$teacherId][$slot->dayId]` (TeacherMaxGapsPerDayConstraint) and `$context->periods` (GenericHardConstraint). No audited context object in the cluster exposes `teacherOccupied` or `periods` — when the property is missing the null-coalescing silently yields empty, so the rule passes without ever being checked. |
| **Consequence** | The constraints silently no-op (wrong timetables) and the duplicated constructors make the next fix a 70-file chore. |
| **Reproduce** | Static only — e.g. `$context->teacherOccupied[$teacherId][$slot->dayId] ?? []` returns `[]` when the property does not exist, so a gaps rule is never evaluated. |
| **Fix approach** | Define one abstract base (meta/params ctor) and a documented context contract with the arrays the rules need; convert the classes onto it — a DECISION (large refactor, engine risk). |
| **Plan item** | DECISION CST-23 in `02-fix-plan.md` §9 |

```php
    protected array $meta = [];
    protected array $params = [];

    public function __construct(array $params = [])
    {
        parent::__construct($params);
        $this->params = $params;
        $this->meta = $params['_constraint_meta'] ?? [];
    }
```

**Evidence**
```
$ grep -c "protected array \$meta" Modules/SmartTimetable/app/Services/Constraints/Hard/*.php Modules/SmartTimetable/app/Services/Constraints/Soft/*.php
(23 files in Hard/, 42 in Soft/ repeat the block — sed of TeacherUnavailablePeriodsConstraint:17-27 above)
$ grep -rn "teacherOccupied\|->periods" Modules/SmartTimetable/app/Services/Constraints --include=*.php | head
Soft/TeacherMaxGapsPerDayConstraint.php:51: $dayOccupied = $context->teacherOccupied[$teacherId][$slot->dayId] ?? [];
Hard/GenericHardConstraint.php:28: $periods = $context->periods;
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | Q1 overwrite | Q2 delete-before-store | Q3 duplicate impl | Q4 soft-delete×unique | Q5 race | Q6 auth hole | Q7 lying message | Q8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok (insert then log) | ok (store/update arrays share intent; kept separate by design) | ok | ok (rules-only check) | ok (Gate + FormRequest; L-dup CST-14) | ok ('Created' matches) | CST-19 (stored rule not enforced) |
| `update` | ok (absent fields preserve `$constraint->x`) | ok | ok | ok | ok | ok | ok ('Updated') | CST-19 |
| `destroy` | CST-03 (is_active forced false) | ok (log inside txn) | ok | ok | ok | ok | ok ('Trashed') | CST-19 |
| `restore` | CST-04 (is_active forced true) | ok | ok | ok | ok | ok | ok ('Restored') | CST-19 |
| `forceDelete` | ok | ok (log inside txn; RESTRICT surfaces) | ok | ok | ok | ok | ok ('Deleted') | CST-19 |
| `toggleStatus` | ok (writes the boolean posted) | ok | ok | ok | ok | CST-08 (auth after load) | ok ('Toggled') | CST-19 |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SmartTimetable/resources/views/pages/constraint-engine.blade.php` + `partials/.../_list.blade.php` (TimetableMenuController page) | The list partial's own comment admits: "⚠ VIEW-SURFACE ONLY: ExportController has no Gate:: call, so this hides the button and leaves the endpoint reachable" — the constraint export endpoint is reachable without the `.export` ability | AUTH-01/F10 export gate | TimetableMenuController / ExportController report |
| `Modules/SmartTimetable/routes/web.php:255` | `GET constraint/{id}/restore` is a state change over GET (CST-07, DECISION) — file is shared with the other SmartTimetable controllers | RTE-01 | this plan (DECISION) |
| `Modules/SmartTimetable/app/Services/Constraints/ConstraintRegistry.php` registrations in `SmartTimetableServiceProvider` | Registry keys (TEACHER_*, CLASS_*, ...) overlap with the legacy map and the inferred-name path; three resolution mechanisms for one operation (CST-19/CST-22 family) | SVC-04 | this plan (DECISION) |

## 8. Not covered, and why

- The generation call path beyond the cluster was not traced into `PrimeSolver`/`ImprovedTimetableGenerator`/`GenerateTimetableJob` (owned by TimetableGenerationController) — the cluster's reachability into those is confirmed by imports, but the `$context` object PrimeSolver passes to `passes()` was not verified, so the CST-23 "solver internals" cells are `⚠ UNVERIFIED — what would settle it: read PrimeConstraintBridge::buildContext and PrimeSolver call sites`.
- `ConstraintEvaluator` has no caller today; its fatal (CST-17) and empty catch (CST-20) are armed landmines, not live crashes — verification was static only.
- The category form blades (teacher/class/room/global/inter-activity/db create+edit) were checked for structure but their JavaScript and the `constraint-engine` page tabs were not executed in a browser.
- Role granting was measured (roles 1 and 2 hold `constraint.create`); the meaning of role 1 vs role 2 (super-admin vs principal) is tenant config, not verified.
- `normalizeJson()` (private helper, line 523-539) uses a try/catch around `json_decode(..., JSON_THROW_ON_ERROR)`; it is a pure parse guard returning `false`, not an error sink, and is left as-is (a D1-strict reading would flag it; the improvement is cosmetic).
- No queue jobs, observers or events belong to this controller; none were executed.