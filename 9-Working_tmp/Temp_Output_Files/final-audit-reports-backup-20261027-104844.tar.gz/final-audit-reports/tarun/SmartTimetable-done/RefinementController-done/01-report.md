# Final Audit — SmartTimetable / RefinementController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php` (158 lines, 5 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `POST /smart-timetable/refinement/swap` · `POST /smart-timetable/refinement/move` · `POST /smart-timetable/refinement/lock` · `GET /smart-timetable/refinement/candidates/{cellId}` · `GET /smart-timetable/refinement/impact/{cellId}` |
| Menu path | Smart Timetable → View & Refinement (the workspace tab that drags, swaps and locks periods in a generated timetable) |
| Who uses it | Only the two roles that hold `tenant.smart-timetable.timetable.update` (permission id 1643): Super Admin (role 1) and School Admin (role 2). The two GET endpoints use `.view`, held by the same two roles. |
| What a user does here | A timetabler opens a generated timetable and manually fixes it: swap two periods between two grid cells, move one period into a free slot, or lock a period so a regeneration will not overwrite it. The two GET endpoints feed the confirmation dialog (which cells can be swapped, what the impact of the change is). There is no server-rendered page here: every method returns JSON, called by the workspace JavaScript. |
| Tables written | `tt_timetable_cells`, `tt_timetable_cell_teachers`, `sys_activity_logs` (through the `activityLog()` helper) |
| Tables read | `tt_timetable_cells`, `tt_timetable_cell_teachers`, `sch_teachers`, `tt_timetables`, `tt_activities`, `tt_subjects`, `tt_teacher_assignment_roles`, `users` |
| Live data | `tt_timetable_cells` 0 live, 0 trashed, 0 locked · `tt_timetable_cell_teachers` 0 · `tt_timetables` 0 · `tt_teacher_assignment_roles` 5 · `sys_activity_logs` 396. The tenant has no generated timetable yet, so none of these endpoints can be exercised on `test.localhost` today. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

**Not production-ready. 1 blocker, 2 high.**

The single worst finding is **RFN-07 (blocker)**: both write paths (`swap` and `move`) call `teachers()->sync(...)` without supplying `assignment_role_id`, and that pivot column is `NOT NULL` with no default (canonical DDL `pgdatabase/2-DDL_Tenant_Consolidated/Timetable_DDL_v7.8.sql:1473`). Under `STRICT_TRANS_TABLES` this makes the pivot INSERT throw, so the swap and move endpoints return a 500 for any cell that actually carries teachers — the core purpose of the screen. The controller also keeps three non-D2 `try/catch` blocks that violate D1; the `toggleLock` one additionally swallows `ValidationException` (422 shown as 500) and logs only `$e->getMessage()`. The service issues one query per teacher inside two loops (N+1) while validating conflicts.

The plan is about a half-day: one blocker, one error/handling rewrite, two N+1 fixes, plus style. Two DECISION items need your choice first (the inline-validation refactor and the check-then-act race).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 5 | 3 | 2 | 11 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | RFN-01, RFN-02 | F8 Services/Jobs | RFN-07 |
| F2 Transactions/Audit | RFN-03, RFN-04 | F9 Queries/Perf | RFN-08, RFN-09 |
| F3 Authorization | clean — see evidence in the family section | F10 Views | checked, not present — the controller renders no view |
| F4 Validation | RFN-05 | F11 Security/Tenancy | clean — see evidence in the family section |
| F5 Routes | clean — see evidence in the family section | F12 Style | RFN-10, RFN-11 |
| F6 Controller shape | RFN-06 | F13 Deep read | answers in the family section (RFN-07, RFN-08) |
| F7 Models | linked — `TimetableCell` audited by its owner; usage checked | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php` | controller | 158 | this report | ✅ whole class |
| 2 | `Modules/SmartTimetable/app/Services/RefinementService.php` | service | 336 | this report (claim appended to `00-CLASS-OWNERS.md`) | ✅ whole class |
| 3 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | 320 | ↗ [tarun/TimetableFoundation/TimetableController](../../TimetableFoundation/TimetableController-done/01-report.md) | ↗ linked — usage checked (columns and `teachers()`/`activity()` relations all match the service calls) |
| 4 | `Modules/SmartTimetable/app/Models/TimetableCell.php` | model | 10 | ↗ [tarun/SmartTimetable/TimetableExportController](../TimetableExportController-done/01-report.md) | ↗ linked — thin alias of the TimetableFoundation model |
| 5 | `Modules/SmartTimetable/routes/web.php` lines 194-200 | routes | — | this report | ✅ |
| — | `Modules/TimetableFoundation/app/Models/TimetableCellTeacher.php` | model | 78 | not claimed | referenced only (the pivot model is never instantiated here; `teachers()` reads the pivot table directly) |
| — | `App\Http\Controllers\Controller`, `Request`, `Gate`, `DB`, `Log`, `ModelNotFoundException`, `activityLog()`, `Modules/SchoolSetup/**` (`Teacher`, `User`) | common | — | common | referenced only |

No pre-applied files for this controller.

## 4. Routes

```
GET|HEAD smart-timetable/refinement/candidates/{cellId}    smart-timetable.refinement.candidates    Modules\SmartTimetable\Http\Controllers\RefinementController@candidates
GET|HEAD smart-timetable/refinement/impact/{cellId}        smart-timetable.refinement.impact        Modules\SmartTimetable\Http\Controllers\RefinementController@impact
POST     smart-timetable/refinement/lock                   smart-timetable.refinement.toggleLock    Modules\SmartTimetable\Http\Controllers\RefinementController@toggleLock
POST     smart-timetable/refinement/move                   smart-timetable.refinement.move          Modules\SmartTimetable\Http\Controllers\RefinementController@move
POST     smart-timetable/refinement/swap                   smart-timetable.refinement.swap          Modules\SmartTimetable\Http\Controllers\RefinementController@swap
```

Middlewares (uncached `route:list --json`): `web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains, Stancl\Tenancy\Middleware\InitializeTenancyByDomain, App\Http\Middleware\EnsureTenantIsActive, Illuminate\Auth\Middleware\Authenticate, Illuminate\Auth\Middleware\EnsureEmailIsVerified, App\Http\Middleware\EnsureTenantHasModule:smart-timetable`, plus `snapshot.read` on the two GETs and `snapshot.readonly` on the three POSTs (RTE-05 satisfied). No `Route::resource` shares this prefix, so RTE-06 does not apply. Route param `{cellId}` matches the `int $cellId` argument on `candidates()` and `impact()` (no unbound-model risk).

Unrouted public methods: none. `route:list` covers all five public methods; the only other `public function` is the constructor.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `swap` | 23 | POST /smart-timetable/refinement/swap | `tenant.smart-timetable.timetable.update` | service `swapActivities()` `DB::transaction` | `SWAP` (service `logChange`, inside tx) | tt_timetable_cells, tt_timetable_cell_teachers, sys_activity_logs | RFN-02, RFN-04, RFN-05, RFN-07, RFN-08 |
| `move` | 61 | POST /smart-timetable/refinement/move | `tenant.smart-timetable.timetable.update` | service `moveActivity()` `DB::transaction` | `MOVE` (service `logChange`, inside tx) | tt_timetable_cells, tt_timetable_cell_teachers, sys_activity_logs | RFN-02, RFN-04, RFN-05, RFN-07, RFN-08 |
| `toggleLock` | 101 | POST /smart-timetable/refinement/lock | `tenant.smart-timetable.timetable.update` | controller `DB::transaction` wrapping service `lockCell()`/`unlockCell()` (each also transactional) | `Locked` / `Unlocked` (service, inside tx) | tt_timetable_cells, sys_activity_logs | RFN-01, RFN-03, RFN-05, RFN-06 |
| `candidates` | 137 | GET /smart-timetable/refinement/candidates/{cellId} | `tenant.smart-timetable.timetable.view` | none (read path) | none | none | RFN-09 |
| `impact` | 149 | GET /smart-timetable/refinement/impact/{cellId} | `tenant.smart-timetable.timetable.view` | none (read path) | none | none | — |

**Tables each mutation SHOULD touch:**
- **swap** should write the two cell rows, swap the two cells' teacher links, and write two `SWAP` audit rows. It does exactly those, inside one transaction in the service.
- **move** should write the target cell (or the moved cell) and clear the source cell, move its teacher links, and write one `MOVE` audit row. It does those inside one service transaction.
- **toggleLock** should write one cell row and one `Locked`/`Unlocked` audit row. It does, inside the service transaction.

## 6. Findings

### F1 — Errors

#### RFN-01 · H · ERR-02 — `toggleLock` validates inside the try, so a 422 becomes a 500

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — a catch must never turn a 404/403/422 into a redirect or 500; validation belongs before the try. D1 also bans a controller try/catch here (none of the D2 shapes apply). |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:105-131`, method `toggleLock()` |
| **Root cause** | `$request->validate()` runs inside both the `try` and the `DB::transaction` closure. When validation fails it throws `ValidationException`, which is thrown out of the transaction and then caught by the generic `catch (\Throwable $e)`; there is no `catch (ValidationException)` re-throw, so the framework never renders the normal 422. The earlier `catch (ModelNotFoundException)` shows the author knew the pattern but only covered the 404 case. |
| **Consequence** | A user who submits a lock request with a missing or deleted `cell_id` sees the generic 500 JSON `"The operation could not be completed."` instead of the validation message, and no field error is returned. The failure is logged as an application error. |
| **Reproduce** | `POST /smart-timetable/refinement/lock` with body `{"cell_id": 999999, "lock": true}` as a Super Admin. Expected 422 with an `exists` error; actual 500 `{"success":false,"message":"The operation could not be completed."}`. |
| **Fix approach** | Remove the try/catch entirely (D1); read and validate the request first, run the service inside one `DB::transaction`, then build the JSON response after the closure returns. This also removes the swallowed-validation path and the `getMessage()` logging. |
| **Plan item** | RFN-01 in `02-fix-plan.md` §3 |

```php
        try {
            return DB::transaction(function () use ($request) {
                $validated = $request->validate([
                    'cell_id' => 'required|integer|exists:tt_timetable_cells,id',
                    'lock' => 'required|boolean',
                ]);

                $result = $validated['lock']
                    ? $this->refinementService->lockCell($validated['cell_id'])
                    : $this->refinementService->unlockCell($validated['cell_id']);

                return response()->json($result);

            });
        } catch (ModelNotFoundException $e) {
            // Rule A1: a missing record must stay a 404. Without this the generic
            // catch below swallows it and the user gets a redirect instead.
            throw $e;
        } catch (\Throwable $e) {
            Log::error('RefinementController::toggleLock failed', ['error' => $e->getMessage()]);

            // AJAX endpoint — the caller reads JSON.
            return response()->json([
                'success' => false,
                'message' => 'The operation could not be completed.',
            ], 500);
        }
```

**Evidence**
```
$ grep -n "try {\|catch (" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php
32:        try {
38:        } catch (\Throwable $e) {
71:        try {
78:        } catch (\Throwable $e) {
105:        try {
119:        } catch (ModelNotFoundException $e) {
123:        } catch (\Throwable $e) {
```

#### RFN-02 · M · ERR-00 (D1) + ERR-05 — `swap` and `move` keep a controller try/catch that logs only the message

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, D1) — no try/catch in a controller; `DB::transaction()` rolls back and rethrows by itself, and the central handler renders the error. ERR-05 (M) — log the exception object, not `getMessage()`, which loses the trace. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:32-49` (method `swap()`) and `:71-89` (method `move()`) |
| **Root cause** | Both methods wrap a single service call that already owns its own `DB::transaction` in a defensive `catch (\Throwable)` that returns a generic 500 after `Log::error(... ['error' => $e->getMessage()])`. The catch is not one of the D2 shapes and cannot add a page-specific message the central handler does not already give. |
| **Consequence** | Every swap/move failure loses the stack trace in the log (only the message string is kept), and the app's central exception renderer never runs — an operator cannot diagnose the failure from the log, and the response is a hand-built 500 instead of the framework's. |
| **Reproduce** | Static only — the catch fires on any thrown exception; with RFN-07 unfixed it is the normal path for a swap/move on a cell that has teachers. |
| **Fix approach** | Delete both try/catch blocks (D1). Call the service directly and keep the existing `expectsJson()`/`back()` response tail. |
| **Plan item** | RFN-02 in `02-fix-plan.md` §3 |

```php
        try {
            // Rules A2/A3 are inside RefinementService::swapActivities(), which owns the
            // transaction and now writes its SWAP audit entries inside it (§6/§4). A refusal —
            // locked cell, cross-timetable, conflict — returns success:false and writes
            // nothing, so it logs nothing.
            $result = $this->refinementService->swapActivities($validated['cell_id_1'], $validated['cell_id_2']);
        } catch (\Throwable $e) {
            Log::error('RefinementController::swap failed', [
                'cells' => [$validated['cell_id_1'], $validated['cell_id_2']],
                'error' => $e->getMessage(),
            ]);

            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'The swap could not be completed.'], 500);
            }

            return back()->with('error', 'The swap could not be completed.');
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php
41:                'error' => $e->getMessage(),
81:                'error'   => $e->getMessage(),
124:            Log::error('RefinementController::toggleLock failed', ['error' => $e->getMessage()]);
$ grep -n "RefinementService::swapActivities\|RefinementService::moveActivity" Modules/SmartTimetable/routes/web.php
112:        // ⚠ NOT the refinement.move route below. RefinementService::moveActivity() writes
```

### F2 — Transactions and audit

#### RFN-03 · M · TXN-05 — `toggleLock` builds the JSON response inside the transaction

| Field | Value |
|---|---|
| **Rule** | TXN-05 (M) — the transaction closure returns data; `response()`/`redirect()` are built after it. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:105-118`, method `toggleLock()` |
| **Root cause** | The closure's last statement is `return response()->json($result);`, so the HTTP response object is constructed before commit. The controller also wraps the service in a second `DB::transaction` even though `lockCell()` and `unlockCell()` already open their own, which is redundant. |
| **Consequence** | The success JSON is assembled before the write is committed; a commit failure would still have built a success payload. The redundant outer transaction holds the write open around request validation. |
| **Reproduce** | Static only — the response object is created inside the closure; no browser path distinguishes it today. |
| **Fix approach** | Return `$result` from the closure, then `return response()->json($result);` after it. This is folded into the RFN-01 rewrite of the method. |
| **Plan item** | none — see plan §10 |

```php
            return DB::transaction(function () use ($request) {
                $validated = $request->validate([
                    'cell_id' => 'required|integer|exists:tt_timetable_cells,id',
                    'lock' => 'required|boolean',
                ]);

                $result = $validated['lock']
                    ? $this->refinementService->lockCell($validated['cell_id'])
                    : $this->refinementService->unlockCell($validated['cell_id']);

                return response()->json($result);

            });
```

**Evidence**
```
$ grep -n "response()->json" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php
116:                return response()->json($result);
```

#### RFN-04 · M · TXN-06 — `move`/`swap` check the target outside the transaction (check-then-act)

| Field | Value |
|---|---|
| **Rule** | TXN-06 (M, lowered from H — single-school timetabling screen, two writers at most) — check-then-act needs a lock or a unique index. |
| **Where** | `Modules/SmartTimetable/app/Services/RefinementService.php:96-100` (method `moveActivity()`), and `:27-34` (method `swapActivities()`) |
| **Root cause** | `moveActivity()` reads the target cell and confirms it is empty (lines 88-98) **before** opening the transaction at line 100; `swapActivities()` runs `validateSwap()` before its transaction at line 38. Nothing locks the rows between the check and the write. |
| **Consequence** | Two timetablers acting on the same slot within the same second can both pass the "slot is empty" check; the second write overwrites or double-books the slot, and both audit rows claim success. Low probability on a one-timetabler screen, hence M. |
| **Reproduce** | Static only — the check and the write are in different transactions; no browser action shows it deterministically. |
| **Fix approach** | Either accept the risk on this screen (recommended, one DECISION), or load the cells with `lockForUpdate()` inside the transaction and re-run the empty/conflict checks there. |
| **Plan item** | RFN-04 (DECISION) in `02-fix-plan.md` §9 |

```php
        if ($targetCell && $targetCell->activity_id) {
            return ['success' => false, 'message' => 'Target slot is already occupied.'];
        }

        DB::transaction(function () use ($cell, $cellId, $newDayId, $newPeriodOrd, $targetCell, $oldState) {
```

**Evidence**
```
$ sed -n '96,100p' Modules/SmartTimetable/app/Services/RefinementService.php
        if ($targetCell && $targetCell->activity_id) {
            return ['success' => false, 'message' => 'Target slot is already occupied.'];
        }

        DB::transaction(function () use ($cell, $cellId, $newDayId, $newPeriodOrd, $targetCell, $oldState) {
```

### F3 — Authorization

**clean** — every routed method calls `Gate::authorize()` before loading a record: `swap`/`move`/`toggleLock` use `tenant.smart-timetable.timetable.update`, the two GETs use `tenant.smart-timetable.timetable.view`. Both names are declared in `config/permissionslist.php` (key `smart-timetable.timetable` = `$crud` + `generate`, line 714) and seeded in the tenant. Evidence:
```
$ php artisan tinker --execute '...SELECT name FROM sys_permissions WHERE name LIKE "%smart-timetable.timetable%"...'
tenant.smart-timetable.timetable.create
tenant.smart-timetable.timetable.delete
tenant.smart-timetable.timetable.forceDelete
tenant.smart-timetable.timetable.generate
tenant.smart-timetable.timetable.restore
tenant.smart-timetable.timetable.update
tenant.smart-timetable.timetable.view
tenant.smart-timetable.timetable.viewAny
$ ...sys_role_has_permissions_jnt where permission_id = 1643...
role_ids=1,2   (Super Admin, School Admin)
```
No policy is consulted (the gates pass permission strings), so there is no AUTH-04 double-check and no unreachable policy registered for these classes. Each method authorizes exactly once.

### F4 — Validation and input

#### RFN-05 · M · VAL-02 — inline `$request->validate()` instead of Form Requests

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — validation lives in a Form Request; inline `validate()` is allowed only for a one-field AJAX toggle. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:27-30` (`swap`, 2 fields), `:65-69` (`move`, 3 fields), `:107-110` (`toggleLock`, 2 fields) |
| **Root cause** | Each mutating method validates inline. `swap` and `move` are ordinary multi-field writes, not one-field toggles, so they fall outside the exception. No Form Request exists for this controller. |
| **Consequence** | The three write endpoints carry their business input rules in the controller instead of a reusable, unit-testable FormRequest; `move`'s `day_id` and `period_ord` have no existence check (only `integer`). |
| **Reproduce** | Static only — the rules run and pass; the concern is where the rules live. |
| **Fix approach** | DECISION: either record the inline rules as accepted for these small AJAX endpoints, or extract `RefinementSwapRequest` / `RefinementMoveRequest` / `RefinementLockRequest` (moving the gate into `authorize()`). |
| **Plan item** | RFN-05 (DECISION) in `02-fix-plan.md` §9 |

```php
        $validated = $request->validate([
            'cell_id_1' => 'required|integer|exists:tt_timetable_cells,id',
            'cell_id_2' => 'required|integer|exists:tt_timetable_cells,id|different:cell_id_1',
        ]);
```

**Evidence**
```
$ grep -n "request->validate\|request->input" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php
27:        $validated = $request->validate([
65:        $validated = $request->validate([
107:                $validated = $request->validate([
153:        $action = $request->input('action', 'swap');
```
`impact()` reads `action` with `input('action', 'swap')` and no validation; it is echoed into the JSON response only, so it is a low-risk VAL-05 note, folded here.

### F5 — Routes

**clean** — uncached `route:list` shows all five public methods routed; the three writes are POST and the two lookups are GET (no RTE-01); no custom route shares a prefix with a `Route::resource` (RTE-06 not applicable); every route sits in the tenant + auth middleware group with `EnsureTenantHasModule:smart-timetable` and a snapshot guard (RTE-05). Evidence:
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json | php -r '...RefinementController@...'
GET|HEAD smart-timetable/refinement/candidates/{cellId}  smart-timetable.refinement.candidates  ...@candidates
GET|HEAD smart-timetable/refinement/impact/{cellId}      smart-timetable.refinement.impact      ...@impact
POST     smart-timetable/refinement/lock                 smart-timetable.refinement.toggleLock  ...@toggleLock
POST     smart-timetable/refinement/move                 smart-timetable.refinement.move        ...@move
POST     smart-timetable/refinement/swap                 smart-timetable.refinement.swap        ...@swap
```

### F6 — Controller shape

#### RFN-06 · L · CTL-04 — no return types on the five public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — return types on public methods. |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:137-143`, method `candidates()` (and the same on `swap:23`, `move:61`, `toggleLock:101`, `impact:149`) |
| **Root cause** | None of the public methods declares a return type, though every one returns either a `JsonResponse` or a `RedirectResponse`. |
| **Consequence** | A reader cannot see the response contract from the signature; static analysis cannot flag a method that returns the wrong type. |
| **Reproduce** | Static only — cosmetic contract gap. |
| **Fix approach** | Add the union return type `JsonResponse|RedirectResponse` to all five methods (one item). |
| **Plan item** | RFN-06 in `02-fix-plan.md` §5 |

```php
    public function candidates(int $cellId)
    {
        Gate::authorize('tenant.smart-timetable.timetable.view');

        $candidates = $this->refinementService->getSwapCandidates($cellId);

        return response()->json(['success' => true, 'data' => $candidates]);
    }
```

**Evidence**
```
$ grep -nE "public function [a-zA-Z_]+\(" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php
23:    public function swap(Request $request)
61:    public function move(Request $request)
101:    public function toggleLock(Request $request)
137:    public function candidates(int $cellId)
149:    public function impact(Request $request, int $cellId)
```

### F7 — Models

**linked** — `TimetableCell` is audited by its owner (TimetableFoundation/TimetableController; the SmartTimetable alias by TimetableExportController). Usage checked against the audited `Modules/TimetableFoundation/app/Models/TimetableCell.php`: the service's `activity`, `teachers`, `is_locked`, `is_active`, `activity_id`, `sub_activity_id`, `room_id`, `source`, `day_of_week`, `period_ord`, `class_group_id`, `timetable_id` all exist in `$fillable`/`$casts` and the relations resolve. No model-level finding here; the pivot risk is reported as RFN-07 because the fix belongs to this service.

### F8 — Services and jobs

#### RFN-07 · B · DEEP-01 — `teachers()->sync()` omits the `NOT NULL` pivot role, so swap/move throw

| Field | Value |
|---|---|
| **Rule** | Deep-read checklist #1/#2 (B) — a write must not crash or corrupt; the project catalogue (`module-finalization.md` §4) maps the inverse NOT-NULL mismatch to BUG-003b. The pivot column `assignment_role_id` is `NOT NULL` with no default, so the Eloquent pivot INSERT that `sync()` builds (foreign keys + timestamps only) throws `SQLSTATE 1364` under `STRICT_TRANS_TABLES`. |
| **Where** | `Modules/SmartTimetable/app/Services/RefinementService.php:42-43, 60-61` (method `swapActivities()`) and `:109` (method `moveActivity()`) |
| **Root cause** | `swapActivities()` builds plain id lists with `teachers->pluck('id')->toArray()` and passes them to `sync()`; `moveActivity()` does the same inline. `sync()` with a plain list inserts only `cell_id` + `teacher_id` (+ timestamps). It cannot supply `assignment_role_id`, and neither the pivot model's `$attributes` nor the relation (`withPivot('assignment_role_id','is_substitute')`, no `withPivotValue`) provides a value. Every other writer in the codebase (e.g. `SubstitutionService.php:1002`, `TimetableStorageService.php:1012`) supplies `assignment_role_id` explicitly for exactly this reason. |
| **Consequence** | Swapping two cells that carry teachers, or moving a lesson into an empty cell (which gets the source's teachers via `sync`), throws a QueryException; the endpoint 500s and the timetable cannot be refined. This is the screen's core action. |
| **Reproduce** | Static only — this audit is read-only. Proof: the canonical DDL declares the column `NOT NULL` with no default, the live table matches, and the session sql_mode is strict. Any `swap`/`move` that reaches a `sync()` INSERT fails. |
| **Fix approach** | Pass each teacher's existing role into `sync()` as pivot attributes: build an `[id => ['assignment_role_id' => ..., 'is_substitute' => ...]]` map (Laravel's `sync()` accepts pivot attributes on the values) from the already-eager-loaded `teachers` collections, instead of a plain id list. |
| **Plan item** | RFN-07 in `02-fix-plan.md` §1 |

```php
            $tempTeachers1 = $cell1->teachers->pluck('id')->toArray();
            $tempTeachers2 = $cell2->teachers->pluck('id')->toArray();
```

```php
            // Swap teacher assignments
            $cell1->teachers()->sync($tempTeachers2);
            $cell2->teachers()->sync($tempTeachers1);
```

**Evidence**
```
$ grep -n "sync(\|pluck('id')\|detach(" Modules/SmartTimetable/app/Services/RefinementService.php
42:            $tempTeachers1 = $cell1->teachers->pluck('id')->toArray();
43:            $tempTeachers2 = $cell2->teachers->pluck('id')->toArray();
60:            $cell1->teachers()->sync($tempTeachers2);
61:            $cell2->teachers()->sync($tempTeachers1);
109:                $targetCell->teachers()->sync($cell->teachers->pluck('id')->toArray());
118:                $cell->teachers()->detach();
$ php artisan tinker --execute '...tenancy()->initialize(...); SHOW CREATE TABLE tt_timetable_cell_teachers; SELECT @@sql_mode...'
  `assignment_role_id` tinyint unsigned NOT NULL,
  UNIQUE KEY `uq_cct_cell_teacher` (`cell_id`,`teacher_id`),
  CONSTRAINT `fk_cct_role` FOREIGN KEY (`assignment_role_id`) REFERENCES `tt_teacher_assignment_roles` (`id`),
sql_mode = ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION
$ grep -n "assignment_role_id" pgdatabase/2-DDL_Tenant_Consolidated/Timetable_DDL_v7.8.sql
1473:    `assignment_role_id` TINYINT UNSIGNED NOT NULL,  -- FK to tt_teacher_assignment_roles.id
```

### F9 — Queries and performance

#### RFN-08 · H · QRY-01 — one query per teacher inside the conflict-validation loops (N+1)

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — no `Model::where(...)` inside `foreach`; eager-load or pre-fetch and use one query. |
| **Where** | `Modules/SmartTimetable/app/Services/RefinementService.php:226-237` (method `validateMove()`), and `:292-304`, `:306-318` (method `validateSwap()`) |
| **Root cause** | Each loop iterates the cell's teachers and runs an independent `TimetableCell::...->whereHas('teachers', ...)->exists()` per teacher. A cell with k teachers costs k queries in `validateMove` and 2k in `validateSwap`; a move then calls `moveActivity()` which calls `validateMove()`, adding another load of the same cell. |
| **Consequence** | A move or swap on a lesson with several co-teachers issues several repeated, near-identical queries per request; on a large timetable this is the slowest part of an interactive drag-and-drop action. |
| **Reproduce** | Static only — count the `->exists()` calls inside the `foreach` bodies. |
| **Fix approach** | Replace each loop with one query: join `tt_timetable_cell_teachers` and filter `whereIn('ct.teacher_id', $ids)` (and `value('ct.teacher_id')` for the specific-teacher message). |
| **Plan item** | RFN-08 in `02-fix-plan.md` §6 |

```php
        // Check teacher conflicts at new slot
        foreach ($cell->teachers as $teacher) {
            $conflict = TimetableCell::where('timetable_id', $cell->timetable_id)
                ->where('day_of_week', $newDayId)
                ->where('period_ord', $newPeriodOrd)
                ->where('is_active', true)
                ->whereHas('teachers', fn($q) => $q->where('teacher_id', $teacher->id))
                ->exists();

            if ($conflict) {
                return ['valid' => false, 'reason' => "Teacher {$teacher->id} has a conflict at the target slot."];
            }
        }
```

**Evidence**
```
$ grep -n "foreach\|->exists()" Modules/SmartTimetable/app/Services/RefinementService.php
226:        foreach ($cell->teachers as $teacher) {
232:                ->exists();
292:        foreach ($cell2->teachers as $teacher) {
299:                ->exists();
306:        foreach ($cell1->teachers as $teacher) {
313:                ->exists();
```

#### RFN-09 · M · QRY-02 — `getSwapCandidates()` returns an unbounded list

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M, lowered from H — bounded by one timetable's cell count) — lists are paginated/limited, not unbounded `->get()`. |
| **Where** | `Modules/SmartTimetable/app/Services/RefinementService.php:193-199`, method `getSwapCandidates()` |
| **Root cause** | The candidate query has no `limit()`/`paginate()`; it loads every eligible cell of the timetable as full models with two relations. |
| **Consequence** | A timetable with hundreds of cells returns the whole set to the JSON dialog in one response; heavier than the dialog needs. |
| **Reproduce** | Static only — the query has no limit clause. |
| **Fix approach** | Add a bounded `->limit(200)` after the existing filters (the dialog only shows a scrollable pick list). |
| **Plan item** | RFN-09 in `02-fix-plan.md` §6 |

```php
        $candidates = TimetableCell::where('timetable_id', $cell->timetable_id)
            ->where('id', '!=', $cellId)
            ->where('is_locked', false)
            ->where('is_active', true)
            ->whereNotNull('activity_id')
            ->with(['activity.subject', 'teachers'])
            ->get();
```

**Evidence**
```
$ grep -n -e "->get();" Modules/SmartTimetable/app/Services/RefinementService.php
199:            ->get();
```

### F10 — Views

**checked, not present** — the controller renders no Blade view; every method returns `response()->json(...)`. `grep -oE "view(...)"` on the controller returns nothing, and the service has no view reference. There is therefore no VIEW-01/02/03 surface here.

### F11 — Security and tenancy

**clean** — no `env()` outside config (`grep -n "env(" ` → none in either file); no personal data over-exposed (the JSON payloads carry cell ids, day/period ordinals, activity/subject names and teacher display names only); no hard-coded ids or `?? 1` fallbacks; no request bodies or secrets logged (only cell ids and an error message); no cache to key by tenant, and no Spatie media. Snapshot writes are handled by the `snapshot.readonly` middleware on all three POST routes, which refuses a detached-snapshot cell before the service runs; the service's plain-id writes therefore target live cells only. Evidence:
```
$ grep -n "env(" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php Modules/SmartTimetable/app/Services/RefinementService.php
(no output)
```

### F12 — Style

#### RFN-10 · L · STY-01 — controller: missing `declare(strict_types=1)` and unsorted import block

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1);` in PHP files (old files when touched). STY-02 (L) — Pint-clean imports (no stray blank lines between `use` statements). |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/RefinementController.php:1-14` |
| **Root cause** | The file has no `declare(strict_types=1);` and its `use` statements are separated by blank lines (`ModelNotFoundException`, `Log`, `DB` are each on their own block), which Pint will collapse. |
| **Consequence** | Style drift; the file will be reformatted the next time anyone runs Pint on it. |
| **Reproduce** | Static only — run `vendor/bin/pint --test` on the file. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag and let Pint sort/collapse the imports in one pass on this file. |
| **Plan item** | RFN-10 in `02-fix-plan.md` §8 |

```php
use Illuminate\Database\Eloquent\ModelNotFoundException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Modules\SmartTimetable\Services\RefinementService;
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/SmartTimetable/app/Http/Controllers/RefinementController.php
(no output)
```

#### RFN-11 · L · STY-01 — service: missing `declare(strict_types=1)` and an unused `Log` import

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — `declare(strict_types=1);`. STY-05 (L) — one import per class, none unused. |
| **Where** | `Modules/SmartTimetable/app/Services/RefinementService.php:5-7` |
| **Root cause** | The file has no `declare(strict_types=1);` and imports `Illuminate\Support\Facades\Log` although the service never calls `Log::` (its logging goes through `activityLog()`). |
| **Consequence** | An unused import misleads a reader into thinking the service logs directly; style drift. |
| **Reproduce** | Static only — `grep -n "Log::"` on the service returns nothing. |
| **Fix approach** | Add `declare(strict_types=1);` and delete the unused `Log` import. |
| **Plan item** | RFN-11 in `02-fix-plan.md` §8 |

```php
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Modules\TimetableFoundation\Models\TimetableCell;
```

**Evidence**
```
$ grep -n "Log::" Modules/SmartTimetable/app/Services/RefinementService.php
NONE
$ grep -n "declare(strict_types" Modules/SmartTimetable/app/Services/RefinementService.php
(no output)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutating method | 1 wrong data | 2 delete-before-store | 3 duplicate impl | 4 soft-delete×unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `swapActivities()` (service) | RFN-07 | ok — swap writes both cells inside one tx | ok | ok — `detach()`/`sync()` hard-delete via pivot; no soft-deleted pivot rows created here | RFN-04 | ok | ok | ok |
| `moveActivity()` (service) | RFN-07 | ok — target written before source cleared, inside one tx | ok — the lock/empty re-checks overlap `validateMove()` but do not disagree | ok | RFN-04 | ok | ok | ok |
| `lockCell()` (service) | ok | ok | ok | ok | ok | ok | ok | ok |
| `unlockCell()` (service) | ok | ok | ok | ok | ok | ok | ok | ok |
| `logChange()` (service) | ok — writes an audit row only | ok | ok | ok | ok | ok | ok | `getImpactAnalysis()`'s `$params` argument is never used and the controller passes no third argument (informational; no behavioural effect) |
| `swap` (controller) | RFN-07 | ok | ok | ok | RFN-04 | ok | ok — the refusal messages match the service results | ok — delegates to the service |
| `move` (controller) | RFN-07 | ok | ok | ok | RFN-04 | ok | ok | ok |
| `toggleLock` (controller) | ok | ok | ok | ok | ok — a boolean lock toggle is idempotent | ok | RFN-01 — a validation failure is reported as a generic 500, which is a message that does not describe the cause | ok |

**Wrong data (Q1):** the only data-loss risk is RFN-07 (the pivot insert either throws or, if a role default ever appeared, would write a wrong role). No method resets a status it should not.
**Irreversible order (Q2):** `swapActivities()` and `moveActivity()` write both sides inside one `DB::transaction`; the source cell is cleared after the target is written. No file/mail/HTTP side effects exist in either service.
**Duplicate implementations (Q3):** `moveActivity()` re-checks `is_locked`/empty that `validateMove()` also checks. The checks agree, so this is a minor duplication, not a bug.
**Soft-delete × unique (Q4):** `sync()`/`detach()` hard-delete pivot rows, so no soft-deleted row can collide with `uq_cct_cell_teacher`. The `teachers()` relation does not add `wherePivotNull('deleted_at')` (an MDL-03 concern in the linked `TimetableCell` model), but this service never creates trashed pivot rows, so it cannot bite here.
**Races (Q5):** RFN-04.
**Auth holes (Q6):** none — every entry method gates before touching a record, and the service is reachable only through this controller (`grep` across the codebase shows `RefinementService` used only by `RefinementController`).
**Lying messages (Q7):** RFN-01 reports a validation failure as an internal 500. The service's refusal messages ("Cannot swap locked cells.", "Target slot is already occupied.") are accurate and are returned in the 422 path.
**Dead features (Q8):** `getImpactAnalysis()` ignores both `$action` and `$params`, so the "impact" for a swap and a move is identical and `$params` is dead; no consumer reads a richer impact. Informational only.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/app/Models/TimetableCellTeacher.php` | `$fillable` lists `substitution_log_id`, which is not a column of `tt_timetable_cell_teachers` (the table has `cell_id`, `teacher_id`, `assignment_role_id`, `is_substitute`, `is_active`). Harmless for reads but a latent trap on mass-assignment. | MDL-01 / VAL-01 | the TimetableFoundation report that owns the pivot model |
| `Modules/TimetableFoundation/app/Models/TimetableCell.php` | `teachers()` is a `belongsToMany` over a pivot with `deleted_at` but does not add `wherePivotNull('deleted_at')`. | MDL-03 | the owning report (TimetableFoundation/TimetableController-done) |

## 8. Not covered, and why

- **Blade views**: the controller renders none, so the VIEW family has no surface (checked, not present).
- **Live browser reproduction**: the tenant `test.localhost` has 0 rows in `tt_timetable_cells` and `tt_timetables`, so none of the five endpoints can be driven end-to-end. Every write finding is proven statically (DDL + sql_mode + source), not by executing the write — this audit is read-only.
- **Executing `sync()`**: prohibited (no DB writes in this workflow). RFN-07 is proven from the canonical DDL (`NOT NULL`, no default), the live `SHOW CREATE TABLE`, the strict `sql_mode`, and the Eloquent pivot-insert shape, corroborated by every other writer in the module supplying `assignment_role_id` explicitly.
- **The two DECISION items** (RFN-04, RFN-05): options are in the plan; no choice is assumed here.
- **Jobs, events, mail, notifications, exports, imports**: none are referenced by this controller.
