# Final Audit — SmartTimetable / SubstitutionController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php` (419 lines, 10 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/substitute-management?tab=substitute-assignment` (the tab these endpoints serve); `/smart-timetable/substitution/history/{teacherId}` (history page) |
| Menu path | Smart Timetable → Substitute Management → tabs Substitute Requirement / Substitute Assignment / Substitute Notifications |
| Who uses it | Roles holding `tenant.smart-timetable.timetable.update` (School Admin role id 2 and Super Admin id 1 on test.localhost) and `...timetable.view` (same roles) |
| What a user does here | An office user reports a teacher absent for a day or a range, sees which periods lose their teacher, picks a substitute for each period (manually or auto-assign), marks a substitute as notified, and approves or rejects an absence request. Cover given on an old-but-still-published timetable keeps working through the snapshot mirror. |
| Tables written | `tt_teacher_absences`, `tt_substitution_logs`, `tt_timetable_cell_teachers`, `sys_activity_logs` (and the `tt_snap_*` mirrors when the cell is from a snapshot) |
| Tables read | `tt_timetable_cells`, `tt_timetable_cell_teachers`, `tt_activities`, `tt_timetables`, `tt_teacher_absences`, `tt_substitution_logs`, `tt_school_days`, `sch_holidays`, `sch_teachers`, `sch_teacher_profile`, `sch_teacher_capabilities`, `sch_subject_study_format_jnt`, `sch_classes`, `sch_sections` |
| Live data | tenant DB `xyz_school_00000000000040008000_202627` today: `tt_teacher_absences` 0 live / 0 trashed, `tt_substitution_logs` 0 live / 0 trashed, `tt_timetable_cells` 0, `tt_timetable_cell_teachers` 0, `sys_activity_logs` 396. The tenant is currently empty of timetable data, so every screen is reachable but shows no rows. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No, this controller is not production-ready: the write endpoints turn a failed database operation into a full user-facing error that echoes the raw exception message, a class of defect that leaks SQL and table names (SBS-01, SBS-02). The single worst finding is SBS-01 — every failed write on this screen shows the browser the database's own error text instead of a plain sentence. Two model helpers that approve/reject an absence and mark a substitute notified write a row and an audit row with no transaction, so a failure between the two leaves the audit log and the data disagreeing (SBS-05, SBS-06). Several long-standing design choices are deliberate and documented (per-cell transactions, `getDashboard()` kept with no caller), so the fix plan is mostly mechanical: hours, not days, once the DECISION items are answered.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 6 | 8 | 7 | 3 | 23 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SBS-01, SBS-02, SBS-03, SBS-04 | F8 Services/Jobs | SBS-18 |
| F2 Transactions/Audit | SBS-05, SBS-06, SBS-07, SBS-08, SBS-09 | F9 Queries/Perf | SBS-20, SBS-21 |
| F3 Authorization | SBS-10 | F10 Views | clean |
| F4 Validation | SBS-11, SBS-12 | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | SBS-22, SBS-23 |
| F6 Controller shape | SBS-13, SBS-14, SBS-15, SBS-16, SBS-17 | F13 Deep read | SBS-08 |
| F7 Models | SBS-19 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php` | controller | 419 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Services/SubstitutionService.php` | service | 1698 | this report (claimed) | ✅ |
| 3 | `Modules/SmartTimetable/app/Services/SubstitutionHistoryReader.php` | service | 118 | this report (claimed) | ✅ |
| 4 | `Modules/SmartTimetable/app/Http/Requests/SaveSubstituteGridRequest.php` | request | 64 | this report | ✅ |
| 5 | `Modules/SmartTimetable/app/Models/SubstitutionLog.php` | model | 244 | this report | ✅ |
| 6 | `Modules/SmartTimetable/app/Models/TeacherAbsences.php` | model | 267 | this report | ✅ |
| 7 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotWriteGuard.php` | support | 89 | this report (claimed) | ✅ |
| 8 | `Modules/TimetableFoundation/app/Support/Snapshot/CellExistsInSource.php` | support | 43 | this report (claimed) | ✅ |
| 9 | `Modules/TimetableFoundation/app/Support/Snapshot/SnapshotContext.php` | support | 342 | ↗ [tarun/StandardTimetable/StandardTimetableController-done](../StandardTimetable/StandardTimetableController-done/01-report.md) | ↗ linked |
| 10 | `Modules/SmartTimetable/resources/views/substitution/history.blade.php` | view | 148 | this report | ✅ |
| 11 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | — | ↗ [TimetableFoundation/TimetableController](../../TimetableFoundation/TimetableController-done/01-report.md) | ↗ linked |
| 12 | `Modules/TimetableFoundation/app/Models/TimetableCell.php` | model | — | ↗ [TimetableFoundation/TimetableController](../../TimetableFoundation/TimetableController-done/01-report.md) | ↗ linked |
| 13 | `Modules/TimetableFoundation/app/Models/TeacherAssignmentRole.php` | model | — | ↗ [TimetableFoundation/TeacherAssignmentRoleController](../../TimetableFoundation/TeacherAssignmentRoleController-done/01-report.md) | ↗ linked |
| 14 | `Modules/TimetableFoundation/app/Services/OptionCellResolver.php` | service | 533 | ↗ [TimetableFoundation/TimetableFoundationController](../../TimetableFoundation/TimetableFoundationController/01-report.md) | ↗ linked |
| 15 | `Modules/TimetableFoundation/app/Services/PublishedTimetable.php` | service | 255 | ↗ [TimetableFoundation/TimetableFoundationController](../../TimetableFoundation/TimetableFoundationController/01-report.md) | ↗ linked |
| 16 | `Modules/SchoolSetup/**` (`Teacher`, `User`, `SchoolClass`, `Section`, `OrganizationAcademicSession`) | common | — | common (§4.2) | ➖ not audited |

No pre-applied files named in a `PRE-APPLIED-*.md` apply to these paths.

The linked snapshot classes and TimetableFoundation services are audited by the reports above; this report only checks **how** this controller uses them (see §7 and SBS-08/SBS-18).

## 4. Routes

```
POST     smart-timetable/substitution-log/{id}/notify            smart-timetable.substitution-log.notify      Modules\SmartTimetable\Http\Controllers\SubstitutionController@markNotified
POST     smart-timetable/substitution/absence                    smart-timetable.substitution.reportAbsence   Modules\SmartTimetable\Http\Controllers\SubstitutionController@reportAbsence
POST     smart-timetable/substitution/assign                     smart-timetable.substitution.assign          Modules\SmartTimetable\Http\Controllers\SubstitutionController@assign
POST     smart-timetable/substitution/auto-assign                smart-timetable.substitution.autoAssign      Modules\SmartTimetable\Http\Controllers\SubstitutionController@autoAssign
GET|HEAD smart-timetable/substitution/candidates/{cellId}/{date} smart-timetable.substitution.candidates      Modules\SmartTimetable\Http\Controllers\SubstitutionController@candidates
GET|HEAD smart-timetable/substitution/history/{teacherId}        smart-timetable.substitution.history         Modules\SmartTimetable\Http\Controllers\SubstitutionController@history
POST     smart-timetable/substitution/teacher-grid/save          smart-timetable.substitution.saveTeacherGrid Modules\SmartTimetable\Http\Controllers\SubstitutionController@saveTeacherGrid
GET|HEAD smart-timetable/substitution/teacher-grid/{teacherId}   smart-timetable.substitution.teacherGrid     Modules\SmartTimetable\Http\Controllers\SubstitutionController@teacherGrid
POST     smart-timetable/teacher-absence/{id}/approve            smart-timetable.teacher-absence.approve      Modules\SmartTimetable\Http\Controllers\SubstitutionController@approveAbsence
POST     smart-timetable/teacher-absence/{id}/reject             smart-timetable.teacher-absence.reject       Modules\SmartTimetable\Http\Controllers\SubstitutionController@rejectAbsence
```

Every route sits inside `Route::middleware(['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable'])` (verified in `Modules/SmartTimetable/routes/web.php:44-47`). The three substitution writes carry the extra `snapshot.cell` middleware.

Unrouted public methods: none. All ten public methods are routed (the constructor is not a route target).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `reportAbsence` | 64 | POST substitution/absence | `tenant.smart-timetable.timetable.update` | service `reportAbsenceRange` | `AbsenceReported` (service) | tt_teacher_absences, sys_activity_logs | SBS-01, SBS-03, SBS-04, SBS-07, SBS-11, SBS-20 |
| `candidates` | 147 | GET substitution/candidates/{cellId}/{date} | `tenant.smart-timetable.timetable.view` | none (read) | none | none | clean |
| `assign` | 164 | POST substitution/assign | `tenant.smart-timetable.timetable.update` | service `assignInSource` | `SubstituteAssigned` (service) | tt_timetable_cell_teachers, tt_substitution_logs, sys_activity_logs | SBS-01, SBS-02, SBS-03, SBS-04, SBS-11, SBS-20 |
| `autoAssign` | 237 | POST substitution/auto-assign | `tenant.smart-timetable.timetable.update` | service `autoAssign` (per-cell + run) | `SubstitutesAutoAssigned` (service) | tt_timetable_cell_teachers, tt_substitution_logs, tt_teacher_absences, sys_activity_logs | SBS-01, SBS-03, SBS-04, SBS-11 |
| `history` | 277 | GET substitution/history/{teacherId} | `tenant.smart-timetable.timetable.view` | none (read) | none | none | SBS-16 |
| `approveAbsence` | 289 | POST teacher-absence/{id}/approve | `tenant.smart-timetable.timetable.update` | none | `AbsenceApproved` (model) | tt_teacher_absences, sys_activity_logs | SBS-05, SBS-15 |
| `rejectAbsence` | 302 | POST teacher-absence/{id}/reject | `tenant.smart-timetable.timetable.update` | none | `AbsenceRejected` (model) | tt_teacher_absences, sys_activity_logs | SBS-05, SBS-15 |
| `markNotified` | 315 | POST substitution-log/{id}/notify | `tenant.smart-timetable.timetable.update` | none | `SubstituteNotified` (model) | tt_substitution_logs, sys_activity_logs | SBS-06, SBS-15 |
| `teacherGrid` | 344 | GET substitution/teacher-grid/{teacherId} | `tenant.smart-timetable.timetable.view` | none (read) | none | none | SBS-03, SBS-04 |
| `saveTeacherGrid` | 379 | POST substitution/teacher-grid/save | `tenant.smart-timetable.timetable.update` (also FormRequest) | service per cell | `SubstituteAssigned` / `SubstituteRemoved` (service) | tt_timetable_cell_teachers, tt_substitution_logs, sys_activity_logs | SBS-01, SBS-03, SBS-04, SBS-08, SBS-10, SBS-20 |
| `SubstitutionService::reportAbsenceRange` | 379 | via reportAbsence | n/a | 1 transaction, lines 440-512 | `AbsenceReported` | tt_teacher_absences, sys_activity_logs | SBS-07, SBS-20 |
| `SubstitutionService::findSubstitutes` | 543 | via candidates/assign | n/a | none (read) | none | none | SBS-14 |
| `SubstitutionService::assignSubstitute` | 967 | via assign/autoAssign/save | n/a | service `assignInSource` | `SubstituteAssigned` | see assign row | SBS-02 |
| `SubstitutionService::autoAssign` | 1057 | via autoAssign | n/a | per cell + run (lines 1117-1132) | `SubstitutesAutoAssigned` | see autoAssign row | SBS-14 |
| `SubstitutionService::getSubstitutionHistory` | 1145 | via history | n/a | none (read) | none | none | clean |
| `SubstitutionService::getDashboard` | 1177 | none | n/a | none (read) | none | none | SBS-17 |
| `SubstitutionService::getTeacherSubstitutionPlan` | 1247 | via TimetableMenuController | n/a | none (read) | none | none | clean |
| `SubstitutionService::getTeacherGrid` | 1327 | via teacherGrid | n/a | none (read) | none | none | SBS-20 |
| `SubstitutionService::saveTeacherGrid` | 1406 | via saveTeacherGrid | n/a | per cell | `SubstituteAssigned` / `SubstituteRemoved` | see saveTeacherGrid row | SBS-08, SBS-14, SBS-20 |
| `SubstitutionService::removeSubstitute` | 1509 | via saveTeacherGrid | n/a | service `removeInSource` | `SubstituteRemoved` | tt_timetable_cell_teachers, tt_substitution_logs, sys_activity_logs | SBS-02, SBS-09 |
| `SubstitutionService::getSubstituteDutyRecords` | 1578 | via TimetableMenuController | n/a | none (read) | none | none | SBS-14, SBS-20 |
| `SubstitutionService::dateString` (private) | 1692 | n/a | n/a | none | none | none | clean |

## 6. Findings

### F1 — Errors

#### SBS-01 · B · ERR-01 — Failed writes show the browser the database's own error text

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:134-140`, methods `reportAbsence()` (also `assign()` 215-219, `autoAssign()` 266-270, `saveTeacherGrid()` 413-416) |
| **Root cause** | Each catch interpolates `$e->getMessage()` into the flash or JSON string shown to the user, so a `QueryException` reveals the SQL statement and the table/column names. |
| **Consequence** | A school admin reporting an absence that hits a strict-mode or FK error reads "SQLSTATE 1265 ... Data truncated for column 'absence_type'" in a red banner instead of "The absence could not be reported." |
| **Reproduce** | POST `/smart-timetable/substitution/absence` with a payload the DB rejects (for example a `date_to` that fails validation is caught before the write, but any FK/strict failure inside the service reaches these catches). Static evidence below is sufficient for the code shape. |
| **Fix approach** | Replace the interpolated message with a fixed sentence and let the log hold the detail (SBS-02 covers the service half). |
| **Plan item** | SBS-01 in `02-fix-plan.md` §1 |

```php
// SubstitutionController.php:134-140 — CURRENT
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Failed to report absence: '.$e->getMessage()], 500);
            }

            return back()
                ->withInput()
                ->with('error', 'Failed to report absence: '.$e->getMessage());
```

**Evidence**
```
$ grep -n 'getMessage' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
130:                'error' => $e->getMessage(),
135:                return response()->json(['success' => false, 'message' => 'Failed to report absence: '.$e->getMessage()], 500);
140:                ->with('error', 'Failed to report absence: '.$e->getMessage());
212:                'error' => $e->getMessage(),
216:                return response()->json(['success' => false, 'message' => 'Failed to assign substitute: '.$e->getMessage()], 500);
219:            return back()->with('error', 'Failed to assign substitute: '.$e->getMessage());
263:                'error' => $e->getMessage(),
267:                return response()->json(['success' => false, 'message' => 'Auto-assign failed: '.$e->getMessage()], 500);
270:            return back()->with('error', 'Auto-assign failed: '.$e->getMessage());
356:                'error' => $e->getMessage(),
410:                'error' => $e->getMessage(),
415:                'message' => 'Failed to save the substitute grid: '.$e->getMessage(),
```

#### SBS-02 · B · ERR-01 — The service returns the raw exception message as its error result

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:1038-1047`, methods `assignInSource()` (also `removeInSource()` 1559-1565) |
| **Root cause** | Both service writes catch `\Throwable` and return `message => '...'.$e->getMessage()`. The controller forwards that result straight to the JSON response or flash, so the leak reaches the user even without the controller catches. |
| **Consequence** | Assigning a substitute can answer with `Failed to assign substitute: SQLSTATE[23000]: Integrity constraint violation ...` in the modal. |
| **Reproduce** | `POST /smart-timetable/substitution/assign`; force a pivot constraint failure. Static evidence below. |
| **Fix approach** | Per D2, a service catch uses `report($e)` plus a fixed message. |
| **Plan item** | SBS-02 in `02-fix-plan.md` §1 |

```php
// SubstitutionService.php:1038-1047 — CURRENT
        } catch (\Throwable $e) {
            \Log::error('Substitution assignSubstitute failed', [
                'cell_id' => $cellId,
                'substitute_teacher_id' => $substituteTeacherId,
                'date' => $date,
                'error' => $e->getMessage(),
            ]);

            return ['success' => false, 'message' => 'Failed to assign substitute: '.$e->getMessage()];
        }
```

**Evidence**
```
$ grep -n 'getMessage' Modules/SmartTimetable/app/Services/SubstitutionService.php
1043:                'error' => $e->getMessage(),
1046:            return ['success' => false, 'message' => 'Failed to assign substitute: '.$e->getMessage()];
1561:                'cell_id' => $cellId, 'date' => $date, 'error' => $e->getMessage(),
1564:            return ['success' => false, 'message' => 'Failed to remove substitute: '.$e->getMessage()];
```

#### SBS-03 · M · ERR-05 — Logging captures the message string, not the exception object

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `['exception' => $e]`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:127-132`, method `reportAbsence()` (also `assign()`, `autoAssign()`, `teacherGrid()`, `saveTeacherGrid()`) |
| **Root cause** | Every catch calls `\Log::error(..., ['error' => $e->getMessage()])`. Only `reportAbsence()` also logs `getTraceAsString()`, and even that is a string, not the object the framework can deduplicate. |
| **Consequence** | When a write fails in production, the log has a bare message with no stack trace and no exception class for the remaining four methods, so the cause cannot be located. |
| **Reproduce** | static only — a log file is needed to see the missing trace. |
| **Fix approach** | Use `report($e)` (or `Log::error($msg, ['exception' => $e])`); the SBS-02 fix already applies this inside the service. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionController.php:126-132 — CURRENT
        } catch (\Throwable $e) {
            \Log::error('Substitution reportAbsence failed', [
                'teacher_id' => $validated['teacher_id'] ?? null,
                'date' => $validated['date'] ?? null,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
```

**Evidence**
```
$ grep -n 'Log::error' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
127:            \Log::error('Substitution reportAbsence failed', [
209:            \Log::error('Substitution assign failed', [
260:            \Log::error('Substitution autoAssign failed', [
354:            \Log::error('Substitution teacherGrid failed', [
408:            \Log::error('Substitution saveTeacherGrid failed', [
```

#### SBS-04 · M · ERR-00 — The controller still wraps its writes in try/catch, which D1 has retired

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M, D1 override) — *settled: the Laravel idiom has no try/catch in a controller; `DB::transaction()` rolls back and the central handler renders errors* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:80-89`, method `reportAbsence()` (also `assign()` 178, `autoAssign()` 246, `teacherGrid()` 348, `saveTeacherGrid()` 385) |
| **Root cause** | Five methods carry a `try { ... } catch (\Throwable $e) { ... }` written under the older house rule "STRICT RULE 1". D1 reverses that rule; none of these catches matches a D2 shape (no `DomainException`, no truncate-then-rebuild, no `SnapshotProtectionException`). |
| **Consequence** | A 404 or validation failure inside the block is converted to a redirect/J500-shaped response instead of the framework's correct status; the code carries duplicate error handling the central handler already does. |
| **Reproduce** | static only — the defect is the presence of the try/catch, not a runtime path. |
| **Fix approach** | Remove the controller try/catch and let `DB::transaction()` and `bootstrap/app.php` do their job. Deferred in this pass because removing it changes the on-screen error text for five endpoints; tracked here as a decision. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionController.php:80-89 — CURRENT
        try {
            $result = $this->substitutionService->reportAbsenceRange(
                $validated['teacher_id'],
                $validated['date'],
                $validated['date_to'] ?? null,
                $validated['reason'] ?? null,
                $validated['absence_type'] ?? 'OTHER',
                $validated['start_period'] ?? null,
                $validated['end_period'] ?? null
            );
```

**Evidence**
```
$ grep -n 'try {\|catch (' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
80:        try {
126:        } catch (\Throwable $e) {
178:        try {
206:        } catch (ModelNotFoundException $e) {
208:        } catch (\Throwable $e) {
246:        try {
259:        } catch (\Throwable $e) {
348:        try {
353:        } catch (\Throwable $e) {
385:        try {
407:        } catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### SBS-05 · H · TXN-01 — Approving or rejecting an absence writes two tables with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (a model and its audit row) runs inside one `DB::transaction`* |
| **Where** | `Modules/SmartTimetable/app/Models/TeacherAbsences.php:216-246`, methods `approve()` and `reject()` |
| **Root cause** | Each method calls `$this->update([...])` and then `activityLog($this, ...)` with no `DB::transaction` around them. The model docblock asserts a single-row update needs no transaction, but the audit row is a second table write. |
| **Consequence** | If the audit insert fails after the status update commits, the absence is APPROVED with no `AbsenceApproved` entry in `sys_activity_logs` — the decision becomes unattributable, which is exactly what the audit row exists to prevent. |
| **Reproduce** | POST `/smart-timetable/teacher-absence/{id}/approve`. Static evidence below. |
| **Fix approach** | Wrap both writes in one `DB::transaction` closure in the model method. |
| **Plan item** | SBS-05 in `02-fix-plan.md` §3 |

```php
// TeacherAbsences.php:216-230 — CURRENT
    public function approve(int $userId): void
    {
        $this->update([
            'status' => self::STATUS_APPROVED,
            'approved_by' => $userId,
            'approved_at' => now(),
        ]);

        activityLog($this, 'AbsenceApproved', [
            'message' => 'Teacher absence was approved.',
            'teacher_id' => $this->teacher_id,
            'date' => $this->absence_date?->toDateString(),
            'approved_by' => $userId,
        ]);
    }
```

**Evidence**
```
$ grep -n 'activityLog\|DB::transaction' Modules/SmartTimetable/app/Models/TeacherAbsences.php
224:        activityLog($this, 'AbsenceApproved', [
240:        activityLog($this, 'AbsenceRejected', [
```

#### SBS-06 · H · TXN-01 — Marking a substitute notified writes two tables with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *a model write plus its audit row runs inside one `DB::transaction`* |
| **Where** | `Modules/SmartTimetable/app/Models/SubstitutionLog.php:208-219`, method `markNotified()` |
| **Root cause** | `$this->update(['notified_at' => now()])` is followed by `activityLog(...)` with no transaction, and the controller calls it inside `runSnapshot()` with no transaction either. |
| **Consequence** | A substitute can be recorded as notified while the `SubstituteNotified` audit entry is missing, so a school cannot prove who was told to cover a lesson. |
| **Reproduce** | POST `/smart-timetable/substitution-log/{id}/notify`. Static evidence below. |
| **Fix approach** | Wrap the update and the audit row in one `DB::transaction` in the model method. |
| **Plan item** | SBS-06 in `02-fix-plan.md` §3 |

```php
// SubstitutionLog.php:208-219 — CURRENT
    public function markNotified(): void
    {
        $this->update([
            'notified_at' => now(),
        ]);

        activityLog($this, 'SubstituteNotified', [
            'message' => 'Substitute teacher was marked as notified.',
            'substitution_log_id' => $this->id,
            'notified_at' => $this->notified_at?->toDateTimeString(),
        ]);
    }
```

**Evidence**
```
$ grep -n 'activityLog\|DB::transaction' Modules/SmartTimetable/app/Models/SubstitutionLog.php
214:        activityLog($this, 'SubstituteNotified', [
```

#### SBS-07 · H · TXN-06 — Reporting a range reads existing rows then inserts, with no lock

| Field | Value |
|---|---|
| **Rule** | TXN-06 (H) — *check-then-act needs a lock or a unique index; `count()` then insert, `exists()` then `create()`* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:425-429`, method `reportAbsenceRange()` (insert at 495-499) |
| **Root cause** | `TeacherAbsences::withTrashed()->...->get()->keyBy(...)` is read **before** the `DB::transaction` opens, then each missing date is inserted inside it. Two requests for the same teacher/date in the same instant both see no row and both insert. `uq_ta_teacher_date` is a plain unique index and is not soft-delete aware. |
| **Consequence** | The second request hits SQLSTATE 1062; the open range transaction rolls back and the user is told (after SBS-01/02 are fixed) only that the absence could not be reported. |
| **Reproduce** | send two `POST /smart-timetable/substitution/absence` for the same teacher and date concurrently. Static evidence below. |
| **Fix approach** | Re-read the date inside the transaction with `lockForUpdate()`, or catch the duplicate and treat it as "already recorded". |
| **Plan item** | SBS-07 in `02-fix-plan.md` §3 |

```php
// SubstitutionService.php:425-429 — CURRENT
        $existing = TeacherAbsences::withTrashed()
            ->where('teacher_id', $teacherId)
            ->whereBetween('absence_date', [$start->toDateString(), $end->toDateString()])
            ->get()
            ->keyBy(fn ($a) => $a->absence_date->toDateString());
```

**Evidence**
```
$ php artisan tinker --execute '... SHOW INDEX FROM tt_teacher_absences ...'
uq_ta_teacher_date col=teacher_id uniq=1
uq_ta_teacher_date col=absence_date uniq=1
```

#### SBS-08 · H · TXN-03 — Saving a grid removes the old substitute before proving the new one can be attached

| Field | Value |
|---|---|
| **Rule** | TXN-03 (H) — *no irreversible side effect before the write succeeds; deep-read question 2, is anything deleted before its replacement is stored* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:1461-1487`, method `saveTeacherGrid()` |
| **Root cause** | On "replace", the code calls `removeSubstitute()` (which deletes the pivot row and soft-deletes the log in its own transaction) and only then calls `assignSubstitute()`. If the assign fails — a teacher who became busy since the modal opened — the original cover is already gone. |
| **Consequence** | A period that was covered ends up uncovered and the message names it as a failure, so the user believes the old substitute is still there. Real cover is lost. |
| **Reproduce** | Open one teacher's grid, change a period's substitute to a teacher who is busy at that period, save. Static evidence below. |
| **Fix approach** | Attach the new substitute first and only remove the old one when the attach succeeded, or wrap the replace in one transaction that rolls the removal back on failure. Behaviour change; tracked as a decision. |
| **Plan item** | SBS-08 in `02-fix-plan.md` §9 |

```php
// SubstitutionService.php:1461-1487 — CURRENT
            if ($current !== null) {
                $removal = $this->removeSubstitute($cellId, $date);

                if (! $removal['success']) {
                    $failures[] = ['cell_id' => $cellId, 'date' => $date, 'message' => $removal['message']];

                    continue;
                }
            }

            if ($wanted === null) {
                $cleared++;

                continue;
            }

            $absenceId = TeacherAbsences::where('teacher_id', $teacherId)
                ->whereDate('absence_date', $date)
                ->value('id');

            $result = $this->assignSubstitute($cellId, $wanted, $date, $absenceId ? (int) $absenceId : null);
```

**Evidence**
```
$ grep -n 'removeSubstitute\|assignSubstitute' Modules/SmartTimetable/app/Services/SubstitutionService.php
1462:                $removal = $this->removeSubstitute($cellId, $date);
1481:            $result = $this->assignSubstitute($cellId, $wanted, $date, $absenceId ? (int) $absenceId : null);
```

#### SBS-09 · M · TXN-04 — The removal audit row is written before the log it describes is deleted

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:1545-1553`, method `removeInSource()` |
| **Root cause** | Inside the loop, `activityLog($log, 'SubstituteRemoved', ...)` runs first and `$log->delete()` second. The audit entry describes a deletion that has not happened yet. |
| **Consequence** | If the delete fails, `sys_activity_logs` claims a substitute was removed when the row is still on the timetable. |
| **Reproduce** | static only — the ordering is the defect. |
| **Fix approach** | Move `$log->delete()` above the `activityLog()` call. |
| **Plan item** | SBS-09 in `02-fix-plan.md` §3 |

```php
// SubstitutionService.php:1545-1553 — CURRENT
                foreach ($logs as $log) {
                    activityLog($log, 'SubstituteRemoved', [
                        'message' => 'A substitute teacher was removed from a cell.',
                        'cell_id' => $cellId,
                        'substitute_teacher_id' => $substitute->id,
                        'date' => $date,
                    ]);
                    $log->delete();
                }
```

**Evidence**
```
$ sed -n '1545,1553p' Modules/SmartTimetable/app/Services/SubstitutionService.php
                foreach ($logs as $log) {
                    activityLog($log, 'SubstituteRemoved', [
                    ...
                    $log->delete();
                }
```

### F3 — Authorization

#### SBS-10 · L · AUTH-04 — `saveTeacherGrid` authorizes the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice; keep one* |
| **Where** | `Modules/SmartTimetable/app/Http/Requests/SaveSubstituteGridRequest.php:28-31`, method `authorize()` (and `SubstitutionController.php:381`) |
| **Root cause** | The FormRequest `authorize()` checks `tenant.smart-timetable.timetable.update` and the controller immediately checks the same string with `Gate::authorize`. The request runs first, so the controller check is redundant. |
| **Consequence** | No user is wrongly refused; the cost is a duplicated rule that can drift (one surface changed, the other forgotten). |
| **Reproduce** | static only. |
| **Fix approach** | Keep the FormRequest check (it runs first) and drop the controller `Gate::authorize`; or the reverse. Low priority. |
| **Plan item** | none — see plan §10 |

```php
// SaveSubstituteGridRequest.php:28-31 — CURRENT
    public function authorize(): bool
    {
        return Gate::allows('tenant.smart-timetable.timetable.update');
    }
```

**Evidence**
```
$ grep -n "smart-timetable.timetable.update" Modules/SmartTimetable/app/Http/Requests/SaveSubstituteGridRequest.php Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
Modules/SmartTimetable/app/Http/Requests/SaveSubstituteGridRequest.php:30:        return Gate::allows('tenant.smart-timetable.timetable.update');
Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:381:        Gate::authorize('tenant.smart-timetable.timetable.update');
```

### F4 — Validation and input

#### SBS-11 · M · VAL-02 — Three writes validate inline instead of through a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request, not inline `$request->validate()` (one-field AJAX toggle excepted)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:68-78`, method `reportAbsence()` (also `assign()` 168-176, `autoAssign()` 241-244) |
| **Root cause** | Each write calls `$request->validate([...])` in the controller. The grid save already uses a FormRequest, so the pattern is inconsistent inside one controller. |
| **Consequence** | The rules cannot be reused or unit-checked in isolation, and the permission/authorization surface is split across files unpredictably. |
| **Reproduce** | static only. |
| **Fix approach** | Extract three FormRequests with the same rules; the write path is unchanged. Tracked as a decision because it adds three files. |
| **Plan item** | SBS-11 in `02-fix-plan.md` §9 |

```php
// SubstitutionController.php:68-78 — CURRENT
        $validated = $request->validate([
            'teacher_id' => 'required|integer|exists:sch_teachers,id',
            'date' => 'required|date',
            // Optional end of a RANGE. Blank means a single day, which is what the form
            // submits when the field is left alone — so the old one-day flow is unchanged.
            'date_to' => 'nullable|date|after_or_equal:date',
            'reason' => 'nullable|string|max:500',
            'absence_type' => 'nullable|string|in:LEAVE,SICK,TRAINING,OFFICIAL_DUTY,OTHER',
            'start_period' => 'nullable|integer|min:1',
            'end_period' => 'nullable|integer|min:1|gte:start_period',
        ]);
```

**Evidence**
```
$ grep -n 'request->validate' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
68:        $validated = $request->validate([
168:        $validated = $request->validate([
241:        $validated = $request->validate([
```

#### SBS-12 · L · VAL-05 — `absence_id` is accepted without an existence check

| Field | Value |
|---|---|
| **Rule** | VAL-05 (M, lowered to L) — *every field is typed; write paths with no real validation are H* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:168-176`, method `assign()` |
| **Root cause** | `absence_id` is `nullable|integer` only. It is written to `tt_substitution_logs.teacher_absence_id`, so any integer — including one belonging to another teacher — is stored as the link. |
| **Consequence** | A crafted request can attach a substitution to an unrelated absence; no UI does this today, so the practical risk is low. |
| **Reproduce** | POST `/smart-timetable/substitution/assign` with `absence_id` set to an arbitrary integer. |
| **Fix approach** | Add `exists:tt_teacher_absences,id` (and, if needed, a match on teacher/date). Lowered to L because the field is optional and only the AJAX caller sets it. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionController.php:172-175 — CURRENT
            'cell_id' => ['required', 'integer', new CellExistsInSource],
            'substitute_teacher_id' => 'required|integer|exists:sch_teachers,id',
            'date' => 'required|date',
            'absence_id' => 'nullable|integer',
```

**Evidence**
```
$ grep -n 'absence_id' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
175:            'absence_id' => 'nullable|integer',
183:                $validated['absence_id'] ?? null
```

### F5 — Routes

clean — every public method is routed and each route sits inside the tenant middleware group; `python3 -c` over `/tmp/fa-routes.json` (see §4) lists 10 routes for 10 public methods, and `Modules/SmartTimetable/routes/web.php:44-47` wraps them in `['web', 'auth', 'verified', EnsureTenantHasModule::class.':smart-timetable']`.

### F6 — Controller shape

#### SBS-13 · M · CTL-01 — `SubstitutionService` is a 1,698-line, 11-public-method god service

| Field | Value |
|---|---|
| **Rule** | CTL-01 (M) — *over 1,000 lines or 25 public methods is a god class; split by responsibility* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:22-23`, class `SubstitutionService` |
| **Root cause** | Absence reporting, candidate scoring, assignment, history, the teacher grid, duty records and snapshot plumbing all live in one class. It is 1,698 lines with 11 public methods. |
| **Consequence** | Every change to any substitution behaviour risks the others; the class is the hardest file in the module to review. |
| **Reproduce** | static only. |
| **Fix approach** | Split into absence, assignment and reporting services. Per D3 this is a deferred decision; not applied in this pass. |
| **Plan item** | SBS-13 in `02-fix-plan.md` §9 |

```php
// SubstitutionService.php:22-23 — CURRENT
class SubstitutionService
{
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Services/SubstitutionService.php
M  CTL-01   .../SubstitutionService.php:22  - — SubstitutionService: 1677 lines, 11 public methods
```

#### SBS-14 · H · CTL-02 — Two service methods run to 160 and 377 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *a method over 80 lines is M; over 150 lines is H* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:379`, method `reportAbsenceRange()` (160 lines); `:543`, method `findSubstitutes()` (377 lines) |
| **Root cause** | Each method handles several concerns end to end: the absence method expands a range, filters school days and holidays, revives trashed rows, writes, then re-counts; `findSubstitutes()` runs five queries and a scoring loop in one body. |
| **Consequence** | A defect at any point requires reading the whole method; the scoring loop cannot be tested or reasoned about on its own. |
| **Reproduce** | static only. |
| **Fix approach** | Extract the range walk and the scoring loop into private helpers. Covered by the SBS-13 split decision. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionService.php:379-389 — CURRENT
    public function reportAbsenceRange(
        int $teacherId,
        string $from,
        ?string $to = null,
        ?string $reason = null,
        string $type = 'OTHER',
        ?int $startPeriod = null,
        ?int $endPeriod = null,
        int $maxDays = 90
    ): array {
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Services/SubstitutionService.php
H  CTL-02   .../SubstitutionService.php:379  reportAbsenceRange — reportAbsenceRange() is 160 lines
H  CTL-02   .../SubstitutionService.php:543  findSubstitutes — findSubstitutes() is 377 lines
```

#### SBS-15 · M · CTL-03 — `approveAbsence`, `rejectAbsence` and `markNotified` use `$id` plus `findOrFail`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` plus `findOrFail`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:289-296`, method `approveAbsence()` (also `rejectAbsence()` 302-309, `markNotified()` 315-331) |
| **Root cause** | The route parameter is `{id}` and the method loads the record by hand. Route model binding would both shorten the method and keep the 404 outside any try block. |
| **Consequence** | Consistent with the rest of the module, but the extra lookup is easy to forget to scope and it is not the framework idiom. |
| **Reproduce** | static only. |
| **Fix approach** | Type-hint `TeacherAbsences $absence` / `SubstitutionLog $substitutionLog`; rename the route parameter to match. |
| **Plan item** | SBS-15 in `02-fix-plan.md` §5 |

```php
// SubstitutionController.php:289-296 — CURRENT
    public function approveAbsence(int $id): JsonResponse
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');

        $absence = TeacherAbsences::findOrFail($id);
        $absence->approve(auth()->id());

        return response()->json(['success' => true, 'message' => 'Absence approved.']);
    }
```

**Evidence**
```
$ grep -n 'findOrFail' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
293:        $absence = TeacherAbsences::findOrFail($id);
306:        $absence = TeacherAbsences::findOrFail($id);
330:            fn () => SubstitutionLog::findOrFail($id)->markNotified()
```

#### SBS-16 · L · CTL-04 — Five public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:64`, methods `reportAbsence()`, `candidates()` 147, `assign()` 164, `autoAssign()` 237, `history()` 277 |
| **Root cause** | Five methods declare no return type; the other five (`approveAbsence`, `rejectAbsence`, `markNotified`, `teacherGrid`, `saveTeacherGrid`) do. |
| **Consequence** | Style inconsistency; no runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Add `: RedirectResponse|JsonResponse`, `: JsonResponse` and `: View`. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionController.php:64-66 — CURRENT
    public function reportAbsence(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.timetable.update');
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php | grep CTL-04
L  CTL-04   .../SubstitutionController.php:64  reportAbsence — reportAbsence() has no return type
L  CTL-04   .../SubstitutionController.php:147  candidates — candidates() has no return type
L  CTL-04   .../SubstitutionController.php:164  assign — assign() has no return type
L  CTL-04   .../SubstitutionController.php:237  autoAssign — autoAssign() has no return type
L  CTL-04   .../SubstitutionController.php:277  history — history() has no return type
```

#### SBS-17 · M · CTL-10 — Dead code: `getDashboard()` has no caller and four model helpers are never used

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused methods, commented-out blocks* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:1177`, method `getDashboard()`; `SubstitutionLog::accept/complete/cancel`, `TeacherAbsences::markSubstitutionCompleted` |
| **Root cause** | The assignment tab became teacher-first on 2026-09-02 and stopped calling `getDashboard()`; the docblock admits it is kept "because it is the natural shape for a date-first API". The four model helpers have no caller at all. |
| **Consequence** | Maintainers must reason about code no screen reaches; a defect in it is never surfaced. Not a crash. |
| **Reproduce** | `grep -rn 'getDashboard' Modules/SmartTimetable/app` returns only the class itself and a comment. |
| **Fix approach** | Either wire `getDashboard()` into an API/digest or remove it; remove the unused model helpers. Informational only here. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionService.php:1177-1184 — CURRENT
    public function getDashboard(?string $date = null): array
    {
        $date = $date ?? now()->toDateString();

        $absences = TeacherAbsences::where('absence_date', $date)
            ->with('teacher.user')
            ->get();
```

**Evidence**
```
$ grep -rn 'getDashboard' Modules/SmartTimetable/app
Modules/SmartTimetable/app/Services/SubstitutionService.php:1177:    public function getDashboard(?string $date = null): array
Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:36:     * getDashboard() — it reads getTeacherSubstitutionPlan() for the list and
```

### F7 — Models

#### SBS-18 · L · MDL-04 — Every relationship method on both models is missing its return type

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods are return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/SmartTimetable/app/Models/SubstitutionLog.php:110-116`, method `teacherAbsence()` (and `cell()` 121, `absentTeacher()` 132, `substituteTeacher()` 143, `assignedBy()` 154) |
| **Root cause** | None of the five `belongsTo` methods on `SubstitutionLog` — nor the four on `TeacherAbsences` — declares a return type. |
| **Consequence** | Static analysis cannot help, and an accidental change from `belongsTo` to `hasMany` is invisible. No runtime effect. |
| **Reproduce** | static only. |
| **Fix approach** | Add the return type to each relationship method in both models. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionLog.php:110-116 — CURRENT
    public function teacherAbsence()
    {
        return $this->belongsTo(
            TeacherAbsences::class,
            'teacher_absence_id'
        );
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Models/SubstitutionLog.php Modules/SmartTimetable/app/Models/TeacherAbsences.php | grep MDL-04
L  MDL-04   .../SubstitutionLog.php:110  teacherAbsence — relation teacherAbsence() has no return type
L  MDL-04   .../SubstitutionLog.php:121  cell — relation cell() has no return type
... (five on SubstitutionLog, four on TeacherAbsences)
```

### F8 — Services and jobs

#### SBS-19 · M · SVC-02 — The service resolves three dependencies with `app()` instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection — not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:157-165`, methods `snapshots()`, `writeGuard()` (and `history()` at 169-172) |
| **Root cause** | `SubstitutionService` has no constructor; it pulls `SnapshotContext`, `SnapshotWriteGuard` and `SubstitutionHistoryReader` from the container on each call via `app(...)`. |
| **Consequence** | The three collaborators are invisible at construction, cannot be stubbed, and the service reaches into global state — the classic hidden-dependency shape SVC-02 warns about. |
| **Reproduce** | static only. |
| **Fix approach** | Add the three to the constructor and use `$this->snapshots`, `$this->writeGuard`, `$this->history`; delete the private resolver methods. |
| **Plan item** | SBS-19 in `02-fix-plan.md` §5 |

```php
// SubstitutionService.php:157-165 — CURRENT
    private function snapshots(): SnapshotContext
    {
        return app(SnapshotContext::class);
    }

    private function writeGuard(): SnapshotWriteGuard
    {
        return app(SnapshotWriteGuard::class);
    }
```

**Evidence**
```
$ grep -n 'return app(' Modules/SmartTimetable/app/Services/SubstitutionService.php
159:        return app(SnapshotContext::class);
164:        return app(SnapshotWriteGuard::class);
171:        return $this->historyMemo ??= app(SubstitutionHistoryReader::class);
```

### F9 — Queries and performance

#### SBS-20 · H · QRY-01 — Queries run inside loops in four places

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; eager-load, key a collection, or bulk-write* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:517-525`, method `reportAbsenceRange()` (also `assignInSource()` 999-1003, `saveTeacherGrid()` 1436-1447 and 1477-1481, `getSubstituteDutyRecords()` 1601-1606) |
| **Root cause** | Each loop issues its own Eloquent call: the affected-count loop re-fetches the absence per date; `assignInSource()` re-fetches each sibling cell; `saveTeacherGrid()` fetches the cell and its lesson substitute per entry and looks up the absence per entry; the duty loop fetches sibling cells per log. |
| **Consequence** | A 26-cell grid save or one absent teacher opens with hundreds of queries (the class docblock measures about 286 queries / 270 ms for the teacher grid). This is the module's known performance trap on a real screen. |
| **Reproduce** | open one teacher's grid, or save a full grid; watch the query log. Static evidence below. |
| **Fix approach** | Key the existing rows by id and reuse them; pre-fetch sibling cells with one `whereIn`; pre-fetch the per-date absence ids with one query. |
| **Plan item** | SBS-20 in `02-fix-plan.md` §6 |

```php
// SubstitutionService.php:517-525 — CURRENT
        foreach (array_merge($created, $revived) as $date) {
            $absence = TeacherAbsences::where('teacher_id', $teacherId)
                ->whereDate('absence_date', $date)
                ->first();

            if ($absence) {
                $affectedCells += $this->uncoveredCellsForAbsence($absence, $date)->count();
            }
        }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Services/SubstitutionService.php | grep QRY-01
H  QRY-01   .../SubstitutionService.php:518  reportAbsenceRange — TeacherAbsences::where() inside a loop — N+1 query
H  QRY-01   .../SubstitutionService.php:1000  assignInSource — TimetableCell::find() inside a loop — N+1 query
H  QRY-01   .../SubstitutionService.php:1437  saveTeacherGrid — TimetableCell::with() inside a loop — N+1 query
H  QRY-01   .../SubstitutionService.php:1477  saveTeacherGrid — TeacherAbsences::where() inside a loop — N+1 query
H  QRY-01   .../SubstitutionService.php:1602  getSubstituteDutyRecords — TimetableCell::with() inside a loop — N+1 query
```

#### SBS-21 · L · QRY-05 — `->get()->filter()` cannot be aggregated because the filter is a PHP rule

| Field | Value |
|---|---|
| **Rule** | QRY-05 (M, lowered to L) — *aggregate in SQL; avoid `->get()->filter()`* |
| **Where** | `Modules/SmartTimetable/app/Services/SubstitutionService.php:327-331`, method `affectedCellsForAbsence()` |
| **Root cause** | The query hydrates the day's cells and then calls `->filter(fn ($cell) => $absence->affectsPeriod($cell->period_ord))`. The predicate is a PHP method that encodes a half-open period window, not a SQL condition the scanner can see. |
| **Consequence** | Slightly more rows hydrated than needed; the filter is correct and mirrored in one place. Lowered to L because turning it into SQL means duplicating the `affectsPeriod()` rule. |
| **Reproduce** | static only. |
| **Fix approach** | Optionally replace with a `when()` on `period_ord` between start and end when both are set, keeping `affectsPeriod()` as the one definition. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionService.php:327-331 — CURRENT
                ->with(['activity.subject', 'activity.class', 'activity.section', 'teachers.user'])
                ->orderBy('period_ord')
                ->get()
                ->filter(fn ($cell) => $absence->affectsPeriod((int) $cell->period_ord))
                ->values();
```

**Evidence**
```
$ grep -n 'ownerClassIdSql' Modules/TimetableFoundation/app/Services/OptionCellResolver.php
106:    public static function ownerClassIdSql(...): string
$ sed -n '106,109p' Modules/TimetableFoundation/app/Services/OptionCellResolver.php
    public static function ownerClassIdSql(string $activity = 'a', ...): string
    {
        return "COALESCE({$sg}.class_id, {$cg}.class_id, {$activity}.class_id)";
```

### F10 — Views

clean — `Modules/SmartTimetable/resources/views/substitution/history.blade.php` runs no query (no `Model::`, `DB::`, `->where(`, `->get()` in the file), uses `{{ }}` throughout (no `{!! !!}`), and the two relations it reads inside `@forelse` (`absentTeacher.user`, `substituteTeacher.user`) are eager-loaded by `SubstitutionService::getSubstitutionHistory()` at lines 1152 and 1160. Prove: `grep -nE 'Model::|DB::|->get\(|->count\(|\{!!' Modules/SmartTimetable/resources/views/substitution/history.blade.php` returns no output.

### F11 — Security and tenancy

clean — no `env()` call in any in-scope file (`grep -rn 'env(' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php Modules/SmartTimetable/app/Services/SubstitutionService.php` returns no output); no hard-coded id or `?? 1`; `SnapshotContext`/`SnapshotWriteGuard` are resolved from the container and the per-request memo arrays on the service are instance state, not a static cache, so no tenant key is needed.

### F12 — Style

#### SBS-22 · L · STY-01 / STY-06 — Missing `strict_types` and un-imported `\Log::`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` on touched files*; STY-06 (L) — *one style per concern, `Log::` not `\Log::`* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:1-16`, file header; `:127`, `:209`, `:260`, `:354`, `:408` |
| **Root cause** | The file opens with `<?php` and no `declare(strict_types=1);`, and uses the global `\Log::` five times instead of importing `Illuminate\Support\Facades\Log`. |
| **Consequence** | Style only; no runtime effect (Laravel resolves the facade alias either way). |
| **Reproduce** | static only. |
| **Fix approach** | Add the declare and import `Log`, then replace the five `\Log::` with `Log::`. |
| **Plan item** | SBS-22 in `02-fix-plan.md` §8 |

```php
// SubstitutionController.php:1-16 — CURRENT
<?php

namespace Modules\SmartTimetable\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Modules\SmartTimetable\Http\Requests\SaveSubstituteGridRequest;
use Modules\SmartTimetable\Models\SubstitutionLog;
use Modules\SmartTimetable\Models\TeacherAbsences;
use Modules\SmartTimetable\Services\SubstitutionService;
use Modules\TimetableFoundation\Support\Snapshot\CellExistsInSource;
use Modules\TimetableFoundation\Support\Snapshot\SnapshotContext;
use Modules\TimetableFoundation\Support\Snapshot\SnapshotWriteGuard;
```

**Evidence**
```
$ head -1 Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
<?php
$ grep -c 'declare(strict_types' Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php
0
```

#### SBS-23 · L · STY-04 — Emoji markers used as comment emphasis

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php:27,35,369` (and the whole module, including the service) |
| **Root cause** | The module's house style prefixes block comments with `⛔` and `⚠`. |
| **Consequence** | Style only. The emoji are a module-wide convention, so removing them in one file would make it inconsistent. |
| **Reproduce** | static only. |
| **Fix approach** | Accept as a module convention, or strip across the module in one codemod pass. Informational. |
| **Plan item** | none — see plan §10 |

```php
// SubstitutionController.php:27-31 — CURRENT
     * ⛔ index() and its blade (substitution/index.blade.php) were REMOVED 2026-09-01.
     *
     * They were a second, older substitute screen: not in the menu, reachable only by
     * typing the URL, and yet the destination every write below redirected to — so
     * reporting an absence on the tabbed page silently moved the user onto a different
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/SmartTimetable/app/Http/Controllers/SubstitutionController.php | grep STY-04
L  STY-04   .../SubstitutionController.php:27  - — emoji in comment
L  STY-04   .../SubstitutionController.php:35  - — emoji in comment
L  STY-04   .../SubstitutionController.php:369  - — emoji in comment
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 overwrite? | 2 delete-before-store? | 3 duplicate impl? | 4 soft-delete x unique? | 5 race? | 6 auth hole? | 7 lying message? | 8 dead feature? |
|---|---|---|---|---|---|---|---|---|
| `reportAbsence` / `reportAbsenceRange` | ok | ok | ok | handled by revive (lines 479-493) | SBS-07 | ok | ok | ok |
| `assign` / `assignSubstitute` | ok | ok | ok | ok | ok | ok | ok | ok |
| `autoAssign` | ok | ok | ok | ok | ok | ok | ok | ok |
| `approveAbsence` / `rejectAbsence` | ok | ok | ok | ok | ok | ok | ok | SBS-17 |
| `markNotified` | ok | ok | ok | ok | ok | ok | ok | ok |
| `saveTeacherGrid` | ok | SBS-08 | ok | ok | ok | ok | ok | ok |
| `removeSubstitute` | ok | SBS-09 | ok | ok | ok | ok | ok | ok |

Question 1 (wrong data): no write resets a column outside the row it targets. Question 3 (duplicate implementations): `affectedCellsForAbsence()` is the single definition, reused by the board, the grid and auto-assign. Question 4: `uq_ta_teacher_date` is not soft-delete aware, but `reportAbsenceRange()` revives a trashed row instead of colliding (lines 479-493). Question 6: every routed method authorizes before loading a record.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/TimetableFoundation/Support/Snapshot/SnapshotContext.php` | Linked owner report (`StandardTimetableController`); no defect found in the calls this controller makes | — | owner report |
| `Modules/TimetableFoundation/Services/OptionCellResolver.php` | Linked owner report; `ownerClassIdSql()`/`ownerSectionIdSql()` return constant SQL strings built from hard-coded defaults (verified at lines 106-113), so the scanner's QRY-11 candidate is not an injection | QRY-11 (not a finding) | owner report |
| `Modules/SchoolSetup/**` (`Teacher`, `User`, `SchoolClass`, `Section`, `OrganizationAcademicSession`) | Common classes under §4.2; used read-only with eager loads | — | common, not audited |

## 8. Not covered, and why

- Scheduler/queue behaviour: none of the endpoints dispatch a job, so JOB-01..05 do not apply.
- Snapshot mirror writes (`tt_snap_*`): exercised only when the tenant holds a published timetable with a requirement reset; the tenant is empty today, so the snapshot code paths are reviewed statically, not run.
- Pint cleanliness (STY-02): not run on the in-scope files because the audit is read-only; SBS-22 covers the visible style items.
- The `snapshot.cell` middleware body: it belongs to TimetableFoundation and is not in this controller's reach beyond the route decoration. Its owner report covers it.
- Permission seeding: `tenant.smart-timetable.timetable.update` (id 1643) and `.view` (id 1641) exist in `sys_permissions` and are granted to roles 1 and 2; the exact-name query in `config/permissionslist.php:714` is correct.
