# Final Audit — SmartTimetable / PythonTimetableController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php` (3227 lines, 8 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/smart-timetable/timetable-generation?tab=timetable` (the Timetable tab, where the Python Generate and Conflicts buttons live) · endpoints: `POST smart-timetable/python-timetable/generate`, `POST smart-timetable/python-timetable/store`, `GET smart-timetable/python-timetable/grid`, `GET smart-timetable/python-timetable/progress/{token}`, `POST smart-timetable/python-timetable/cancel/{token}`, `GET smart-timetable/python-timetable/generate` |
| Menu path | Timetable → Timetable tab → Generate timetable (Python engine) button / Conflicts button / Warnings & Fixes tab |
| Who uses it | Roles holding `tenant.smart-timetable.python-timetable.viewAny`, `.generate`, `.create` — declared in `config/permissionslist.php` line 717, seeded via `/system-config/sync-permissions` |
| What a user does here | Picks an academic term, timetable type, time budget and options in the Generate modal, then runs the Python solver (a request that blocks for the whole budget, up to 30 minutes). The preview page renders the solved grid; Save promotes the GENERATED draft into a saved timetable. The Conflicts button shows pre-flight data problems (blockers/warnings); the Warnings & Fixes tab is server-rendered from the same source. |
| Tables written | `tt_timetables`, `tt_generation_runs`, `tt_timetable_cells`, `tt_timetable_cell_teachers` (all via `TimetableStorageService`), `sys_activity_logs` (store() only), session + cache writes |
| Tables read | `tt_activities`, `tt_school_days`, `tt_period_sets`, `tt_period_set_periods`, `tt_timetable_cells` (locked cells), `sch_rooms`, `sch_rooms_type`, `sys_users`, plus the whole ProblemExporter read surface (owned elsewhere) |
| Live data | On tenant `test.localhost` (xyz_school_00000000000040008000_202627): `tt_timetables` 0 (0 trashed), `tt_generation_runs` 0, `tt_timetable_cells` 0, `tt_activities` 0, `tt_school_days` 7, `tt_period_sets` 4. The tenant is empty, so `generate()` answers "No active activities exist…" until requirement data is added. |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready until the four raw-exception leaks (PYC-01…04) are stopped: every one is reachable from a normal user action (open the Conflicts modal, click Generate with no data, save a draft) and shows exception text — SQL, filesystem paths, or the solver's stderr — on screen. The single worst finding is `store()` (PYC-04): the save path is the moment a user commits a timetable, and both catch blocks flash `$e->getMessage()` straight into the error toast. The controller itself is heavily documented, the security-critical process boundary (`PythonRunner`, `SolverProcessReaper`) is genuinely sound — array-form Symfony Process, no shell interpolation, tenant-scoped payloads — and all routed methods authorize first. Effort to fix the blockers is small (M, a few hours); the medium items are mostly mechanical; the god-controller split is deferred (D3).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 4 | 2 | 8 | 4 | 5 | 18 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PYC-01, PYC-02, PYC-03, PYC-04, PYC-05, PYC-06 | F8 Services/Jobs | PYC-16 |
| F2 Transactions/Audit | PYC-07, PYC-08 | F9 Queries/Perf | clean |
| F3 Authorization | PYC-09 | F10 Views | clean |
| F4 Validation | PYC-10 | F11 Security/Tenancy | clean |
| F5 Routes | PYC-11 | F12 Style | PYC-17, PYC-18 |
| F6 Controller shape | PYC-12, PYC-13, PYC-14, PYC-15 | F13 Deep read | table below |
| F7 Models | clean | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php` | controller | 3227 | this report | ✅ |
| 2 | `Modules/SmartTimetable/app/Services/Python/PythonRunner.php` | service | 629 | this report | ✅ |
| 3 | `Modules/SmartTimetable/app/Services/Python/GenerationProgress.php` | service | 465 | this report | ✅ |
| 4 | `Modules/SmartTimetable/app/Services/Python/GenerationSuperseded.php` | service | 27 | this report | ✅ |
| 5 | `Modules/SmartTimetable/app/Services/Python/LockedCellPins.php` | service | 435 | this report | ✅ |
| 6 | `Modules/SmartTimetable/app/Services/Python/SolverProcessReaper.php` | service | 120 | this report | ✅ |
| 7 | `Modules/SmartTimetable/app/Services/Python/SolutionAdapter.php` | service | 677 | this report | ✅ |
| 8 | `Modules/SmartTimetable/app/Services/Python/UnplacedLessonAdvisor.php` | service | 484 | this report | ✅ |
| 9 | `Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php` | service | 1426 | ↗ [tarun/SmartTimetable/TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 10 | `Modules/SmartTimetable/app/Services/TimetableGenerationService.php` | service | — | ↗ [tarun/SmartTimetable/TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 11 | `Modules/SmartTimetable/app/Services/Preview/PreviewViewData.php` | service | 128 | ↗ [tarun/SmartTimetable/TimetableGenerationController](../TimetableGenerationController-done/01-report.md) | ↗ linked |
| 12 | `Modules/SmartTimetable/app/Services/Preview/PreviewDerivedData.php` | service | — | ↗ [tarun/SmartTimetable/TimetablePreviewController](../TimetablePreviewController-done/01-report.md) | ↗ linked |
| 13 | `Modules/TimetableFoundation/app/Services/ProblemExporter.php` | service | — | ↗ [TimetableFoundation/TimetableFoundationController](../../../../TimetableFoundation/TimetableFoundationController/01-report.md) | ↗ linked |
| 14 | `Modules/TimetableFoundation/app/Models/Timetable.php` | model | — | ↗ [tarun/SmartTimetable/AnalyticsController](../AnalyticsController-done/01-report.md) | ↗ linked |
| 15 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | — | ↗ [tarun/SmartTimetable/TtGenerationStrategyController](../TtGenerationStrategyController-done/01-report.md) | ↗ linked |
| 16 | `Modules/TimetableFoundation/app/Models/ClassTimetableType.php`, `PeriodSet.php` | models | — | common (SchoolSetup / TimetableFoundation models) | ❌ common |
| 17 | `Modules/Prime/Models/AcademicSession.php` | model | — | common (cross-module) | ❌ common |
| 18 | `Modules/SmartTimetable/resources/views/preview/*` | views | — | ↗ [tarun/SmartTimetable/TimetablePreviewController](../TimetablePreviewController-done/01-report.md) | ↗ linked |
| 19 | `Modules/SmartTimetable/resources/views/python-timetable/*.blade.php` | views | — | used by TimetableGenerationController / TimetablePageController pages | ↗ linked |
| 20 | `Modules/SmartTimetable/config/python.php` | config | — | common | ❌ common (checked: `env()` only here, SEC-01 OK) |

No pre-applied files.

## 4. Routes

```
POST    smart-timetable/python-timetable/cancel/{token}              smart-timetable.python-timetable.cancel                 Modules\SmartTimetable\Http\Controllers\PythonTimetableController@cancel
POST    smart-timetable/python-timetable/generate                    smart-timetable.python-timetable.generate               Modules\SmartTimetable\Http\Controllers\PythonTimetableController@generate
GET|HEAD smart-timetable/python-timetable/generate                    smart-timetable.python-timetable.generate.get           Modules\SmartTimetable\Http\Controllers\PythonTimetableController@redirectGenerate
GET|HEAD smart-timetable/python-timetable/grid                        smart-timetable.python-timetable.grid                   Modules\SmartTimetable\Http\Controllers\PythonTimetableController@grid
GET|HEAD smart-timetable/python-timetable/progress/{token}            smart-timetable.python-timetable.progress               Modules\SmartTimetable\Http\Controllers\PythonTimetableController@progressStatus
POST    smart-timetable/python-timetable/store                       smart-timetable.python-timetable.store                  Modules\SmartTimetable\Http\Controllers\PythonTimetableController@store
```

Unrouted public methods:
- `conflictsSummary()` at 651 — called by `TimetableGenerationController` line 414 via `app(PythonTimetableController::class)->conflictsSummary(...)` (the Warnings & Fixes tab). Intentional internal API, not a route (PYC-11).
- `persistErrorMessage()` at 2896 — static helper used by the preview view (`$viewData['persist_error']`) and structural tests. Intentional helper, not a route (PYC-11).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `__construct` | 70 | no | — | — | — | none | — |
| `progressStatus` | 107 | GET python-timetable/progress/{token} | tenant.smart-timetable.python-timetable.generate | none (read cache) | — | cache (GenerationProgress) | clean |
| `cancel` | 130 | POST python-timetable/cancel/{token} | tenant.smart-timetable.python-timetable.generate | none (cache + process kill) | — | cache, kills orphan Python processes | clean |
| `grid` | 158 | GET python-timetable/grid | tenant.smart-timetable.python-timetable.viewAny | none (read) | — | none | PYC-01, PYC-10 |
| `generate` | 202 | POST python-timetable/generate | tenant.smart-timetable.python-timetable.generate | in TimetableStorageService (createSkeleton, populateFromResult, lockInDraft each own) | none (deliberate: unsaved preview) | tt_timetables, tt_generation_runs, tt_timetable_cells, tt_timetable_cell_teachers, session, cache | PYC-02, PYC-05, PYC-06, PYC-08, PYC-10, PYC-16 |
| `conflictsSummary` | 651 | not routed (internal) | tenant.smart-timetable.python-timetable.viewAny | none (read) | — | none | PYC-03, PYC-11 |
| `persistErrorMessage` | 2896 | not routed (helper) | — | none | — | none | PYC-11 |
| `store` | 3095 | POST python-timetable/store | tenant.smart-timetable.python-timetable.create | in TimetableStorageService::finalizeGenerated | 'Generated' (after commit — PYC-07) | tt_timetables, sys_activity_logs | PYC-04, PYC-05, PYC-07 |
| `redirectGenerate` | 3168 | GET python-timetable/generate | tenant.smart-timetable.python-timetable.viewAny | none | — | session reflash | PYC-14 |

## 6. Findings

### F1 — Errors

#### PYC-01 · B · ERR-01 — grid() returns the raw exception text to the browser

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:189-193`, method `grid()` |
| **Root cause** | The whole handler sits in a controller `try`, and the generic `catch (Throwable $e)` (line 189) echoes `$e->getMessage()` into the JSON `message` at line 192. Under D1 the Laravel idiom is to remove the try entirely; the central handler renders the 500. |
| **Consequence** | A user who opens the Conflicts modal when the export hits any error sees exception text — a PDO message, a filesystem path — in the modal, instead of a fixed message. |
| **Reproduce** | Open `smart-timetable/timetable-generation?tab=timetable`, click Conflicts. On this empty tenant the endpoint is normal; force an export failure (e.g. delete a period set) and the modal shows `message: <raw exception>`. |
| **Fix approach** | Drop the try/catch (D1) so a failure is handled by the central renderer; keep the business 422 branches which use fixed strings. |
| **Plan item** | PYC-01 in `02-fix-plan.md` §1 |

```php
        } catch (Throwable $e) {
            Log::error('Python timetable grid failed', ['error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
```

**Evidence**
```
$ grep -n "getMessage\|catch (" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
189:        } catch (Throwable $e) {
190:            Log::error('Python timetable grid failed', ['error' => $e->getMessage()]);
192:            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
```

#### PYC-02 · B · ERR-01 — generate() flashes the raw exception to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:540-550`, method `generate()` |
| **Root cause** | `catch (Throwable $e)` at 540 does three things with the message: puts it in the progress record (`finish(false, 'Generation failed: '.$e->getMessage())`), logs only the message, and flashes `'Python generation failed: '.$e->getMessage()`. A DB/export/path exception therefore reaches the user verbatim. |
| **Consequence** | Any generate-time failure (a broken export, a missing script, a DB error) shows raw internals in the red flash on the Timetable tab. |
| **Reproduce** | Click Generate while the Python binary is misconfigured, or after breaking a period set — the redirect `with('error', 'Python generation failed: …')` prints the exception. |
| **Fix approach** | Keep the `catch (GenerationSuperseded)` flow (documented control flow), but in the generic catch finish the progress record and `report($e)`, then flash a fixed message. |
| **Plan item** | PYC-02 in `02-fix-plan.md` §1 |

```php
        } catch (Throwable $e) {
            $this->progress->finish(false, 'Generation failed: '.$e->getMessage());

            Log::error('Python timetable generation failed', [
                'script' => 'generate.py',
                'term_id' => $validated['academic_term_id'] ?? null,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'Python generation failed: '.$e->getMessage());
        }
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php | sed -n '5,7p'
541:            $this->progress->finish(false, 'Generation failed: '.$e->getMessage());
546:                'error' => $e->getMessage(),
549:            return back()->with('error', 'Python generation failed: '.$e->getMessage());
```

#### PYC-03 · B · ERR-01 — conflictsSummary() leaks the raw exception into the Warnings & Fixes tab

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:672-677`, method `conflictsSummary()` |
| **Root cause** | `catch (Throwable $e)` at 672 stores `$e->getMessage()` in `message` which the Warnings & Fixes blade (`warnings-fixes/_list.blade.php` line 25) renders on the page. |
| **Consequence** | The Warnings & Fixes tab prints raw exception text (engine sentences, DB details) to every user with viewAny when the export throws. |
| **Reproduce** | Open `smart-timetable/timetable-generation` and switch to the Warnings & Fixes tab with an export failure pending. |
| **Fix approach** | Same as PYC-01/02: drop the generic catch (D1) or return a fixed string; `report($e)` so the trace is kept. |
| **Plan item** | PYC-03 in `02-fix-plan.md` §1 |

```php
        } catch (Throwable $e) {
            Log::warning('conflictsSummary failed', ['error' => $e->getMessage()]);

            return ['success' => false, 'message' => $e->getMessage(),
                'blockers' => 0, 'warnings' => 0, 'groups' => [], 'problem' => null];
        }
```

**Evidence**
```
$ sed -n '672,678p' Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
        } catch (Throwable $e) {
            Log::warning('conflictsSummary failed', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => $e->getMessage(),
                'blockers' => 0, 'warnings' => 0, 'groups' => [], 'problem' => null];
        }
```

#### PYC-04 · B · ERR-01 — store() flashes raw exception text on the save path, and catches \RuntimeException

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user* · ERR-00/D2 (D1) — *no controller try/catch; never catch RuntimeException (QueryException extends it)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:3144-3155`, method `store()` |
| **Root cause** | `catch (\RuntimeException $e)` at 3144 treats every RuntimeException as a business rule and shows `$e->getMessage()`; because QueryException extends RuntimeException, a DB failure would also be shown as if it were a rule. The second `catch (Throwable $e)` at 3148 flashes `'Save failed: '.$e->getMessage()`. Both leak raw text. |
| **Consequence** | When Save fails for a genuine DB reason, the user sees SQL or a QueryException message in the error toast on the Timetable tab — and a business error and a crash are indistinguishable. |
| **Reproduce** | Save a preview after making the underlying table write fail (e.g. drop a column the storage service writes) — the toast shows `Save failed: SQLSTATE…`. |
| **Fix approach** | Business-rule exceptions become `\DomainException` per D2 (service change, shared file — coordinated), the controller catches `\DomainException` with the fixed message and, for anything else, `report($e)` and a fixed message. |
| **Plan item** | PYC-04 in `02-fix-plan.md` §1 |

```php
        } catch (\RuntimeException $e) {
            // A business rule from finalizeGenerated — already published, or not
            // in GENERATED status. The row is fine; show the reason.
            return $this->backToTab($e->getMessage());
        } catch (Throwable $e) {
            Log::error('Python timetable publish failed', [
                'timetable_id' => $timetableId,
                'error' => $e->getMessage(),
            ]);

            return $this->backToTab('Save failed: '.$e->getMessage());
        }
```

**Evidence**
```
$ grep -n "catch (" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
3144:        } catch (\RuntimeException $e) {
3148:        } catch (Throwable $e) {
$ grep -n "throw new" Modules/SmartTimetable/app/Services/Storage/TimetableStorageService.php
857:                throw new \RuntimeException(
```

#### PYC-05 · M · ERR-05 — logs carry only the message, never the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('…', ['exception' => $e])`; `getMessage()` alone loses the trace* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:190,434-438,543-547,673-674,2870,3052-3055,3080-3083,3149-3152` and `Modules/SmartTimetable/app/Services/Python/GenerationProgress.php:104,443` |
| **Root cause** | Every catch logs `['error' => $e->getMessage()]` (or `Log::debug`), dropping the stack trace; a message alone cannot show where a generation failed. |
| **Consequence** | Support debugging a failed solve requires re-running; the trace that would name the failing line is gone. |
| **Reproduce** | Trigger any caught failure and read `storage/logs/laravel.log` — each entry has `error` but no `exception`/trace. |
| **Fix approach** | Append `'exception' => $e` to each log payload (and `report($e)` where the catch body is removed by PYC-01/03). |
| **Plan item** | PYC-05 in `02-fix-plan.md` §1 |

```php
            Log::error('Python timetable generation failed', [
                'script' => 'generate.py',
                'term_id' => $validated['academic_term_id'] ?? null,
                'error' => $e->getMessage(),
            ]);
```

**Evidence**
```
$ grep -n "getMessage" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
190:            Log::error('Python timetable grid failed', ['error' => $e->getMessage()]);
436:                        'error' => $e->getMessage(),
541:            $this->progress->finish(false, 'Generation failed: '.$e->getMessage());
546:                'error' => $e->getMessage(),
673:            Log::warning('conflictsSummary failed', ['error' => $e->getMessage()]);
2870:            Log::warning('Python timetable: tail repair failed, keeping the full attempt', ['error' => $e->getMessage()]);
3054:                'error' => $e->getMessage(),
3082:                'error' => $e->getMessage(),
3151:                'error' => $e->getMessage(),
```

#### PYC-06 · M · ERR-00 (D1) — deliberate controller try/catch blocks that D1 forbids

| Field | Value |
|---|---|
| **Rule** | ERR-00/D1 — *no try/catch in controllers; the central handler renders errors* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:431-441,2853-2873,2927-3059,3072-3085` |
| **Root cause** | Four controller-level catch blocks exist for "best-effort" reasons: lock-carried-over failure (431), tail-repair failure (2853), persistence failure (2927), preview-drop failure (3072). Each logs and continues/degrades on purpose. D1 says controllers carry no try/catch; D2's documented exceptions do not literally cover them. |
| **Consequence** | A hidden failure path per catch — e.g. a populate failure leaves a GENERATED skeleton row with no cells and the user is told "could not be saved" with no reason on screen (the reason is only in laravel.log). |
| **Reproduce** | Static only — force `populateFromResult` to throw; the preview renders with `persist_error` set and the raw reason only in the log. |
| **Fix approach** | Extract the catches into their services (which may `report($e)` + fixed message), or annotate each with a D2-style comment naming ERR-01 and the date. Deferred with the CTL-01/02 split. |
| **Plan item** | none — see plan §10 |

```php
            if ($pinReport !== null && $timetableId !== null) {
                try {
                    $pinReport['locked_in_draft'] = $this->pins->lockInDraft($timetableId, $pinReport, auth()->id());
                } catch (Throwable $e) {
                    Log::warning('Python timetable: could not lock carried-over cells', [
                        'timetable_id' => $timetableId,
                        'error' => $e->getMessage(),
                    ]);
                    $pinReport['warnings'][] = 'The kept lessons are in their locked slots, but their cells could not be '
                        .'locked in this draft (error logged). Lock them again in Manual Placement before regenerating.';
                }
            }
```

**Evidence**
```
$ grep -n "catch (" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
433:                } catch (Throwable $e) {
2869:        } catch (Throwable $e) {
3051:        } catch (Throwable $e) {
3079:        } catch (Throwable $e) {
```

### F2 — Transactions and audit

#### PYC-07 · M · TXN-04 — store() logs activity outside the transaction that saved the row

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *activityLog() sits inside the transaction, after the write it describes — not after commit* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:3125-3136`, method `store()` |
| **Root cause** | `finalizeGenerated()` owns the write transaction in the shared service and commits when it returns; the controller then calls `activityLog($saved, 'Generated', …)`. The audit row is a separate, uncommitted-at-write step — if it fails, the save stands with no audit entry. |
| **Consequence** | A rare failure between commit and log leaves a saved timetable with no 'Generated' audit trail. |
| **Reproduce** | Static only — the window is between the two statements. |
| **Fix approach** | Move the activityLog call into `TimetableStorageService::finalizeGenerated` inside its `DB::transaction` — but `TimetableGenerationController` repeats this exact call (lines 249-258), so the move must coordinate both engines or the PHP path double-logs. DECISION item. |
| **Plan item** | PYC-07 in `02-fix-plan.md` §9 (DECISION) |

```php
            $saved = $this->storage->finalizeGenerated($timetableId, $validated);

            // Rule A3 — logged on the saved row, after the write, matching
            // TimetableGenerationController::storeTimetable.
            activityLog($saved, 'Generated', [
                'message' => "Timetable '{$saved->name}' was generated and saved as a draft.",
                'timetable_id' => $timetableId,
                'engine' => 'python',
                'effective_from' => $validated['effective_from'],
                'effective_to' => $validated['effective_to'] ?? null,
                'status' => 'GENERATED',
            ]);
```

**Evidence**
```
$ sed -n '3125,3137p' Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
            $saved = $this->storage->finalizeGenerated($timetableId, $validated);
            // Rule A3 — logged on the saved row, after the write, matching
            // TimetableGenerationController::storeTimetable.
            activityLog($saved, 'Generated', [
```

#### PYC-08 · M · TXN-01 — a failed populate leaves an orphan GENERATED skeleton (two separate service transactions)

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H→M, lowered: the write is in the linked service and the draft is kept by design D-2026-10-05) — *more than one write runs inside one DB::transaction* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:2985-3000,3051-3059`, method `persistPreview()` |
| **Root cause** | `createSkeleton()` commits, then `populateFromResult()` runs in a second transaction. A populate failure is caught at 3051 and returns null — the preview announces "could not be saved", but the skeleton row (tt_timetables + tt_generation_runs at status GENERATED) stays. Drafts are kept by design, but only healthy ones. |
| **Consequence** | A failed save leaves a junk GENERATED timetable with zero cells in the list that the user must delete by hand; every real failure hides its footprint. |
| **Reproduce** | Static only — break the storage write for one generate and inspect `tt_timetables` afterwards. |
| **Fix approach** | In the catch, call `$this->storage->deleteSkeleton()` for the just-created skeleton id, or move both phases behind one service transaction (shared file — coordinate with the owner). DECISION item. |
| **Plan item** | PYC-08 in `02-fix-plan.md` §9 (DECISION) |

```php
            session(['py_preview_timetable_id' => $skeleton['timetable_id']]);

            return $skeleton['timetable_id'];
        } catch (Throwable $e) {
            Log::error('Python timetable persist failed', [
                'term_id' => $termId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return null;
        }
```

**Evidence**
```
$ grep -n "createSkeleton\|populateFromResult\|return null;\|catch (Throwable" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php | sed -n '1,8p'
2985:            $skeleton = $this->storage->createSkeleton([
3000:            $this->storage->populateFromResult(
3051:        } catch (Throwable $e) {
3058:            return null;
```

### F3 — Authorization

#### PYC-09 · M · AUTH-06 — permission strings repeated as literals in six methods

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place — a Policy, or constants — not repeated as literals* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:111,134,160,204,653,3097,3170` |
| **Root cause** | Three literals are repeated once each per method: `.generate` three times (111, 134, 204), `.viewAny` three times (160, 653, 3170), `.create` once (3097). A rename in the config leaves these silently false (403s for everyone) unless every site is found. |
| **Consequence** | A permission rename breaks the feature quietly; nothing compiles. |
| **Reproduce** | Static only. |
| **Fix approach** | Module-level constants (`private const GATE_GENERATE = 'tenant.smart-timetable.python-timetable.generate'; …`) — the same pattern exists in every SmartTimetable controller, so fix as a module pass (cross-cutting). |
| **Plan item** | none — see plan §10 |

```php
        Gate::authorize('tenant.smart-timetable.python-timetable.generate');
```

**Evidence**
```
$ grep -n "Gate::authorize" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
111:        Gate::authorize('tenant.smart-timetable.python-timetable.generate');
134:        Gate::authorize('tenant.smart-timetable.python-timetable.generate');
160:        Gate::authorize('tenant.smart-timetable.python-timetable.viewAny');
204:        Gate::authorize('tenant.smart-timetable.python-timetable.generate');
653:        Gate::authorize('tenant.smart-timetable.python-timetable.viewAny');
3097:        Gate::authorize('tenant.smart-timetable.python-timetable.create');
3170:        Gate::authorize('tenant.smart-timetable.python-timetable.viewAny');
```

(Authority itself is clean: all three names are declared — `config/permissionslist.php:717` `'smart-timetable.python-timetable' => array_merge($crud, ['generate'])` with `$crud` including `viewAny`/`create` — and the views gate the same strings: `_search-bar.blade.php:50,73`, `_list.blade.php:345,349`, `generation.blade.php:27,31`. Every routed method authorizes before it loads or writes anything.)

### F4 — Validation and input

#### PYC-10 · M · VAL-02 — inline validation in three write/lookup methods instead of FormRequests

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a Form Request (project rule), not inline `$request->validate()` — except one-field AJAX toggles* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:162-165,206-266,3099-3104` |
| **Root cause** | `grid()`, `generate()` and `store()` all call `$request->validate([…])` inline. generate() carries a large commented rule block that documents product decisions; it works, but the rules are not reusable and blur the controller. |
| **Consequence** | Maintainability debt: the validation block cannot be shared with a second engine or unit-tested alone; the controller grows toward its 3,227 lines. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract three FormRequests (store has only four fields; grid two). For generate() this is a behavior-preserving move of a 25-rule block with its comments. DECISION item. |
| **Plan item** | PYC-10 in `02-fix-plan.md` §9 (DECISION) |

```php
        $validated = $request->validate([
            'academic_term_id' => ['nullable', 'integer', 'min:1'],
            'timetable_type_id' => ['nullable', 'integer', 'min:1'],
            'seconds' => ['nullable', 'integer', 'min:1', 'max:600'],
            'seed' => ['nullable', 'integer', 'min:1'],
```

**Evidence**
```
$ grep -n "request->validate" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
162:        $validated = $request->validate([
206:        $validated = $request->validate([
3099:        $validated = $request->validate([
```

### F5 — Routes

#### PYC-11 · L · RTE-03 — two public methods are not routes (intentional internal helpers)

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M→L, lowered: both are deliberate helpers, not unrouted actions) — *every public method is routed or deliberately disabled* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:651-653,2896-2901` |
| **Root cause** | `conflictsSummary()` is the single server-side entry point for the Warnings & Fixes tab, called from TimetableGenerationController:414; `persistErrorMessage()` is a static helper consumed by the preview view and a structural test. Neither is (or should be) an abort(403) D5 case — D5 targets dead actions. |
| **Consequence** | None at runtime; the public surface is slightly wider than necessary. |
| **Reproduce** | Static only. |
| **Fix approach** | Optionally narrow to `public static`/`protected`; otherwise record as accepted. |
| **Plan item** | none — see plan §10 |

```php
    public function conflictsSummary(?int $academicTermId = null, ?int $timetableTypeId = null): array
    {
        Gate::authorize('tenant.smart-timetable.python-timetable.viewAny');
```

**Evidence**
```
$ grep -rn "conflictsSummary" Modules/SmartTimetable/app/Http/Controllers/TimetableGenerationController.php
414:        $conflictsSummary = app(PythonTimetableController::class)
415:            ->conflictsSummary($currentTermId, $defaultTimetableTypeId);
```

(RTE-01 candidate on `GET python-timetable/generate`: `redirectGenerate()` only reflashes and redirects — no state change. `grep -n "session()->reflash\|route(" …:3168-3193` shows no write. Confirmed not state-changing.)

### F6 — Controller shape

#### PYC-12 · H · CTL-01 — 3,227-line god controller

| Field | Value |
|---|---|
| **Rule** | CTL-01 (H) — *no god controllers; over 2,500 lines is H; split by responsibility* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:68` (class declaration; 3227 lines) |
| **Root cause** | One class holds route actions, the 852-line conflict engine, the export-warning translator, the portfolio-retry loop and persistence glue. |
| **Consequence** | The file is hard to review in one pass; every family finding above has to be read against 3,000 lines. |
| **Reproduce** | Static only. |
| **Fix approach** | Split is DEFERRED (D3). When it happens: extract the conflict engine + warning translator into a service, the retry loop into the Python cluster, persistence into the storage service. DECISION item. |
| **Plan item** | PYC-12 in `02-fix-plan.md` §9 (DECISION) |

```php
class PythonTimetableController extends Controller
{
```

**Evidence**
```
$ wc -l Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
3227 Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
$ php -r '$c=file("Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php"); $m=0; foreach($c as $n=>$l){ if(str_contains($l,"public function")) $m++; } echo "public methods: $m\n";'
public methods: 8
```

#### PYC-13 · H · CTL-02 — twelve methods exceed the 150-line limit

| Field | Value |
|---|---|
| **Rule** | CTL-02 (H) — *methods over 80 lines → extract; over 150 lines is H* |
| **Where** | controller: `generate()` 202-551 (350), `conflicts()` 753-1604 (852), `exportWarningRow()` 1633-2105 (473), `runUntilFullPlacement()` 2376-2694 (319), `persistPreview()` 2920-3060 (141, M) · services: `SolutionAdapter::toGenerationResult()` 38-285 (248), `LockedCellPins::apply()` 53-340 (288), `UnplacedLessonAdvisor::advise()` 298-435 (138), `PythonRunner::run()` 81-186 (106), `runBatch()` 270-416 (147) |
| **Root cause** | The controller was built as a single-threaded pipeline with the analysis beside the calls; the services carry long-but-focused transformation methods. |
| **Consequence** | Any change inside these methods risks the surrounding 300-850 lines; the god-controller split (PYC-12) is the real cure. |
| **Reproduce** | Static only. |
| **Fix approach** | Deferred with PYC-12 (D3). No per-method extraction in this pass. DECISION item. |
| **Plan item** | PYC-13 in `02-fix-plan.md` §9 (DECISION) |

```php
    private function conflicts(array $problem, array $demand, int $slots, array $sectionSlots = []): array
    {
        $days = max(1, count($problem['days']));
        $perDay = max(1, count(array_filter($problem['hours'], fn ($h) => $h['is_teaching'])));
        $groups = [];
```

**Evidence**
```
$ php -r '$c=file("Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php"); foreach($c as $n=>$l){ if(preg_match("/function (\w+)\(/",$l,$m)){ echo $m[1].": ".($n+1)."\n"; } }' | head -3
__construct: 70
progressStatus: 107
cancel: 130
```

#### PYC-14 · L · CTL-04 — public actions without return types

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:202,3095,3168` |
| **Root cause** | `generate()`, `store()` and `redirectGenerate()` declare no return type (they return view/redirect/JSON branches). |
| **Consequence** | A future refactor can change the branch shape without the signature noticing; no runtime cost today. |
| **Reproduce** | Static only. |
| **Fix approach** | Type them `: View|RedirectResponse|JsonResponse` after the ERR-01 fixes settle the return shapes. |
| **Plan item** | PYC-14 in `02-fix-plan.md` §8 |

```php
    public function store(Request $request)
    {
        Gate::authorize('tenant.smart-timetable.python-timetable.create');

        $validated = $request->validate([
```

**Evidence**
```
$ grep -nE 'public function [a-zA-Z_]+\([^)]*\)$' Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
202:    public function generate(Request $request)
3095:    public function store(Request $request)
3168:    public function redirectGenerate()
```

#### PYC-15 · M · CTL-10 — dropPreviousPreview() is dead code

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused private methods, unused properties* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:3063-3085` |
| **Root cause** | The author kept `dropPreviousPreview()` "unused, so the decision is reversible" (comment at 2979-2982), but drafts are now intentionally kept. |
| **Consequence** | 23 lines of dead code (including a third controller try/catch) that loom as a "maybe I should call this" trap. |
| **Reproduce** | Static only. |
| **Fix approach** | Delete the method (no behavior change; grep proves no caller). |
| **Plan item** | PYC-15 in `02-fix-plan.md` §8 |

```php
    private function dropPreviousPreview(): void
    {
        $previousId = (int) session('py_preview_timetable_id');
        if ($previousId <= 0) {
            return;
        }

        session()->forget('py_preview_timetable_id');

        try {
            $previous = Timetable::find($previousId);
            // ⛔ Never delete something the user published, or anything that has
            // gone live. Only a draft this controller made and nobody saved.
            if ($previous && in_array($previous->status, ['GENERATING', 'GENERATED'], true) && ! $previous->is_active) {
                $this->storage->deleteSkeleton($previousId);
            }
        } catch (Throwable $e) {
            Log::warning('Could not drop previous Python preview', [
                'timetable_id' => $previousId,
                'error' => $e->getMessage(),
            ]);
        }
    }
```

**Evidence**
```
$ grep -rn "dropPreviousPreview" Modules/ | grep -v "function dropPreviousPreview"
(no callers — only the definition at PythonTimetableController.php:3063)
```

### F7 — Models

clean — the controller only uses models owned elsewhere (`Timetable`, `Activity`, `ClassTimetableType`, `PeriodSet`, `AcademicSession`) and queries them appropriately (`Timetable::whereNull('deleted_at')->find()`, `PeriodSet::…->value('id')`, aggregates via `selectRaw`). No model defect surfaced from this controller's use.

### F8 — Services and jobs

#### PYC-16 · M · SVC-02 — container lookups and `new` instead of constructor injection

| Field | Value |
|---|---|
| **Rule** | SVC-02 (M) — *dependencies arrive by constructor injection, not `new FooService()` or `app(Foo::class)` mid-method* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:466`, `:494` and `Modules/SmartTimetable/app/Services/Python/SolutionAdapter.php:488` |
| **Root cause** | `generate()` resolves `app(TimetableGenerationService::class)` and `app(PreviewDerivedData::class)` inside the method to avoid loading them on every constructor call; SolutionAdapter news up the stateless advisor. |
| **Consequence** | A test that constructs the controller without the container gets a runtime resolution; the dependency graph is implicit. |
| **Reproduce** | Static only. |
| **Fix approach** | Inject `TimetableGenerationService` and `PreviewDerivedData` in the constructor (both are already module services). SolutionAdapter's advisor stays internal (stateless helper). |
| **Plan item** | PYC-16 in `02-fix-plan.md` §4 |

```php
            $viewData['algorithm_stats']['class_teaching_windows'] = app(TimetableGenerationService::class)
                ->loadClassTeachingWindows(
                    (int) ($problem['timetable_type_id'] ?? 0),
                    $generationResult->periods,
                );
```

**Evidence**
```
$ grep -n "app(.*::class)\|new UnplacedLessonAdvisor" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php Modules/SmartTimetable/app/Services/Python/SolutionAdapter.php
PythonTimetableController.php:466:            $viewData['algorithm_stats']['class_teaching_windows'] = app(TimetableGenerationService::class)
PythonTimetableController.php:494:                $derived = app(PreviewDerivedData::class);
SolutionAdapter.php:488:        $advisor = new UnplacedLessonAdvisor($problem, $output);
```

### F9 — Queries and performance

clean — no query inside a loop, no N+1, aggregates in SQL (`selectRaw('academic_term_id, COUNT(*) …')` at 3220), lookups once per request (`conflictLabels()` is three queries for the whole panel; `lessonLabels()` memoised at 2770; progress is cache-backed). No interpolated raw SQL anywhere (QRY-11 absent): `grep -rn "DB::raw\|whereRaw\|orderByRaw" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php` → no output.

### F10 — Views

clean — the controller renders only `view('smarttimetable::preview.index', $viewData)` (line 521), which is owned by the TimetablePreviewController report (↗ linked). The python-timetable modal/scripts blades belong to the TimetableGeneration/TimetablePage pages. No view defect introduced by this controller. The generate form is a normal POST (`_generate-modal.blade.php:34-35`), which is what makes the JSON branches of generate() (lines 276-281, 294-298, 309-314) render raw JSON to a browser form submission — recorded in PYC-02/ERR-04 context above.

### F11 — Security and tenancy

clean — the process boundary is sound:
- `PythonRunner` uses Symfony `Process` array form (`new Process([$binary, $scriptPath, ...$arguments])`, lines 133/326) — no shell, no user-input interpolation into a command line; `basename()` guards on the script name (106-107) and the payload label (219-223);
- payloads are written to `storage_path('app/smart-timetable/python')`, which is tenant-aware (writePayload 210);
- `SolverProcessReaper::orphanPids()` only matches `generate.py` processes whose command line contains this tenant's storage dir and whose parent is not PHP (68-74);
- `GenerationProgress` cache keys carry tenant + user (`key()` 461, `activeKey()` 452) — the scanner's TEN-02 hits on this class are false positives confirmed in source;
- `env()` appears only in `Modules/SmartTimetable/config/python.php` (SEC-01 OK); `grep -rn "env(" Modules/SmartTimetable/app/` finds no call sites;
- no hard-coded ids (`?? 1`), no `Log::…($request->all())`, no secrets in logs.

### F12 — Style

#### PYC-17 · L · STY-01 — `declare(strict_types=1)` missing on 7 of 8 files

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (mandatory for new files; old files when touched)* |
| **Where** | `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php:1`, `Modules/SmartTimetable/app/Services/Python/GenerationProgress.php:1`, `GenerationSuperseded.php:1`, `LockedCellPins.php:1`, `PythonRunner.php:1`, `SolverProcessReaper.php:1`, `UnplacedLessonAdvisor.php:1` (all under `Modules/SmartTimetable/`) |
| **Root cause** | Only SolutionAdapter declares strict types; the cluster does not. |
| **Consequence** | Coercions (e.g. numeric strings) pass silently. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the declare line to each file when it is next touched. |
| **Plan item** | PYC-17 in `02-fix-plan.md` §8 |

```php
<?php

namespace Modules\SmartTimetable\Http\Controllers;
```

**Evidence**
```
$ grep -L "declare(strict_types=1)" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php Modules/SmartTimetable/app/Services/Python/*.php
Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
Modules/SmartTimetable/app/Services/Python/GenerationProgress.php
Modules/SmartTimetable/app/Services/Python/GenerationSuperseded.php
Modules/SmartTimetable/app/Services/Python/LockedCellPins.php
Modules/SmartTimetable/app/Services/Python/PythonRunner.php
Modules/SmartTimetable/app/Services/Python/SolverProcessReaper.php
Modules/SmartTimetable/app/Services/Python/UnplacedLessonAdvisor.php
```

#### PYC-18 · L · STY-04 — emoji markers (⚠ ⛔ ⭐) in comments across the cluster

| Field | Value |
|---|---|
| **Rule** | STY-04 (L) — *comments in English, no emoji markers, no commented-out code* |
| **Where** | 80+ occurrences across `Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php` and the six Python services (e.g. `PythonTimetableController.php:99-106`, `PythonRunner.php:37`, `LockedCellPins.php:22`, `GenerationProgress.php:65`) |
| **Root cause** | The whole cluster uses ⚠/⛔/⭐ as documentation emphasis in docblocks and inline comments. |
| **Consequence** | Cosmetic; grep-based tooling and the copy-not-retype rules treat them as noise. |
| **Reproduce** | Static only. |
| **Fix approach** | Strip markers when files are touched; one pass per file (grouped, not per line). |
| **Plan item** | PYC-18 in `02-fix-plan.md` §8 |

```php
     * ⛔ IT MUST NOT WRITE THE SESSION. Laravel saves the session at the end of every
     * request — and ages the flash data while doing it. A poll that started before
     * generate() saved its session and finished after would write the OLD session
```

**Evidence**
```
$ grep -c "⛔\|⚠\|⭐" Modules/SmartTimetable/app/Http/Controllers/PythonTimetableController.php
80
$ grep -c "⛔\|⚠\|⭐" Modules/SmartTimetable/app/Services/Python/*.php
GenerationProgress.php:15
LockedCellPins.php:8
PythonRunner.php:10
SolutionAdapter.php:22
SolverProcessReaper.php:1
UnplacedLessonAdvisor.php:5
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 wrong overwrite | 2 delete before replace | 3 duplicate impl | 4 soft-delete×unique | 5 race | 6 auth hole | 7 message lies | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `cancel()` | ok (token-scoped) | ok | ok | ok | ok (per-user token) | ok (gated) | ok | ok |
| `generate()` | ok (always a new draft) | ok (source only read) | note: mirrors PHP engine by design | ok | ok (`activeKey` per user stops older run) | ok | PYC-02 | PYC-15 (dropPreviousPreview) |
| `persistPreview()` | ok | ok | ok | ok | ok | ok | PYC-04-adjacent | ok |
| `store()` | ok (`lockForUpdate` + GENERATED-only + session guard) | ok | ok | ok | ok (service `lockForUpdate`) | ok (gated) | PYC-04 | ok |
| `lockInDraft()` (service) | ok (only the new draft's cells) | ok | ok | ok | ok | ok | ok | ok |
| `SolverProcessReaper::reapOrphans()` | ok (orphans only, this tenant) | — | ok | — | — | — | ok | ok |
| `GenerationProgress::*` cache writes | ok (tenant+user+token keyed) | ok | ok | — | ok (supersede check) | — | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `TimetableStorageService::finalizeGenerated` | throws `\RuntimeException` for business rules; D2 wants `\DomainException` | ERR-01/D2 | all three callers (PythonTimetableController, TimetableGenerationController, TimetablePublishController) — coord |
| `TimetableStorageService` | `createSkeleton`/`populateFromResult` are two transactions (PYC-08) | TXN-01 | TimetableGenerationController owner |
| `TimetableGenerationController` | same `catch (\RuntimeException)` + raw-message pattern in its store path (line 271) | ERR-01/D2 | TimetableGenerationController report |
| `config/permissionslist.php` | `smart-timetable.python-timetable` key declared but seeding is `/system-config/sync-permissions` (documented, not seeded) — buttons 403 for non-super-admin until then | F3 | operations/Tarun |
| Permission literals | AUTH-06 literal repetition is module-wide (same strings in ~8 controllers) | AUTH-06 | module-wide pass |

## 8. Not covered, and why

- **Python engine internals** — `Modules/SmartTimetable/python/*` (generate.py, engine.py) are not PHP and out of the rulebook's reach; only the PHP boundary (PythonRunner, SolverProcessReaper) was audited.
- **TimetableStorageService / TimetableGenerationService / PreviewViewData / PreviewDerivedData / ProblemExporter** — audited in their owner reports; only this controller's usage was checked here.
- **Generator/Solver clusters** — `PrimeSolver`, `ImprovedTimetableGenerator`, `PrimeConstraintBridge`, `Slot*`, `TimetableSolution` are mentioned only in comments by SolutionAdapter; they are the PHP engine's classes (TimetableGenerationService owner). Not reachable from this controller's runtime, so not claimed.
- **Full live run** — the tenant DB has 0 activities/timetables, so a real generate+save could not be exercised end-to-end (D4 forbids tests anyway). The lock-carry and portfolio loops were verified statically and via the code's own documented measurements.
- **Blade compile** of `preview.index` — owned by the preview report; the fixer's §10 verification covers any blade touched.