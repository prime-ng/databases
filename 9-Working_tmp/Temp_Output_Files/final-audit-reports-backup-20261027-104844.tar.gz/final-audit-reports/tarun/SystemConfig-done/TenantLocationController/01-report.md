# Final Audit — SystemConfig / TenantLocationController

**Audited:** 2026-10-17 · **By:** opencode · **Developer folder:** tarun
**Controller:** `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php` (101 lines, 2 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/system-config/location` (defaults to the Country tab); `…?tab=state`, `…?tab=district`, `…?tab=city`; the autocomplete JSON is `GET http://test.localhost:8000/system-config/location/search?tab=city&search=TEXT` |
| Menu path | Core Configuration → Location Mgmt |
| Who uses it | Roles holding `tenant.system-config.geography.viewAny`. On the calibration tenant `test.localhost` (tenant id `00000000-0000-4000-8000-000000000001`) that permission is row id 53 and is held by **Super Admin** and **School Admin**. |
| What a user does here | Read-only. A school user opens the tabbed page and browses four central reference lists — Country, State, District, City — with a search box per tab. There is no create, edit, delete or restore: the comment at `routes/tenant.php:123` says location masters are managed centrally. |
| Tables written | None. This controller (and the classes it calls) performs no INSERT/UPDATE/DELETE. |
| Tables read | `glb_countries`, `glb_states`, `glb_districts`, `glb_cities` — all on the central `global_master_mysql` connection. |
| Live data | Measured on `test.localhost` + central DB: `glb_countries` 1 live / 1 total, `glb_states` 36 / 36, `glb_districts` 785 / 785, `glb_cities` 1592 / 1592 (0 trashed). |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is production-ready. It is a 101-line, two-method, read-only window onto central reference data: both routed methods authorize before they query, both are GET-only, the tenant middleware group is present, the four relations the view needs are eager-loaded, and there is not a single write, `try/catch`, raw SQL string, `env()` call, debug statement or unvalidated model write. The single worst finding is a consistency one: each of the four tab lists paginates at 15 rows, while the estate standard (C12, `.claude/rules/screen-readiness-audit.md` §677) is exactly 10 with no documented exception — a reader comparing this screen with the rest of the backend sees a different page size for no reason. Rough effort to clear the whole plan: **S** (four identical tokens changed on one file).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 0 | 0 | 0 | 3 | 0 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean (no services or jobs in scope) |
| F2 Transactions/Audit | clean (no writes) | F9 Queries/Perf | TL-01, TL-02 |
| F3 Authorization | clean | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | clean |
| F5 Routes | clean | F12 Style | clean |
| F6 Controller shape | TL-03 | F13 Deep read | clean (no mutating methods) |
| F7 Models | ↗ linked to four owner reports | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php` | controller | 101 | this report | ✅ |
| 2 | `Modules/SystemConfig/resources/views/location/index.blade.php` | blade | 251 | this report | ✅ |
| 3 | `Modules/GlobalMaster/app/Models/Country.php` | model | 31 | ↗ [tarun/GlobalMaster-done/CountryController](../../GlobalMaster/CountryController-done/01-report.md) | ↗ linked |
| 4 | `Modules/GlobalMaster/app/Models/State.php` | model | 41 | ↗ [tarun/GlobalMaster-done/StateController](../../GlobalMaster/StateController-done/01-report.md) | ↗ linked |
| 5 | `Modules/GlobalMaster/app/Models/District.php` | model | 39 | ↗ [tarun/GlobalMaster-done/DistrictController](../../GlobalMaster/DistrictController-done/01-report.md) | ↗ linked |
| 6 | `Modules/GlobalMaster/app/Models/City.php` | model | 43 | ↗ [tarun/GlobalMaster-done/CityController](../../GlobalMaster/CityController-done/01-report.md) | ↗ linked |

The four models are already claimed in `final-audit-reports/00-CLASS-OWNERS.md` (lines 284–290, owner `opencode 2026-10-12`); this report does not re-audit them. How this controller uses them is checked here: every query runs against a model whose `$connection` is pinned to `global_master_mysql`, so a tenant-context read reaches the central reference DB without `tenancy()->central()` and without leaking into the tenant DB.

Common classes referenced but **not audited here** (protocol §4.2): the layout `x-backend.layouts.app`, `x-backend.components.breadcrum` + `App\View\Components\Backend\Components\Breadcrum`, `x-backend.tab.nav-tab`, `x-backend.tab.search-bar` (both under `resources/views/components/backend/tab/`), and the paginator views.

No in-scope file appears in a module `PRE-APPLIED-*.md`. No pre-applied files.

## 4. Routes

```
GET|HEAD  system-config/location         system-config.location.index   Modules\SystemConfig\Http\Controllers\TenantLocationController@index
GET|HEAD  system-config/location/search  system-config.location.search  Modules\SystemConfig\Http\Controllers\TenantLocationController@search
```

Both routes carry the tenant middleware group (from `php artisan route:list --json`): `web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\SetTenantAuthGuard`, `App\Http\Middleware\EnsureTenantIsActive`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`.

Unrouted public methods: none — both public methods (`index`, `search`) are registered at `routes/tenant.php:124-125`.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 33 | GET system-config/location | `tenant.system-config.geography.viewAny` (line 35-37, `Gate::any(...) \|\| abort(403)`) | none (no write) | none | none | TL-01, TL-02, TL-03 |
| `search` | 78 | GET system-config/location/search | `tenant.system-config.geography.viewAny` (line 82, `Gate::authorize`) | none (no write) | none | none | TL-01 |

## 6. Findings

### F1 — Errors

clean — `grep -nE '\btry\b|\bcatch\b|getMessage' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php` → no output. There is no `try/catch` and no exception text reaching the user, so ERR-01/ERR-02 cannot occur here (D1's Laravel idiom).

### F2 — Transactions and audit

clean — `grep -nE 'DB::|->save\(|->create\(|->update\(|->delete\(|insert\(|updateOrCreate|activityLog' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php` → no output. Both methods are reads; there is no multi-table write and therefore no transaction or `activityLog()` obligation.

### F3 — Authorization

clean. Both routed methods authorize **before** loading any record: `index()` at line 35 and `search()` at line 82. The permission name `tenant.system-config.geography.viewAny` is declared once in `config/permissionslist.php:362` as `'system-config.geography' => ['view', 'viewAny']` (the scope `tenant` is prepended by `PermissionHelper::flatten()`), and it appears identically on the view surface (`@can('tenant.system-config.geography.viewAny')` at blade lines 15, 73, 131, 189 and in the nav-tab `permission` keys at lines 8-11). Permissions resolve through Gate because `config/permission.php:104` has `'register_permission_check_method' => true` (Spatie registers a Gate check), and `AppServiceProvider` only additively bypasses for Super Admin. AUTH-06 (permission literals repeated) is app-wide convention — the config is the single declaration — so it is not raised as a defect here.

### F4 — Validation and input

clean. There are no model writes to validate. The only request input is `tab` and `search`: `tab` is whitelisted by the `match` in `search()` (unknown values fall to `default => collect()`) and by string comparison in `index()`; `search` is passed as a bound parameter to `LIKE` (never concatenated into SQL).

```
$ grep -nE 'request->all\(|->except\(|->fill\(|->validate\(' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php
(no output)
```

### F5 — Routes

clean. Both routes point at existing methods, both are GET reads (no state change over GET — RTE-01), custom routes precede nothing (no `Route::resource` here), there are no route parameters to mismatch, and the tenant middleware group is present on both.

### F6 — Controller shape

#### TL-03 · L · CTL-05 — four tab lists are four near-identical copy-paste blocks

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M, lowered to L — 4 short low-churn blocks in a read-only controller) — *no copy-paste: shared loaders, repeated blocks* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php:42-68`, method `index()` |
| **Root cause** | The four tab lists are written out four times; each block differs only in the model (`Country`/`State`/`District`/`City`), the eager-load (`null`/`country`/`state`/`district.state`), the page name and the tab key. |
| **Consequence** | Nothing breaks today, but any list change (for example the page-size fix in TL-02) must be made in four places, and a future edit that touches only one block will make the tabs disagree. |
| **Reproduce** | static only — the four blocks are identical in shape; there is no runtime difference to observe. |
| **Fix approach** | Optional refactor: extract one private helper that takes the model, the eager-load and the page name and returns the paginator. Deferred — the controller is 101 lines, the gain is maintainability only, and D3 keeps changes in place. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TenantLocationController.php:49-54 — the state block; the country/district/city blocks are identical modulo names
        $statesQuery = State::with('country')->orderBy('name');
        if ($tab === 'state' && $search) {
            $statesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $states = $statesQuery->paginate(15, ['*'], 'state_page')
            ->appends(['tab' => $tab, 'search' => $search]);
```

**Evidence**
```
$ grep -nE 'paginate\(' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php
46:        $countries = $countriesQuery->paginate(15, ['*'], 'country_page')
53:        $states = $statesQuery->paginate(15, ['*'], 'state_page')
60:        $districts = $districtsQuery->paginate(15, ['*'], 'district_page')
67:        $cities = $citiesQuery->paginate(15, ['*'], 'city_page')
```

### F7 — Models

↗ linked. All four models are owned by other reports (see the §3 scope table). Checked here is how this controller uses them: each model pins `protected $connection = 'global_master_mysql'` (`Country.php:13`, `State.php:13`, `District.php:11`, `City.php:14`), so the tenant-context queries go to the central reference DB. Relationships used by the view are eager-loaded (`State::with('country')`, `District::with('state')`, `City::with(['district', 'district.state'])`).

### F8 — Services and jobs

clean — `grep -oE '[A-Z][A-Za-z]+(Service|Job|Event|Mail|Notification)\b' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php` → no output. The controller injects no service and dispatches no job.

### F9 — Queries and performance

#### TL-01 · L · QRY-08 — leading-wildcard `LIKE '%search%'` on all eight search paths

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M, lowered to L — measured tables are tiny) — *leading-wildcard `LIKE '%x%'` cannot use an index; acceptable on small tables* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php:92-95`, method `search()`; and `:43-44, :50-51, :57-58, :64-65`, method `index()` |
| **Root cause** | The search term is wrapped as `'%'.$search.'%'`. The leading `%` makes the `name` column non-sargable, so MySQL must scan the whole table for each lookup. |
| **Consequence** | On the measured data (`glb_countries` 1, `glb_states` 36, `glb_districts` 785, `glb_cities` 1592 rows) the scan is imperceptible; it only becomes a real cost if the central city master grows to tens of thousands of rows. |
| **Reproduce** | Open `http://test.localhost:8000/system-config/location?tab=city&search=a` and type in the box — no visible delay on the current data. |
| **Fix approach** | Accept as-is per the rulebook (small tables). If the city master grows, switch to a prefix match, a FULLTEXT index, or a dedicated lower-cased search column — a central-schema decision, not this controller's. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// TenantLocationController.php:91-97 — the four autocomplete lookups, all leading-wildcard
        $results = match ($tab) {
            'country'  => Country::where('name', 'like', "%{$search}%")->limit(10)->pluck('name'),
            'state'    => State::where('name', 'like', "%{$search}%")->limit(10)->pluck('name'),
            'district' => District::where('name', 'like', "%{$search}%")->limit(10)->pluck('name'),
            'city'     => City::where('name', 'like', "%{$search}%")->limit(10)->pluck('name'),
            default    => collect(),
        };
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-systemconfig-scan.json Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php
L  STY-01   ... (models, linked)
M  QRY-08   Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php:44  index — 4 leading-wildcard LIKE search(es)
13 scanner rows for 6 path(s). Candidates only — confirm each in source.
```
Confirmed in source: 8 `like`/`LIKE` literals at lines 44, 51, 58, 65 (index) and 92-95 (search).

#### TL-02 · L · QRY-02 — every tab paginates at 15, the estate standard is 10

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H — pagination is mandatory and present here) with screen-readiness-audit.md C12 (page size exactly **10** unless the screen documents why) — *lists must paginate; the size is 10* |
| **Where** | `Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php:46, :53, :60, :67`, method `index()` |
| **Root cause** | Each of the four tab query chains ends in `->paginate(15, ['*'], '<tab>_page')`. Pagination itself is correct (distinct page names, links printed, tab appended), but the size is 15 and nothing on the screen documents a reason to differ from the C12 standard of 10. |
| **Consequence** | A user browsing this screen sees 15 rows per page while every C12-conforming screen shows 10 — an inconsistency in a reference list, not a functional failure. |
| **Reproduce** | Open `http://test.localhost:8000/system-config/location` and count the rows in the Country tab: 15. |
| **Fix approach** | Change the four page sizes from 15 to 10. |
| **Plan item** | TL-02 in `02-fix-plan.md` §6 |

```php
// TenantLocationController.php:42-68 — four paginate(15, ...) calls
        $countriesQuery = Country::orderBy('name');
        if ($tab === 'country' && $search) {
            $countriesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $countries = $countriesQuery->paginate(15, ['*'], 'country_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $statesQuery = State::with('country')->orderBy('name');
        if ($tab === 'state' && $search) {
            $statesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $states = $statesQuery->paginate(15, ['*'], 'state_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $districtsQuery = District::with('state')->orderBy('name');
        if ($tab === 'district' && $search) {
            $districtsQuery->where('name', 'LIKE', "%{$search}%");
        }
        $districts = $districtsQuery->paginate(15, ['*'], 'district_page')
            ->appends(['tab' => $tab, 'search' => $search]);

        $citiesQuery = City::with(['district', 'district.state'])->orderBy('name');
        if ($tab === 'city' && $search) {
            $citiesQuery->where('name', 'LIKE', "%{$search}%");
        }
        $cities = $citiesQuery->paginate(15, ['*'], 'city_page')
            ->appends(['tab' => $tab, 'search' => $search]);
```

**Evidence**
```
$ grep -nE 'paginate\(' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php
46:        $countries = $countriesQuery->paginate(15, ['*'], 'country_page')
53:        $states = $statesQuery->paginate(15, ['*'], 'state_page')
60:        $districts = $districtsQuery->paginate(15, ['*'], 'district_page')
67:        $cities = $citiesQuery->paginate(15, ['*'], 'city_page')
```

### F10 — Views

clean. No query in the blade. Every relation used inside `@forelse` is eager-loaded by the controller (`$state->country`, `$district->state`, `$city->district`, `$city->district->state`). No `{!! !!}`. Each pane is individually `@can('tenant.system-config.geography.viewAny')`-gated (blade lines 15, 73, 131, 189) so the pane, not just the tab strip, is protected. The breadcrumb resolves server-side: `Breadcrum.php:56` calls `resolveLinks()` when `links` is empty (the view passes `:links="[]"`), and `app/Services/Breadcrumbs/registry.php:3690` registers `system-config.location.index`.

```
$ grep -nE '\b[A-Z][A-Za-z]+::|DB::|->where\(|->get\(\)|->count\(\)' Modules/SystemConfig/resources/views/location/index.blade.php
(no output)
```

### F11 — Security and tenancy

clean. No `env()` outside config (`grep -nE 'env\(' <controller>` → no output). No personal data is returned — `search()` returns `pluck('name')` only. No hard-coded id or `?? 1`. No cache or static cache is used, so TEN-02 is not applicable. The central models are reached safely because each pins `$connection = 'global_master_mysql'` rather than relying on the ambient tenant connection.

### F12 — Style

clean — `declare(strict_types=1);` is on line 3; imports are sorted (lines 7-15); names are camelCase (`$countriesQuery`, `$districtsQuery`); `Request` is injected, not the `request()` helper. The only comments are the class docblock (lines 17-23), section dividers, and one feature-context comment at lines 80-81 — no commented-out code and no emoji.

```
$ grep -nE 'dd\(|dump\(|var_dump|print_r|ray\(|phpinfo' Modules/SystemConfig/app/Http/Controllers/TenantLocationController.php
(no output)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

There are no mutating methods; both methods are pure reads. The eight questions are answered for completeness:

| Method | 1 Wrong data | 2 Irreversible order | 3 Duplicate impl | 4 Soft-delete × unique | 5 Race | 6 Auth hole | 7 Message lies | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `index` | ok | ok | TL-03 | ok (read-only) | ok | ok | ok | ok |
| `search` | ok | ok | ok | ok | ok | ok | ok | ok |

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `resources/views/components/backend/tab/nav-tab.blade.php` | Has no `@props` declaration yet its `@php` block reads `$tabs` and `$active`; the `system-config/location` view passes `:tabs` but not `:active`. Verified by rendering the component with only `:tabs` — it renders without error (2450 bytes), so this is a latent robustness gap, not a live defect. | STY/CTL | owner of the shared `backend/tab` components |
| `resources/views/components/backend/tab/search-bar.blade.php` | The view hands it `url="system-config.location.country"` (and state/district/city), base route names that do not exist (only `.index`/`.search` are registered). The component guards with `Route::has($url.'.create')`/`.trashed`, so the action buttons are simply hidden — correct behaviour for a read-only list, but the prop values are misleading. | VIEW/RTE informational | view owner when the prop is next touched |

## 8. Not covered, and why

- The four `GlobalMaster` models are audited by their own reports; only this controller's usage of them was checked.
- Common shared components (`nav-tab`, `search-bar`, `breadcrum`, the backend layout, paginator views) are outside the per-controller scope (protocol §4.2); they are noted in §7 only.
- The screen was not rendered in a browser (no authenticated tenant session was established for this read-only audit); findings are static plus the route/config/DB measurements above.
- Seeding of the permission is Tarun's hand via `/system-config/sync-permissions`; the config declares it (`config/permissionslist.php:362`) and the calibration tenant already holds it (permission id 53).
