# Final Audit — TimetableFoundation / WorkingDayController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/WorkingDayController.php` (970 lines, 14 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 4 HIGH, 11 MEDIUM, 4 LOW.**

The write paths are the focus of this controller. The calendar is the live surface; the resource CRUD (`index/create/store/show/edit/update/destroy`) is not. Three of those resource methods are **routed to views that do not exist** and throw a 500 on any access. On the calendar path, a note longer than 255 characters — which the UI explicitly invites up to 500 — overflows the `varchar(255)` column and the save is lost. The 2026-10-10 pass converted only `ajaxStore`/`ajaxEdit` to the D2 error shape; **seven other methods still carry a controller `try/catch`**, and in `store`/`update` the `validate()` call sits inside it, so validation failures are swallowed into a generic message.

The single worst finding is **WDY-01**: `GET …/working-day/create`, `…/{id}` and `…/{id}/edit` each render `timetablefoundation::create`, `working-day.show` and `working-day.edit`, none of which exist on disk, so all three return 500.

The effort is about a day. Five DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 4 | 11 | 4 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | WDY-03, WDY-05, WDY-06 | F8 Services/Jobs | clean — no service, no job, no event (`grep -n "Service\|dispatch\|event(" $C` → none) |
| F2 Transactions/Audit | WDY-07 | F9 Queries/Perf | WDY-04 |
| F3 Authorization | WDY-08, WDY-17 | F10 Views | WDY-01, WDY-13, WDY-16 |
| F4 Validation | WDY-02, WDY-09, WDY-10, WDY-19 | F11 Security/Tenancy | clean — `grep -n "env(" $C` → none; no `?? 1`; no secrets logged |
| F5 Routes | WDY-01 (adjacent); otherwise clean | F12 Style | WDY-18 |
| F6 Controller shape | WDY-11, WDY-14, WDY-15 | F13 Deep read | WDY-11, WDY-12 |
| F7 Models | WDY-18 (model part); otherwise clean | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/WorkingDayController.php` | controller | 970 | this report | ✅ whole class |
| 2 | `app/Models/WorkingDay.php` | model | 118 | **this report (pre-assigned; reached by many files)** | ✅ |
| 3 | `app/Policies/WorkingDayPolicy.php` | policy | 44 | this report | ✅ — unreachable, see WDY-17 |
| 4 | `routes/web.php` lines 179-202 (Working Day block) | routes | — | this report (shared route file) | ✅ |
| 5 | `resources/views/pages/partials/timetable-masters/working-days/_list.blade.php` | tab partial | 464 | this report | ✅ |
| 6 | `resources/views/create.blade.php` (`timetablefoundation::create`) | page | — | **does not exist** | ❌ missing — WDY-01 |
| 7 | `resources/views/working-day/show.blade.php` | page | — | **does not exist** | ❌ missing — WDY-01 |
| 8 | `resources/views/working-day/edit.blade.php` | page | — | **does not exist** | ❌ missing — WDY-01 |
| 9 | `app/Models/ClassWorkingDay.php` | model | 194 | ↗ linked → [ClassWorkingDayController](../ClassWorkingDayController-done/01-report.md) | usage only (counts + `forceDelete`) |
| 10 | `app/Models/DayType.php` | model | 193 | ↗ linked → [DayTypeController](../DayTypeController/01-report.md) | usage only |
| 11 | `app/Models/Config.php` | model | 145 | ↗ linked → [ConfigController](../ConfigController/01-report.md) | usage only (`get()`) |
| 12 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model (other module) | 46 | common (§4.2) | relation only; §7 |
| 13 | `flash()`, `activityLog()` | helpers | — | common | not audited |
| 14 | `Modules/StudentPortal/.../Mobile/MobileCalendarController.php` | consumer | — | other module | cross-cutting note; reads `DAY_TYPE_COLORS` |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md` ("same as ClassWorkingDay: 7 `throw new \DomainException` across both controllers, 3 narrow catches"). In this file the pass left the `\DomainException` catch in `ajaxStore` (:340) and `ajaxEdit` (:509), both with the "do NOT widen to RuntimeException" comment naming ERR-01. It did **not** touch `store`, `update`, `destroy`, `ajaxUpdateRemark`, `ajaxDestroy`, `ajaxInitializeWorkingDays` or `ajaxClearWorkingDays`, which still carry controller `try/catch` — the reason WDY-05/06/08 exist. This audit reviewed the result fresh; the pass is incomplete. `ClassWorkingDayController` was touched in the same pass and shares the `ClassWorkingDay` and `DayType` models; it is owned by its own report — linked, not re-audited.

## 4. Routes

```
GET|HEAD  timetable-foundation/working-day                           timetable-foundation.working-day.index                  index
POST      timetable-foundation/working-day                           timetable-foundation.working-day.store                  store
GET|HEAD  timetable-foundation/working-day/create                    timetable-foundation.working-day.create                 create
GET|HEAD  timetable-foundation/working-day/{working_day}             timetable-foundation.working-day.show                   show
PUT|PATCH timetable-foundation/working-day/{working_day}             timetable-foundation.working-day.update                 update
DELETE    timetable-foundation/working-day/{working_day}             timetable-foundation.working-day.destroy                destroy
GET|HEAD  timetable-foundation/working-day/{working_day}/edit        timetable-foundation.working-day.edit                   edit
GET|HEAD  timetable-foundation/working-day/ajax/events               timetable-foundation.working-day.eventFeed              eventFeed
POST      timetable-foundation/working-day/ajax/store                timetable-foundation.working-day.ajaxStore              ajaxStore
POST      timetable-foundation/working-day/ajax/edit                 timetable-foundation.working-day.ajaxEdit               ajaxEdit
POST      timetable-foundation/working-day/ajax/remark/{id}          timetable-foundation.working-day.ajaxUpdateRemark       ajaxUpdateRemark
DELETE    timetable-foundation/working-day/ajax/delete/{id}          timetable-foundation.working-day.ajaxDestroy            ajaxDestroy
POST      timetable-foundation/working-day/ajax/initialize-calander  timetable-foundation.working-day.ajaxInitializeWorkingDays ajaxInitializeWorkingDays
DELETE    timetable-foundation/working-day/ajax/clear                timetable-foundation.working-day.ajaxClearWorkingDays   ajaxClearWorkingDays
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`. ✅ RTE-05.

**Unrouted public methods:** none — all 14 public methods are routed. The AJAX routes are declared (lines 181-187) before `Route::resource` (line 201), so the `{working_day}` wildcard cannot capture `ajax/*`. ✅ RTE-06.

Three routed methods point at non-existent views: `create`, `show`, `edit` (WDY-01).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to tab) | — |
| create | ✅ | create | — | — | — | WDY-01, WDY-11 |
| store | ✅ | create | ✅ closure | `Stored` | tt_working_days, sys_activity_logs | WDY-03, 05, 06, 07, 09, 10, 11 |
| show | ✅ | view | — | — | — | WDY-01 |
| edit | ✅ | update | — | — | — | WDY-01 |
| update | ✅ | update | ✅ closure | `Updated` | tt_working_days, sys_activity_logs | WDY-03, 05, 06, 07, 09, 11 |
| destroy | ✅ | delete | ✅ closure | `Trashed` | tt_working_days, sys_activity_logs | WDY-05, 06, 07, 11 |
| eventFeed | ✅ GET | viewAny | — | — | — | WDY-19 |
| ajaxStore | ✅ | create | ✅ per-date closure | `Stored` / `Restored` / `Updated` | tt_working_days, sys_activity_logs | WDY-04, 09 |
| ajaxEdit | ✅ | update | ✅ closure | `Updated` / `Stored` / `Deleted` | tt_working_days, sys_activity_logs | WDY-09, 14 |
| ajaxUpdateRemark | ✅ | update | ✅ closure | `Updated` | tt_working_days, sys_activity_logs | WDY-02, 05, 06, 08, 09 |
| ajaxDestroy | ✅ | delete | ✅ closure | `Deleted` / `Updated` | tt_working_days, tt_class_working_days_jnt, sys_activity_logs | WDY-05, 06, 08, 14 |
| ajaxInitializeWorkingDays | ✅ | create | ✅ closure | `Generated` | tt_working_days, tt_class_working_days_jnt, sys_activity_logs | WDY-04, 05, 06, 08, 12, 14 |
| ajaxClearWorkingDays | ✅ | delete | ✅ closure | `Deleted` | tt_working_days, tt_class_working_days_jnt, sys_activity_logs | WDY-05, 06, 08 |

**Tables each mutation SHOULD touch, before counting what it does:**
- `store`, `update`, `destroy` — the working-day row plus one audit row (`sys_activity_logs`, because `activityLog()` is a second table). They do both. ✅
- `ajaxStore`, `ajaxEdit` — the working-day row(s) on source/target plus their audit row(s). They do both, per date. ✅
- `ajaxUpdateRemark` — the row plus the audit row. ✅
- `ajaxDestroy`, `ajaxClearWorkingDays` — `tt_working_days` **and** the linked `tt_class_working_days_jnt` rows, plus one audit row. They delete the children before the parent. ✅
- `ajaxInitializeWorkingDays` — `tt_working_days` (and `tt_class_working_days_jnt` when `clear_existing`), plus one audit row. ✅
- **No transaction lives in a service** — this controller has no service; every closure is in the controller.

## 6. Findings

### F5 / F10 — Routes and views
#### WDY-01 · H · RTE-03 / VIEW — three routed methods render views that do not exist (500)
**Where:** `WorkingDayController.php:39`, `:92`, `:104`
```php
public function create()   { …; return view('timetablefoundation::create'); }
public function show(WorkingDay $workingDay) { …; return view('timetablefoundation::working-day.show', compact('workingDay')); }
public function edit(WorkingDay $workingDay) { …; return view('timetablefoundation::working-day.edit', compact('workingDay', 'dayTypes')); }
```
**Evidence:**
- `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan tinker --execute 'view()->exists("timetablefoundation::create")'` → **NO**; same for `working-day.show` and `working-day.edit`.
- `find Modules/TimetableFoundation/resources/views -path '*working-day*'` → only `pages/partials/timetable-masters/working-days/_list.blade.php`; there is no `working-day/` directory and no top-level `create.blade.php`.
- `route:list` shows the three routes live (from `Route::resource('working-day', …)`, `routes/web.php:201`).
- The module's own sibling `school-day` handles exactly this by `->except(['create'])` and an `abort(403)` method (`routes/web.php:150-154`). Working-day did not get that treatment.

**Consequence:** any hit on `GET /timetable-foundation/working-day/create`, `/{id}` or `/{id}/edit` — a bookmark, a stale link, or a future table action — throws `View [timetablefoundation::…] not found` and returns 500.

### F4 — Validation
#### WDY-02 · H · VAL-04 / VAL-05 — a 256–500-character remark passes validation but overflows the column
**Where:** `WorkingDayController.php:538-545` · migration `database/migrations/tenant/2026_06_16_152616_create_tt_working_day_table.php:19` · `_list.blade.php:255`
```php
// controller
'remarks' => ['nullable', 'string', 'max:500'],
…
$workingDay->update(['remarks' => $validated['remarks'] ?? null]);
// migration: $table->string('remarks')->nullable();   → varchar(255)
// blade:     <textarea id="wdRemarkInput" rows="3" maxlength="500" …>
```
**Evidence:**
- `SHOW COLUMNS FROM tt_working_days LIKE 'remarks'` → `varchar(255)`.
- `SELECT @@sql_mode` → `ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,…` (strict, so overflow is error 1406, not a truncation warning).
- Live data max remark length is 16 (57 rows carry one) — the bug is latent, not yet triggered.

**Consequence:** a school admin types a note of 256–500 characters in the calendar popup (the UI says "Max 500 characters" and permits it), the INSERT/UPDATE raises SQL 1406, the generic catch returns JSON 500, and the typed note is lost.

#### WDY-03 · H · ERR-02 — `validate()` runs inside the try, so ValidationException is swallowed
**Where:** `store:51` inside `try` at `:49`; `update:116` inside `try` at `:114`
```php
try {
    return DB::transaction(function () use ($request) {
        $validated = $request->validate([ 'date' => 'required|date', … ]);
        …
} catch (ModelNotFoundException $e) {
    throw $e;
} catch (\Throwable $e) {
    Log::error('WorkingDayController::store failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** scanner ERR-02 H at `store:49` and `update:114`. Unlike `ajaxUpdateRemark`/`ajaxDestroy`, these two catches do **not** rethrow `ValidationException`, so it is caught by `\Throwable` and converted into a flash.
**Consequence:** a validation failure on `POST/PUT /working-day` shows "The operation could not be completed." instead of the field errors, so the user cannot see which input is wrong. (Reachability is via direct POST today — see WDY-01.)

#### WDY-09 · M · VAL-02 — validation lives inline in the controller, not a FormRequest
**Where:** `store:51-56`, `update:116-121`, `ajaxStore:257-261`, `ajaxEdit:376-379`, `ajaxUpdateRemark:538-540`
**Evidence:** `ls Modules/TimetableFoundation/app/Http/Requests/` → only `DayTypeRequest.php` and `SchoolDayRequest.php`; there is no `WorkingDayRequest`. Every rule set is a literal `$request->validate([...])`.
**Consequence:** the same rule block is duplicated in `store` and `update`, and is unavailable to any other entry point (importer, API), so they can drift apart.

#### WDY-10 · M · VAL-04 — `store()` cannot create a date that has a soft-deleted row
**Where:** `store:61` `$validated['academic_session_id'] = …; $workingDay = WorkingDay::create($validated);` · migration unique index `uq_workday_date`
**Evidence:**
- `SHOW CREATE TABLE tt_working_days` → `UNIQUE KEY uq_workday_date (date)` — a plain unique that includes soft-deleted rows (soft delete is only the `deleted_at` column).
- `store()` reads the default (non-trashed) model and has no `unique:tt_working_days,date` rule.
- `delete` trashes (`destroy:156`); `tt_working_days` currently has 0 trashed rows → latent.

**Consequence:** if a resource `destroy` ever soft-deletes a date and the same date is created again, the insert raises 1062 and the user sees the generic error instead of "that date already exists".

#### WDY-19 · L · VAL-05 — `eventFeed` does not validate `start`/`end`
**Where:** `eventFeed:206-207`, `:210`
```php
$start = $request->input('start');
$end = $request->input('end');
$days = WorkingDay::with([...])->whereBetween('date', [$start, $end])->where('is_active', true)->get();
```
**Evidence:** no `validate()` in `eventFeed`; a null range yields `date BETWEEN NULL AND NULL` → an empty feed, not an error.
**Consequence:** low — FullCalendar always sends ISO bounds; a malformed range silently returns `[]` rather than a 422.

### F1 — Errors
#### WDY-05 · M · ERR-00 (D1) — seven methods still carry a controller `try/catch`
**Where:** `store:49-80`, `update:114-144`, `destroy:154-175`, `ajaxUpdateRemark:528-570`, `ajaxDestroy:579-673`, `ajaxInitializeWorkingDays:795-909`, `ajaxClearWorkingDays:917-966`
**Evidence:** the 2026-10-10 pass (see §3) added the D2 shape to `ajaxStore`/`ajaxEdit` only; these seven still wrap their body in `try { … } catch (\Throwable) { … }` (three of them also rethrow `ModelNotFoundException`). D2 allows only `\DomainException` business messages, a truncate-then-rebuild catch, `SnapshotProtectionException`, or a service `report($e)` — none of which applies here.
**Consequence:** errors are rendered twice — once by the local generic catch, once by the central handler in `bootstrap/app.php`; the local catch hides the real exception class and makes the 404/403/422 rethrow list a thing that can be forgotten.

#### WDY-06 · M · ERR-05 — the local catches log only `$e->getMessage()`
**Where:** `:77`, `:141`, `:172`, `:564`, `:667`, `:903`, `:960`
```php
Log::error('WorkingDayController::store failed', ['error' => $e->getMessage()]);
```
**Evidence:** scanner ERR-05 M at each of the seven sites; no `report($e)` and no exception object is passed.
**Consequence:** the stack trace is discarded, so a production failure cannot be traced from the log.

### F2 — Transactions and audit
#### WDY-07 · M · TXN-05 — the redirect and flash are built inside the transaction closure
**Where:** `store:67-69`, `update:131-133`, `destroy:162-164`
```php
return DB::transaction(function () use ($request) {
    …
    return redirect()->route('timetable-foundation.menu.timetableMasters', ['tab' => 'working-days'])
        ->with('success', flash('created.working_day'));
});
```
**Evidence:** the redirect response is the closure's return value; the closure also returns it into the controller's `return`.
**Consequence:** the success flash is queued before the commit. If the commit fails, the next page can still show "Working Day was created successfully." for a row that does not exist. Fix: the closure returns the model; the redirect is built after it.

### F3 — Authorization
#### WDY-08 · M · AUTH-02 — `Gate::authorize` runs inside the try (4 methods)
**Where:** `ajaxUpdateRemark:529` (try at `:528`), `ajaxDestroy:580` (try at `:579`), `ajaxInitializeWorkingDays:796` (try at `:795`), `ajaxClearWorkingDays:918` (try at `:917`)
**Evidence:** scanner AUTH-02 M at `:528`, `:579`, `:795`, `:917`. Each method does authorize before loading its record, which is correct; the problem is only that the call is inside the `try`.
**Consequence:** a 403 currently stays a 403 only because each catch rethrows `AuthorizationException`. If a future edit widens a catch, an authorization failure silently becomes a generic 500. Authorize before the `try`.

#### WDY-17 · L · AUTH-04 / AUTH-06 — `WorkingDayPolicy` is registered but never consulted
**Where:** `TimetableFoundationServiceProvider.php:142` `Gate::policy(WorkingDay::class, WorkingDayPolicy::class)`; every gate in the controller passes a permission **string** (`Gate::authorize('tenant.timetable-foundation.working-day.…')`).
**Evidence:** no `$this->authorize('…', $workingDay)` or `can:` route middleware exists for this model, so none of the policy's seven methods is ever reached.
**Consequence:** dead code that looks active; the five permission strings are repeated as literals across the controller instead of living in one place. Module-wide pattern (see §7).

### F6 — Controller shape
#### WDY-14 · M · CTL-02 — four methods exceed 80 lines
**Where:** `ajaxStore` 112 lines (`253-364`), `ajaxEdit` 149 (`372-520`), `ajaxDestroy` 98 (`577-674`), `ajaxInitializeWorkingDays` 118 (`793-910`)
**Evidence:** scanner CTL-02 M at `:253`, `:372`, `:577`, `:793`.
**Consequence:** the per-date and per-branch logic is hard to review and test; extraction is deferred (D3).

#### WDY-15 · M · CTL-06 — business rules live in the controller
**Where:** `addDayTypeToWorkingDay:723-763` (max 4 slots, no duplicate, mutual exclusion working/holiday), `removeSlotAndCompact:770-787` (slot compaction, `is_school_day` recompute)
**Evidence:** the rules are private controller methods, not a service/action; `ajaxStore` and `ajaxEdit` both call them.
**Consequence:** any other writer (importer, future API) cannot reuse the rules, so alternative paths can store rows that violate them. Extraction is a DEFERRED decision (D3).

#### WDY-11 · M · deep read — the resource `store`/`update`/`destroy` duplicate the AJAX write paths with weaker rules
**Where:** `store`/`update` (`:45-145`) vs `ajaxStore` (`:253-364`); `destroy` (`:150-176`) vs `ajaxDestroy` (`:577-674`)
**Evidence:** the resource path calls `WorkingDay::create()/update()` directly — it never calls `addDayTypeToWorkingDay()` (no mutual-exclusion check) and takes no `lockForUpdate()`, while the AJAX path does both. `update()` writes `day_type1_id` but leaves `day_type2-4` untouched, so a stacked row can be left with a working type and a holiday type. `destroy()` soft-deletes; the calendar only `forceDelete`s. The working-days tab links to none of the resource routes.
**Consequence:** two create/update/delete implementations that disagree; a direct POST can store an invalid multi-slot row or soft-delete a row the calendar treats as force-deleted. Resolve together with WDY-01.

### F13 — Deep read
#### WDY-12 · M · deep read — `ajaxInitializeWorkingDays` overwrites `day_type1` but leaves slots 2–4
**Where:** `ajaxInitializeWorkingDays:864-869`
```php
$existing->update([
    'academic_session_id' => $academicSession->id,
    'day_type1_id' => $isClosedDay ? $holidayType->id : $workingDayType->id,
    'is_school_day' => ! $isClosedDay,
    'is_active' => true,
]);
```
**Evidence:** the update sets only `day_type1_id`; `day_type2-4` are never reset (compare `ajaxStore:285-293` and `ajaxEdit:455-463`, which null all four). Live data today has only single-slot rows (0 with a second type), so it is latent.
**Consequence:** running "Auto-Fill Year" (`clear_existing=false`) over a date that already carries a stacked type can leave a holiday type next to a working type on the same date — the exact combination `addDayTypeToWorkingDay` refuses everywhere else. The calendar then shows an impossible day.

### F9 — Queries and performance
#### WDY-04 · H · QRY-01 — one database round-trip per date inside the loop
**Where:** `ajaxInitializeWorkingDays:852-880` (`withTrashed()->where('date', …)->first()` then `update`/`create` for every date), and `addDayTypeToWorkingDay:737` (re-queries `DayType` on every call from the loops in `ajaxStore`/`ajaxEdit`)
**Evidence:** scanner QRY-01 H at `:856` (withTrashed inside loop) and `:276/:277` (DB::transaction + withTrashed inside the `ajaxStore` loop). `tt_working_days` currently holds 365 rows — one full session.
**Consequence:** "Auto-Fill Year" issues ~365 SELECTs plus ~365 single-row writes one at a time; the existing rows can be pre-loaded into a `keyBy('date')` collection and the creates sent in bulk. `ajaxStore`'s per-date transaction is intentional (partial success is reported via `applied`/`skipped`) and should **not** be hoisted; only the read inside its loop is the target.

### F12 — Style
#### WDY-18 · L · STY / MDL — style and model polish
**Evidence (scanner):**
- `WorkingDayController.php` — `STY-01` (no `declare(strict_types=1)`), `STY-04` (emoji `⚠` in the `:188` comment), `CTL-04` (no return type on all 14 public methods).
- `WorkingDay.php` — `STY-01`; `MDL-04` (`dayType`, `dayType2`, `dayType3`, `dayType4` have no return type); `STY-04` (duplicate docblock: `:63-65` "Day type (Working / Half / Holiday etc.)" and `:66-68` "Primary day type (shift 1)").
- `WorkingDayPolicy.php` — `STY-01`.
**Consequence:** consistency debt only.

### F10 — Views
#### WDY-13 · M · VIEW-03 — stored remarks are injected unescaped into the SweetAlert popup (DOM XSS)
**Where:** `resources/views/pages/partials/timetable-masters/working-days/_list.blade.php:248`, `:257`
```js
const currentRemark = info.event.extendedProps?.remarks || '';
…
html: '<div …><textarea id="wdRemarkInput" …>' + currentRemark + '</textarea>' + …
```
**Evidence:** `remarks` is served by `eventFeed:237` and concatenated straight into `html:` with no escaping. HTML in a saved remark is executed when any admin opens the popup; a `</textarea>` closes the field.
**Consequence:** a saved remark can render markup / run script in the admin's calendar, and can break out of the remark box. Escaping the value (`textContent`/`jQuery.text`/replace) removes the sink.

#### WDY-16 · L · CTL-05 — the day-type palette is duplicated in the blade
**Where:** `WorkingDayController.php:191-195` `public const DAY_TYPE_COLORS = ['WD' => '#3b82f6', …]` · `_list.blade.php:27-31` `$dtColors = ['WD' => '#3b82f6', …]`
**Evidence:** both arrays list the same nine codes and colours; the controller's own comment (`:188-190`) admits the repetition. `MobileCalendarController:41` reads the constant too.
**Consequence:** a palette change must be made in two places or the drag chips and the calendar events drift apart.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`OrganizationAcademicSession` (SchoolSetup):** resolves — `where('is_current', true)` returns session id 7 (2026-27, 2026-04-01…2027-03-31). It is a tenant table (`sch_org_academic_sessions_jnt`) and is common (§4.2). Not audited.
- **Unreachable policies (module-wide):** every policy in this module is unreachable because gates pass strings (WDY-17). Same pattern the AcademicTerm report recorded; it needs a module-level decision.
- **`MobileCalendarController` (StudentPortal):** reads `WorkingDayController::DAY_TYPE_COLORS` for the mobile school calendar. Any change to the palette / constant touches another module's controller — link, do not edit here.
- **Tenant data observation (not a code defect):** `tt_working_days` holds 365 rows for dates 2025-04-01…2026-03-31 but all carry `academic_session_id = 1` (Session 2020-21), while the current session is id 7. `eventFeed` filters by `date` only, so the calendar still works; the mismatch is data drift, and repair is out of scope.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static analysis or a read-only SQL / view-existence probe.
- **Blade compilation:** the `_list.blade.php` compile check was not performed (D4 — no test harness). It is a live, in-use partial; WDY-13 is a source-level read.
- **Pint:** not run. Running it edits files, which this phase forbids; `STY-02` (Pint-clean) is therefore unverified.
- **`WorkingDayRequest`:** does not exist; WDY-09 recommends creating it, which is a fix, not an audit.
- **Data repair:** the session-id/date drift noted in §7, and the 365 live rows, are reported only.
- **The other controllers that write `tt_working_days`** (seeders, `TimetableFoundationController:510`, `MobileCalendarController`) were not audited; the soft-delete/unique trap in WDY-10 is shared with them.
