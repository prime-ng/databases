# Final Audit — TimetableFoundation / RequirementConsolidationController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/RequirementConsolidationController.php` (1,616 lines, 15 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`
**ID prefix:** `RCC` (confirmed free — ATC/ACT/PSC/WDY are taken).

## 1. Verdict

**Not production-ready. 2 blockers, 7 HIGH.**

The generation path (`generateRequirements`) is the only large, well-guarded method: it truncates outside the transaction, rebuilds inside one, logs `Generated` after the write, and shows a fixed message on failure. Everything around it is weaker.

The worst finding is **RCC-22**: the "add requirement" button on the Class-Timetable-Type screen links to `requirement-consolidation.create`, and that screen 500s on render because its blade calls two route names (`timetable-foundation.class-group-requirement.store` / `.index`) that do not exist. Its `store()` sibling (**RCC-15**) is independently broken — it calls `ClassGroupRequirement`, a class that exists nowhere in the codebase, so a POST fatals before the transaction.

The rest is god-controller debt (1,616 lines, two methods of 228/337 lines), a legacy `update()` branch that can never run, validation that is silently dead, and a trash list that lazy-loads six relations per row. Effort is roughly 1.5–2 days, most of it deciding whether the create screen is repaired or retired.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 2 | 7 | 15 | 8 | 6 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | RCC-01, RCC-02, RCC-03 | F8 Services/Jobs | RCC-19 |
| F2 Transactions/Audit | clean | F9 Queries/Perf | RCC-20, RCC-21 |
| F3 Authorization | clean (policy unreachable — §7) | F10 Views | RCC-22, RCC-23 |
| F4 Validation | RCC-04, RCC-05, RCC-06 | F11 Security/Tenancy | RCC-24, RCC-25 |
| F5 Routes | RCC-07 | F12 Style | RCC-26, RCC-27, RCC-28 |
| F6 Controller shape | RCC-08, RCC-09, RCC-10, RCC-11, RCC-12, RCC-13, RCC-14 | F13 Deep read | RCC-29, RCC-30, RCC-31, RCC-32 |
| F7 Models | RCC-15, RCC-16, RCC-17, RCC-18 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/RequirementConsolidationController.php` | controller | 1,616 | this report | ✅ whole class |
| 2 | `app/Models/RequirementConsolidation.php` | model | 335 | this report (pre-assigned) | ✅ |
| 3 | `app/Models/ClassSubjectGroup.php` | model | 169 | this report (pre-assigned) | ✅ |
| 4 | `app/Models/ClassRequirementGroup.php` | model | 106 | this report (pre-assigned) | ✅ |
| 5 | `app/Models/ClassRequirementSubgroup.php` | model | 128 | this report (pre-assigned) | ✅ |
| 6 | `app/Services/RequirementTableTruncator.php` | service | 192 | this report (pre-assigned) | ✅ |
| 7 | `app/Policies/RequirementConsolidationPolicy.php` | policy | 44 | this report | ✅ — unreachable, §7 / F3 |
| 8 | `routes/web.php` lines 284–294 | routes | — | this report | ✅ |
| 9 | `resources/views/class-group-requirement/create.blade.php` | page | 439 | this report | ✅ — RCC-22 |
| 10 | `resources/views/class-group-requirement/trash.blade.php` | page | 112 | this report | ✅ — RCC-21 |
| 11 | `resources/views/requirement-consolidation/edit.blade.php` | page | 783 | this report | ✅ |
| 12 | `resources/views/requirement-consolidation/show.blade.php` | page | 123 | this report | ✅ |
| 13 | `resources/views/class-group-requirement/edit.blade.php` | page (orphan) | 196 | this report | ✅ — RCC-23 |
| 14 | `resources/views/class-group-requirement/index.blade.php` | page (orphan) | 44 | this report | ✅ — RCC-23 |
| 15 | `resources/views/class-group-requirement/show.blade.php` | page (orphan) | 25 | this report | ✅ — RCC-23 |
| 16 | `app/Models/ClassSubjectSubgroup.php` | model | 129 | ↗ [ClassSubjectSubgroupController](../ClassSubjectSubgroupController-done/01-report.md) | ↗ linked — used by `create`/`processClassSubjectSubgroups`; usage checked |
| 17 | `app/Models/AcademicTerm.php` | model | — | ↗ [AcademicTermController](../AcademicTermController/01-report.md) | ↗ linked — only `AcademicTerm::all()` in `edit` |
| 18 | `app/Models/TimetableType.php` | model | — | ↗ [TimetableTypeController](../TimetableTypeController-done/01-report.md) | ↗ linked — only `TimetableType::all()` in `edit` |
| 19 | `app/Support/Snapshot/SnapshotProtectionException.php` | support | 514 b | ❌ not audited | Indirect, via the truncator; message shown verbatim is D2-allowed |
| 20 | `app/Support/Snapshot/SnapshotWriter.php` (and the Snapshot\* subsystem) | service | 22 KB+ | ❌ not audited | Shared snapshot subsystem reached indirectly; out of this controller's direct reach (§5/§7) |
| 21 | `OrganizationAcademicSession`, `Room`, `RoomType`, `SchClassGroupsJnt`, `SchoolClass`, `Section`, `StudyFormat`, `Subject`, `SubjectType` (SchoolSetup) | models | — | common (other module) | referenced only — dropdown/relation reads |
| 22 | `x-backend.table.action-trashed` + its class `App\View\Components\Backend\Table\ActionTrashed`, `x-backend.layouts.app`, `x-backend.components.breadcrum` | shared UI | — | common | props checked: `restorePermission`/`forceDeletePermission`/`url`/`:id` match the constructor |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md` ("same raw-message removal (truncate-rebuild); `generateClassGroups`' second catch gained `report($e)`"). The audit reviewed the result fresh:
- The raw-message removal **is present** — the `generateRequirements` catch now returns the fixed message at `:1285`.
- The claimed `report($e)` **is absent**. `grep -c "report(" ` on the file returns `0`, and there is no `generateClassGroups` method — the regeneration method is `generateRequirements`. The second catch (there is only one catch in that method) still uses `Log::error(...)`. See RCC-03.

## 4. Routes

Uncached (`APP_ROUTES_CACHE=/tmp/fa-nocache.php`):

```
GET|HEAD  timetable-foundation/requirement-consolidation                          requirement-consolidation.index            index
POST      timetable-foundation/requirement-consolidation                          requirement-consolidation.store            store
GET|HEAD  timetable-foundation/requirement-consolidation/create                   requirement-consolidation.create           create
GET|HEAD  timetable-foundation/requirement-consolidation/{requirement_consolidation}            requirement-consolidation.show    show
PUT|PATCH timetable-foundation/requirement-consolidation/{requirement_consolidation}            requirement-consolidation.update  update
DELETE    timetable-foundation/requirement-consolidation/{requirement_consolidation}            requirement-consolidation.destroy destroy
GET|HEAD  timetable-foundation/requirement-consolidation/{requirement_consolidation}/edit       requirement-consolidation.edit    edit
GET|HEAD  timetable-foundation/requirement-consolidation/trash/view               requirement-consolidation.trashed          trashedRequirementConsolidation
GET|HEAD  timetable-foundation/requirement-consolidation/{id}/restore             requirement-consolidation.restore          restore   ← GET
DELETE    timetable-foundation/requirement-consolidation/{id}/force-delete        requirement-consolidation.forceDelete      forceDelete
POST      timetable-foundation/requirement-consolidation/{requirement_consolidation}/toggle-status requirement-consolidation.toggleStatus toggleStatus
POST      timetable-foundation/requirement-consolidation/generate-requirements/generate requirement-consolidation.generateRequirements generateRequirements
POST      timetable-foundation/class-subject-requirement/update                   requirement-consolidation.update-requirement updateRequirement
POST      timetable-foundation/class-subject-requirement/update-periods           requirement-consolidation.update-periods   updatePeriods
POST      timetable-foundation/requirement-consolidation/ajax/inline-update/{id}  requirement-consolidation.ajaxInlineUpdate ajaxInlineUpdate
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.
**Unrouted public methods:** none — all 15 public methods are routed.
**Scanner RTE-02 false positive:** `scan.php` (cached `routes.json`) reports `requirement-consolidations/stats → getRequirementsStats(): method does not exist`. That route was removed 2026-10-10 (`routes/web.php:291` comment); the uncached list above has no such route. Not present.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect) | — |
| create | ✅ | create | — | — | reads only | RCC-20, RCC-22 |
| store | ✅ | create | ✅ closure :270 | `Stored` | *intended* tt_class_requirement_groups, sys_activity_logs | RCC-02, 04, 05, 06, 15 |
| show | ✅ | view | — | — | — | RCC-10 |
| edit | ✅ | update | — | — | reads only | RCC-10, RCC-20 |
| update | ✅ | update | ✅ closure :442 | `Updated` (with diff) | tt_requirement_consolidations, sys_activity_logs | RCC-01, 02, 04, 10, 11, 13, 14 |
| destroy | ✅ | delete | ✅ closure :727 | `Trashed` | tt_requirement_consolidations, sys_activity_logs | RCC-02, 10 |
| trashedRequirementConsolidation | ✅ | restore | — | — | — | RCC-21 |
| forceDelete | ✅ | forceDelete | ✅ closure :795 | `Deleted` | tt_requirement_consolidations, sys_activity_logs | RCC-02, 10, 29 |
| restore | ✅ GET | restore | ✅ closure :840 | `Restored` | tt_requirement_consolidations, sys_activity_logs | RCC-02, 07, 10 |
| toggleStatus | ✅ | update | ✅ closure :902 | `Toggled` | tt_requirement_consolidations, sys_activity_logs | RCC-02 |
| updatePeriods | ✅ | update | ✅ closure :964 | `Updated` | tt_requirement_consolidations, sys_activity_logs | RCC-01, 02, 04 |
| updateRequirement | ✅ | update | ✅ closure :1071 | `Updated` | tt_requirement_consolidations, sys_activity_logs | RCC-01, 02, 04, 25, 32 |
| ajaxInlineUpdate | ✅ | update | ✅ closure :1141 | `Updated` | tt_requirement_consolidations, sys_activity_logs | RCC-02, 10 |
| generateRequirements | ✅ | generate | ✅ closure :1227 (truncate :1225 before it) | `Generated` | TRUNCATE tt_requirement_consolidations + 6 downstream tables; upsert tt_requirement_consolidations; sys_activity_logs | RCC-19, 30, 31 |

**Tables each mutation SHOULD touch** (named before counting what it does):
- **update / destroy / forceDelete / restore / toggleStatus / updatePeriods / updateRequirement / ajaxInlineUpdate** should touch `tt_requirement_consolidations` + `sys_activity_logs`. They do — each has one transaction with the log inside, after the write.
- **store** should touch `tt_class_requirement_groups` + `sys_activity_logs`. It does neither: the target class is undefined (RCC-15).
- **generateRequirements** should TRUNCATE `tt_requirement_consolidations` and every later pipeline stage, then upsert the consolidation rows and log. It does — via `RequirementTableTruncator::truncateFrom('consolidations')` (RCC-30).

## 6. Findings

### F1 — Errors
#### RCC-01 · H · ERR-02 — `validate()` sits inside a catch that turns a 422 into a flash / 500
**Where:** `RequirementConsolidationController.php:376-378`, `:484-491`, `:949-956`, `:1008-1019`
```php
try {
    $validated = $request->validate([...]);       // ValidationException → caught below
    ...
} catch (ModelNotFoundException $e) {
    throw $e;
} catch (\Throwable $e) {
    return back()->with('error', 'Failed to update requirement.')->withInput();
}
```
**Evidence:** `grep -n "validate(" ...` → validation appears at 377, 491, 950, 1009, each on the first line inside its `try`. `ValidationException` does not extend `ModelNotFoundException`, so the generic `\Throwable` catch wins.
**Consequence:** a bad field on the edit form / inline AJAX shows a generic "Failed to update…" (form) or HTTP 500 (JSON) instead of the field-level 422 the user needs.

#### RCC-02 · M · ERR-00 (D1) — nine controller methods still catch their own errors, in two shapes
**Where:** `store:268`, `update:376,484`, `destroy:724`, `forceDelete:792`, `restore:837`, `toggleStatus:899`, `updatePeriods:949`, `updateRequirement:1008`, `ajaxInlineUpdate:1140`
**Evidence:** each is a `try { … } catch (ModelNotFoundException) { throw } catch (\Throwable) { Log::error…; return … }`. None is the D2 shape (a `\DomainException` business catch, or a truncate-rebuild's single fixed-message catch). `generateRequirements:1211` **is** the D2 truncate-rebuild shape and is exempt.
**Consequence:** the controller mixes the legacy house style with the Laravel idiom Tarun settled on (ERR-00 = the idiom); the central handler is bypassed and each catch is another place to hide a 404/422 (see RCC-01).

#### RCC-03 · M · ERR-05 — ten catches log `getMessage()` + a class-name string, not the exception; the pre-applied `report($e)` is missing
**Where:** `:285, 470, 696, 750, 814, 863, 925, 983, 1091, 1157`; service `RequirementTableTruncator.php:145`
```php
Log::error('Failed to update requirement consolidation: '.$e->getMessage(), [
    'requirement_id' => $id,
    'exception' => get_class($e),        // a string, not the object — no trace
]);
```
**Evidence:** `grep -n "report(" RequirementConsolidationController.php` → **0 matches**. The 2026-10-10 note claims the second catch gained `report($e)`; it did not. `RequirementTableTruncator.php:145` logs `'error' => $e->getMessage()` alone.
**Consequence:** the stack trace is lost for ten failure paths, so a production error cannot be located from the log.

### F2 — Transactions/Audit
**clean.** Every mutating method opens exactly one `DB::transaction(fn …)`; `activityLog()` sits inside it, after the write (`store:273`, `update:458`, `destroy:735`, `forceDelete:799`, `restore:848`, `toggleStatus:906`, `updatePeriods:967`, `updateRequirement:1076`, `ajaxInlineUpdate:1146`, `generateRequirements:1248`); redirects/responses are built after the closure (TXN-05 ✅); the TRUNCATE runs before the transaction (TXN-03 ✅). Compulsory proof: `grep -nE "DB::transaction|activityLog\(" …`.

### F3 — Authorization
**clean.** All 15 routed methods call `Gate::authorize(...)` with a `scope.module.feature.action` name, before loading records. All eight names are declared (`config/permissionslist.php:696` `array_merge($crud, ['generate'])`, `$crud` = create/view/viewAny/update/delete/restore/forceDelete) and seeded in the tenant (`sys_permissions` exact-name query → 8 rows). Command: `DB::table('sys_permissions')->whereIn('name',$names)->count()` → `8`.
**But** `RequirementConsolidationPolicy` (registered at `TimetableFoundationServiceProvider.php:133`) is never consulted, because every gate passes a permission **string**. Module-wide pattern — see §7.

### F4 — Validation
#### RCC-04 · M · VAL-02 — validation is inline in the controller; there is no FormRequest
**Where:** `:78` (store), `:377`/`:491` (update), `:893` (toggleStatus), `:950` (updatePeriods), `:1009` (updateRequirement), `:1186` (generateRequirements)
**Evidence:** `grep -rln "class .*Request" Modules/TimetableFoundation/app/Http/Requests/ | grep -i requirement` → none.
**Consequence:** the same 15-field rule set is duplicated between `store` and the legacy `update` branch (RCC-11) and can drift; the project rule is a Form Request.

#### RCC-05 · M · VAL-05 — `'is_active' => 'nullable'` validates nothing
**Where:** `:167-169` (store), `:580-582` (update legacy)
```php
'is_active' => [ 'nullable' ],
```
**Evidence:** `nullable` alone casts nothing and accepts any value; the field is later read with `$request->boolean()`.
**Consequence:** a non-boolean payload passes validation silently instead of being rejected as malformed.

#### RCC-06 · H · VAL-07 — the weekly/daily min≤max rule is dead: it reads keys validation never sets
**Where:** `:216-217`, `:228-229`
```php
if (isset($validated['min_periods_required_per_week'], $validated['max_periods_required_per_week']) && ...)
```
**Evidence:** the rules above validate `min_periods_per_week` / `max_periods_per_week` (`:105-115`) and `min_per_day` / `max_per_day` (`:118-128`). The `*_required_*` keys are never produced, so `isset()` is always false.
**Consequence:** a user can save a requirement whose minimum weekly (or daily) periods exceed its maximum; the intended guard never runs.

### F5 — Routes
#### RCC-07 · H · RTE-01 — Restore runs over a GET request
**Where:** `routes/web.php:287`
```php
Route::get('/requirement-consolidation/{id}/restore', [RequirementConsolidationController::class, 'restore'])->name('requirement-consolidation.restore');
```
**Evidence:** `route:list` shows `GET|HEAD …/{id}/restore`. The caller is `<x-backend.table.action-trashed>` (`trash.blade.php:83`), which derives the HTTP verb from the route, so changing the verb needs no blade edit.
**Consequence:** GET has no CSRF protection, so a link prefetch or a crawler can restore a trashed requirement.

*Otherwise clean:* every route points at an existing method; all public methods routed; custom routes do not shadow `Route::resource` (resource is registered first, and no custom one-segment route collides); tenant middleware present (RTE-05 ✅).

### F6 — Controller shape
#### RCC-08 · M · CTL-01 — god controller (DEFERRED split)
**Where:** the class — 1,616 lines, 15 public methods (over 1,000 lines). `scan.php` agrees: `CTL-01 … RequirementConsolidationController: 1588 lines, 15 public methods`.
**Consequence:** hard to review, hard to test; split is a DEFERRED decision (D3, never applied now).

#### RCC-09 · H · CTL-02 — two methods far over the 150-line limit
**Where:** `store:68-295` (228 lines), `update:369-705` (337 lines); also `generateRequirements:1182-1287` (106 → M) and `updateRequirement:1004-1101` (98 → M).
**Evidence:** line deltas; `scan.php` reports "store() is 228 lines", "update() is 337 lines".
**Consequence:** the two most-edited write paths are the hardest to reason about, and `update()` carries a dead twin inside it (RCC-11).

#### RCC-10 · M · CTL-03 — `$id` + `findOrFail` instead of route model binding
**Where:** `show:300`, `edit:324`, `update:369`, `destroy:720`, `forceDelete:788`, `restore:833`, `ajaxInlineUpdate:1112`
**Consequence:** seven methods re-implement lookup and 404 handling; `toggleStatus` already demonstrates the correct binding pattern (`RequirementConsolidation $requirement_consolidation`). Note the route parameter is `{requirement_consolidation}` while the argument is `$id` — it works only because Laravel injects scalar params positionally.

#### RCC-11 · M · CTL-05 / CTL-10 — the legacy `update` branch is dead code and a 224-line copy of `store`
**Where:** `:481-704`
```php
// Original ClassGroupRequirement update (LEGACY — no route registers
// this name anymore; kept for backward compatibility, wrapped for STRICT RULE 1 …)
```
**Evidence:** the branch runs only when the route name is not `…requirement-consolidation.update`. The only registered update route **is** that name, so the branch is unreachable; its validation block duplicates `store:78-170` almost verbatim, and it updates a `$classGroupRequirement` found by `RequirementConsolidation::find($id)` at `:373` — an assignment used nowhere else.
**Consequence:** 224 lines of untested, unreachable logic that reviewers and future editors must keep in their heads.

#### RCC-12 · M · CTL-06 — generation/business logic lives in the controller
**Where:** `processClassSubjectGroups:1294`, `processClassSubjectSubgroups:1343`, `activeSchoolDayCount:1403`, `feasibleMaxPerDay:1432`, `isCompulsoryRequirement:1452`, `mapGroupToRequirement:1461`, `mapSubgroupToRequirement:1542`
**Consequence:** the "what a requirement row should contain" rules (including the deliberate `max_per_day` raise) are welded to the HTTP layer and cannot be reused or unit-tested; `generateRequirements` would be a thin controller over a generator service.

#### RCC-13 · L · CTL-04 — no return types on any of the 15 public methods
**Evidence:** `scan.php` emits `CTL-04` for index, create, store, show, edit, update, destroy, trashed, forceDelete, restore, toggleStatus, updatePeriods, updateRequirement, ajaxInlineUpdate, generateRequirements.

#### RCC-14 · L · CTL-08 — `request()` helper used inside `update`
**Where:** `:375` `if (request()->route()->getName() === '…update')`
**Consequence:** should use the injected `$request` argument.

### F7 — Models
#### RCC-15 · B · MDL-07 (class-missing) — `store()` calls a class that does not exist
**Where:** `:249`, `:271`
```php
$exists = ClassGroupRequirement::where('class_group_id', $validated['class_group_id']) …   // :249
…
$requirement = ClassGroupRequirement::create($validated);                                   // :271
```
**Evidence:**
- `grep -n "ClassGroupRequirement" controller` → only `:249`, `:271`, and a comment at `:481`; there is **no import**, so it resolves to `Modules\TimetableFoundation\Http\Controllers\ClassGroupRequirement`.
- `class_exists('Modules\TimetableFoundation\Http\Controllers\ClassGroupRequirement')` → `false`.
- `class_exists('Modules\SmartTimetable\Models\ClassGroupRequirement')` → `false` (the only other reference, `database/seeders/ClassGroupRequirementSeeder.php`, points at this non-existent class).
- `find . -iname "*ClassGroupRequirement*"` → only the seeder.

**Consequence:** `store()` fatals with "Class not found" before the insert. Line `:249` is **outside** the `try`, so the error is not even caught — a POST to `requirement-consolidation.store` returns a 500.

#### RCC-16 · H · MDL-07 / MDL-04 — two models' relationships point at non-existent classes
**Where:** `ClassRequirementGroup.php:64-94`, `ClassRequirementSubgroup.php:76-116`
```php
// ClassRequirementGroup
return $this->belongsTo(\Modules\SchoolSetup\Models\SchClass::class, 'class_id');            // :67
return $this->belongsTo(\Modules\SchoolSetup\Models\SchSection::class, 'section_id');        // :74
return $this->belongsTo(\Modules\SchoolSetup\Models\SchSubjectStudyFormatJnt::class, …);     // :83
return $this->belongsTo(\Modules\SchoolSetup\Models\SchRoom::class, 'class_house_room_id');  // :91
```
**Evidence:** `class_exists` probe:
```
MISSING Modules\SchoolSetup\Models\SchClass
MISSING Modules\SchoolSetup\Models\SchSection
MISSING Modules\SchoolSetup\Models\SchRoom
MISSING Modules\SchoolSetup\Models\SchSubjectStudyFormatJnt
```
`ClassRequirementSubgroup` repeats the same three (`SchClass`, `SchSection`, `SchRoom`). The working siblings (`ClassSubjectGroup`, `ClassRequirementSubgroup`'s non-`Sch` relations) use `SchoolClass`, `Section`, `Room`, `SubjectStudyFormat`.
**Consequence:** any code that touches `$classRequirementGroup->class`, `…->section`, `…->classHouseRoom` (or the subgroup equivalents) fatals with "Class not found". This controller does not exercise them today, but the models are live in the module.

#### RCC-17 · M · MDL-02 — `ClassRequirementSubgroup` has no cast for `subject_study_format_option_id`
**Where:** `ClassRequirementSubgroup.php:37` (fillable) vs casts `:51-68`
**Consequence:** the option id round-trips as a string and any `===` comparison against an int fails silently.

#### RCC-18 · M · MDL duplicate — `ClassSubjectGroup` and `ClassRequirementGroup` are two models over one table
**Where:** `ClassSubjectGroup.php:21` and `ClassRequirementGroup.php:13` both declare `protected $table = 'tt_class_requirement_groups';`
**Evidence:** the two fillables/casts overlap but their relations diverge (one uses `SchoolClass`/`Section`, the other the non-existent `Sch*` classes of RCC-16).
**Consequence:** two sources of truth for one table; a fix applied to one model silently misses the other. `ClassRequirementGroup` is not referenced by this controller at all.

*Otherwise clean:* every owned model declares `$fillable` (no `$guarded = []`); `SoftDeletes` matches the `deleted_at` columns; no `InteractsWithMedia`; `tt_requirement_consolidations` exists (662 rows); `RequirementConsolidation` casts cover every boolean/date/JSON/integer column.

### F8 — Services/Jobs
#### RCC-19 · M · SVC-02 — the truncator is resolved by service-locator, not injected
**Where:** `:1225`
```php
app(RequirementTableTruncator::class)->truncateFrom('consolidations');
```
**Consequence:** the dependency is invisible to the constructor and harder to swap or mock; constructor injection is the project rule.

*Otherwise clean:* `RequirementTableTruncator` touches no HTTP (`request()`/`session()`/`redirect()` absent), guards against being called inside a transaction (`:131-133`), and rethrows a fixed-message `SnapshotProtectionException` (`:150-157`). No jobs, listeners or events in scope.

### F9 — Queries/Performance
#### RCC-20 · H · QRY-02 / QRY-15 — dropdown loaders pull whole tables
**Where:** `create:48-50`, `edit:342-350`
```php
$classGroupsJnt = ClassSubjectGroup::all();          // :48
$classSubgroups = ClassSubjectSubgroup::all();       // :49
…
$subjectTypes = SubjectType::all(); $roomTypes = RoomType::all();
$academicTerms = AcademicTerm::all(); $timetableTypes = TimetableType::all();
$classes = SchoolClass::orderBy('name')->get(); …    // :342-348
```
**Evidence (tenant, read-only):** `tt_class_requirement_groups` = **539** rows, `tt_class_requirement_subgroups` = **123**. The four `orderBy(...)->get()` calls are unfiltered too. `scan.php` flags five `QRY-02` (48, 49, 345, 346, 347, 349, 350) and four `QRY-15` (342-344, 348).
**Consequence:** the create and edit screens load ~660 + all masters rows on every open, and (for `edit`) without `pluck` — a slow page as the master tables grow. QRY-15 severity M; the two 100+ row `::all()` are H.

#### RCC-21 · M · QRY-01 / VIEW-02 — the trash list lazy-loads six relations per row
**Where:** `trashedRequirementConsolidation:771-773` (no `with()`), `trash.blade.php:22-89`
```php
$classGroupRequirements = RequirementConsolidation::onlyTrashed()->orderByDesc('deleted_at')->paginate(10);
```
The blade touches `classRequirementGroup`, `classRequirementSubgroup`, `academicTerm`, `class`, `section`, `subject` inside the `@forelse`.
**Evidence:** `RequirementConsolidation::onlyTrashed()->count()` → **0** today, so the N+1 is latent; at 10 rows it becomes ~60 extra queries.
**Consequence:** the trash screen degrades as soon as one row is trashed; severity lowered from H to M only because the table is empty today.

*Clean:* no interpolated raw SQL (QRY-11); `generateRequirements` uses bulk `upsert` (QRY-07 ✅); the generation mappers eager-load (`:1297`, `:1346`). Scanner `QRY-01` at `RequirementTableTruncator.php:173` is a false positive — `DB::table($table)->truncate()` in a loop is one statement per listed table and cannot be batched.

### F10 — Views
#### RCC-22 · B · VIEW / RTE — the create screen 500s: its blade calls two route names that do not exist
**Where:** `class-group-requirement/create.blade.php:7` and `:293`
```blade
<form action="{{ route('timetable-foundation.class-group-requirement.store') }}" method="POST">   {{-- :7 --}}
<a href="{{ route('timetable-foundation.class-group-requirement.index') }}" …>                     {{-- :293 --}}
```
**Evidence:**
- `app('router')->getRoutes()->hasNamedRoute('timetable-foundation.class-group-requirement.store')` → `false`; only `…requirement-consolidation.store` exists.
- `route:list --json` filtered for `class-group-requirement` → no `timetable-foundation.*` hits (only `marksheet-generation.*` and `school-setup.*` unrelated).
- The screen is reachable from the UI: `Modules/SmartTimetable/.../class-timetable-type/_list.blade.php:42` renders a `+` button to `route('timetable-foundation.requirement-consolidation.create')`.

**Consequence:** clicking "add requirement" renders `class-group-requirement/create.blade.php`, which throws `RouteNotFoundException` while resolving the form action — a 500 on a button a user can see. The create screen cannot be opened at all.

#### RCC-23 · L · VIEW — three orphan blades
**Where:** `class-group-requirement/edit.blade.php` (196), `index.blade.php` (44), `show.blade.php` (25)
**Evidence:** no controller method renders them (`create` → `class-group-requirement.create`; `edit` → `requirement-consolidation.edit`; `show` → `requirement-consolidation.show`; `trashed` → `class-group-requirement.trash`), and no `@include` references them. `edit.blade.php:7` also calls the non-existent `timetable-foundation.class-group-requirement.update`.
**Consequence:** dead views that invite edits which never appear. Delete or wire them.

*Otherwise clean:* no `Model::`/`DB::`/`->get()`/`->count()` in the in-scope blades (VIEW-01 ✅); no `{!! !!}` anywhere in them (VIEW-03 ✅); `trash.blade.php` uses `x-backend.table.action-trashed` with 4-part permission names that are seeded; the `requirement-consolidation.edit` form posts to the real `…update` route. Breadcrumbs pass `:links="[]"` (empty trail) — minor, noted with RCC-13.

### F11 — Security/Tenancy
#### RCC-24 · M · SEC-03 — hard-coded id fallback `?? 1`
**Where:** `:1527` and `:1605`
```php
'required_room_type_id' => $schClassGroup?->required_room_type_id ?? 1,
```
**Consequence:** a requirement generated without a configured room type silently points at room type id 1 (whatever that tenant calls it), producing a wrong timetable constraint rather than a visible gap.

#### RCC-25 · M · SEC-02 — `updateRequirement` returns the whole model as JSON
**Where:** `:1085`
```php
return response()->json(['success' => true, 'message' => 'Requirement updated successfully', 'data' => $requirement]);
```
**Consequence:** every column of `tt_requirement_consolidations` (including internal ids and flags) is serialised to the browser; map the fields the UI needs.

*Clean:* no `env()` outside config (SEC-01 ✅); no secrets in logs (SEC-04 ✅); tenant middleware present on every route (TEN-05 ✅); no tenant-keyed cache exists to get wrong (TEN-02 n/a).

### F12 — Style
#### RCC-26 · L · STY-01 — no `declare(strict_types=1)`
**Where:** controller, `RequirementConsolidation`, `ClassSubjectGroup`, `ClassRequirementGroup`, `ClassRequirementSubgroup`, `RequirementTableTruncator` (all line 1).

#### RCC-27 · L · STY-04 — emoji in comments
**Where:** controller `:1221, :1411, :1422, :1426`; `RequirementTableTruncator.php:21, :27, :135`.

#### RCC-28 · L · STY-02 — `ClassRequirementGroup.php` is not Pint-clean
**Evidence:** `vendor/bin/pint --test` on the six in-scope files → only `ClassRequirementGroup.php` fails (`fully_qualified_strict_types`). The controller is Pint-clean.

### F13 — Deep read
#### RCC-29 · H · deep read — `forceDelete` accepts a LIVE record and purges it
**Where:** `:793`
```php
$requirement = RequirementConsolidation::withTrashed()->findOrFail($id);
```
**Evidence:** `withTrashed()` matches live rows too, so `DELETE /requirement-consolidation/{id}/force-delete` skips the trash. FK probe: `information_schema.KEY_COLUMN_USAGE` for `REFERENCED_TABLE_NAME = 'tt_requirement_consolidations'` → **no child tables**, so nothing blocks the delete and nothing else is blanked.
**Consequence:** a crafted or stale DELETE permanently destroys an active requirement (and its history) with no child guard, no "must be trashed first" check, and no recovery. Mirrors ATC-03.

#### RCC-30 · M · deep read — a failed regeneration leaves the tab and six later tabs empty
**Where:** `:1219-1225` (TRUNCATE before the transaction), `:1268-1285` (fixed-message catch)
```php
app(RequirementTableTruncator::class)->truncateFrom('consolidations');
DB::transaction(function () { … });
```
**Evidence:** `truncateFrom('consolidations')` truncates `tt_requirement_consolidations` **and every later stage** (teacher availability, activities, timetable cells, slot requirements, priority configs — `RequirementTableTruncator::STAGES`). TRUNCATE is DDL and cannot roll back.
**Consequence:** if any upsert fails after the truncate, all seven tables are empty and the only recovery is "Generate" again on every tab. This is the deliberate D2 truncate-rebuild contract (the flash says the tabs are now empty), so it is reported as an accepted hazard, not a bug — but a user who clicks "Generate" accidentally has no undo.

#### RCC-31 · L · deep read — the upsert's unique key includes a nullable column
**Where:** `generateRequirements` upsert `uniqueBy` (`:1321-1326`, `:1364-1369`) vs the DB index
**Evidence:** `uq_cgr_group_session` = (`academic_term_id`, `timetable_type_id`, `class_requirement_group_id`, `class_requirement_subgroup_id`), all `Null=YES`. MySQL treats NULLs as distinct, and group rows always carry `class_requirement_subgroup_id = NULL` (`mapGroupToRequirement:1470`).
**Consequence:** the `ON DUPLICATE KEY` never fires for group rows, so two groups mapping to the same `class_requirement_group_id` in one run would insert duplicate rows instead of updating. Latent (the table is truncated first).

#### RCC-32 · L · deep read — silent defaults when the form omits a field
**Where:** `updateRequirement:1046-1047`
```php
$requirement->required_weekly_periods = $request->required_weekly_periods ?? 0;
$requirement->class_priority_score   = $request->class_priority_score ?? 50;
```
**Consequence:** a partial AJAX payload resets weekly periods to 0 / priority to 50 rather than leaving them unchanged — the response says "Requirement updated successfully", which is true but not what the caller intended.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Unreachable policy (module-wide).** `RequirementConsolidationPolicy` is registered (`TimetableFoundationServiceProvider.php:133`) but every gate passes a permission **string**, so the policy is never consulted. Same pattern as `AcademicTermPolicy` (ATC-14) and `ActivityPolicy`. Needs a module-level decision.
- **`ClassGroupRequirementSeeder`** (`database/seeders/…) references `Modules\SmartTimetable\Models\ClassGroupRequirement`, which does not exist — same root cause as RCC-15. It is seed data, not this controller's code, but it will fatal if ever run.
- **The snapshot subsystem** (`app/Support/Snapshot/SnapshotWriter.php`, `SnapshotContext`, `SnapshotQueryGrammar`, `SnapshotSchema`, `SnapshotTables`, `SnapshotWriteGuard`) is reached indirectly through `RequirementTableTruncator::truncateFrom()` when the `timetable_cells` stage is included. It is a large shared subsystem, not audited here (§5). Its `SnapshotProtectionException` message is user-safe and is shown verbatim by this controller under D2.
- **`ClassSubjectSubgroup` model** is owned by the [ClassSubjectSubgroupController report](../ClassSubjectSubgroupController-done/01-report.md); this controller uses it in `create()` and `processClassSubjectSubgroups()`. The usage (`with(['schClassGroup','class','section','subject'])`, `where('is_active', true)`) is correct.
- **`OrganizationAcademicSession`, `SchoolClass`, `Section`, `Subject`, `StudyFormat`, `SubjectType`, `Room`, `RoomType`, `SchClassGroupsJnt`** are other-module models, referenced only. Their dropdown `::all()` calls are this report's business (RCC-20); the models themselves are not audited here.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static, a read-only SQL probe, a `class_exists`/`route` probe, or `pint --test`.
- **Snapshot subsystem internals:** see §7 — indirect, shared, outside this controller's direct reach.
- **Other writers of `tt_requirement_consolidations`:** seeders and any sibling controllers were not audited. RCC-30's risk materialises from them.
- **Data repair:** none attempted; the audit is read-only. The 662 live consolidation rows and the 0 trashed rows were read, never changed.
