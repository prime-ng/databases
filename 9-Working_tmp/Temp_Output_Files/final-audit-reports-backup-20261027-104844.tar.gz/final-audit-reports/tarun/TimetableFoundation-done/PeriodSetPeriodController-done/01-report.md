# Final Audit — TimetableFoundation / PeriodSetPeriodController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/PeriodSetPeriodController.php` (471 lines, 11 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 2 blockers, 3 HIGH.**

The write paths run inside `DB::transaction` closures and every routed method authorizes before it loads anything — that part is sound. But the period-set-period trash lifecycle is broken end to end:

- **The model has no `SoftDeletes` trait** while the table has `deleted_at`. `trashedPeriodSetPeriod`, `restore` and `forceDelete` call `onlyTrashed()` and fatal (BadMethodCallException); `destroy()` silently **hard-deletes** the row while flashing "moved to trash".
- Two validation gaps crash saves: an empty **Short Name** (rule says nullable, column is NOT NULL) and a repeated **timeslot** in the same set (the DB's `uq_psp_set_config` unique has no validation mirror) both raise SQL errors → 500.
- Restore still runs over **GET**.

The single worst finding is **PSP-01/PSP-02**: Delete promises a recoverable trash and instead destroys the row permanently, and the trash screen that is supposed to list it 500s. The effort is a day, mostly one design decision (PSP-01) plus three smaller DECISIONs.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 2 | 3 | 13 | 6 | 5 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | PSP-06, PSP-07 | F8 Services/Jobs | clean: no service, job or event (`grep -n "Service\|dispatch\|event("` → none) |
| F2 Transactions/Audit | PSP-10, PSP-11, PSP-12 | F9 Queries/Perf | clean: no query-in-loop; `count()` in SQL (store:107); 20/paginated trash list; dropdowns are small tables (4 sets / ~2 types / ~19 configs live) |
| F3 Authorization | PSP-21 (policy dead) — gates present on all 11 methods | F10 Views | PSP-18 |
| F4 Validation | PSP-04, PSP-05, PSP-08, PSP-09 | F11 Security/Tenancy | clean: no `env()`, no hard-coded ids, no media; all 7 permission keys seeded (7/7, held by Super Admin + School Admin) |
| F5 Routes | PSP-03, PSP-17 | F12 Style | PSP-23 |
| F6 Controller shape | PSP-13, PSP-14, PSP-15, PSP-19, PSP-20, PSP-22 | F13 Deep read | PSP-02 |
| F7 Models | PSP-01, PSP-16, PSP-24 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/PeriodSetPeriodController.php` | controller | 471 | this report | ✅ whole class |
| 2 | `app/Models/PeriodSetPeriod.php` | model | 152 | **this report (pre-assigned — SmartTimetable aliases it)** | ✅ |
| 3 | `routes/web.php` lines 224-229 | routes | — | this report | ✅ |
| 4 | `views/period-set-period/create.blade.php` | page | 125 | this report | ✅ |
| 5 | `views/period-set-period/edit.blade.php` | page | 114 | this report | ✅ |
| 6 | `views/period-set-period/show.blade.php` | page | 118 | this report | ✅ |
| 7 | `views/period-set-period/trash.blade.php` | page | 91 | this report | ✅ — broken, PSP-18 |
| 8 | `views/period-set-period/index.blade.php` | page | 48 | this report | ✅ — orphan, PSP-19 |
| 9 | `app/Policies/PeriodPolicy.php` | policy | 27 | this report | ✅ — unreachable, PSP-21 |
| — | `PeriodSet` model (+ `periodSetPeriods` usage in period-set/edit) | model | — | ↗ [PeriodSetController](TimetableFoundation/PeriodSetController-done/01-report.md) | usage checked |
| — | `PeriodType` model | model | — | ↗ [PeriodTypeController](TimetableFoundation/PeriodTypeController/01-report.md) | usage checked |
| — | `PeriodConfig` model (+ `shift` relation) | model | — | ↗ [PeriodConfigController](TimetableFoundation/PeriodConfigController-done/01-report.md) | usage checked |
| — | `App\Models\BaseModel` | base model | — | common (app/) | referenced only |
| — | `Modules/SmartTimetable/.../PeriodSetPeriod` | alias | — | other module | alias extends the audited model; not re-audited |

**Pre-applied 2026-10-10:** `PeriodSetPeriodController` itself is **not** listed in `../PRE-APPLIED-2026-10-10.md`. The shared `routes/web.php` was touched that day (a dead `add-period-to-organization` route was removed, and the comment at line 231 records it); this audit reviewed the resulting route set fresh.

## 4. Routes

```
GET|HEAD  timetable-foundation/period-set-period                     period-set-period.index        index
POST      timetable-foundation/period-set-period                     period-set-period.store        store
GET|HEAD  timetable-foundation/period-set-period/create              period-set-period.create       create
GET|HEAD  timetable-foundation/period-set-period/trash/view          period-set-period.trashed      trashedPeriodSetPeriod
DELETE    timetable-foundation/period-set-period/{id}/force-delete   period-set-period.forceDelete  forceDelete
GET|HEAD  timetable-foundation/period-set-period/{id}/restore        period-set-period.restore      restore   ← GET
GET|HEAD  timetable-foundation/period-set-period/{period_set_period} period-set-period.show         show
PUT|PATCH timetable-foundation/period-set-period/{period_set_period} period-set-period.update       update
DELETE    timetable-foundation/period-set-period/{period_set_period} period-set-period.destroy      destroy
GET|HEAD  timetable-foundation/period-set-period/{period_set_period}/edit period-set-period.edit    edit
POST      timetable-foundation/period-set-period/{period}/toggle-status period-set-period.toggleStatus toggleStatus
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` (proven on `store`; the file's `Route::resource` sits inside the same group).
Custom routes (trash/view, restore, force-delete, toggle-status) are registered **before** `Route::resource` (`web.php:224-229`), so RTE-06 is satisfied.
**Unrouted public methods:** none — all 11 are routed, all exist (`method_exists` over the route list → 11/11 true). D5 not triggered.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — | PSP-17, 22 |
| create | ✅ | create | — | — | — | PSP-22 |
| store | ✅ | create (first line of try) | ✅ closure | `Stored` (after write, in tx) | tt_period_set_periods_jnt + sys_activity_logs | PSP-04, 05, 06, 07, 08, 09, 12, 13, 15, 23 |
| show | ✅ | view | — | — | — | PSP-14, 22 |
| edit | ✅ | update | — | — | — | PSP-14, 22 |
| update | ✅ | update (first line of try) | ✅ closure | `Updated` (after write, in tx, with diff) | tt_period_set_periods_jnt + sys_activity_logs | PSP-04, 05, 06, 07, 08, 09, 12, 13, 14, 15, 17, 23 |
| destroy | ✅ | delete | ✅ closure | `Trashed` (after delete — **event lies, see PSP-02**) | tt_period_set_periods_jnt (**HARD delete**) + sys_activity_logs | PSP-01, 02, 06, 11, 20 |
| toggleStatus | ✅ | update | ✅ closure | `Toggled` (**BEFORE save** — PSP-10) | tt_period_set_periods_jnt + sys_activity_logs | PSP-06, 10, 11, 20 |
| trashedPeriodSetPeriod | ✅ | viewAny | — | — | — | PSP-01, 18, 19 |
| restore | ✅ GET | restore | ✅ closure | `Restored` (unreachable — crashes first) | (should be) jnt + logs | PSP-01, 03, 06, 11 |
| forceDelete | ✅ | forceDelete | ✅ closure | `Deleted` (unreachable — crashes first) | (should be) jnt + logs | PSP-01, 06, 11 |

**Tables each mutation SHOULD touch:** every mutation writes the period-row table **and** `sys_activity_logs` (via `activityLog()`). store/update/destroy/toggleStatus do exactly that inside one transaction. `trashedPeriodSetPeriod`/`restore`/`forceDelete` should touch the same two tables but cannot — see PSP-01.

## 6. Findings

### F1 — Errors
#### PSP-06 · M · ERR-00 (D1) + ERR-05 — six mutators keep hand-rolled try/catch and log only the message
**Where:** `store:55-165`, `update:200-304`, `destroy:314-340`, `toggleStatus:350-390`, `restore:411-435`, `forceDelete:445-469`
```php
} catch (\Throwable $e) {
    Log::error('PeriodSetPeriodController::store failed', ['error' => $e->getMessage()]);
    return response()->json(['status' => false, 'message' => 'The operation could not be completed.'], 500);
}
```
**Evidence:** `grep -n "catch (\Throwable" $C` → 6 hits (154/296/332/382/427/461 rethrow MNF/Auth/VAL/Http first — that part is correct); `grep -n "getMessage" $C` → 6 message-only logs (159/301/337/387/432/466). D1 (settled) says ERR-00 = the Laravel idiom: no try/catch in controllers.
**Consequence:** the stack trace is lost on every failure (ERR-05), and failures get the method's own generic flash instead of the central handler's response.

#### PSP-07 · M · ERR-04 — error responses ignore the caller's format
**Where:** `store:158-165` (always `response()->json(..., 500)`), `update:293-304` (always `back()`), `destroy:325-329` / `toggleStatus:367-379` / `restore:422-424` / `forceDelete:456-458` (format picked inside the closure)
**Evidence:** `store` alone checks `$request->expectsJson()` for its own error branches (96/111/143) but the generic catch (158-165) returns JSON unconditionally; `update` has **no** `expectsJson()` branch at all (shift-consistency and catch both return `back()`).
**Consequence:** a plain form user whose `store` fails mid-write sees a raw JSON blob instead of a page, and an AJAX caller of `update` whose shift check fires gets an HTML redirect instead of `{success:false}`.

### F2 — Transactions and audit
#### PSP-10 · M · TXN-04 — toggleStatus logs the event before the write it describes
**Where:** `toggleStatus:356-367`
```php
$period->is_active = $request->boolean('is_active');
activityLog($period, 'Toggled', ['message' => 'Period set period status was updated.', 'is_active' => ...]);
if ($period->save()) { ... }
```
**Evidence:** quoted lines read top-to-bottom. `save()` happens at 367, after `activityLog` at 358.
**Consequence:** if `save()` fails, the audit log already records a successful toggle that never happened.

#### PSP-11 · M · TXN-05 — responses are built inside the transaction closures
**Where:** `destroy:325-329`, `toggleStatus:367-379`, `restore:422-424`, `forceDelete:456-458` — e.g. `return redirect()->back()->with(...)` inside `DB::transaction(fn () => ...)`
**Consequence:** flash/session side-effects are written before commit; if the commit then fails the user sees a success toast for a row that is not there. (Same shape as ATC-12.)

#### PSP-12 · M · TXN-06 — the period cap is a count-then-insert without a lock
**Where:** `store:107-115`
```php
$existingCount = PeriodSetPeriod::where('period_set_id', $periodSet->id)->count();
if ($existingCount >= $periodSet->total_periods) { ... return ...; }
// later: create inside DB::transaction (123-141)
```
**Evidence:** the count runs **outside** the transaction; there is no `lockForUpdate` and no DB constraint on the count. All four live sets are at cap today (7/7, 7/7, 9/9, 4/4).
**Consequence:** two concurrent admins can both pass the cap check and push a set beyond `total_periods` — or, when combined with PSP-04/PSP-05, crash on a unique index.

### F3 — Authorization
**Clean (one line):** all 11 routed methods call `Gate::authorize` before loading any record (proven by `ControllerAuthTest` source-parse and by reading the class), permission names are 4-part (`tenant.timetable-foundation.period-set-period.*`), and all 7 are seeded in `sys_permissions` by exact-name query (7/7; held by «Super Admin», «School Admin»).

#### PSP-21 · L · AUTH-06 — PeriodPolicy is registered but never consulted, duplicating every permission string
**Where:** `TimetableFoundationServiceProvider.php:131` (`Gate::policy(PeriodSetPeriod::class, PeriodPolicy::class)`) vs `Gate::authorize('tenant.timetable-foundation.period-set-period.*')` strings in the controller
**Evidence:** every gate passes a permission **string**, so Laravel never invokes the policy. `PeriodPolicy.php` re-declares the same 7 strings.
**Consequence:** the policy is dead code that looks active (module-wide pattern, see §7).

### F4 — Validation and input
#### PSP-04 · H · VAL — the timeslot-per-set unique constraint has no validation mirror
**Where:** `store:58-84` and `update:205-233` validate `code` and `period_ord` uniqueness, but never `period_config_id`; live column set confirmed:
```php
'period_config_id' => ['required', 'exists:tt_period_configs,id'],   // no Rule::unique
```
**Evidence:** `SHOW INDEX FROM tt_period_set_periods_jnt` → `uq_psp_set_config (period_set_id, period_config_id)` UNIQUE; `grep -n "period_config_id'" $C` shows only the `required/exists` rule. Live data: 0 duplicates (guarded client-side in the period-set edit modal only). The standalone create page (`create.blade.php:96-106`) lists **all** configs with no used-filter.
**Consequence:** a user who picks an already-occupied timeslot on the standalone create page passes validation and dies on MySQL 1062 → 500, losing the form.

#### PSP-05 · H · VAL-03 + DDL-drift — an empty Short Name crashes the save
**Where:** `store:72` + `store:129`, `update:220` + `update:263`
```php
'short_name' => ['nullable', 'string', 'max:10'],
...
'short_name' => $validated['short_name'],
```
**Evidence:** `SHOW COLUMNS FROM tt_period_set_periods_jnt` → `short_name varchar(50) | Null=NO | Default=NULL`; `@@sql_mode` includes `STRICT_TRANS_TABLES`. The form field is optional (`create.blade.php:70-74` has no `required`), so `ConvertEmptyStringsToNull` turns a blank box into `null`, which passes `nullable` and hits SQL 1048 → 500. The DDL agrees with NOT NULL (`Timetable_DDL_v7.8.sql:499`).
**Consequence:** leaving Short Name blank on create or edit produces a 500 and the user loses everything they typed.

#### PSP-08 · M · VAL-02 — store/update validate inline instead of a FormRequest
**Where:** `store:58`, `update:205` — `$validated = $request->validate([...])` (toggleStatus's one-line `is_active` rule at 352 is the allowed one-field AJAX exception)
**Consequence:** validation rules live in the controller, so any future check (shift consistency — PSP-13) is hand-written per method instead of living in one FormRequest `after()` hook; the two blocks have already drifted (update lacks the `expectsJson` branch store has).

#### PSP-09 · M · VAL-05 — `is_active => ['sometimes']` validates nothing
**Where:** `store:83`, `update:232`
**Consequence:** the field is untyped; a non-boolean payload is silently coerced by `$request->boolean()` instead of rejected.

### F5 — Routes
#### PSP-03 · H · RTE-01 — Restore runs over GET
**Where:** `routes/web.php:225` — `Route::get('/period-set-period/{id}/restore', ...)`
**Evidence:** uncached `route:list` shows `GET|HEAD …/{id}/restore`.
**Consequence:** GET has no CSRF protection, so a link preview or prefetcher can restore a trashed row (and today, restore 500s before it does anything — PSP-01).

#### PSP-17 · M · RTE/UX — index() and update() redirect to a tab that does not exist
**Where:** `index:32`, `update:293-295` → `tab=period-set-period`
**Evidence:** `timetable-masters.blade.php:4-15` lists ten tab panes (shifts … timetable-types); there is **no** `period-set-period` pane. `grep -n "period-set-period" timetable-masters.blade.php` → nothing. `store` correctly redirects to `tab=period-sets` (152).
**Consequence:** after a successful edit the user lands on an empty masters page with no list and no visible result; the same dead-end follows "Back to List" from `show`.

### F6 — Controller shape
#### PSP-13 · M · VAL-07 + CTL-06 + CTL-05 — shift-consistency business logic duplicated in the controller
**Where:** `store:94-100` vs `update:243-247` (verbatim block, and update's copy already lost the `expectsJson` branch)
```php
if ((int) $periodConfig->shift_id !== (int) $periodSet->shift_id) { ... }
```
**Consequence:** the cross-field check lives in two places that disagree about JSON; it belongs in a FormRequest `after()` hook (and would collapse once PSP-08 is done).

#### PSP-14 · M · CTL-03 — no route model binding on four methods
**Where:** `show:175`, `edit:186`, `update:203`, `destroy:316` — `PeriodSetPeriod::findOrFail($id)` while `toggleStatus:346` uses `PeriodSetPeriod $period`
**Consequence:** half the controller binds the model and half re-queries by scalar `$id`; the untyped `$id` also forces `findOrFail` where a URL-typed model would 404 automatically.

#### PSP-15 · M · CTL-02 — store and update exceed 80 lines
**Where:** `store` 53-166 (114 lines), `update` 198-305 (108 lines)
**Consequence:** the two longest methods are exactly the ones carrying try/catch + inline validation + duplicated business rules; fixing PSP-06/08/13 shrinks them below the line.

#### PSP-19 · L · CTL-10 — dead code: orphan index blade, orphan create page, dead trash UI
**Evidence:**
- `index.blade.php` (48 lines) is never rendered — `index()` redirects; `grep -rn "period-set-period.index\\b"` finds only a `RouteAuthenticationTest` entry and a **SmartTimetable** link (`slot-availability/show.blade.php:107`). The blade itself renders "Day Management" and iterates `$schoolDays` — someone else's resource entirely.
- The standalone `create` route/page is still reachable by URL while the real UI adds periods through the `period-set/edit` modal (`period-set/edit.blade.php:390`), so two create surfaces exist and can drift (same shape as ATC-17).
**Consequence:** dead surfaces remain reachable and can be mistaken for live ones.

#### PSP-20 · L · CTL-08 — `request()` helper instead of the injected `Request`
**Where:** `destroy:325` (`request()->expectsJson()`)
**Consequence:** inconsistent with the rest of the class, which uses the injected `$request` (store/update/toggleStatus).

#### PSP-22 · L · CTL-04 — no return types on any of the 11 public methods
**Where:** whole class (`:28-441`)
**Consequence:** the class cannot be checked for a `TypeError` class of bugs — the exact bug ERR-03 guards against.

### F7 — Models
#### PSP-01 · B · MDL-03 — the model has no `SoftDeletes` while the table has `deleted_at`; the whole trash flow fatals and destroy hard-deletes
**Where:** `PeriodSetPeriod.php:10` (`class PeriodSetPeriod extends BaseModel`, no `use SoftDeletes`), `BaseModel.php:11` adds no traits; callers `trashedPeriodSetPeriod:400`, `restore:413`, `forceDelete:447` (`PeriodSetPeriod::onlyTrashed()…`), `destroy:317` (`$psp->delete()`)
**Evidence (tinker, tenant):**
```
traits:
method_exists onlyTrashed: false
method_exists restore: false
```
`SHOW COLUMNS` → `deleted_at timestamp Null=YES` exists. `destroy:317` therefore issues a hard `DELETE`, and the three `onlyTrashed()` routes throw `BadMethodCallException` → `trashedPeriodSetPeriod` (no catch) = 500 page; `restore`/`forceDelete` fall into `catch (\Throwable)` = "could not be completed" flash.
**Consequence:** the trash feature is fiction — Delete permanently destroys the row while telling the user it was "moved to trash", and the trash/restore screens can never work.

#### PSP-16 · M · MDL-08 — the global `ordered` scope runs three correlated subqueries on every query
**Where:** `PeriodSetPeriod.php:61-73`
```php
->orderByRaw("(SELECT shift_id FROM {$cfgTable} WHERE id = {$jntTable}.period_config_id) ASC")
->orderByRaw("(SELECT display_order FROM {$cfgTable} WHERE id = {$jntTable}.period_config_id) ASC")
->orderByRaw("(SELECT slot_ord FROM {$cfgTable} WHERE id = {$jntTable}.period_config_id) ASC")
```
**Evidence:** scanner flags QRY-11 at 67-69 — confirmed **not** user-input interpolation (both variables are hard-coded local strings), so QRY-11 does **not** apply; the defect is the cost: three correlated subqueries run on every read of the model, including counts.
**Consequence:** every `PeriodSetPeriod` read pays three per-row lookups; on a large set this is a real-perf trap on list screens.

#### PSP-24 · L · MDL-06 — code normalisation lives in the controller, not a mutator
**Where:** `store:128`, `update:262` — `'code' => strtoupper($validated['code'])`
**Consequence:** any other writer of the table (import, seeder, SmartTimetable alias) can store mixed-case codes; the rule should live on the model.

### F8 — Services and jobs
**Clean —** the controller instantiates no service, dispatches no job/event (`grep -nE "new .*Service|dispatch\\(|event\\(" $C` → none).

### F9 — Queries and performance
**Clean —** `count()` answered in SQL (store:107); trash list paginates (20/item, trashedPeriodSetPeriod:400); `show` eager-loads `periodSet`+`periodType` (175); create/edit dropdowns hit the 4 registered sets / 2 period types / ~19 configs (measured), so QRY-15 is not a real cost here. The one perf item is PSP-16 (model scope).

### F10 — Views
#### PSP-18 · L · VIEW — the trash blade is a copy-paste of the PeriodSet trash screen
**Where:** `trash.blade.php:22` (`$periodSets`), `:62-65` (`url="timetable-foundation.period-set"` + `period-set.restore/forceDelete` permissions)
**Evidence:** the controller renders `view('timetablefoundation::period-set-period.trash', compact('trashedPeriods'))` (400-401); the blade iterates `$periodSets`, a variable that is never passed — so the page fatals before the wrong URL/permissions ever matter.
**Consequence:** even if PSP-01 restored the model's soft-delete, the trash screen would still crash and would render/mangle the wrong resource's rows.

**Clean checks (one line each):** all five in-scope blades compile (`Blade::compileString` + `php -l` → no errors); no `{!! !!}` on user text; no queries inside `@foreach` beyond eager-loaded relations (`periodConfigs` loads `shift`, show loads `periodSet`/`periodType`); create/edit use components (`status-switch`, `breadcrum`) with no permission prop needed for a form surface.

### F11 — Security and tenancy
**Clean —** no `env()` anywhere in class/model; no hard-coded ids or `?? 1`; request bodies are never logged (ERR-05 logs exception messages only — that defect is PSP-06); no media; all routes inside the tenancy middleware chain; central tenant access verified through the initialized tenant connection.

### F12 — Style
#### PSP-23 · L · STY — strict_types, import spacing, docblocks
**Evidence:** `grep -c "strict_types" $C` → 0; imports `:5-9` have stray blank lines between `use` statements (Pint-unclean); the stub docblocks `"Display a listing of the resource."` / `"Display the specified resource."` are copy-paste defaults (STY-04).
**Consequence:** cosmetic only.

### F13 — Deep read
#### PSP-02 · B · deep read — destroy permanently deletes while the app promises a trash
**Where:** `destroy:317` `$psp->delete()`; `destroy:319-323` logs `Trashed` / `"was deactivated and moved to trash"`; `destroy:329` flashes `"Period removed from set."`
**Evidence:** no `SoftDeletes` (PSP-01) → `delete()` = `DELETE FROM tt_period_set_periods_jnt`. `SHOW INDEX`/`information_schema` → the table has **no FK children** (probe returned none), so the hard delete always succeeds. Live data: 27 rows, 0 with `deleted_at`.
**Consequence:** every "Delete" is irreversible data loss sold as reversible trash — the worst thing a school admin can do from this screen. Once PSP-01 is fixed this finding becomes moot or the message must be made honest (see plan).

---

**Other deep-read answers (checked, not present):**
1. Wrong-data overwrite: `update` builds a diff from `getOriginal()` and logs `old/new` pairs — clean. 2. Irreversible order: no delete-before-replace. 3. Duplicate implementations: shift-check duplicated (PSP-13), two create surfaces (PSP-19). 4. Soft-delete × unique trap: **latent** — validation uses `whereNull('deleted_at')` (store:67-69, update:214-217) against plain UNIQUE indexes; with no `SoftDeletes` there are no trashed rows today, but adding the trait (PSP-01 option a) re-arms the 1062 trap (module-wide BUG-003 pattern). 5. Races: PSP-12. 6. Auth holes: none — every method gates. 7. Messages that lie: PSP-02 ("moved to trash" on a hard delete). 8. Dead features: the trash lifecycle (PSP-01/19).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Unreachable policies (module-wide):** every `Gate::policy(...)` in `TimetableFoundationServiceProvider.php:122-131` passes ability *strings* in the controllers, so all module policies (incl. `PeriodPolicy`) are dead code. Same pattern as ATC-14; needs the module-level decision already flagged for the module batch.
- **`tt_period_set_periods_jnt` unique indexes are not soft-delete aware** (`uq_psp_set_ord/code/config`). If PSP-01 chooses to add `SoftDeletes`, a trashed row blocks its own re-creation (1062). The validator's `whereNull('deleted_at')` mirrors nothing in the DB — an instance of the module-wide BUG-003 trap.
- **`PeriodSet::periodSetPeriods` in `period-set/edit.blade.php`** (the real UI) is owned by PeriodSetController's report; its membership matrix already client-filters `$usedPeriodConfigIds`, which is the only thing holding PSP-04's duplicate off today.
- **SmartTimetable** links `period-set-period.index` (`slot-availability/show.blade.php:107`) and **aliases** `Modules\SmartTimetable\Models\PeriodSetPeriod` onto the audited model (`SmartTimetable/app/Models/PeriodSetPeriod.php:9`). Both now inherit PSP-17 / PSP-01.
- **Tests (D4):** `RouteAuthenticationTest:89-132` lists the resource routes; `ControllerAuthTest:89` treats the controller as fully authorized (true today). No plan change affects them unless the trash routes are aborted (PSP-01 decision note). `ModelStructureTest` does **not** assert `SoftDeletes`, so it would not have caught PSP-01.

## 8. Not covered, and why

- **Runtime behaviour:** no browser/test run (D4). Every finding is static or a read-only SQL/tinker probe.
- **Other writers of `tt_period_set_periods_jnt`:** `PeriodSetController::update`'s membership matrix (owned report) is the main one; seeders/importers were not audited here.
- **Live data repair:** 27 rows, 4/4 sets at cap, 0 trashed. Nothing to repair; no data changed.
- **The SmartTimetable alias model** (Phase-6 cleanup file) — noted, not audited.