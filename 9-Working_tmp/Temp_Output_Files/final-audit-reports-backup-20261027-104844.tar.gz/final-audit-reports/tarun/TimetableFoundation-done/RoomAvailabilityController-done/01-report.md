# Final Audit — TimetableFoundation / RoomAvailabilityController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/RoomAvailabilityController.php` (115 lines, 2 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 1 HIGH, 6 MEDIUM, 2 LOW.**

The `generate()` write path is sound after today's pre-applied pass: one transaction covers the service write plus its audit entry, and it is exactly the D1 shape. The problems sit in the second method and in the service:

- **RAV-04 (H) is the worst finding.** `generateRoomAvailabilityRatio()` is a second, older implementation of the room supply/demand arithmetic that the module **replaced on 2026-09-01** — it divides by the *row count* of `tt_slot_requirements` (43) and falls back to `365 × 8 = 2,920` using a *calendar* table, and it stamps `overall_availability_status` with the pre-2026-09-01 reading. The sibling `ResourceRatioService` and the ratio blade both document these exact two wrongs. When a school runs Generate and then Generate Ratio, the Room Availability tab shows verdicts that contradict the Ratio tab's own bands.
- **RAV-06 (M)** — two public service methods query columns that do not exist (`available_for_full_timetable`, `room_type_id` instead of `available_for_full_timetable_duration`, `rooms_type_id`). No production caller exists today; the moment one is wired, it is a guaranteed SQL 500.
- The effort is about half a day. Three DECISION items need your choice first (RAV-04, RAV-02, RAV-05).

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 1 | 6 | 2 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | RAV-01 | F8 Services/Jobs | RAV-06, RAV-04 (SVC-04) |
| F2 Transactions/Audit | RAV-02 | F9 Queries/Perf | RAV-07 |
| F3 Authorization | RAV-03 | F10 Views | — (none rendered; see §7) |
| F4 Validation | clean — no form input consumed; `$request` unused | F11 Security/Tenancy | RAV-08 (SEC-03); no `env()`, no secrets, no JSON exposure |
| F5 Routes | clean — 2 POSTs, both exist, tenant middleware | F12 Style | RAV-09 |
| F6 Controller shape | RAV-04 (CTL-06, business logic in controller), RAV-09 | F13 Deep read | RAV-04 (duplicate impls that disagree, Q8), RAV-05 |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/RoomAvailabilityController.php` | controller | 115 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Models/RoomAvailability.php` | model | 135 | **this report (pre-assigned)** | ✅ |
| 3 | `Modules/TimetableFoundation/app/Models/RoomAvailabilityDetail.php` | model | 129 | **this report (pre-assigned)** | ✅ |
| 4 | `Modules/TimetableFoundation/app/Services/RoomAvailabilityService.php` | service | 145 | **this report (pre-assigned)** | ✅ |
| 5 | `Modules/TimetableFoundation/routes/web.php` lines 272-273 | routes | — | this report | ✅ |
| 6 | `Modules/TimetableFoundation/app/Models/SlotRequirement.php` | model | — | [SlotRequirementController](TimetableFoundation/SlotRequirementController-done/01-report.md) | ↗ linked — usage (row count as "periods per week") is RAV-04 |
| 7 | `Modules/TimetableFoundation/app/Models/WorkingDay.php` | model | — | [WorkingDayController](TimetableFoundation/WorkingDayController-done/01-report.md) | ↗ linked — usage (calendar-day count × 8) is RAV-04 |
| 8 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | — | [ActivityController](TimetableFoundation/ActivityController-done/01-report.md) | ↗ linked — usage checked: `required_room_type_id`, `required_weekly_periods` exist; 599 active demand rows |
| 9 | `Modules/TimetableFoundation/app/Services/ResourceRatioService.php` | service | 810 | [TimetableFoundationController](TimetableFoundation/TimetableFoundationController/01-report.md) (CLAIMED, in progress) | ↗ linked — the implementation RAV-04 duplicates and contradicts |
| 10 | `Modules/SchoolSetup/.../Room.php`, `RoomType.php`, `Section.php`, `SchoolClass.php`, `StudyFormat.php` | common (other module) | — | common | referenced only (FKs, relations); §7 |
| 11 | `views/.../resource-availability/room-availability/_list.blade.php`, `room-availability-ratio/_list.blade.php` | views | — | [TimetableFoundationController](TimetableFoundation/TimetableFoundationController/01-report.md) (CLAIMED) | ↗ linked — rendered by that controller; they only POST to this controller |
| 12 | `config/permissionslist.php` line 694 | config (common) | — | common | referenced — key declared **and seeded** (exact-name probe) |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md`. In that pass, `generate()` lost its try/catch, kept `$count = DB::transaction(...)`, and gained the ERR-00 comment; Pint was applied. This audit reviewed the result fresh and confirms the change is **complete** — `generate()` has no try/catch, wraps service + audit entry in one closure, and builds the redirect after commit. Nothing to redo (see PER-METHOD table).

## 4. Routes

```
POST  timetable-foundation/room-availability/generate-ratio   timetable-foundation.room-availability.generateRatio   generateRoomAvailabilityRatio
POST  timetable-foundation/room-availability/generate         timetable-foundation.room-availability.generate        generate
```

Middleware on both: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.

**Unrouted public methods:** none — both public methods are routed (D5 not needed).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| generate | ✅ POST | `.generate` | ✅ closure in controller `:31` (service opens none) | `RoomAvailabilityGenerated` — inside tx, after write | tt_room_availabilities, sys_activity_logs | RAV-02 (race), RAV-06 (service, latent) |
| generateRoomAvailabilityRatio | ✅ POST | `.generate` (inside try) | ✅ closure `:77` | `RoomAvailabilityRatioComputed` — inside tx, after write | tt_room_availabilities, sys_activity_logs | RAV-01, RAV-03, RAV-04, RAV-07, RAV-08 |

**Tables each mutation SHOULD touch:**
- **generate** should create one row per active room (72 on this tenant) plus the audit row. It does both, in one transaction.
- **generateRatio** should update `overall_availability_status` on every active availability row (currently 0 on this tenant — the table is empty until generate runs) plus the audit row. It does both, in one transaction. The *values* it writes are wrong (RAV-04).

## 6. Findings

### F13 — Deep read
#### RAV-04 · H · SVC-04 / CTL-06 — the ratio method reimplements arithmetic the module replaced and stamps the wrong reading onto the status column
**Where:** `RoomAvailabilityController.php:54-58, 78-93` (vs `ResourceRatioService.php` docblock lines 73-82, and the ratio blade rewrite comment `_list.blade.php:11-19`)
```php
$totalPeriodsPerWeek = SlotRequirement::where('is_active', true)->count();
if ($totalPeriodsPerWeek === 0) {
    $wDays = WorkingDay::where('is_active', true)->count();
    $totalPeriodsPerWeek = max(1, $wDays * 8);
}
...
RoomAvailability::where('is_active', true)->get()->each(function ($ra) use (...) {
    $typeId = $ra->rooms_type_id;
    $activeRooms = $countByType[$typeId] ?? 1;
    ...
    $ratio = $demand > 0 ? round($supply / $demand, 2) : 1.00;
    $status = match (true) {
        $ratio >= 1.2 => 'Available',
        $ratio >= 1.0 => 'Partially Available',
        default       => 'Unavailable',
    };
    $ra->update(['overall_availability_status' => $status]);
```
**Evidence:**
- Tenant probe: `tt_slot_requirements` has 43 active rows and `weekly_total_slots` between 31-48; `tt_working_days` has **365** rows (one row per date — a calendar). So `count()` = 43 is used as "periods per week", and the fallback is `365 × 8 = 2,920`.
- `ResourceRatioService.php:73-82` (owned by the TimetableFoundationController report): *"TWO ARITHMETIC BUGS THIS REPLACES, both measured on the live tenant 2026-09-01: 1. `$totalPeriodsPerWeek = SlotRequirement::where('is_active', true)->count()` … That is the ROW COUNT … 2. Its fallback, `WorkingDay::where('is_active')->count() * 8`, returned 365 * 8 = 2,920. `tt_working_days` is a CALENDAR … ~60x the real figure."*
- The blade the button lives in repeats the same warning (`room-availability-ratio/_list.blade.php:11-19`).
- `overall_availability_status` is **displayed** on the Room Availability tab (`room-availability/_list.blade.php:125,163`), so the value is user-visible.
- The controller's reading is the pre-2026-09-01 one (≥ 1.0 green/"Available"); `ResourceRatioService` since 2026-09-01 reads a room ratio **below** 1 as OVER CAPACITY (a blocker) and above 1 as under-used (see `isOver()` and `roomBand()`).

**Consequence:** after a school runs Generate then Generate Ratio, every room's Overall Status on the Room Availability tab is computed from the row-count/calendar arithmetic the module already proved wrong and contradicts the Ratio tab's own verdicts on the same rows.

#### RAV-05 · M · MDL / deep-read — the detail model's table has `deleted_at` but the model cannot see it
**Where:** `RoomAvailabilityDetail.php:14-16` · migration `2026_06_16_152643 ...:23`
```php
class RoomAvailabilityDetail extends BaseModel
{
    public $timestamps = false;
```
**Evidence:**
- `SHOW COLUMNS FROM tt_room_availability_details` → `deleted_at timestamp YES NULL`.
- `class_uses(RoomAvailabilityDetail::class)` → does **not** contain `SoftDeletes` (probe output: `useSoftDeletes=NO`).
- The sibling model `RoomAvailability` does use it; the DDL/migration pair declares `softDeletes()`.

**Consequence:** any future soft-delete write to this table silently stays visible to every query (`TimetableFoundationController:2307` builds its room-slot matrix from it), and `RoomAvailability::details()` would include trashed rows — the schema promises soft deletes the model cannot apply. ⚠ The live writer, SmartTimetable's `AvailabilityCanvasService`, deliberately hard-deletes rows to rebuild; this fix therefore needs a decision, not a blind trait add.

### F8 — Services
#### RAV-06 · M · MDL/SVC (latent, becomes H when wired) — `updateEligibleRoomCount()` queries two columns that do not exist
**Where:** `RoomAvailabilityService.php:90, 94`
```php
$query = RoomAvailability::where('is_active', true)
    ->where('available_for_full_timetable', true);
...
$query->where('room_type_id', $activity->required_room_type_id);
```
**Evidence:**
- `SHOW COLUMNS FROM tt_room_availabilities` → the real columns are `available_for_full_timetable_duration` and `rooms_type_id`; there is no `available_for_full_timetable` and no `room_type_id`.
- A `where()` on either is SQLSTATE 42S22 the moment the method executes.
- Caller probe: `grep -rn "updateEligibleRoomCount" Modules app | grep -v tests` → **no production callers**; only reflection tests in `ServiceTest.php` reference the method names. The service docblock says it is "Called during Phase 3.2 — before activity creation and scoring", so a generator is expected to call it.
- Downstream consumer already reads the field it would write: `SmartTimetable/ActivityScoreService.php:72` uses `$activity->eligible_room_count ?? 1`.

**Consequence:** today nothing crashes because nothing calls it, but `eligible_room_count` on every activity stays NULL and the scoring service silently assumes **1 eligible room** per activity; the first caller that appears gets a guaranteed 500.

### F1 — Errors
#### RAV-01 · M · ERR-00 (D1) + ERR-05 — `generateRoomAvailabilityRatio` still catches and logs only the message
**Where:** `RoomAvailabilityController.php:50, 107-113`
```php
try {
    Gate::authorize('tenant.timetable-foundation.room-availability.generate');
    ...
} catch (AuthorizationException|ValidationException|HttpExceptionInterface $e) {
    throw $e;   // 403 / 422 / abort() must not become a generic 500
} catch (\Throwable $e) {
    Log::error('RoomAvailabilityController::generateRoomAvailabilityRatio failed', ['error' => $e->getMessage()]);
    return back()->with('error', 'The operation could not be completed.');
}
```
**Evidence:** `scan.php` → `ERR-05 M L110 logs getMessage() without the exception/trace`. `grep -n 'catch'` shows the only try/catch in the file is here; `generate()` has none. This catch is not a D2 shape (not a `\DomainException` rule, not a truncate-then-rebuild, not `SnapshotProtectionException`).
**Consequence:** the codebase keeps two error models in one 115-line file, the stack trace is lost (only `getMessage()` is logged), and a failure produces a generic flash where the central handler's response (JSON for AJAX) is the D1 answer. Note the reserved catch is correct ERR-02 shape — the 403/422 survive; that part is fine.

### F2 — Transactions / Audit
#### RAV-02 · M · TXN-06 (lowered from H: needs a concurrent double-submit) — `updateOrCreate` on `room_id` has no unique backstop
**Where:** `RoomAvailabilityService.php:49-50` inside the controller's transaction (`RoomAvailabilityController.php:31`)
```php
RoomAvailability::updateOrCreate(
    ['room_id' => $room->id],
    [...]
```
**Evidence:** `SHOW INDEX FROM tt_room_availabilities WHERE Non_unique=0` → only `PRIMARY (id)` and `uq_ra_class_wise (room_id, rooms_type_id, class_id, section_id, subject_study_format_id)`. The service writes NULL for `class_id`/`section_id`/`subject_study_format_id`, and MySQL treats NULLs as distinct — so no unique constraint can stop two concurrent GENERATE posts both inserting a row for the same room (check-then-act with no lock).
**Consequence:** a double-click / retried POST can create duplicate rows for one room, and the ratio computation then silently counts that room twice.

### F3 — Authorization
#### RAV-03 · L · AUTH-02 (lowered from H: nothing precedes the gate) — the gate sits inside the try
**Where:** `RoomAvailabilityController.php:52`
**Evidence:** scan `AUTH-02 M L52 Gate::authorize inside try`. The first catch rethrows `AuthorizationException`, so no 403 leaks; no record is loaded before the gate, so no id-existence leak either.
**Consequence:** purely placement/style; removed automatically by RAV-01.

### F9 — Queries / Performance
#### RAV-07 · M · QRY-07 — one UPDATE per room in a loop
**Where:** `RoomAvailabilityController.php:78-95`
```php
RoomAvailability::where('is_active', true)->get()->each(function ($ra) ... {
    ...
    $ra->update(['overall_availability_status' => $status]);
```
**Evidence:** `scan.php` → `QRY-07 M L93 ->update() per row inside a loop`. The whole table is loaded (`->get()`) and then updated row-by-row inside a transaction.
**Consequence:** at today's 72 rooms it is merely wasteful; on a school with hundreds of room rows the ratio recompute issues one write per room instead of three grouped `whereIn()->update()` calls.

### F11 — Security / Tenancy
#### RAV-08 · M · SEC-03 — hard-coded `?? 1` fallback for room supply
**Where:** `RoomAvailabilityController.php:80`
```php
$activeRooms = $countByType[$typeId] ?? 1;
```
**Evidence:** `scan.php` → `SEC-03 M L80 hard-coded id fallback: $countByType[$typeId] ?? 1`. A room type with **zero** assignable rooms is credited with 1 room's weekly supply.
**Consequence:** a type with no assignable rooms can still be marked "Available" / "Partially Available" instead of "Unavailable".

### F12 — Style
#### RAV-09 · L · STY / CTL-04 — style across the four files
- **Controller:** no `declare(strict_types=1)` (STY-01); `generate()` and `generateRoomAvailabilityRatio()` have no return type (CTL-04); `$request` is injected but never used in `generateRoomAvailabilityRatio`.
- **Service:** no `declare(strict_types=1)`; `\Log::info(...)` uses the global alias instead of the imported convention (STY-06).
- **RoomAvailabilityDetail:** no `declare(strict_types=1)`; scopes `scopeActive`/`scopeAvailable` have no return type.
- **RoomAvailability:** `roomType()` comment says "references sch_room_type — verify model class name in SchoolSetup" — the class is `Modules\SchoolSetup\Models\RoomType` and its table is `sch_rooms_type`; the comment is stale (STY-04).
Evidence: `scan.php` rows + read. All four files are otherwise Pint-clean (`grep` shows no stray formatting; pre-applied pass ran Pint on the controller).

**Clean checks (one line each):**
- F2: both mutations run in ONE `DB::transaction` closure; `activityLog()` sits inside it **after** the write; the redirect/flash is built after the closure (TXN-04/TXN-05 clean).
- F3: both methods authorize **before** loading anything; both `.generate` and `.export`/CRUD keys are declared **and seeded** with exact-name probes (`sys_permissions` id 1572; grants: Super Admin + School Admin).
- F4: no controller-side validation needed — neither method reads a form field; no `$request->all()` anywhere.
- F5: no state change over GET; no missing methods; no resource routes to shadow; tenant middleware present (probe §4).
- F6: 115 lines / 2 methods (CTL-01 clean); no debug leftovers (`grep dd|dump|var_dump|print_r|ray` → none); no commented-out code.
- F7: both models declare `$fillable` (no `$guarded`); `RoomAvailability` casts every boolean/date/id and uses `SoftDeletes` matching its `deleted_at`; `$table` names exist in tenant migrations (MDL-01/02/07 clean).
- F9: no query inside a loop in the controller reads (the demand/type aggregates are pre-fetched with `pluck` before the loop); only the writes are per-row (RAV-07).
- F10: this controller renders no views — nothing to leak; the two blades that POST to it are owned by the TimetableFoundationController report.
- F11: no `env()`, no JSON of personal data, no logging of request bodies, keys carry no tenant id but no cache is used (TEN clean).
- QRY-11: the two `DB::raw()` uses are constant strings, no interpolation — safe.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`overall_availability_status` is displayed by the Room Availability tab**, which `TimetableFoundationController` renders. That report (CLAIMED, in progress) owns the blade; the consequence of RAV-04 is visible there, but the writer is this controller.
- **`ResourceRatioService`** is the sanctioned single implementation of this arithmetic, owned by the TimetableFoundationController report. RAV-04's fix should delegate to it or mirror its weekly-supply numbers; the two must never disagree again.
- **`AvailabilityCanvasService` (SmartTimetable)** is the live writer of `tt_room_availability_details` and hard-deletes rows to rebuild. Any SoftDeletes change (RAV-05) interacts with it — hence the DECISION.
- **`ActivityScoreService` (SmartTimetable)** reads `eligible_room_count` with a `?? 1` fallback; because the only writer (RAV-06) is broken, every activity is currently scored as having 1 eligible room.
- **`ControllerAuthTest`** has a test *"no controller references tenant.timetable* prefix"* that matches `Gate::authorize('tenant.timetable-foundation…')` — which this and ~30 sibling controllers use — so that test is already inconsistent module-wide. Not this report's business to fix; team to verify (D4).
- **Permission key choice:** both methods share `…room-availability.generate`. A distinct `.generateRatio` ability would be a new key (DECISION territory); the shared key is acceptable and seeded.

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe; the two mutating methods were never executed.
- **Writes on the reference tenant:** `tt_room_availabilities` currently holds **0 rows**; the consequences of `generate()` / `generateRatio()` are reasoned from schema + counts, not observed.
- **`ResourceRatioService` and the resource-availability page** are audited by the TimetableFoundationController report (linked, in progress). Only its *interaction* with this controller is assessed here.
- **SmartTimetable's `AvailabilityCanvasService` and `ActivityScoreService`** (other module) are referenced for consequence only.
- **Data repair:** no existing rows were changed; nothing to repair at audit time (table empty).