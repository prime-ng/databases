# Final Audit — TimetableFoundation / ClassSubjectSubgroupController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/ClassSubjectSubgroupController.php` (790 lines, 14 public methods, 10 private methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 1 BLOCKER, 7 HIGH.**

The controller is the front door of the class-subgroup screen, but **it does not work at all**. Every
CRUD method loads `Modules\SmartTimetable\Models\ClassSubgroup` and `…\ClassGroupJnt`, and **neither
class exists**, in any namespace, with no autoload entry and no table. `create`, `store`, `show`,
`edit`, `update` and `getSubgroupStats` therefore fatal (`Error: Class … not found`) on the first
call. The store path fatals even earlier, at validation, because it builds its `in:` rule from
`ClassSubgroup::SUBGROUP_TYPES`, a constant that exists nowhere (CSG-14).

The pre-applied 2026-10-10 rewrite of `store()` is correct in shape (one `DB::transaction`, log after
the writes, `?? null` for optional fields) — but it cannot succeed: it writes to that missing model,
and the fields it writes (`description`, `subgroup_type`, `min_students`, `max_students`) do not exist
on the only subgroups table that does exist, `tt_class_requirement_subgroups` (CSG-27).

The whole controller also mixes two unrelated resources — CRUD on the (missing) `ClassSubgroup`,
AJAX and the member FK on `ClassSubjectSubgroup` — which is the decision the fix must settle first
(CSG-14 / CSG-27).

A second, independent blocker-class defect sits in `ClassModeRule`: its table `tt_class_mode_rules`
exists in neither the tenant nor the central DB, and no migration creates it (CSG-15).

Rough effort: this is a rebuild decision, not a tidy-up — about two days once you choose which model
is canonical. Seven DECISION items need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 1 | 7 | 16 | 4 | 7 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CSG-01..04 | F8 Services/Jobs | clean — no service, job, event or listener named (`grep -oE '[A-Z][A-Za-z]+(Service\|Job\|Event\|Mail\|Notification)' $C` → none) |
| F2 Transactions/Audit | CSG-05 | F9 Queries/Perf | CSG-18..21 |
| F3 Authorization | CSG-06 | F10 Views | CSG-22..25 |
| F4 Validation | CSG-07, CSG-08 | F11 Security/Tenancy | clean — no `env()`, tenant middleware present on all 10 routes, no personal JSON |
| F5 Routes | CSG-09, CSG-10 | F12 Style | CSG-26 |
| F6 Controller shape | CSG-11..13 | F13 Deep read | CSG-27, CSG-28 |
| F7 Models | CSG-14..17 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/ClassSubjectSubgroupController.php` | controller | 790 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Models/ClassSubjectSubgroup.php` | model | 232 | **this report (pre-assigned)** | ✅ |
| 3 | `Modules/TimetableFoundation/app/Models/ClassSubgroupMember.php` | model | 108 | **this report (pre-assigned)** | ✅ |
| 4 | `Modules/TimetableFoundation/app/Models/ClassModeRule.php` | model | 144 | **this report (pre-assigned)** | ✅ — not reached by this controller; audited because pre-assigned |
| 5 | `Modules/TimetableFoundation/app/Policies/ClassSubgroupPolicy.php` | policy | 46 | this report | ✅ — unreachable, CSG-06 |
| 6 | `Modules/TimetableFoundation/routes/web.php` lines 276-283 | routes | — | this report | ✅ |
| 7 | `resources/views/class-subgroup/create.blade.php` | page | 345 | this report | ✅ |
| 8 | `resources/views/class-subgroup/edit.blade.php` | page | 342 | this report | ✅ |
| 9 | `resources/views/class-subgroup/show.blade.php` | page | 470 | this report | ✅ |
| 10 | `resources/views/class-subgroup/index.blade.php` | page (orphan) | 47 | this report | ✅ — CSG-25 |
| 11 | `resources/views/class-subgroup/trash.blade.php` | page (orphan) | 105 | this report | ✅ — CSG-25 |
| 12 | `resources/views/class-subgroup/_partials/_scripts.blade.php` | partial | 329 | this report | ✅ |
| 13 | `resources/views/class-subgroup/_partials/_styles.blade.php` | partial | 24 | this report | ✅ |
| 14 | `Modules\SmartTimetable\Models\ClassSubgroup` | model class | — | ❌ **does not exist** | ❌ no file, no autoload entry — CSG-14 |
| 15 | `Modules\SmartTimetable\Models\ClassGroupJnt` | model class | — | ❌ **does not exist** | ❌ no file, no autoload entry — CSG-14 |
| — | `Modules/TimetableFoundation/Models/Config.php` | shared model | — | [ConfigController](../ConfigController/01-report.md) | ↗ linked — `Config::get()` usage only |
| — | `SchoolSetup\Models\SchoolClass`, `Section`, `ClassSection` | other-module models | — | common (other module) | referenced only |
| — | `SchoolSetup\Models\SchClassGroupsJnt` | other-module model | — | common (other module) | referenced only (ClassSubjectSubgroup `schClassGroup`) |
| — | `x-backend.layouts.app`, `x-backend.components.breadcrum`, `x-backend.table.action`, `status-switch`, `action-trashed` | shared components | — | common | props checked only |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md`. That pass
rewrote `store()` as `DB::transaction` returning the subgroup then redirecting to
`timetable-foundation.class-subgroup.show`; read optional fields with `?? null`; and turned
`generateClassSubgroups()` into `abort(403)` under a `// NOT ROUTED` comment. **Fresh finding:** the
`store()` rewrite is structurally correct but still cannot run (CSG-14, CSG-27), and the redirect
target is a real route. `generateClassSubgroups()` is confirmed on disk at lines 363-372, and its 9
private helpers are confirmed orphaned (CSG-12).

## 4. Routes

```
GET|HEAD  timetable-foundation/class-subject-subgroup                            timetable-foundation.class-subgroup.index             index
POST      timetable-foundation/class-subject-subgroup                            timetable-foundation.class-subgroup.store             store
POST      timetable-foundation/class-subject-subgroup/ajax/save-share-targets/{id} timetable-foundation.class-subgroup.ajaxSaveShareTargets ajaxSaveShareTargets
POST      timetable-foundation/class-subject-subgroup/ajax/toggle-sharing/{id}   timetable-foundation.class-subgroup.ajaxToggleSharing  ajaxToggleSharing
GET|HEAD  timetable-foundation/class-subject-subgroup/create                     timetable-foundation.class-subgroup.create            create
GET|HEAD  timetable-foundation/class-subject-subgroup/{class_subject_subgroup}   timetable-foundation.class-subgroup.show              show
PUT|PATCH timetable-foundation/class-subject-subgroup/{class_subject_subgroup}   timetable-foundation.class-subgroup.update            update
DELETE    timetable-foundation/class-subject-subgroup/{class_subject_subgroup}   timetable-foundation.class-subgroup.destroy           destroy
GET|HEAD  timetable-foundation/class-subject-subgroup/{class_subject_subgroup}/edit timetable-foundation.class-subgroup.edit           edit
GET|HEAD  timetable-foundation/class-subject-subgroup/{class}/get/sections       timetable-foundation.class-subgroup.sections.ajax     getSectionsByClass
```

Middleware on every route: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified`.

**Unrouted public methods:** `listSubgroups` (122), `getSectionsWithClassGroups` (321), `getSubgroupStats` (529). `generateClassSubgroups` (363) is deliberately NOT ROUTED + `abort(403)` (D5, pre-applied). See CSG-09.

**Stale-instrument warning.** `scripts/routes.json` (7,675 routes) is older than the app (7,660 live).
It still contains four routes that the 2026-10-10 pass deleted — `…/trash/view → trashedClassSubgroup`,
`…/{id}/restore → restore`, `…/{id}/force-delete → forceDelete`, `…/{class_subgroup}/toggle-status →
toggleStatus` — and the scanner reports them as `RTE-02`/`RTE-01` (B). **They are false positives.**
Live `route:list` filtered on `ClassSubjectSubgroupController@` returns exactly the 10 rows above; the
four names appear nowhere. `routes/web.php:278-280` records the removal.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ | viewAny | — | — | — (redirect to menu tab) | — |
| create | ✅ | create | — | — | — | CSG-14, CSG-21 |
| store | ✅ | create | ✅ closure | `Stored` | `ClassSubgroup`(missing) + `tt_class_subgroup_members` + log | CSG-07, CSG-14, CSG-18, CSG-27 |
| listSubgroups | ❌ | viewAny | — | — | reads `ClassSubgroup`(missing) | CSG-09, CSG-13, CSG-21 |
| show | ✅ | view | — | — | reads `ClassSubgroup`(missing) | CSG-14, CSG-16, CSG-22 |
| edit | ✅ | update | — | — | reads `ClassSubgroup`(missing) | CSG-14, CSG-16, CSG-22 |
| update | ✅ | update | ⚠ manual begin/commit | `Updated` | `ClassSubgroup`(missing) + log | CSG-01, CSG-14, CSG-27 |
| destroy | ✅ | delete | — | — | **none** | CSG-28 |
| getSectionsByClass | ✅ | viewAny | — | — | reads `sch_classes`/`sch_class_sections`/`sch_sections` | CSG-02, CSG-18, CSG-24 |
| getSectionsWithClassGroups | ❌ | viewAny | — | — | reads `sch_sections` | CSG-03, CSG-09 |
| generateClassSubgroups | ❌ abort(403) | **none** | — | — | — (unreachable) | CSG-12 |
| getSubgroupStats | ❌ | viewAny | — | — | reads `ClassGroupJnt`(missing)/`ClassSubgroup`(missing) | CSG-09, CSG-14 |
| ajaxToggleSharing | ✅ | update | ✅ closure | `SharingToggled` | `tt_class_requirement_subgroups` + log | CSG-04, CSG-05, CSG-09, CSG-10 |
| ajaxSaveShareTargets | ✅ | update | ✅ closure | `ShareTargetsUpdated` | `tt_class_requirement_subgroups` (N rows) + log | CSG-04, CSG-05, CSG-11, CSG-20 |

**Tables each mutation SHOULD touch** (`controller-alignment.md` §0.1):
- **store:** the subgroup row + one `tt_class_subgroup_members` row per cohort + a `student_count`
  update + the log. It does all four — but the subgroup write targets a class that does not exist.
- **update / ajaxToggleSharing:** the subgroup row + the log. It does both.
- **ajaxSaveShareTargets:** every pool member row + one log row per changed member. It does both.

## 6. Findings

### F7 — Models

#### CSG-14 · B · MDL-07 — the two primary models do not exist; every CRUD method fatals
**Where:** `ClassSubjectSubgroupController.php:16-17` (imports), `:41`, `:66`, `:88`, `:126`, `:149`, `:174`, `:194`, `:533-542`
```php
use Modules\SmartTimetable\Models\ClassGroupJnt;
use Modules\SmartTimetable\Models\ClassSubgroup;
...
$classGroupsJnt = ClassGroupJnt::all();                 // create:41, edit:174
'subgroup_type' => 'required|in:'.implode(',', ClassSubgroup::SUBGROUP_TYPES),  // store:66
$subgroup = ClassSubgroup::create([...]);               // store:88
$subgroups = ClassSubgroup::with(['classGroup'])->...   // listSubgroups:126
$classSubgroup = ClassSubgroup::with([...])->findOrFail($id);  // show:149, update:194
$totalClassGroups = ClassGroupJnt::where('is_active', true)->count();  // getSubgroupStats:533
```
**Evidence:**
```
php artisan tinker --execute 'var_dump(class_exists("Modules\\SmartTimetable\\Models\\ClassSubgroup"));'
  → bool(false)   (same for ClassGroupJnt)
grep -rn "class ClassSubgroup\\b|class ClassGroupJnt\\b" --include=*.php Modules app  → (no matches)
vendor/composer/autoload_classmap.php | grep ClassSubgroup   → only ClassSubgroupMember, ClassSubgroupPolicy
SHOW TABLES  → tt_class_subgroups MISSING, tt_class_groups_jnt MISSING
```
`grep -rn "SUBGROUP_TYPES" Modules app database` returns **only** controller line 66 — the constant is
defined nowhere.
**Consequence:** opening the class-subgroup screen (create/show/edit/update or the store POST) returns
a 500 "Class not found"; the store POST dies at validation before any write.

#### CSG-15 · H · MDL-07 — `ClassModeRule` maps to a table that exists nowhere
**Where:** `ClassModeRule.php:18` — `protected $table = 'tt_class_mode_rules';`
**Evidence:**
```
grep -rln "mode_rule|mode_rules" database/migrations/   → (none)
tenant SHOW TABLES  → tables containing "mode": rec_recommendation_modes, sys_model_has_*  (no tt_class_mode_rules)
central SHOW TABLES → same (no tt_class_mode_rules)
```
**Consequence:** any `ClassModeRule::query()` — from `TimetableType`, `PeriodSet`, `AcademicSession`
or `SchoolClass` — throws `QueryException` (base table missing) the first time it runs.

#### CSG-16 · M · MDL-04 / MDL-02 / STY — `ClassSubjectSubgroup` has no `members()` inverse; member/mode relations untyped
**Where:** `ClassSubjectSubgroup.php:65-125` (relations) · `ClassSubgroupMember.php:57-85` · `ClassModeRule.php:74-113`
**Evidence:**
```
SHOW CREATE / KEY_COLUMN_USAGE: tt_class_subgroup_members.class_subgroup_id → tt_class_requirement_subgroups (fk_csm_subgroup)
grep -n "function members" Modules/TimetableFoundation/app/Models/ClassSubjectSubgroup.php → (none)
```
`ClassSubgroupMember::classSubgroup()` is `belongsTo(ClassSubjectSubgroup)`, but `ClassSubjectSubgroup`
declares no `hasMany(ClassSubgroupMember)`. Every relation in `ClassSubgroupMember` and `ClassModeRule`
is declared without a return type (`MDL-04`). `ClassSubgroupMember::$casts` omits `created_at`,
`updated_at`, `deleted_at`.
**Consequence:** the controller and both blades call `$subgroup->members` / `->members()` and
`->classGroup` / `->roomType`; on the only real subgroups model these throw
`BadMethodCallException`/`RelationNotFoundException` (folded with CSG-22).

#### CSG-17 · M · MDL-03 / VAL-04 — soft-delete × unique-index trap on the subgroups table
**Where:** `tt_class_requirement_subgroups` indexes `uq_subgroup_code (code)` and
`uq_subgroup_class_section_ssf_option (class_id, section_id, subject_study_format_id, option_key)`
**Evidence:** both are plain `UNIQUE` keys (`SHOW INDEX`); the table has `deleted_at` but neither index
excludes trashed rows. The `store` validator's `unique:tt_class_requirement_subgroups,code` runs against
the SoftDeletes model, so it cannot see trashed rows.
**Consequence:** re-creating a subgroup with the code (or cohort) of a soft-deleted row passes
validation and fails on insert with SQLSTATE 23000 (1062).

### F1 — Errors

#### CSG-01 · M · ERR-00 (D1) + TXN-02 — `update()` uses a manual transaction inside a try/catch
**Where:** `ClassSubjectSubgroupController.php:205-238`
```php
try {
    DB::beginTransaction();
    $subgroup->update([...]);
    activityLog($subgroup, 'Updated', [...]);
    DB::commit();
    return redirect()->route('timetable-foundation.menu.timetablePreparation', ['tab' => 'class-subject-requirement'])->with('success', ...);
} catch (\Exception $e) {
    DB::rollBack();
    Log::error('Failed to update subgroup: '.$e->getMessage(), [...]);
    return back()->withInput()->with('error', 'Failed to update subgroup. Please try again.');
}
```
**Evidence:** `grep -n "beginTransaction\|rollBack" ClassSubjectSubgroupController.php` → 206, 223, 229.
ERR-00 (settled D1) = the Laravel idiom: no controller try/catch; `DB::transaction(fn () => …)`. This
is the only write method not converted by the 2026-10-10 pass. `findOrFail` (194) and `validate` (197)
are correctly outside the try, and the user message is fixed (not `getMessage()`), so the defect is
the shape, not a leak.
**Consequence:** a failed update returns a flash and a rollback that bypasses the central handler, and
the manual commit/rollback is one early-return away from leaking an open transaction.

#### CSG-02 · M · ERR-07 / ERR-00 — `getSectionsByClass()` is a read method wrapped in try/catch
**Where:** `:256-314` (`try` at 256; `catch (ModelNotFoundException)` 299; `catch (\Exception)` 306; `\Log::error(...$e->getMessage())` 307)
**Evidence:** read methods need no try/catch (ERR-07). The ModelNotFoundException branch is a valid
404, but the generic branch swallows everything else and hand-builds a JSON 500 that the central
handler would render. `\Log::error` also violates STY-06 (imported `Log` exists at line 10).
**Consequence:** a real failure in this lookup is reduced to `{"message":"Failed to load sections"}`
with the trace lost; the fix belongs to the exception renderer, not this method.

#### CSG-03 · H · ERR-02 — `getSectionsWithClassGroups()` swallows its own 404 [unrouted]
**Where:** `:325-357`
```php
try {
    $class = SchoolClass::where('id', $classId)->where('is_active', true)->firstOrFail();
    ...
} catch (\Exception $e) {
    return response()->json(['success' => false, 'message' => 'Failed to load sections', 'sections' => []], 500);
}
```
**Evidence:** `firstOrFail` (328) sits inside the try and the only catch is generic, so a missing/inactive
class returns **500** instead of 404. ERR-02, tagged `[H-only]`.
**Consequence:** a bad `classId` reports a server error and logs nothing; the method is currently
unrouted, so this arms itself the moment it is routed (see CSG-09).

#### CSG-04 · M · ERR-05 — three log sites record the message, never the exception
**Where:** `:307`, `:597`, `:782`
```php
\Log::error('Failed to fetch sections for class: '.$e->getMessage());          // 307
Log::error('ClassSubjectSubgroupController::ajaxToggleSharing failed', ['error' => $e->getMessage()]);  // 597
Log::error('ClassSubjectSubgroupController::ajaxSaveShareTargets failed', ['error' => $e->getMessage()]);  // 782
```
**Evidence:** none passes the exception object or `getTraceAsString()`; ERR-05 requires `report($e)` or
`['exception' => $e]`.
**Consequence:** production 500s on these paths log one line with no stack trace, so the cause cannot
be reconstructed from logs.

### F2 — Transactions and audit

#### CSG-05 · M · TXN-05 — HTTP responses are built inside the transaction closures
**Where:** `:585-589` (`ajaxToggleSharing`) and `:765-775` (`ajaxSaveShareTargets`)
**Evidence:** `return response()->json([...], 200)` is the closure's return value (the closure is the
outer `return DB::transaction(...)`); the comment at 599 confirms it is intentional for the catch.
TXN-05 requires the closure to return data and the response to be built after it.
**Consequence:** a JSON success body is constructed before the commit; if the commit fails, the built
response is discarded but the pattern invites a success payload for an uncommitted write.

**Audit/transaction otherwise clean:** `store` (87-116), `ajaxToggleSharing` and `ajaxSaveShareTargets`
each run one `DB::transaction`; `activityLog` sits after the write and inside the transaction in all
four writers (`Stored` / `SharingToggled` / `ShareTargetsUpdated`); no mail/file/HTTP side effect sits
inside a transaction.

### F3 — Authorization

#### CSG-06 · L · AUTH-05 — `ClassSubgroupPolicy` is doubly dead
**Where:** `TimetableFoundationServiceProvider.php:124` (`Gate::policy(ClassSubgroup::class, ClassSubgroupPolicy::class)`)
**Evidence:** `ClassSubgroup::class` resolves to `Modules\TimetableFoundation\Models\ClassSubgroup`,
which does not exist (CSG-14) — the registration binds a policy to a class that can never instantiate.
Separately, every gate in this controller passes a **permission string**, so no Policy is ever
consulted (module-wide pattern). The policy's `restore`/`forceDelete` methods target permissions whose
controller methods do not exist.
**Consequence:** the policy is inert; the permission checks that actually run are the controller's
`Gate::authorize('tenant.timetable-foundation.class-subgroup.*')` strings.

**F3 clean otherwise:** all 10 routed methods call `Gate::authorize` **before** loading any record
(AUTH-01, AUTH-02). All 7 permission names are seeded by exact name:
```
SELECT name FROM sys_permissions WHERE name LIKE '%class-subgroup%'
→ tenant.timetable-foundation.class-subgroup.{create,delete,forceDelete,restore,update,view,viewAny}
```

### F4 — Validation

#### CSG-07 · M · VAL-02 — four methods validate inline; there is no FormRequest
**Where:** `store:61-77`, `update:197-203`, `ajaxToggleSharing:569-571`, `ajaxSaveShareTargets:638-642`
**Evidence:** `grep -n "function store(Request\|function update(Request\|->validate(" $C` shows four
inline `$request->validate()` calls and zero `*Request` imports
(`grep -oE '[A-Z][A-Za-z]+Request\b' $C` → none). The store payload (17 rules) and the share-target
payload exceed the "one-field AJAX toggle" carve-out.
**Consequence:** validation is duplicated per method, cannot be reused by a future sibling route, and
the `store` rules are not covered by any cross-field `after()` hook.

#### CSG-08 · M · VAL-07 — the member combination the UI promises is never validated
**Where:** `store:72-76` (`members.*.class_id`, `members.*.section_id`) vs `create.blade.php:284-285`
**Evidence:** the create page states "Unique combination of (subgroup, class, section) is required", but
the rules contain no `distinct`/`unique` across the `members` array, and `tt_class_subgroup_members`
has no unique key on `(class_subgroup_id, class_id, section_id)` (only a non-unique `idx_csm_lookup`).
**Consequence:** a payload may contain the same class/section twice; two duplicate member rows are
inserted and `student_count` counts both.

### F5 — Routes

#### CSG-09 · M · RTE-03 — three public methods are unrouted and must follow D5
**Where:** `listSubgroups:122`, `getSectionsWithClassGroups:321`, `getSubgroupStats:529`
**Evidence:** `route:list` filtered on this controller lists 10 routes; none names these three.
`grep -rn "listSubgroups|getSubgroupStats" Modules/*/routes/` matches only SchoolSetup's
`ClassGroupController` (`school-setup.subgroups.list` / `.stats`), not this controller. Both methods
duplicate that SchoolSetup pair.
**Consequence:** all three are dead today. Per D5 each body becomes `abort(403)` with a `// NOT ROUTED`
comment (kept, not deleted). `listSubgroups` additionally returns `view('partials.subgroups-table')`,
a view that exists nowhere (`find . -name "subgroups-table*"` → empty), so routing it would 500 with
`ViewNotFoundException`.

#### CSG-10 · M · CTL-03 — no route-model binding; the route parameter name does not match the argument
**Where:** routes `…/{class_subject_subgroup}` (show/edit/update/destroy) vs `show($id)` (145),
`edit($id)` (169), `update(Request $request, $id)` (189), `destroy($id)` (244); route `…/{class}/get/sections`
vs `getSectionsByClass(Request $request, $classId)` (252)
**Evidence:** `route:list --json` reports `parameterNames` `class_subject_subgroup`; the methods are
untyped `$id`, so Laravel fills them positionally and no model is bound. `findOrFail($id)` (161, 194)
then replaces binding.
**Consequence:** the intent to bind is defeated; a renamed route parameter silently changes what the
method receives, and every lookup re-queries by raw id.

**F5 clean otherwise:** no state change over GET; all routes point at existing methods; custom routes
do not collide with the resource (different segment counts); tenant middleware present on all 10.

### F6 — Controller shape

#### CSG-11 · H · CTL-02 — `ajaxSaveShareTargets()` is 158 lines
**Where:** `:632-789`
**Evidence:** scanner `CTL-02` `size=158`; CTL-02 makes >150 lines **H**. The method holds the whole
pool-merge algorithm (nested closures `$findPartner`, `$poolOf`, `$writePool`), validation, writes and
the HTTP response.
**Consequence:** a single cohesive business operation lives in the controller (CTL-06 too); it cannot
be unit-reasoned or reused, and any edit risks the one-shared-pool invariant documented at 607-631.

#### CSG-12 · M · CTL-10 — the 9 `generate*` helpers are dead code (kept per D5)
**Where:** `:377-524` — `shouldUpdateSubgroup` (377), `updateSubgroup` (396),
`createSubgroupForClassGroup` (418), `generateSubgroupCode` (452), `generateSubgroupName` (468),
`generateSubgroupDescription` (480), `createSubgroupMember` (493), `shouldShareAcrossSections` (507),
`shouldShareAcrossClasses` (518)
**Evidence:** `grep -n "shouldUpdateSubgroup|updateSubgroup|createSubgroupForClassGroup|generateSubgroupCode|generateSubgroupName|generateSubgroupDescription|createSubgroupMember|shouldShareAcrossSections|shouldShareAcrossClasses" $C` → one definition each, zero call sites (their only caller, `generateClassSubgroups`, is now `abort(403)` at 371). Scanner agrees (CTL-10).
**Consequence:** ~150 lines of unreachable logic remain; per D5 they stay and their intent lives only
in git history.

#### CSG-13 · M · CTL-05 / SVC-04 — one resource, two unrelated model families
**Where:** CRUD → `ClassSubgroup` (16-17, 88, 126, 149, 174, 194); AJAX + member FK + policy +
permissions → `ClassSubjectSubgroup` (18, 573, 644; `tt_class_subgroup_members.class_subgroup_id`
FK; `tenant.timetable-foundation.class-subgroup.*`; `ClassSubgroupPolicy`)
**Evidence:** `listSubgroups`/`getSubgroupStats` (this controller) duplicate `ClassGroupController`'s
`listSubgroups`/`getSubgroupStats` (SchoolSetup). The members FK (`fk_csm_subgroup`) points at
`tt_class_requirement_subgroups`, the `ClassSubjectSubgroup` table — **not** at any `ClassSubgroup`.
**Consequence:** the list page links to `show`/`edit` with a `ClassSubjectSubgroup` id, but those
methods load a `ClassSubgroup` (missing); whichever class is chosen, one half of the controller is
wrong (see CSG-14, CSG-27).

### F9 — Queries and performance

#### CSG-18 · H · QRY-01 — N+1 in `getSectionsByClass()` and the loop-write in `store()`
**Where:** `:263-286` — `ClassSection::where(...)->get()->map(fn ($classSection) => … $classSection->section …)`
**Evidence:** `ClassSection` rows are fetched without `with('section')`; `$classSection->section` is
accessed inside the `->map()` callback (267, 271), so each row issues its own `SELECT`.
**Consequence:** a class with N sections costs 1 + N queries; on a large school this is the slowest
lookup on the create screen.

#### CSG-19 · M · QRY-07 — members are inserted one row per loop iteration
**Where:** `store:101-109`
```php
foreach ($validated['members'] as $index => $memberData) {
    ClassSubgroupMember::create([...]);
}
```
**Evidence:** `create()` inside a loop; QRY-07 wants one `insert()` per batch.
**Consequence:** up to 5 inserts + 1 count + 1 update per create; not harmful at this size but the
pattern is the rulebook's named debt.

#### CSG-20 · M · QRY-01 / QRY-12 — `ajaxSaveShareTargets()` queries inside its loops
**Where:** `:660-711` (`$findPartner`), `:674-684` (`$poolOf`), `:715-727`, `:747-760`
**Evidence:** `$findPartner` runs one `ClassSubjectSubgroup::where(...)->first()` per target and per
pool member; `$poolOf` calls it again for every JSON entry; the write phase calls `$poolOf($p)` for
each selected partner. The same partner can be resolved several times in one request.
**Consequence:** saving an N-cohort pool issues O(N²) small queries; on a 10-cohort option that is
dozens of round-trips for one click.

#### CSG-21 · L · QRY-02 / QRY-15 — a 20-row page and unbounded form loads
**Where:** `listSubgroups:128` (`->paginate(20)`), `create:41,43` (`ClassGroupJnt::all()`,
`SchoolClass::active()->get()`), `edit:174,176`
**Evidence:** C12 fixes list pagination at 10 with a distinct `pageName`; `ClassGroupJnt::all()` has no
filter or limit. `listSubgroups` is unrouted, so the pagination point is latent.
**Consequence:** if routed, lists show 20 rows; create/edit load every class group and class row into
the page.

### F10 — Views

#### CSG-22 · H · VIEW-01/VIEW — `show`/`edit` blades call methods and relations that do not exist
**Where:** `show.blade.php:64` `availableSeats()`, `:205,208` `$classSubgroup->members`, `:287` `hasMinimumStudents()`, `:308,355` `isFull()`, `:110` `classGroup`, `:120` `roomType`, `:349` `current_version` · `edit.blade.php:31,270` `classGroup`, `:167-168,286` `members()`
**Evidence:** `grep -rn "function availableSeats|function hasMinimumStudents|function isFull"
--include=*.php Modules app` → no match anywhere in the app. `ClassSubjectSubgroup` declares none of
`members`, `classGroup`, `roomType` (CSG-16). `current_version` is not a column of
`tt_class_requirement_subgroups`.
**Consequence:** even after CSG-14 is fixed, rendering `show`/`edit` throws
`BadMethodCallException` (`availableSeats`) or `RelationNotFoundException` (`classGroup`); the
`?? '1.0'` on `current_version` hides a missing column forever.

#### CSG-23 · H · VIEW / CTL-09 — the shared `_scripts` partial breaks the form and references undefined names
**Where:** `_partials/_scripts.blade.php:62-73` (submit), `:227-234` (`template`, `predefinedClassId`), `:304,324` (`$classSubgroup`)
```php
form.addEventListener('submit', function (e) {
    e.preventDefault();                       // 63 — unconditional
    const members = document.querySelectorAll('.member-item');
    if (members.length === 0) { alert('Please add at least one class/section to the subgroup.'); return false; }
    // ... rest of your validation code    // 72 — never reaches submit
});
```
**Evidence:** the handler calls `e.preventDefault()` before any branch and never calls `form.submit()`,
so the create and update forms can never be submitted from the browser. `addMember`/`updatePreview`
(80-86) are empty stubs. Lines 227-234 reference `template` and `predefinedClassId`, neither declared.
`$classSubgroup` (304, 324) is not passed by `create()` (50), so Blade throws `Undefined variable
$classSubgroup` when the create page renders the partial.
**Consequence:** the create/edit UI is unusable and the create page errors before paint; the page
promises validation it never runs.

#### CSG-24 · M · VIEW — the section-loader fetches a URL that is not registered
**Where:** `_scripts.blade.php:107`
```php
fetch(`/timetable-foundation/class-subgroup/${classId}/get/sections`, { ... })
```
**Evidence:** the registered route is `timetable-foundation/class-subject-subgroup/{class}/get/sections`
(route:list). `class-subgroup` is not a segment of the real path.
**Consequence:** every section dropdown issues a 404 and shows "Error loading sections"; the AJAX
endpoint is never reached.

#### CSG-25 · L · VIEW — two orphan blades and a missing partial
**Where:** `index.blade.php:2,19,29` (title "Day Management", `@forelse($schoolDays …)`, `status-switch`), `trash.blade.php:22,80` (loops `$teacherUnavailables`), `listSubgroups:130` (`view('partials.subgroups-table')`)
**Evidence:** `index()` redirects (31), so `index.blade.php` is never rendered by any route;
`trash.blade.php` has no route (removed 2026-10-10). `find . -name "subgroups-table*"` → empty.
`grep -rn "toggleStatus" routes/web.php` → only a comment.
**Consequence:** both blades are copy-paste from DayType/TeacherAvailability and will mislead the next
developer; `listSubgroups` would 500 if routed.

### F12 — Style

#### CSG-26 · L · STY-01/STY-04/STY-06 · every in-scope PHP file
- **Controller:** no `declare(strict_types=1)`; 14 public methods without return types (CTL-04);
  `\Log::` at 307; emoji markers in comments at 613, 626, 743 (`⛔`, `·`, `⚠`).
- **ClassSubjectSubgroup.php / ClassSubgroupMember.php / ClassModeRule.php:** no `strict_types`;
  `ClassSubgroupMember`/`ClassModeRule` import `HasFactory` without a factory and carry a commented
  `// use …Factory` line; relation methods have no return types.
- **ClassSubgroupPolicy.php:** no `strict_types`.
One plan item per file (CSG-26a..e).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Stale cross-module class imports (module-wide).** `Modules\SmartTimetable\Models\ClassSubgroup`
  and `…\ClassGroupJnt` are referenced by `Modules/SchoolSetup/app/Http/Controllers/ClassGroupController.php`
  (23-24, 407, 426, 474-482) and by `database/seeders/ClassSubgroupSeeder.php` (7). They are equally
  broken there — a different report's business.
- **`ClassSubgroupMember` referenced under the wrong namespace.**
  `Modules/SmartTimetable/.../ClassSubgroupMember` is imported by `SchoolSetup/Models/SchoolClass.php`
  (9) and `SchoolSetup/Models/Section.php` (8), but the real class is
  `Modules\TimetableFoundation\Models\ClassSubgroupMember`. Fatal if those relations are used.
- **`ClassModeRule` under the wrong namespace.** `Modules/Prime/app/Models/AcademicSession.php` (11,73)
  and `Modules/SchoolSetup/app/Models/SchoolClass.php` (8,87,93) import
  `Modules\SmartTimetable\Models\ClassModeRule`, which does not exist; the real class is
  `Modules\TimetableFoundation\Models\ClassModeRule` (also CSG-15).
- **Unreachable policies (module-wide).** Every policy registered in
  `TimetableFoundationServiceProvider.php:119-140` is unreachable because gates pass permission
  strings; CSG-06 adds that `ClassSubgroup` itself is a missing class. Module-level decision, as in the
  AcademicTerm report §2.0.4.
- **`Config` model** is owned by `ConfigController`; only `Config::get()` is used here (↗ linked).

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL/reflection probe.
- **The real class-subgroups list pane** (`resources/views/pages/partials/timetable-requirement/class-subgroups/_list.blade.php`)
  and the `generated-groups/_list.blade.php` pane that calls the two AJAX routes: rendered by the
  menu/TimetablePreparation controller, not by this controller, so not in scope. They link into
  `show`/`edit` and therefore hit CSG-14.
- **`ClassSubgroup`/`ClassGroupJnt` intent:** no source file exists to audit; their intended table
  schema is unknown. CSG-14/CSG-27 record the consequence only.
- **The delete/restore/force-delete UI** removed on 2026-10-10: not re-added here; the live route set
  is the 10 rows in §4.
- **`ControllerAuthTest`** lists `getSectionsWithClassGroups`/`getSubgroupStats` expectations; the D5
  change may interact with it. Tests are the team's (D4).
