# Status — TimetableFoundation / ClassWorkingDayController

**Fixed:** 2026-10-13 · **By:** claude (fix) · **Audit:** opencode, 2026-10-10
**Plan:** `02-fix-plan.md` — 21 items ticked. 5 plan items left open on purpose (CWD-07, 14, 17, 23, 27).

---

## 1. Pre-applied work

None. `PRE-APPLIED-2026-10-10.md` lists no file in this controller's scope.

---

## 2. Applied

| ID | File:line | What changed | Verify command | Output |
|---|---|---|---|---|
| CWD-28 | controller `forceDelete()` | Looks the row up with `onlyTrashed()->findOrFail($id)`, outside the transaction. A live id now returns a 404 and cannot be purged. `restore()` uses the same pattern. | read | — |
| CWD-09 | `Http/Requests/ClassWorkingDayRequest.php` (new) | `working_day_id` has a `Rule::unique` that mirrors `uq_class_working_day (class_id, section_id, working_day_id)`. It includes trashed rows, treats a NULL section as class-level, and `->ignore()`s the bound row on update. The message tells the user to restore a trashed entry instead. | rolled-back dry run | duplicate → rejected with that message; update of the same row → passes |
| CWD-05 | controller `existingRows()` | `ajaxStore` and `ajaxInitialize` pre-load their target rows `withTrashed()->lockForUpdate()` inside the transaction. This closes the check-then-act race, including the NULL-section case that a unique index cannot catch. | read | — |
| CWD-01 | controller | Removed try/catch from all 8 non-D2 methods. The only catch left is `\DomainException` in `ajaxStore` (D2, commented ERR-01). Unused imports dropped: `AuthorizationException`, `ModelNotFoundException`, `ValidationException`, `HttpExceptionInterface`, `Log`. | `grep -c 'try {'` | 1 |
| CWD-02 | controller `store()` / `update()` | Validation now runs in the FormRequest, before the transaction. A failed field redirects back with its error instead of the generic "operation failed" flash. | read | — |
| CWD-03 | controller | Resolved by CWD-01: no `Log::error(['error' => $e->getMessage()])` remains. The only `getMessage()` is the D2 `DomainException`, which carries a user-safe message. | `grep -c 'Log::'` | 0 |
| CWD-04 | controller | Every closure returns the model. The redirect and flash are built after `DB::transaction(...)`. | read | — |
| CWD-06 | controller `ajaxDestroy()` / `ajaxInitialize()` | `Gate::authorize` is the first statement. `ajaxDestroy` then looks the row up and opens the transaction. | read | — |
| CWD-08 | `ClassWorkingDayRequest.php` (new) | Holds the old store/update rules. `authorize()` uses `authorizeByCrudPermission('tenant.timetable-foundation.class-working-day')`, the same permission the controller gates. `store`/`update` take the request and call `validated()`. The calendar endpoints keep their own inline rules because their payload is different (`class_ids[]` and a date range). | `class_exists` | OK |
| CWD-10 (a) | `routes/web.php:323` | Restore is now `Route::patch(...)` (it was GET). `x-backend.table.action-trashed` reads the verb from the route, so `trash.blade.php` needed no edit. | `route:list` (uncached) | `PATCH …/class-working-day/{id}/restore` |
| CWD-16 | `Models/ClassWorkingDay.php` | Added `: BelongsTo` to `academicSession()`, `class()`, `section()`, `workingDay()`. | `php -l` | OK |
| CWD-18 (b) | controller `ajaxStore()`; `_list.blade.php` | Removed the `send_notification` / `notification_channels` rules, the `SpecialDayAssigned` dispatch and the `#cwdNotificationModal` with its handlers. A confirmed drop now saves straight away (`storeClassWorkingDay()` calls `doAjaxStore()`). The blade went from 644 to 580 lines. | `grep -rn SpecialDayAssigned Modules/` | only a comment in the controller |
| CWD-19 | controller `ajaxStore()` / `ajaxInitialize()` | No queries inside the loops. Working days are pre-loaded keyed by date string, and existing rows are pre-loaded keyed by `class|section|working_day` (`rowKey()`). | read | — |
| CWD-20 (partial) | controller `writeRow()` | Each row is one `save()` against the pre-loaded collection (insert, update or un-trash). `upsert()` was **not** used because every row still needs its own `activityLog()` entry. | read | — |
| CWD-21 | controller `create()` / `edit()` | The WorkingDay dropdown is limited to the current session (`edit` also keeps the row's own working day) and selects only `id, date`. | read | — |
| CWD-22 | `show.blade.php:28`, `trash.blade.php:29` | `->schoolClass` became `->class`. The Class column now shows the name instead of "—". | `grep schoolClass` | 0 |
| CWD-24 | controller `eventFeed()` / `workingDayFeed()` | `start` and `end` are validated as `nullable|date`. A malformed range now returns a 422. | read | — |
| CWD-25 (a) | controller `ajaxStore()` | With no current academic session it returns 422 "No current academic session." The hard-coded `academic_session_id = 1` is gone. | read | — |
| CWD-26a | controller | `strict_types` added. The four emoji comment markers removed. All 16 public methods have return types. | `php -l` | OK |
| CWD-26b | `Models/ClassWorkingDay.php` | `strict_types` added. ⚠ SHARED model; header-only change, approved by Tarun. | `php -l` | OK |
| CWD-26c | `Policies/ClassWorkingDayPolicy.php` | `strict_types` added. | `php -l` | OK |
| CWD-29 | controller `ajaxInitialize()` | Counts `created` and `updated` separately. Message: "{created} class working days created and {updated} updated from the working days calendar." The JSON `data` carries both counts. | read | — |
| Pint | the 4 touched PHP files | Pint fixed `fully_qualified_strict_types`, `ordered_imports` and two operator-spacing rules, and imported `Illuminate\Support\Collection`. | `php -l` re-run after Pint | OK ×4 |

The controller went from 817 lines to 741. One new FormRequest was added (92 lines).

### 2.1 Applied beyond the ticked plan — read this

1. **`ajaxInitialize`'s "clear existing" step is one batched query.** It was one delete per class. It is now `whereIn('class_id')`, plus a `whereIn('section_id')` filter when sections were chosen, followed by `forceDelete()`. The behaviour is unchanged.
2. **`ajaxStore` throws `\DomainException`** when a dropped date has no configured working day. The message is unchanged: "…has not been configured in Working Days yet. Please go to the Working Days tab and add this date first." It is caught once and returned as a 422 (D2).
3. **The `SpecialDayAssigned` event class is still on disk.** Nothing dispatches it now. It was kept so that a later notification feature can reuse it.

---

## 3. Not applied

| ID | Why |
|---|---|
| CWD-07 | Deferred module-wide: the unreachable-policy decision (WDY-17 / ATC-14). |
| CWD-14 | Deferred under D3 (splits and extractions come later). |
| CWD-17 | DDL drift. The fix is to correct `Timetable_DDL_v8.1.sql` to the three-column key. That is a Tarun hand-item, and the misleading migration comment cannot be edited (existing migration). |
| CWD-23 | Not ticked. Making `create()` `abort(403)` would break the green Dusk tests 11 and 12, which use `/create` (see §4). |
| CWD-27 | Not ticked. Requiring a configured working day on the resource path would break green test 15, which updates to `fixtureDate(20)`, a date with no working day (see §4). |
| CWD-11, 12, 13, 15 | No plan item of their own. Covered along the way: CWD-12 (route model binding on show/edit/update/destroy/toggleStatus), CWD-13 (shared `existingRows()` / `writeRow()` / `rowKey()`), CWD-15 (return types, via CWD-26a). CWD-11 (two methods over 80 lines) is shorter but still open; it goes with CWD-14 under D3. |

The inline validation in `eventFeed`, `workingDayFeed`, `ajaxStore` and `ajaxInitialize` stays inline on purpose. These endpoints take a different payload from the resource form (CWD-08).

---

## 4. Needs Tarun's hand

1. **Correct the DDL (CWD-17).** In `Timetable_DDL_v8.1.sql:360`, make the unique key `(class_id, section_id, working_day_id)` to match the live table.
2. **Run the suite.** The tests below are affected; nothing was edited in them.
   - `TtClassWorkingDayBasicTest` (in both `prime_ai` and `prime_testing`) mentions the notification modal only in comments: docblock lines 93-94 and line 597 in prime_ai, lines 92-93 and 572 in prime_testing. No assertion drives the modal, so removing it should not turn a test red.
   - `test_18` drives restore through `action-trashed`, which now emits PATCH. It should stay green.
   - Tests 11, 12 and 15 are the reason CWD-23 and CWD-27 were left unticked. If you tick either later, those tests must change with it.
   ```bash
   php artisan dusk tests/Browser/Modules/V2/TimetableFoundation/TimetableMasters/TtClassWorkingDayBasicTest.php
   ```
3. **Browser check** of `/timetable-foundation/timetable-masters?tab=working-days`:
   - drop a day type on the calendar, confirm it saves straight away with no notification modal;
   - run Initialize and read the created/updated counts;
   - trash a row from the list, then restore it from the trash page.

---

## 5. Unverifiable by this workflow (D4)

- **The `lockForUpdate` race fix (CWD-05)** cannot be shown without two concurrent requests.
- **The `ajaxStore` / `ajaxInitialize` rewrite** was proven by reading and `php -l` only. No rolled-back dry run drove those two endpoints.
- **The calendar drop flow after the modal removal** has no Dusk assertion of its own; it needs the browser check in §4.

---

## 6. Verification log

```
php -l (controller, request, model, policy — before and after Pint)   → No syntax errors ×8
class_exists: controller, request, model, policy (after Pint)          → OK ×4
route:list (uncached)                                                  → restore = PATCH;
                                                                         resource param {class_working_day};
                                                                         0 routes app-wide point at a missing method
blade compile: _list, show, trash                                      → OK; @push 0/0; compiled output passes php -l
_list.blade.php {{-- / --}} count                                      → 14/13 (was 15/14 before the edit — pre-existing)
dry run (tenant xyz_school_00000000000040008000_202627, read-only):
  live 4623 · trashed 0
  store payload duplicating an existing row                            → REJECTED: "This class/section already has an
                                                                         entry for that working day. If it is in the trash,
                                                                         restore it instead."
  update payload for that same row (ignore bound id)                   → PASSES
  restore route methods                                                → PATCH
grep controller: try=1 (D2) · Log::=0 · getMessage=1 (D2) · tx=10 · activityLog=10 · Gate::authorize=16
grep -rn SpecialDayAssigned Modules/                                   → 1 hit, a comment
```

---

## 7. Final state

**Status: FIXED** (2026-10-13). Open items:

- 1 M: CWD-17 (DDL hand-item).
- 2 L + 1 M left unticked by decision: CWD-23, CWD-27 (green tests), CWD-14 (D3).
- 1 L: CWD-07, deferred module-wide.

Every H item is closed (CWD-02, 10, 18, 19, 22).
