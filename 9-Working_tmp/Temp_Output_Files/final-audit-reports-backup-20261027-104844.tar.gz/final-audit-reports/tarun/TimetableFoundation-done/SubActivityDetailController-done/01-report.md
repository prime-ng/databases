# Final Audit — TimetableFoundation / SubActivityDetailController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/SubActivityDetailController.php` (249 lines, 5 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 1 blocker (latent), 2 HIGH.**

The controller is small, every method is routed and gated, and the writes are correctly wrapped in transactions with the audit row inside. But the read path is built on the wrong teacher table: `index()` eager-loads `teacher:id,name` from `sch_teachers`, a table that has **no `name` column**. The listing therefore returns a 500 the moment any detail row has a teacher assigned — which is the whole point of the screen.

The second problem is a soft-delete trap: `uq_subact_detail` is a plain UNIQUE on `(sub_activity_id, period_number)` with no `deleted_at`. Once a period row is soft-deleted, `seed()` and `store()` can never re-create it — every attempt returns the generic 422 forever. Third, four mutating methods still carry a controller `try/catch`, against settled decision D1.

The effort is roughly one day for the code, but two of the fixes (teacher source, soft-delete shape) touch the schema or another module and need your choice first.

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 1 | 2 | 3 | 3 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SAD-01 | F8 Services/Jobs | SAD-07 |
| F2 Transactions/Audit | SAD-02 | F9 Queries/Perf | clean: `index()` eager-loads `teacher`/`room`; the seeder bulk-inserts in one statement |
| F3 Authorization | clean: all 5 routed methods call `Gate::authorize` as their first line; 4 permission names resolve exactly in `sys_permissions` | F10 Views | clean: no Blade (JSON API) |
| F4 Validation | SAD-03, SAD-04 | F11 Security/Tenancy | clean: no `env()`, no hard-coded id, tenant middleware present |
| F5 Routes | clean: 5/5 public methods routed; verbs are POST/PATCH/DELETE (no state change over GET); route params match the method arguments | F12 Style | SAD-08 |
| F6 Controller shape | clean: 249 lines / 5 methods, all methods < 80 lines, route model binding, `: JsonResponse` on every method (copy-paste folded into SAD-01) | F13 Deep read | SAD-09 |
| F7 Models | SAD-05, SAD-06 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `app/Http/Controllers/SubActivityDetailController.php` | controller | 249 | this report | ✅ whole class |
| 2 | `app/Models/SubActivityDetail.php` | model | 176 | this report (pre-assigned) | ✅ whole class |
| 3 | `app/Services/SubActivityDetailSeeder.php` | service | 135 | this report (pre-assigned) | ✅ whole class |
| 4 | `app/Observers/SubActivityObserver.php` | observer | 22 | this report (claimed — not previously registered) | ✅ whole class |
| 5 | `routes/web.php` lines 128-137 | routes | 10 | this report | ✅ |
| 6 | `database/migrations/tenant/2026_06_16_152644_create_tt_sub_activity_detail_table.php` | tenant migration | 44 | reference (schema — DDL wins) | ✅ read for schema |
| 7 | `database/migrations/tenant/2026_06_25_174500_add_audit_columns_to_tt_sub_activity_details.php` | tenant migration | 36 | reference | ✅ read for schema |
| 8 | `app/Models/SubActivity.php` | model | 263 | [ActivityController](../ActivityController/01-report.md) | ↗ linked — usage checked (`details()`, `parentActivity()`, `duration_periods`) |
| 9 | `app/Models/Activity.php` | model | 345 | [ActivityController](../ActivityController/01-report.md) | ↗ linked — usage checked (`required_weekly_periods`) |
| 10 | `Modules/SchoolSetup/app/Models/Teacher.php` | model (other module) | 511 | common (§4.2) | ❌ not audited — its mis-target use is SAD-05/§7 |
| 11 | `Modules/SchoolSetup/app/Models/Room.php` | model (other module) | 127 | common | ❌ not audited — `room()` usage checked, correct |
| 12 | `config/permissionslist.php:704` | config (common) | — | common | ❌ — permission names checked only (F3) |
| 13 | `app/Console/Commands/BackfillSubActivityDetails.php` | command | 71 | not in scope (§4.1) | ❌ — another consumer of the seeder, see §8 |

**Pre-applied 2026-10-10:** `SubActivityDetailController` is **not** listed in `../PRE-APPLIED-2026-10-10.md`. No pre-applied rows apply to this report.

## 4. Routes

```
GET|HEAD  timetable-foundation/sub-activity/{subActivity}/details          timetable-foundation.sub-activity-detail.index   index
POST      timetable-foundation/sub-activity/{subActivity}/details/seed     timetable-foundation.sub-activity-detail.seed    seed
POST      timetable-foundation/sub-activity/{subActivity}/details          timetable-foundation.sub-activity-detail.store   store
PATCH     timetable-foundation/sub-activity-detail/{subActivityDetail}     timetable-foundation.sub-activity-detail.update  update
DELETE    timetable-foundation/sub-activity-detail/{subActivityDetail}     timetable-foundation.sub-activity-detail.destroy destroy
```

Middleware on every route: `web, Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, Illuminate\Auth\Middleware\Authenticate, EnsureEmailIsVerified`.
**Unrouted public methods:** none — 5 public methods, 5 routes. Evidence: `grep -nE 'public function' <C>` (5) vs `route:list` filtered for `SubActivityDetailController@` (5).

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| index | ✅ GET | `…sub-activity-detail.viewAny` | — | — | reads: `tt_sub_activity_details`, `sch_teachers`, `sch_rooms` | SAD-05 |
| seed | ✅ POST | `…sub-activity-detail.create` | none — single bulk `insert()` | — | `tt_sub_activity_details` | SAD-01, SAD-02, SAD-03 |
| store | ✅ POST | `…sub-activity-detail.create` | ✅ closure (L128) | `Stored` | `tt_sub_activity_details`, `sys_activity_logs` | SAD-01, SAD-03 |
| update | ✅ PATCH | `…sub-activity-detail.update` | ✅ closure (L183) | `Updated` | `tt_sub_activity_details`, `sys_activity_logs` | SAD-01, SAD-03, SAD-09 |
| destroy | ✅ DELETE | `…sub-activity-detail.delete` | ✅ closure (L222) | `Trashed` | `tt_sub_activity_details`, `sys_activity_logs` | SAD-01, SAD-09 |

**Tables each mutation SHOULD touch (controller-alignment §0.1):**
- **store:** the detail row (`tt_sub_activity_details`) plus the audit row (`sys_activity_logs`). It does both, in one transaction, audit after the write. ✅
- **update:** the same two. ✅
- **destroy:** the same two. ✅
- **seed:** only `tt_sub_activity_details` (one table, one statement), no audit row. A bulk idempotent seed is not required by TXN to log; recorded here, not counted.

## 6. Findings

### F7 — Models
#### SAD-05 · B · MDL / usage — `index()` eager-loads a non-existent `name` column from `sch_teachers`; the listing 500s once a teacher is assigned
**Where:** `SubActivityDetailController.php:34-36`
```php
$details = $subActivity->details()
    ->with(['teacher:id,name', 'room:id,name'])
    ->get();
```
`SubActivityDetail.php:94-97`:
```php
public function teacher(): BelongsTo
{
    return $this->belongsTo(Teacher::class, 'assigned_teacher_id');
}
```
`Modules/SchoolSetup/app/Models/Teacher.php:21`: `protected $table = 'sch_teachers';`

**Evidence:**
- `SHOW COLUMNS FROM sch_teachers` → `id, user_id, joining_date, total_experience_years, highest_qualification, specialization, last_institution, awards, skills, qualifications_json, certifications_json, experiences_json, notes, created_at, updated_at, deleted_at`. **There is no `name` column.**
- `Modules\SchoolSetup\Models\Teacher::select('id','name')->limit(1)->get()` → `SQLSTATE[42S22]: Column not found: 1054 Unknown column 'name' in 'field list' (… select id, name from sch_teachers …)`.
- The constrained eager load `teacher:id,name` runs exactly that query whenever at least one parent row has a non-null `assigned_teacher_id`.
- Current data masks it: `SELECT COUNT(*) FROM tt_sub_activity_details WHERE assigned_teacher_id IS NOT NULL` → **0**. The `whereIn` key set is empty today, so Eloquent skips the query and `index()` returns. `SELECT COUNT(*) … WHERE assigned_room_id IS NOT NULL` → 0 too (the `room` relation is safe regardless — `sch_rooms` has `name`).
- The teacher's name is an accessor, not a column: `Teacher::getNameAttribute()` returns `$this->user->name` (`Teacher.php:386-389`), so even a full `teacher` load needs `user_id` present, not a `name` column.

**Consequence:** the GET listing that the Period Plan editor (Phase 3) is built on returns a 500 for every sub-activity the first time any period has a teacher assigned; the crash is latent only because zero rows currently carry a teacher.

#### SAD-06 · L · MDL / copy — the model docblock says the unique key was dropped; it exists
**Where:** `SubActivityDetail.php:25-28`
```php
* Uniqueness on (sub_activity_id, period_number) is NOT enforced at the DB
* level (the prior unique key was dropped because nullable FKs make it
* meaningless). Callers are responsible for dedup…
```
**Evidence:** `SHOW CREATE TABLE tt_sub_activity_details` → `UNIQUE KEY uq_subact_detail (sub_activity_id, period_number)` present. The migration that created it is live (`…2026_06_16_152644…:33`). The controller's docblock (lines 95-99) states the opposite and is the correct one.
**Consequence:** the false statement invites a future developer to add application dedup that is unnecessary for sub-activity rows, and hides the soft-delete trap in SAD-09 (only activity-direct rows, `sub_activity_id IS NULL`, are genuinely unconstrained by MySQL).

### F1 — Errors
#### SAD-01 · M · ERR-00 (D1) / ERR-05 / CTL-05 — four mutating methods still catch `\Throwable` themselves and label every server fault a 422
**Where:** `seed:67-89` · `store:116-154` · `update:174-209` · `destroy:221-247`
```php
} catch (\Throwable $e) {
    Log::error('Sub-activity detail create failed', [
        'sub_activity_id' => $subActivity->id,
        'error'           => $e->getMessage(),
        'trace'           => $e->getTraceAsString(),
    ]);
    return response()->json(['success' => false, 'message' => 'Failed to create sub-activity detail.'], 422);
}
```
**Evidence:** the four blocks are line-for-line the same except the message (`grep -n 'try {' …` → 4; `grep -n 'catch (' …` → 4). The comments call it "STRICT RULE 1", but settled decision D1 ("ERR-00 = the Laravel idiom") forbids controller try/catch, and these are not one of the D2 shapes. The user-facing text is fixed, so ERR-01 is **not** breached; the issues are: (a) D1 — the central handler in `bootstrap/app.php` already logs and renders; (b) ERR-05 — logging `$e->getMessage()` plus a string trace instead of `report($e)`; (c) `catch (\Throwable)` also absorbs `\Error` (programming faults) and returns 422, so a genuine 500 is reported as a client validation error and defects are hidden; (d) CTL-05 — the same 12-line block is copy-pasted four times.
**Consequence:** every real server failure (a missing column, an FK violation, a type error) is mislabelled as a 422 "validation" error, and the duplicate-key case the comment is written for (SAD-09) ends up as an opaque generic message rather than a specific one.

### F2 — Transactions/Audit
#### SAD-02 · M · TXN-06 — the seeder's check-then-act has no lock, and activity-direct rows have no unique index
**Where:** `SubActivityDetailSeeder.php:96-131`
```php
$existing = $query->pluck('period_number')->all();   // read
…
DB::table('tt_sub_activity_details')->insert($rows); // write
```
**Evidence:**
- `SHOW CREATE TABLE tt_sub_activity_details` → `UNIQUE KEY uq_subact_detail (sub_activity_id, period_number)`. MySQL treats every `NULL` `sub_activity_id` as distinct, so the index constrains **only** sub-activity rows. `seedForActivity()` (`:55-71`) inserts with `sub_activity_id = null`.
- `SELECT COUNT(*) FROM (SELECT activity_id FROM tt_sub_activity_details WHERE sub_activity_id IS NULL GROUP BY activity_id, period_number HAVING COUNT(*) > 1) t` → **0** duplicated groups today (1,735 activity-direct rows across 539 activities), so this is latent.
**Consequence:** two concurrent seeds for the same activity (e.g. two generate requests, or the observer firing alongside a manual seed) can each read "missing" and both insert, producing duplicate period rows for an activity-direct plan with no DB guard to stop them.

### F4 — Validation
#### SAD-03 · M · VAL-02 — `store` and `update` validate inline instead of in a FormRequest
**Where:** `store:106-111` · `update:165-170`
```php
$validated = $request->validate([
    'period_number'       => ['required', 'integer', 'min:1', 'max:255'],
    'assigned_teacher_id' => ['nullable', 'integer', 'exists:sch_teachers,id'],
    'assigned_room_id'    => ['nullable', 'integer', 'exists:sch_rooms,id'],
    'assigned_time_slot'  => ['nullable', 'string', 'max:50'],
]);
```
**Evidence:** scanner `VAL-02` at lines 59, 106, 165; no `app/Http/Requests/*SubActivity*` exists (project rule: validation belongs in a FormRequest, inline allowed only for a one-field AJAX toggle). `update` validates four fields; `store` validates four — both need a request class. `seed` validates a single field (`count`) and is borderline-acceptable as a one-field call.
**Consequence:** the two largest write surfaces have no reusable, authorizable request object, so their rules can silently drift from `update`'s and there is nowhere to put a future cross-field or permission check (VAL-07).

#### SAD-04 · H · VAL / DDL-drift — the `exists` rule checks `sch_teachers`, but the FK and DDL use `sch_teacher_profile`
**Where:** `store:108`, `update:166` — `'assigned_teacher_id' => ['nullable', 'integer', 'exists:sch_teachers,id']`
**Evidence:**
- `SHOW CREATE TABLE tt_sub_activity_details` → `CONSTRAINT fk_subact_detail_teacher FOREIGN KEY (assigned_teacher_id) REFERENCES sch_teacher_profile (id) ON DELETE SET NULL`.
- The tenant migration agrees: `…2026_06_16_152644…:28` → `references('id')->on('sch_teacher_profile')`.
- The DDL agrees: `pgdatabase/2-DDL_Tenant_Enhanced/Timetable/Timetable_DDL_v8.1.sql:1209,1218` — `assigned_teacher_id … -- FK to sch_teacher_profile.id`.
- The two tables happen to have identical id sets today (`sch_teachers` 89 rows, `sch_teacher_profile` 89 rows, symmetric difference 0), which is why validation passes today.
**Consequence:** the rule validates against a table the write does not actually constrain. Once the two tables diverge, a teacher valid in `sch_teacher_profile` but absent from `sch_teachers` is rejected ("invalid"), while an id present only in `sch_teachers` passes validation and then fails the FK with an opaque 422 — a data-integrity mismatch that is invisible until it breaks.

### F8 — Services/Jobs
#### SAD-07 · L · SVC-01 — the seeder reads `auth()` and `now()` instead of receiving them
**Where:** `SubActivityDetailSeeder.php:104-105`
```php
$now    = now();
$userId = auth()->id();
```
**Evidence:** the service is otherwise pure data-in/data-out (no `request()`, `session()`, `redirect()`, `response()`, `back()`). It is also invoked from observers (`SubActivityObserver::created`) and the backfill command, where per-request auth context is incidental.
**Consequence:** the seeder cannot be reused in a queued/console context without an authenticated user, and `created_by` silently becomes `null` there; low impact, easy to pass in as a parameter.

### F12 — Style
#### SAD-08 · L · STY-01 / STY-02 — no `strict_types` and Pint is not clean (3 files)
**Where:** `SubActivityDetailController.php`, `SubActivityDetail.php`, `SubActivityDetailSeeder.php`
**Evidence:** scanner `STY-01` on all three files (`php -l` is clean; the issue is the missing declaration). `vendor/bin/pint --test <3 files>` → `"result":"fail"` with fixers `binary_operator_spaces` (controller), `class_attributes_separation`, `not_operator_with_successor_space`, `ordered_imports` (model), `single_space_around_construct`, `binary_operator_spaces` (service).
**Consequence:** style only; run Pint on the three files when touching them (never `--dirty`).

### F13 — Deep read
#### SAD-09 · H · deep read / VAL-04 / TXN-06 — a soft-deleted period can never be re-created
**Where:** `destroy:222-230` (soft delete) · `store:128-136` (insert) · `SubActivityDetailSeeder.php:96-131` (insert)
```php
// destroy
DB::transaction(function () use ($subActivityDetail) {
    $subActivityDetail->delete();          // sets deleted_at, row stays
    …
});
// seeder
$existing = $query->pluck('period_number')->all();   // SoftDeletes scope hides trashed rows
```
**Evidence:**
- `SubActivityDetail` uses `SoftDeletes` (`:35`); `destroy()` soft-deletes, so the row remains.
- `SHOW CREATE TABLE tt_sub_activity_details` → `UNIQUE KEY uq_subact_detail (sub_activity_id, period_number)` — it does **not** include `deleted_at`.
- The seeder's `pluck('period_number')` runs through the SoftDeletes model, so a trashed period is invisible; it is then re-inserted and hits the still-present unique row with error 1062.
- `SELECT COUNT(*) FROM tt_sub_activity_details WHERE deleted_at IS NOT NULL` → **0** today, so the trap is latent until the first delete.
**Consequence:** after any period row is deleted, `seed()` tries to re-create every deleted period, the whole multi-row `insert()` aborts on 1062, and the endpoint returns the generic "Failed to seed sub-activity details." forever; `store()` for that same period fails the same way. The delete is effectively irreversible.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **`SchoolSetup\Teacher` (another module):** its `$table` is `sch_teachers`, which has no `name` (name lives on `sys_users` via the `getNameAttribute` accessor). Every consumer that eager-loads `teacher:id,name` or validates `exists:sch_teachers,id` inherits SAD-05/SAD-04. The canonical teacher-data table for this FK is `sch_teacher_profile`; that is a SchoolSetup/module-level decision, not this report's fix.
- **Unreachable-policy / literal-permission pattern (module-wide):** every `Gate::authorize()` in this controller passes a permission **string**, so no Policy is consulted (as in the AcademicTerm audit, ATC-14). This controller has no Policy at all, so it is benign here; noted for consistency.
- **Route model binding runs before `Gate::authorize`:** implicit binding resolves `SubActivity`/`SubActivityDetail` before the method body, so a nonexistent id yields 404 before the 403 check (AUTH-02, framework-level). Module-wide; not counted for this controller.
- **`ControllerAuthTest`:** `tests/Unit/Central/ControllerAuthTest.php` contains no reference to `SubActivityDetailController` (`grep -n "SubActivityDetail"` → none), so this controller is not in any auth-exempt list.
- **Permission surface (F3) is clean:** `tenant.timetable-foundation.sub-activity-detail.viewAny/create/update/delete` are each declared at `config/permissionslist.php:704` (`$crud`, defined `:176-184`) and each exists **exactly once** in the tenant `sys_permissions` (exact-name `where('name', …)` → 1 for all four; never `LIKE`).

## 8. Not covered, and why

- **Runtime behaviour:** no browser or test run (D4). Every finding is static or a read-only SQL probe.
- **`BackfillSubActivityDetails` command (`app/Console/Commands/`, 71 lines):** a command is outside §4.1's class list, so it is not audited; it is a third call-site of `SubActivityDetailSeeder`, so it inherits SAD-02 and SAD-09. Any fix to the seeder changes its behaviour too.
- **`ActivityObserver`/`SubActivityObserver` registration:** `SubActivityObserver` is audited (scope row 4); `ActivityObserver` and the service-provider registration (`TimetableFoundationServiceProvider.php:164-165`) are other reports' scope. `SubActivityObserver::created` is a one-line delegation to the audited seeder and is clean.
- **Data repair:** none needed today (0 rows with a teacher/room assigned, 0 trashed rows).
- **The Phase-3 consumer:** no Blade/JS calls any `timetable-foundation.sub-activity-detail.*` route (`grep` over `resources/views` and `resources/js` → none). The controller's own docblock states the Period Plan editor is "upcoming (Phase 3)", so the endpoints are currently un-consumed; this is intentional and not counted, but it is why SAD-05/SAD-09 are latent rather than live.
