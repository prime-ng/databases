# Final Audit — TimetableFoundation / ActivityController

**Audited:** 2026-10-10 · **By:** opencode · **Controller:** `Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php` (1,624 lines, 2 public methods)
**Rulebook:** `prime_info/Final/CodeReview/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.
**Tenant measured:** `test.localhost` → `xyz_school_00000000000040008000_202627`

## 1. Verdict

**Not production-ready. 0 blockers, 1 HIGH.**

The two write paths (lock update, bulk generation) follow the settled ERR-00/D2 shape on the generation side, and the truncate-rebuild message is now user-safe. But the generation gate is one 987-line method that re-queries the same lookups once per requirement and once per teacher during a 5-minute POST, and the `updateLocks` path still keeps a non-D2 controller catch that logs only the message. The worst finding is **ACT-08**: `generateActivities()` is 987 lines of interleaved business logic — a wrong-answer bug here costs a whole rebuilt timetable, and it is the single hardest thing to review or fix on this controller. There is also a dead service (`SubActivityService`) that duplicates the sub-activity writer with a different, crashing result.

The effort is about a day. Three DECISION items need your choice first (split, dead service, static cache).

## 2. Counts

| B | H | M | L | DECISION |
|---|---|---|---|---|
| 0 | 1 | 8 | 8 | 3 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | ACT-01, ACT-02, ACT-03 | F8 Services/Jobs | ACT-12, ACT-13 |
| F2 Transactions/Audit | ACT-04, ACT-05 | F9 Queries/Perf | ACT-14 |
| F3 Authorization | ACT-06 | F10 Views | checked, not present — the controller renders no view |
| F4 Validation | clean — `UpdateActivityLocksRequest` handles input; `generateActivities` takes no request input | F11 Security/Tenancy | ACT-15 |
| F5 Routes | clean — route:list (uncached) shows both public methods routed, no state change over GET | F12 Style | ACT-16 |
| F6 Controller shape | ACT-07, ACT-08, ACT-09, ACT-10 | F13 Deep read | ACT-17 (answers folded into each finding) |
| F7 Models | ACT-11 | | |

## 3. Scope

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php` | controller | 1,624 | this report | ✅ whole class |
| 2 | `Modules/TimetableFoundation/app/Http/Requests/UpdateActivityLocksRequest.php` | FormRequest | 122 | this report (only this controller uses it) | ✅ whole class |
| 3 | `Modules/TimetableFoundation/app/Models/Activity.php` | model | 345 | this report (pre-assigned) | ✅ |
| 4 | `Modules/TimetableFoundation/app/Models/ActivityTeacher.php` | model | 131 | this report (pre-assigned) | ✅ |
| 5 | `Modules/TimetableFoundation/app/Models/SubActivity.php` | model | 263 | this report (pre-assigned) | ✅ |
| 6 | `Modules/TimetableFoundation/app/Models/SubActivityMember.php` | model | 98 | this report (pre-assigned) | ✅ |
| 7 | `Modules/TimetableFoundation/app/Models/ActivityPriority.php` | model | 96 | this report (pre-assigned) | ✅ |
| 8 | `Modules/TimetableFoundation/app/Services/SubActivityGrouper.php` | service | 471 | this report (pre-assigned) | ✅ |
| 9 | `Modules/TimetableFoundation/app/Services/SubActivityService.php` | service | 96 | this report (pre-assigned) | ✅ dead — ACT-13 |
| 10 | `Modules/TimetableFoundation/app/Services/ActivityExporter.php` | service | 186 | this report (pre-assigned) | ✅ |
| 11 | `Modules/TimetableFoundation/app/Services/ActivityPriorityCalculator.php` | service | 483 | this report (pre-assigned) | ✅ |
| 12 | `Modules/TimetableFoundation/app/Services/ActivityLockService.php` | service | 232 | this report (pre-assigned) | ✅ |
| 13 | `Modules/TimetableFoundation/app/Policies/ActivityPolicy.php` | policy | 44 | this report | ✅ — unreachable, see §7 |
| 14 | `Modules/TimetableFoundation/routes/web.php` lines 112-123 | routes | — | this report | ✅ |
| — | `RequirementTableTruncator` service | service | 192 | [RequirementConsolidationController](../RequirementConsolidationController-done/01-report.md) | ↗ linked — usage checked: `truncateFrom('activities')` at controller `:199` runs before `DB::beginTransaction()` at `:201`, exactly its documented contract |
| — | `ClassSubjectSubgroup`, `RequirementConsolidation`, `TeacherAssignmentRole`, `TeacherAvailability`, `TimetableType` models | models | — | their controllers' reports (00-CLASS-OWNERS) | ↗ linked — usage checked (query shape, option/eligibility filters) |
| — | `SubActivityDetail`, `SubActivityDetailSeeder`, `SubActivityObserver` | model/service/observer | — | [SubActivityDetailController](../SubActivityDetailController-done/01-report.md) | ↗ linked — reached via relations/events; the observer seeds detail rows inside this controller's transaction (§7) |
| — | `Config` model | model | — | [ConfigController](../ConfigController/01-report.md) | ↗ linked — `SubActivityGrouper::configuredMaxOverflow()` reads `Config::get()` |
| — | `OrganizationAcademicSession`, `Room`, `RoomType`, `Teacher`, `SchoolClass`, `Section`, `StudyFormat`, `Subject`, `SubjectStudyFormat`, `SubjectType`, `SchClassGroupsJnt`, `Constraint`, `ParallelGroup`, base `Controller`/`BaseModel`, `activityLog` helper | cross-module/common | — | common | referenced only |

**Pre-applied 2026-10-10:** this controller is listed in `../PRE-APPLIED-2026-10-10.md`. In that pass the user-facing generation message was changed to the D2 fixed form ("…now empty. The error has been logged.") and the `SnapshotProtectionException` branch was commented. This audit reviewed the result fresh. ACT-01 (the `updateLocks` catch) was not part of that pass.

## 4. Routes

```
POST   timetable-foundation/requirements/generate-activities/all    activity.generate-activities    generateActivities
PATCH  timetable-foundation/activity/{activity}/locks               activity.locks.update           updateLocks
```

Middlewares on both routes: `web, PreventAccessFromCentralDomains, InitializeTenancyByDomain, EnsureTenantIsActive, EnsureTenantHasModule:TimetableFoundation, auth, verified` (uncached `route:list --json`).
Route param `{activity}` binds `Activity`; it matches `updateLocks(UpdateActivityLocksRequest $request, Activity $activity)` and the FormRequest reads it via `$this->route('activity')` — no unbound-model insert risk.

**Unrouted public methods:** none. `route:list` covers both public methods; no `D5` work needed here.

## 5. Per-method table

| Method | Routed | Gate | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|
| updateLocks | ✅ PATCH | `tenant.timetable-foundation.activity.update` (twice — ACT-06) | ✅ `DB::transaction` closure | `Updated` (after write, in tx ✅) | tt_activities + sys_activity_logs (via `activityLog`) | ACT-01, ACT-04, ACT-06, ACT-17 |
| generateActivities | ✅ POST | `tenant.timetable-foundation.activity.generate` | TRUNCATE (outside tx, D2) + manual `DB::beginTransaction`/`commit`/`rollBack` | `Generated` (before commit, in tx ✅) | 10 tables truncated via `RequirementTableTruncator::STAGES['activities']`, then writes tt_activities, tt_activity_teachers, tt_sub_activities, tt_sub_activity_members (+ tt_sub_activity_details via observer) + sys_activity_logs | ACT-02, ACT-03, ACT-07, ACT-08, ACT-09, ACT-10, ACT-12, ACT-14, ACT-15 |

**Tables each mutation SHOULD touch:**
- **updateLocks** should write the activity row (locks) **and** the audit log. It does exactly those two, inside one transaction.
- **generateActivities** should (1) empty the four activity-family tables plus the generated timetable cells it invalidates (per `STAGES['activities']`), (2) rebuild activities, teachers, sub-activities and members, (3) log one `Generated` event. It does all three; the truncation set is the truncator's (owned by RequirementConsolidationController), the rebuild writes land in the right tables, and the detail rows the observer seeds are part of the same transaction.

## 6. Findings

### F1 — Errors
#### ACT-01 · M · ERR-00 (D1) + ERR-05 — `updateLocks` keeps a controller try/catch that logs only the message
**Where:** `ActivityController.php:63-64, 141-145`
```php
try {
    return DB::transaction(function () use ($data, $activity, $request) {
...
} catch (\Throwable $e) {
    Log::error('Activity lock update failed', [
        'activity_id' => $activity->id,
        'error' => $e->getMessage(),
    ]);
```
**Evidence:** `grep -n 'try {|catch (\Throwable|Log::error' Modules/.../ActivityController.php` → lines 63, 141, 142. The catch is not one of the D2 shapes (not a `DomainException`, not truncate-rebuild, not SnapshotProtection) and it was not touched by the 2026-10-10 pass. `$e->getMessage()` at :144 and :1129 is log-only (no leak), but the trace is lost.
**Consequence:** every lock failure loses the stack trace and returns a page message instead of the central handler's response — a 2-minute flow (PATCH from the Activities tab) that cannot be diagnosed from the log.

#### ACT-02 · M · ERR-02 — a missing current session is swallowed into an error flash, and the D2 fixed message is false on that path
**Where:** `ActivityController.php:164-166, 1137-1142`
```php
try {
    // Keep current academic session for compatibility with existing screens
    $academicSession = OrganizationAcademicSession::where('is_current', true)->firstOrFail();
...
            return redirect()->back()->with(
                'error',
                // The tables were truncated before the transaction, so they are now EMPTY.
                'Activity generation failed after this tab and all later tabs were cleared, so they are now empty. The error has been logged.'
            );
```
**Evidence:** line 166 sits **before** the truncate (`truncateFrom` at :199). A school with no current session throws `ModelNotFoundException`, which the `catch (\Throwable)` at :1108 converts into a redirect whose fixed message claims "all later tabs were cleared" — nothing was truncated yet. `SHOW COLUMNS`/`SELECT` — the tenant has a current session, so this path is not firing today but it is a normal first-run state.
**Consequence:** an administrator on a school that has not set a current session sees "your data was erased" (it was not) instead of a 404, because `firstOrFail()` sits inside the catch's reach.

#### ACT-03 · L · D2 — the SnapshotProtectionException branch is commented but does not name ERR-01 and the date
**Where:** `ActivityController.php:1109-1116`
```php
// Fail-closed snapshot refusal: NOTHING was truncated, so the generic
// "tabs are now empty" message below would be false (v5 plan T3.1).
// No transaction is open yet when it is thrown (the truncate runs first).
// SnapshotProtectionException carries a message written for the user (no SQL,
// no internals), so it is safe to show verbatim — unlike every other exception here.
if ($e instanceof SnapshotProtectionException) {
```
**Evidence:** the fixed-message comment at :1140 does name "(ERR-01, 2026-10-10)"; this branch's comment does not. D2 requires each allowed catch to name ERR-01 and the date.
**Consequence:** a future reader cannot tell that this verbatim `getMessage()` is deliberately allowed.

### F2 — Transactions / Audit
#### ACT-04 · L · TXN-05 — `updateLocks` builds the redirect/JSON inside the transaction closure
**Where:** `ActivityController.php:127-139`
```php
if ($request->wantsJson()) {
    return response()->json([ ... ]);
}
return redirect()->back()->with('success', 'Lock updated.');
```
**Evidence:** `grep -n 'wantsJson\|return redirect' ActivityController.php` → lines 127, 139; both are inside the closure at :64. Same shape the AcademicTerm audit measured as ATC-12.
**Consequence:** the success flash/JSON payload is assembled before the commit; a commit failure would still hand the user a "Lock updated." toast for a row that kept its old locks.

#### ACT-05 · M · TXN-01 — the dead service deletes then re-inserts without a transaction
**Where:** `SubActivityService.php:54-75`
```php
// Remove stale sub-activities for this parent
SubActivity::where('parent_activity_id', $activity->id)->delete();
...
for ($ordinal = 1; $ordinal <= $duration; $ordinal++) {
    SubActivity::create([ ... ]);
```
**Evidence:** `grep -n 'DB::transaction\|->delete()' SubActivityService.php` → no `DB::transaction` anywhere; delete at :55, inserts at :61. Two or more writes with no transaction.
**Consequence:** latent only (the service has no production caller — ACT-13) — if it is ever invoked, a failure mid-block leaves the parent with half its sub-activities.

### F3 — Authorization
#### ACT-06 · L · AUTH-04 — the update-lock gate is checked twice, and the policy is never consulted
**Where:** `ActivityController.php:59` + `UpdateActivityLocksRequest.php:32`
```php
Gate::authorize('tenant.timetable-foundation.activity.update');
// request:
return Gate::allows('tenant.timetable-foundation.activity.update');
```
**Evidence:** both call sites checked; the FormRequest `authorize()` runs first. The permission is seeded with an exact-name query: `SELECT name FROM sys_permissions WHERE name IN ('tenant.timetable-foundation.activity.update','tenant.timetable-foundation.activity.generate','tenant.timetable-foundation.activity.viewAny')` → all three present (8 `timetable-foundation.activity%` rows total). `ActivityPolicy` is registered at `TimetableFoundationServiceProvider.php:123` (`Gate::policy(Activity::class, ActivityPolicy::class)`), but both gates pass a **permission string**, so the policy is never consulted — module-wide pattern (§7).
**Consequence:** double authorization adds no protection; the registered policy is dead code that looks active, and its 7 methods will silently stop applying if anyone starts passing models.

### F4 — Validation
**clean** — `UpdateActivityLocksRequest` carries all input validation (typed, `exists:sch_teachers,id`, `prepareForValidation` boolean coercion, cross-field team-lock satisfiability in `withValidator()->after()`); `generateActivities()` accepts no request input, so there is nothing to validate on that path. Evidence: `grep -n 'validate(\|validated()\|->all()' ActivityController.php` → only `$request->validated()` at :61 and no `$request->all()`.

### F5 — Routes
**clean** — uncached `route:list` shows both public methods routed; writes are `POST`/`PATCH` (no RTE-01 GET); `{activity}` binds the model (RTE-06 n/a); tenant+auth middleware on both routes (RTE-05). Definition: `routes/web.php:116,121`.

### F6 — Controller shape
#### ACT-07 · M · CTL-01 — 1,624-line generation controller
**Where:** `ActivityController.php` (whole file)
**Evidence:** `wc -l` → 1,624. Between 1,000 and 2,500 → M. Only 2 public methods, so the mass is helper logic around one flow.
**Consequence:** every generation tweak is a change inside a wall of interleaved pooling/packing/room logic; fixes will keep landing on the same method (ACT-08).

#### ACT-08 · H · CTL-02 — `generateActivities()` is 987 lines
**Where:** `ActivityController.php:158-1144`
**Evidence:** method spans lines 158 to 1144 (`grep -n 'public function generateActivities'` + file read) = 987 lines, far over the 150-line H mark. `updateLocks` (:57-156, 100 lines), `resolveSharedRoomRequirement` (:1226-1311, 86) and `assignTeacherToActivity` (:1413-1556, 144) are each also over 80.
**Consequence:** this is where the single worst defect on the controller would hide; today it hides the per-requirement query fan-out (ACT-14) and the duplicate `class_group_id` key (ACT-10).

#### ACT-09 · M · CTL-10 — two private helpers are dead
**Where:** `ActivityController.php:1334` and `:1393`
```php
private function getRoomCapacity(?int $classId = null, ?int $roomTypeId = null): int
private function calculateGroupsNeeded(int $studentCount, int $roomCapacity): int
```
**Evidence:** `grep -n 'getRoomCapacity\|calculateGroupsNeeded' ActivityController.php` → only the definitions; no call site in the file or elsewhere (`grep -rn` across `Modules/` → none outside the controller).
**Consequence:** maintenance dead weight; `getRoomCapacity` even documents a default of 35 in its docblock while returning 50.

#### ACT-10 · L · dead/duplicate — a duplicated array key and three throwaway count queries
**Where:** `ActivityController.php:321-323, 1012-1014, 1090-1095`
```php
'class_group_id' => null,
'have_sub_activity' => false,
'class_group_id' => $group->id,
...
$totalActivitiesInDb = Activity::count();
$classGroupActivities = Activity::whereNotNull('class_group_id')->count();
$consolidatedActivitiesInDb = Activity::where(function ($q) {
    $q->where('code', 'like', 'ACT-SAC-%')->orWhere('code', 'like', 'ACT-SAS-%');
})->count();
```
**Evidence:** PHP keeps the last duplicated key (no behaviour change, but the first `null` is a lie); `consolidatedActivitiesInDb` is never used — the flash uses `$consolidatedActivities->count()` at :1099 — and its `LIKE` patterns (`ACT-SAC-%`/`ACT-SAS-%`) match none of the codes this generator creates (`ACT-CG-`, `ACT-SHR-`, `ACT-SG-`).
**Consequence:** a reader cannot tell which `class_group_id` wins, and three unnecessary queries run after every generation for a number nobody reads.

### F7 — Models
#### ACT-11 · L · MDL-02 — `ActivityTeacher` casts a column that does not exist
**Where:** `ActivityTeacher.php:43`
```php
'preference_score' => 'integer',
```
**Evidence:** tenant probe `SHOW COLUMNS FROM tt_activity_teachers` → columns are `id, is_required, ordinal, is_active, activity_id, teacher_id, assignment_role_id, created_at, updated_at, deleted_at` — no `preference_score`.
**Consequence:** casts on a missing attribute silently return null and mask the fact that the column is gone — a leftover from the model's older shape.

**Rest of F7 — checked, clean:** `$fillable` on all five models declared; nothing sensitive inside; `$casts` cover the boolean/date/decimal/JSON columns that exist; `$table` for each model verified in the tenant (`tt_activities`, `tt_activity_teachers`, `tt_sub_activities`, `tt_sub_activity_members`, `tt_activity_priorities`); `SoftDeletes` present exactly where `deleted_at` exists; relationships return-typed. `SubActivityMember`/`SubActivity` use `HasMany` (no `belongsToMany` pivot, so MDL-03 `wherePivotNull` does not apply). `tt_activities.total_periods` **does** exist (smallint unsigned null), so `Activity::totalRequiredPeriods()` is not a missing-column trap. `tt_activity_priorities.activity_id` has a UNIQUE (`uq_activity_priority`) — matching `ActivityPriorityCalculator::persist()`'s upsert key.

### F8 — Services / Jobs
#### ACT-12 · M · SVC-02 — services resolved via `app()` instead of constructor injection
**Where:** `ActivityController.php:199`, `UpdateActivityLocksRequest.php:88`
```php
app(RequirementTableTruncator::class)->truncateFrom('activities');
// request:
$service = app(ActivityLockService::class);
```
**Evidence:** neither the controller nor the FormRequest has a `__construct`; both wire via the container mid-method.
**Consequence:** the dependencies are invisible in tests and harder to swap; a future constructor injection pass has to touch both classes.

#### ACT-13 · M · SVC-04 + dead feature — `SubActivityService` is a second, broken implementation of sub-activity generation
**Where:** `SubActivityService.php:48-75` (whole class)
```php
SubActivity::create([
    'parent_activity_id' => $activity->id,
    'code' => $activity->code . '_P' . $ordinal,          // not a column, not fillable
    'class_requirement_subgroups' => $activity->class_subgroup_id,  // wrong key, not fillable
    ...
]);
```
**Evidence:** `SHOW COLUMNS FROM tt_sub_activities` → no `code` column; `class_requirement_subgroup_id` is INT UNSIGNED NOT NULL. `SubActivity::$fillable` has `class_requirement_subgroup_id`, not `class_requirement_subgroups`. Both keys are discarded by mass assignment, so the insert sends `class_requirement_subgroup_id = NULL` → SQL 1048 on this schema. `grep -rn 'SubActivityService' Modules --include='*.php'` → no production caller; only `tests/Unit/ServiceTest.php` asserts the class exists and has these methods (D4: tests not run).
**Consequence:** the service is a latent duplicate of the working generator inside `generateActivities()`; if any future controller calls it, every activity it touches crashes with SQL 1048 instead of building groups.

### F9 — Queries / Performance
#### ACT-14 · M · QRY-01 — the generation loop re-queries the same lookups per requirement and per teacher
**Where:** `ActivityController.php:277-283, 289, 1510-1514`
```php
$teachersCount = TeacherAvailability::query()      // one per requirement row
    ->where('class_id', $group->class_id)...
$roomsCount = $group->roomType?->rooms?->count() ?? 0;   // lazy roomType + rooms, not eager-loaded
...
$teacherRow = DB::table('sch_teacher_profile as tp')     // one per eligible teacher
    ->leftJoin('sch_teachers as t', 'tp.user_id', '=', 't.user_id')...
```
**Evidence:** `Requirements` are loaded once (`->get()` at :219) but STEP 2 loops per requirement (`foreach ($classGroupReqs as $req)` at :258) and each iteration issues a `TeacherAvailability` aggregate plus two lazy relation queries (`roomType`, `rooms`) that are not in the `with([...])` at :213-218. `assignTeacherToActivity` (:1413) then runs a `TeacherAvailability` query per activity and one `sch_teacher_profile` lookup per candidate teacher. On this tenant: 599 activities / 1,029 teacher rows → roughly 1,200+ DB round-trips per generation.
**Consequence:** a generation run on a larger school can exhaust the 5-minute budget (`set_time_limit(300)`) and fail empty (truncate already committed), or simply make the Generate button un-usable.

**QRY-07 (bulk writes) — checked, not present as a defect:** the `SubActivity::create`/`SubActivityMember::create` per-group calls at :922/:939 each need the just-created ids, so per-row inserts are inherent there; the teacher `updateOrCreate` at :1542 is guarded by `uq_at_activity_teacher` and deduplicated (`unique('teacher_profile_id')`) — a bulk path would not be faster.

### F10 — Views
**checked, not present** — the controller renders no view (`grep -n "view("` → none of its own; both methods `redirect()->back()`). The blades that POST/PATCH to these routes (`timetable-preparation/activities/_list.blade.php`, `_teacher-lock.blade.php`) are rendered by `TimetableFoundationController` and are that controller's scope (§7).

### F11 — Security / Tenancy
#### ACT-15 · M · TEN-02 — a per-tenant role cache lives in a static across requests
**Where:** `ActivityController.php:1422-1434`
```php
static $cachedPrimaryRole = null;
static $cachedAssistantRole = null;
static $cachedFallbackRole = null;
static $rolesLoaded = false;
if (! $rolesLoaded) {
    $allRoles = TeacherAssignmentRole::where('is_active', true)->get();
```
**Evidence:** the static is process-wide and holds tenant DB rows (`tt_teacher_assignment_roles`) with no tenant key. Under plain FPM each request is a fresh process, so this is latent; under Octane/a queue worker, tenant B's generation would reuse tenant A's roles. `SubActivityGrouper`'s statics (`largestActiveRoomCapacity()` at :177, `configuredMaxOverflow()` at :262) document the same accepted risk; this one has no such comment.
**Consequence:** on a long-running process, a second school's generation assigns roles from the first school's database.

**Rest of F11 — checked, clean:** no `env()` outside config; `updateLocks` returns only lock fields as JSON (no personal data); no hard-coded ids (`?? 1` absent); no request-body logging; `SHOW` probes confirmed activity ids are per-tenant rows.

### F12 — Style
#### ACT-16 · L · STY-01/02/04/06 — one item per file (detailed in the fix plan)
**Evidence:** `head -4` on the in-scope files shows `declare(strict_types=1)` only in `ActivityExporter.php` and `ActivityPriorityCalculator.php`. `\Log::error` (FQN) at `ActivityController.php:1128` vs imported `Log` at :142 (STY-06); `\Log::info` at `SubActivityService.php:77`. The module's `⛔`/`⚠` comment convention (STY-04) appears in every in-scope file; the controller also has no return types on its two public methods and this module's blades — not part of this report's scope.

### F13 — Deep read
#### ACT-17 · L · deep-read #7 — the lock docblock overstates what the FormRequest checks
**Where:** `ActivityController.php:49-53` vs `UpdateActivityLocksRequest.php:72-111`
```php
⛔ THE GENERATOR TREATS THESE AS HARD CONSTRAINTS. ... Satisfiability is
checked in the FormRequest so an impossible lock is refused at the form...
```
**Evidence:** the FormRequest's `withValidator()->after()` probes **only the teacher lock** (`lock_mode`/`locked_teacher_id` via `ActivityLockService`). The room-type lock (`compulsory_specific_room_type`) is never checked for satisfiability — an activity locked to a room type with no usable room is discovered as an unplaced lesson, not refused at the form.
**Consequence:** the comment promises "refused at the form" for all three locks; only two thirds of the promise is true, so a future developer will trust a check that is not there.

**Deep-read answers folded in:** (1) no write overwrites data it should not — the rebuild is truncate-first by design (D2); (2) nothing is deleted before its replacement is stored, except the accepted truncate contract; (3) **duplicate implementations found** — ACT-13; (4) no soft-delete × unique trap after truncate (rows are re-inserted with fresh ids; `uq_activity_code` is safe); (5) race: generation is truncate-first and the pipeline tab lock serialises it; `resolveTeacherId`'s `firstOrCreate` relies on `sch_teachers.user_id` uniqueness, which is respected today (0 unmapped on this tenant); (6) authorization holes: both routed methods gate before loading ✓; (7) messages that lie — ACT-02 and ACT-17; (8) dead features — ACT-09, ACT-10, ACT-13.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

- **Module-wide: policies are unreachable because every gate passes a permission string.** `ActivityPolicy` (registered at `TimetableFoundationServiceProvider.php:123`) is never consulted; same pattern as `AcademicTermPolicy` in the AcademicTerm report (ATC-14). Needs a module-level decision (00-SUMMARY territory).
- **`SubActivityObserver` (TimetableFoundation) seeds `tt_sub_activity_details` inside this controller's transaction** via `SubActivityDetailSeeder` — the detail rows this report counted as part of the generation write. The seeder's correctness belongs to the SubActivityDetail report.
- **The locking blades** (`timetable-preparation/activities/_list.blade.php`, `_teacher-lock.blade.php`) render via `TimetableFoundationController` and use route `timetable-foundation.activity.locks.update` and `ActivityLockService`. Any VIEW-family defect there is that controller's report.
- **`RequirementTableTruncator`** is used correctly by this controller (outside its transaction, per its contract) — its correctness is the RequirementConsolidation report's.
- **`SubActivityGrouper` static caches** (`largestActiveRoomCapacity`, `configuredMaxOverflow`) hold the same long-running-process risk as ACT-15, but they are documented as accepted by design; the fix decision for ACT-15 can cover them.

## 8. Not covered, and why

- **Runtime behaviour:** no browser/test run (D4). Every finding is a static read or a read-only SQL probe.
- **The two blades that POST to `activity.locks.update`:** owned by TimetableFoundationController (F10 walk stops at this controller, which renders nothing).
- **Other writers and readers of `tt_activities`:** `TimetableFoundationController` (prep/dashboard tabs), the Python bridge via `ActivityExporter`, and the `SubActivityDetail`/`ParallelGroup` surfaces were not re-audited here; they are other reports' scope.
- **`tests/Unit/ServiceTest.php` and `ControllerAuthTest` interactions:** D4 — the team must verify that any ACT-13 change does not break the service-existence assertions.
- **Data repair:** none needed; no orphaned `tt_activity_priorities` (0 orphans on this tenant) and no trashed rows in any of the five tables today.