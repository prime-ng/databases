# 03 — Status · DayTypeController

**Fixed:** 2026-10-12 · **By:** claude · **Branch:** development
**Decisions (Tarun):** DTC-12 + DTC-13 (a) refuse trash and permanent delete while in use · DTC-03 (a) validator checks trashed rows · DTC-05 + DTC-06 (a) PATCH restore and `{dayType}` binding · DTC-09 (a) repoint to `classWorkingDays()`.

## 1. Pre-applied 2026-10-10
None.

## 2. Applied

| ID | File:line | What changed | Verify | Output | Date |
|---|---|---|---|---|---|
| DTC-12 | DayTypeController `forceDelete()` | `onlyTrashed()->findOrFail()`; `refuseIfInUse()` counts `tt_working_days.day_type1..4_id` and `tt_class_working_days_jnt.day_type_id` (the second has NO foreign key); only `DomainException` caught | probe: forceDelete a LIVE id | 404 | 2026-10-12 |
| DTC-13 | `destroy()` | same `refuseIfInUse()` before trashing | probe: destroy WD | "…still used by 621 working day(s), 4620 class working day(s)." — row stays live | 2026-10-12 |
| DTC-01 | all 6 mutations | try/catch and `Log::error` removed; transactions kept; `DomainException` catch only in destroy/forceDelete | `grep -c "Throwable\|Log::"` | 0 | 2026-10-12 |
| DTC-02 | `store()`, `update()` | duplicate `Gate::authorize` removed; `DayTypeRequest::authorize()` gates them | read | — | 2026-10-12 |
| DTC-03 | DayTypeRequest | `Rule::unique(...)->whereNull('deleted_at')` replaced by `uniqueIncludingTrashed()` on code/name/ordinal; code compared upper-cased (store upper-cases it) | probe validator | trashed: "A trashed day type already uses this code — restore it instead." · live: "The code has already been taken." | 2026-10-12 |
| DTC-04 | DayTypeRequest | `is_active` gains `boolean` (create `required\|boolean`, update `nullable\|boolean`); the switch posts `value="1"` | probe | `on` rejected, `1` accepted | 2026-10-12 |
| DTC-05 | routes/web.php | restore `Route::get` → `Route::patch`; `action-trashed` derives the verb, no blade edit | route:list | `PATCH timetable-foundation/day-type/{id}/restore` | 2026-10-12 |
| DTC-06 | routes/web.php + controller | `->parameters(['day-type' => 'dayType'])`; `show/edit/update/destroy` bind `DayType $dayType` (restore/forceDelete keep `$id`); request reads `route('dayType')` | route:list + probe | OK | 2026-10-12 |
| DTC-09 | DayType model | `timetableTypes()` (non-existent column) → `classWorkingDays(): HasMany` on `tt_class_working_days_jnt.day_type_id` | probe | 4620 rows on WD | 2026-10-12 |
| DTC-10 | views/day-type/create.blade.php | deleted after re-proving no `view()` reference and no `create` route | grep + route:list | 0 refs | 2026-10-12 |
| DTC-11a-d | Controller, Request, Model, Policy | `strict_types`; controller return types on all 11 methods | php -l, Pint | clean | 2026-10-12 |

## 3. Not applied
None — all 14 items ticked.

## 4. Needs Tarun's hand
- **TtDayTypeTest `test_25_not_found_restore`** (both copies — `prime_ai/tests/...` and `prime_testing/tests/...`) visits `GET /timetable-foundation/day-type/999999999/restore` and expects 404. Restore is PATCH now, so expect 405 (or the DecryptUrl redirect). Same as TtShiftTest test_25. `test_12` (restore via the button) is unaffected. Not edited (D4).
- Browser check: trash the "Working Day" type from the tab → red message naming both tables.

## 5. Cross-cutting (not fixed here)
- `Modules/SmartTimetable/.../partials/day-types/_list.blade.php:42` and `.../partials/working-days/_list.blade.php:45` call `route('timetable-foundation.day-type.create')` with no `Route::has` guard. That route has not existed since 2026-09-10, so pages including them throw RouteNotFoundException — same family as the shift partial. Other module; needs its own instruction.
- `Modules/TimetableFoundation/tests/Feature/RouteAuthenticationTest.php:82` lists `timetable-foundation.day-type.create` as a route — stale since TM-05.

## 6. Verification log
```
php -l + Pint (5 files)                       clean (Pint reordered DayTypeRequest imports)
route:list --path=day-type                    10 routes, {dayType} binding, restore = PATCH
rolled-back probe:
  destroy WD (in use)        refused, names 621 / 4620, still live
  forceDelete live id        404
  new unused type: destroy -> trashed; dup code vs trashed -> "restore it instead"
                   restore -> live+active; destroy + forceDelete -> gone
  logs: Trashed, Restored, Trashed, Deleted
  after rollback: 0 probe rows
```

## 7. Final state
FIXED. Open: 0 (the two cross-cutting notes belong to other files).
