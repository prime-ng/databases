#!/usr/bin/env python3
"""
Print ONLY the scanner rows for the files in one audit's scope — final-audit.md §6 Instruments.

The scan output is ~12 MB / ~34,000 rows. ⛔ Never cat, head or read it directly: it floods the
context. Use this instead.

Usage (from prime_ai/):
    python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-<ctrl>.json <path> [<path> ...]

Each <path> is a file path or a prefix, e.g.
    Modules/TimetableFoundation/app/Http/Controllers/ActivityController.php
    Modules/TimetableFoundation/app/Models/Activity.php
    Modules/TimetableFoundation/resources/views/activity/
Output: one line per finding, sorted by file and line:  SEV  RULE  file:line  method — message
"""
import json
import sys

if len(sys.argv) < 3:
    print(__doc__)
    sys.exit(2)
data = json.load(open(sys.argv[1]))
rows = data.get('findings', data) if isinstance(data, dict) else data
paths = sys.argv[2:]
hit = [r for r in rows if any(str(r.get('file', '')).startswith(p) for p in paths)]
hit.sort(key=lambda r: (r.get('file', ''), int(r.get('line') or 0)))
for r in hit:
    msg = str(r.get('msg', '')).replace('\n', ' ')[:160]
    print(f"{r.get('sev','?'):1}  {r.get('rule','?'):7}  {r.get('file')}:{r.get('line')}  {r.get('method') or '-'} — {msg}")
print(f"\n{len(hit)} scanner rows for {len(paths)} path(s). Candidates only — confirm each in source (§6).")
