<?php

/**
 * Pre-deployment static scanner — implements the `S` / `S~` rules of 00-RULEBOOK.md.
 *
 * Read-only. Parses PHP with nikic/php-parser (from prime_ai/vendor), greps Blade, reads a
 * route list exported with `APP_ROUTES_CACHE=<missing file> php artisan route:list --json`.
 *
 * Usage: php scan.php <prime_ai root> <routes.json> <out findings.json>
 */

declare(strict_types=1);

use PhpParser\Node;
use PhpParser\Node\Expr;
use PhpParser\Node\Stmt;
use PhpParser\NodeFinder;
use PhpParser\ParserFactory;
use PhpParser\PrettyPrinter\Standard as Printer;

[$_, $root, $routesFile, $outFile] = $argv + [null, null, null, null];
if (! $root || ! $routesFile || ! $outFile) {
    fwrite(STDERR, "usage: php scan.php <prime_ai root> <routes.json> <out.json>\n");
    exit(1);
}
$root = rtrim(realpath($root), '/');
require $root.'/vendor/autoload.php';

$parser = (new ParserFactory)->createForNewestSupportedVersion();
$finder = new NodeFinder;
$printer = new Printer;
$findings = [];
$stats = ['files' => 0, 'parse_errors' => [], 'by_layer' => []];

// ─────────────────────────────────────────────────────────────── helpers

function rel(string $path): string
{
    global $root;

    return ltrim(substr($path, strlen($root)), '/');
}

function moduleOf(string $rel): string
{
    return preg_match('#^Modules/([^/]+)/#', $rel, $m) ? $m[1] : 'app';
}

function layerOf(string $rel): ?string
{
    return match (true) {
        str_contains($rel, '/Http/Controllers/') => 'controller',
        str_contains($rel, '/Http/Requests/') => 'request',
        (bool) preg_match('#/Models/#', $rel) => 'model',
        (bool) preg_match('#/Services?/#', $rel), str_contains($rel, '/Actions/') => 'service',
        str_contains($rel, '/Jobs/') => 'job',
        str_contains($rel, '/Listeners/') => 'listener',
        str_contains($rel, '/Console/') || str_contains($rel, '/Commands/') => 'command',
        default => null,
    };
}

function add(string $rule, string $sev, string $file, int $line, string $msg, string $method = '', array $extra = []): void
{
    global $findings;
    $findings[] = [
        'rule' => $rule, 'sev' => $sev, 'module' => moduleOf($file), 'layer' => layerOf($file) ?? 'other',
        'file' => $file, 'line' => $line, 'method' => $method, 'msg' => $msg,
    ] + $extra;
}

function callName(Node $n): ?string
{
    if (($n instanceof Expr\MethodCall || $n instanceof Expr\NullsafeMethodCall || $n instanceof Expr\StaticCall)
        && $n->name instanceof Node\Identifier) {
        return $n->name->toString();
    }
    if ($n instanceof Expr\FuncCall && $n->name instanceof Node\Name) {
        return $n->name->toString();
    }

    return null;
}

function staticClass(Node $n): ?string
{
    if ($n instanceof Expr\StaticCall && $n->class instanceof Node\Name) {
        $parts = explode('\\', $n->class->toString());

        return end($parts);
    }

    return null;
}

/** True when a static call targets an Eloquent model (resolved FQCN) or the DB facade. */
function isModelCall(Node $n): bool
{
    global $modelFq;
    if (! $n instanceof Expr\StaticCall || ! $n->class instanceof Node\Name) {
        return false;
    }
    $fq = ltrim(($n->class->getAttribute('resolvedName') ?? $n->class)->toString(), '\\');

    return isset($modelFq[$fq]) || in_array($fq, ['DB', 'Illuminate\\Support\\Facades\\DB'], true);
}

/** Walk a method-call chain down to its root expression. */
function chainRoot(Expr $e): Expr
{
    while ($e instanceof Expr\MethodCall || $e instanceof Expr\NullsafeMethodCall) {
        $e = $e->var;
    }

    return $e;
}

/** Names of every call in a chain, root first. */
function chainNames(Expr $e): array
{
    $names = [];
    while ($e instanceof Expr\MethodCall || $e instanceof Expr\NullsafeMethodCall) {
        if ($e->name instanceof Node\Identifier) {
            $names[] = $e->name->toString();
        }
        $e = $e->var;
    }
    if ($e instanceof Expr\StaticCall && $e->name instanceof Node\Identifier) {
        $names[] = $e->name->toString();
    }

    return array_reverse($names);
}

function containsCall(Node|array $node, array $names): bool
{
    global $finder;

    return (bool) $finder->findFirst(is_array($node) ? $node : [$node], fn (Node $n) => in_array(callName($n), $names, true));
}

function lines(Node $n): int
{
    return $n->getEndLine() - $n->getStartLine() + 1;
}

// ─────────────────────────────────────────────────────────────── inventory

$phpFiles = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/Modules', FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    $p = $f->getPathname();
    if (str_ends_with($p, '.php') && str_contains($p, '/app/') && ! str_ends_with($p, '.blade.php')) {
        $phpFiles[] = $p;
    }
}
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/app', FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    if (str_ends_with($f->getPathname(), '.php')) {
        $phpFiles[] = $f->getPathname();
    }
}
sort($phpFiles);

// Migrations → tables, soft-delete tables.
$tables = [];
$softTables = [];
$migDirs = [$root.'/database/migrations'];
foreach (glob($root.'/Modules/*/database/migrations', GLOB_ONLYDIR) as $d) {
    $migDirs[] = $d;
}
foreach ($migDirs as $d) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if (! str_ends_with($f->getPathname(), '.php')) {
            continue;
        }
        $src = file_get_contents($f->getPathname());
        // Split on Schema:: so each block is one create/table call.
        foreach (preg_split('/Schema::/', $src) as $block) {
            if (preg_match('/^(?:connection\([^)]*\)->)?(create|table)\(\s*[\'"]([A-Za-z0-9_]+)[\'"]/', $block, $m)) {
                if ($m[1] === 'create') {
                    $tables[$m[2]] = true;
                }
                if (preg_match('/softDeletes|[\'"]deleted_at[\'"]/', $block)) {
                    $softTables[$m[2]] = true;
                }
            }
            if (preg_match('/^rename\(\s*[\'"]([A-Za-z0-9_]+)[\'"]\s*,\s*[\'"]([A-Za-z0-9_]+)[\'"]/', $block, $m)) {
                $tables[$m[2]] = true;
            }
        }
        // Raw CREATE TABLE in DB::statement / unprepared.
        if (preg_match_all('/CREATE TABLE (?:IF NOT EXISTS )?`?([A-Za-z0-9_]+)`?/i', $src, $mm)) {
            foreach ($mm[1] as $t) {
                $tables[$t] = true;
            }
        }
    }
}
// Raw SQL dumps that some environments load instead of migrations.
foreach (glob($root.'/database/*.sql') ?: [] as $sql) {
    if (preg_match_all('/CREATE TABLE (?:IF NOT EXISTS )?`?([A-Za-z0-9_]+)`?/i', file_get_contents($sql), $mm)) {
        foreach ($mm[1] as $t) {
            $tables[$t] = true;
        }
    }
}

// Routes.
$routes = json_decode(file_get_contents($routesFile), true);
$routed = [];          // "FQCN@method" => [route rows]
$routedClasses = [];   // FQCN => true
foreach ($routes as $r) {
    $a = $r['action'] ?? '';
    if (! str_contains($a, '@')) {
        if (str_contains($a, '\\') && $a !== 'Closure') { // invokable
            $a .= '@__invoke';
        } else {
            continue;
        }
    }
    $routed[$a][] = $r;
    $routedClasses[explode('@', $a)[0]] = true;
}

// ─────────────────────────────────────────────────────────────── pass 1: parse + index

$asts = [];
$classIndex = [];      // FQCN => ['file','methods'=>[name=>ClassMethod],'node'=>Class_]
$modelShort = [];      // short model class names
$modelFq = [];         // FQCN of every model
$formRequests = [];    // short name => 'strong'|'weak'
foreach ($phpFiles as $path) {
    $src = file_get_contents($path);
    try {
        $ast = $parser->parse($src);
    } catch (Throwable $e) {
        $stats['parse_errors'][] = rel($path).': '.$e->getMessage();
        add('CTL-09', 'B', rel($path), 1, 'PHP parse error — fatal when loaded: '.$e->getMessage());

        continue;
    }
    $nr = new PhpParser\NodeTraverser(new PhpParser\NodeVisitor\NameResolver(null, ['replaceNodes' => false]));
    $ast = $nr->traverse($ast);
    $asts[$path] = [$ast, $src];
    $ns = $finder->findFirstInstanceOf($ast, Stmt\Namespace_::class);
    foreach ($finder->findInstanceOf($ast, Stmt\Class_::class) as $cls) {
        if (! $cls->name) {
            continue;
        }
        $fq = ($ns && $ns->name ? $ns->name->toString().'\\' : '').$cls->name->toString();
        $methods = [];
        foreach ($cls->getMethods() as $m) {
            $methods[$m->name->toString()] = $m;
        }
        $classIndex[$fq] = ['file' => $path, 'methods' => $methods, 'node' => $cls];
        $r = rel($path);
        if (layerOf($r) === 'model') {
            $modelShort[$cls->name->toString()] = true;
            $modelFq[$fq] = true;
        }
        if (layerOf($r) === 'request' && isset($methods['authorize'])) {
            $body = $printer->prettyPrint($methods['authorize']->stmts ?? []);
            $strong = preg_match('/can\(|Gate::|hasPermission|hasRole|hasAnyRole|authorize|permission/i', $body);
            $formRequests[$cls->name->toString()] = $strong ? 'strong' : 'weak';
        }
    }
}
$modelShort += ['DB' => true];

// ─────────────────────────────────────────────────────────────── pass 2: rules

$authCalls = ['authorize', 'authorizeResource', 'allows', 'denies', 'any', 'check', 'inspect', 'can', 'cannot', 'canAny', 'hasPermissionTo', 'hasRole', 'hasAnyRole', 'abort_unless', 'abort_if'];
$queryStarters = ['where', 'whereIn', 'whereHas', 'find', 'findOrFail', 'first', 'firstOrFail', 'firstWhere', 'query', 'select', 'count', 'exists', 'pluck', 'value', 'get', 'with', 'all', 'table', 'orderBy', 'latest', 'withTrashed', 'onlyTrashed', 'whereNull', 'whereNotNull', 'max', 'sum', 'min'];
$writeNames = ['create', 'insert', 'update', 'save', 'delete', 'forceDelete', 'restore', 'updateOrCreate', 'firstOrCreate', 'upsert', 'increment', 'decrement', 'sync', 'attach', 'detach', 'syncWithoutDetaching', 'insertGetId', 'updateExistingPivot', 'push'];
$readMethodRe = '/^(index|show|create|edit|trash(ed)?|get[A-Z].*|list.*|search.*|fetch.*|load.*|export.*|print.*|download.*|view.*|report.*)$/';

foreach ($asts as $path => [$ast, $src]) {
    $r = rel($path);
    $layer = layerOf($r);
    $stats['files']++;
    $stats['by_layer'][$layer ?? 'other'] = ($stats['by_layer'][$layer ?? 'other'] ?? 0) + 1;
    $isCtl = $layer === 'controller';
    $srcLines = explode("\n", $src);

    // ── file-level: strict types, debug calls, env(), emoji/debug comments, duplicate imports
    if (! preg_match('/declare\s*\(\s*strict_types\s*=\s*1\s*\)/', $src)) {
        add('STY-01', 'L', $r, 1, 'missing declare(strict_types=1)');
    }
    foreach ($finder->find($ast, fn (Node $n) => $n instanceof Expr\FuncCall && in_array(callName($n), ['dd', 'dump', 'var_dump', 'ray', 'phpinfo', 'ddd'], true)) as $n) {
        add('CTL-09', 'B', $r, $n->getStartLine(), 'live debug call '.callName($n).'()');
    }
    foreach ($finder->find($ast, fn (Node $n) => $n instanceof Expr\FuncCall && callName($n) === 'print_r' && count($n->args) < 2) as $n) {
        add('CTL-09', 'B', $r, $n->getStartLine(), 'print_r() writes to output');
    }
    foreach ($srcLines as $i => $l) {
        if (preg_match('#^\s*(//|\*|\#).*\b(dd|dump|var_dump)\s*\(#', $l)) {
            add('CTL-09', 'M', $r, $i + 1, 'commented-out debug call: '.trim($l));
        }
        if (preg_match('#(//|\*).*[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{2705}\x{274C}]#u', $l)) {
            add('STY-04', 'L', $r, $i + 1, 'emoji in comment');
        }
        if (preg_match('#(//|\*)\s*.*\b(TEMP(ORARY)?|DEBUG|HACK|FIXME|XXX)\b#', $l)) {
            add('STY-04', 'L', $r, $i + 1, 'temporary/debug marker: '.trim(mb_substr($l, 0, 140)));
        }
        if (str_contains($l, '\\Log::')) {
            add('STY-06', 'L', $r, $i + 1, '\\Log:: instead of imported Log');
        }
        if (preg_match('#asset\(\s*[\'"]storage/#', $l)) {
            add('TEN-04', 'M', $r, $i + 1, "asset('storage/…') instead of tenant_asset()");
        }
    }
    if (! str_contains($r, '/config/') && ! str_starts_with($r, 'config/')) {
        foreach ($finder->find($ast, fn (Node $n) => $n instanceof Expr\FuncCall && callName($n) === 'env') as $n) {
            add('SEC-01', 'B', $r, $n->getStartLine(), 'env() outside config/ — returns null under config:cache');
        }
    }
    $uses = [];
    foreach ($finder->findInstanceOf($ast, Stmt\Use_::class) as $u) {
        foreach ($u->uses as $uu) {
            $uses[$uu->name->toString()][] = $u->getStartLine();
        }
    }
    foreach ($uses as $fq => $ls) {
        if (count($ls) > 1) {
            add('STY-05', 'L', $r, $ls[1], "class imported twice: $fq");
        }
    }

    foreach ($finder->findInstanceOf($ast, Stmt\Class_::class) as $cls) {
        $methods = $cls->getMethods();
        $className = $cls->name?->toString() ?? '?';
        $fq = null;
        foreach ($classIndex as $k => $v) {
            if ($v['node'] === $cls) {
                $fq = $k;
                break;
            }
        }

        // ── CTL-01 god class
        if (in_array($layer, ['controller', 'service'], true)) {
            $pub = count(array_filter($methods, fn ($m) => $m->isPublic() && ! str_starts_with($m->name->toString(), '__')));
            $len = lines($cls);
            if ($len > 1000 || $pub > 25) {
                add('CTL-01', $len > 2500 ? 'H' : 'M', $r, $cls->getStartLine(), "$className: $len lines, $pub public methods", '', ['size' => $len, 'public' => $pub]);
            }
        }

        // ── repeated literal arrays (enum lists, payloads) and repeated route strings
        $arrays = [];
        foreach ($finder->findInstanceOf($cls, Expr\Array_::class) as $arr) {
            if (count($arr->items) >= 4 && $arr->getStartLine() !== $arr->getEndLine()) {
                $allConst = ! $finder->findFirst($arr, fn (Node $n) => $n instanceof Expr\Variable || $n instanceof Expr\MethodCall || $n instanceof Expr\StaticCall || $n instanceof Expr\FuncCall || $n instanceof Expr\ArrayDimFetch);
                $key = md5($printer->prettyPrintExpr($arr));
                $arrays[$key][] = [$arr->getStartLine(), count($arr->items), $allConst];
            }
        }
        foreach ($arrays as $occ) {
            if (count($occ) >= 3 || (count($occ) >= 2 && $occ[0][1] >= 6)) {
                add('CTL-05', 'M', $r, $occ[0][0], sprintf('identical %d-item array literal repeated %d× (lines %s)', $occ[0][1], count($occ), implode(',', array_column($occ, 0))));
            }
        }
        if ($isCtl) {
            $routeStr = [];
            foreach ($finder->find($cls, fn (Node $n) => $n instanceof Expr\FuncCall && in_array(callName($n), ['route', 'to_route'], true) && isset($n->args[0]) && $n->args[0]->value instanceof Node\Scalar\String_) as $n) {
                $routeStr[$n->args[0]->value->value][] = $n->getStartLine();
            }
            foreach ($routeStr as $name => $ls) {
                if (count($ls) >= 6) {
                    add('CTL-05', 'L', $r, $ls[0], "route('$name') repeated ".count($ls).'× — extract a redirect helper');
                }
            }
        }

        // ── private methods never used
        $text = $printer->prettyPrint([$cls]);
        foreach ($methods as $m) {
            if ($m->isPrivate()) {
                $name = $m->name->toString();
                if (preg_match_all('/(->|::|\?->)'.preg_quote($name, '/').'\b|[\'"]'.preg_quote($name, '/').'[\'"]/', $text) === 0) {
                    add('CTL-10', 'M', $r, $m->getStartLine(), "private method $name() is never called", $name);
                }
            }
        }

        // ── models
        if ($layer === 'model') {
            $props = [];
            foreach ($cls->getProperties() as $p) {
                foreach ($p->props as $pp) {
                    $props[$pp->name->toString()] = $pp;
                }
            }
            if (isset($props['guarded']) && $props['guarded']->default instanceof Expr\Array_ && count($props['guarded']->default->items) === 0) {
                add('MDL-01', 'H', $r, $props['guarded']->getStartLine(), "$className: \$guarded = [] (everything mass-assignable)");
            }
            if (isset($props['table']) && $props['table']->default instanceof Node\Scalar\String_) {
                $t = $props['table']->default->value;
                $t = preg_replace('/^[a-z_]+\./', '', $t);
                if (! isset($tables[$t])) {
                    add('MDL-07', 'B', $r, $props['table']->getStartLine(), "$className: table '$t' is not created by any migration");
                }
            }
            $traits = [];
            foreach ($cls->getTraitUses() as $tu) {
                foreach ($tu->traits as $tn) {
                    $parts = explode('\\', $tn->toString());
                    $traits[end($parts)] = true;
                }
            }
            $methodNames = array_map(fn ($m) => $m->name->toString(), $methods);
            if (isset($traits['InteractsWithMedia']) && ! in_array('getMediaModel', $methodNames, true)
                && ! str_starts_with($r, 'Modules/Prime/') && ! str_starts_with($r, 'app/Models/Central')) {
                add('MDL-05', 'B', $r, $cls->getStartLine(), "$className uses InteractsWithMedia without getMediaModel() — media rows go to the central DB");
            }
            // casts coverage
            if (isset($props['fillable']) && $props['fillable']->default instanceof Expr\Array_) {
                $fill = [];
                foreach ($props['fillable']->default->items as $it2) {
                    if ($it2?->value instanceof Node\Scalar\String_) {
                        $fill[] = $it2->value->value;
                    }
                }
                $castSrc = isset($props['casts']) ? $printer->prettyPrintExpr($props['casts']->default ?? new Expr\Array_) : '';
                if (isset($methods['casts']) || in_array('casts', $methodNames, true)) {
                    $castSrc .= $printer->prettyPrint($cls->getMethod('casts')->stmts ?? []);
                }
                $missing = array_filter($fill, fn ($c) => preg_match('/^(is_|has_|allow_|can_)|_(at|date|json)$/', $c) && ! str_contains($castSrc, "'$c'"));
                if ($missing) {
                    add('MDL-02', 'M', $r, $props['fillable']->getStartLine(), "$className: no cast for ".implode(', ', array_slice($missing, 0, 8)).(count($missing) > 8 ? ' …' : ''));
                }
            }
            // relationship return types + soft pivots
            foreach ($methods as $m) {
                $relCall = $finder->findFirst($m->stmts ?? [], fn (Node $n) => $n instanceof Expr\MethodCall && in_array(callName($n), ['belongsTo', 'hasMany', 'hasOne', 'belongsToMany', 'morphTo', 'morphMany', 'morphOne', 'hasManyThrough', 'hasOneThrough', 'morphToMany', 'morphedByMany'], true) && $n->var instanceof Expr\Variable && $n->var->name === 'this');
                if (! $relCall) {
                    continue;
                }
                if (! $m->returnType) {
                    add('MDL-04', 'L', $r, $m->getStartLine(), "relation {$m->name}() has no return type", $m->name->toString());
                }
                if (callName($relCall) === 'belongsToMany' && isset($relCall->args[1]) && $relCall->args[1]->value instanceof Node\Scalar\String_) {
                    $pivot = $relCall->args[1]->value->value;
                    $body = $printer->prettyPrint($m->stmts);
                    if (isset($softTables[$pivot]) && ! str_contains($body, 'wherePivotNull') && ! str_contains($body, 'deleted_at')) {
                        add('MDL-03', 'H', $r, $m->getStartLine(), "belongsToMany over soft-delete pivot '$pivot' without wherePivotNull('deleted_at')", $m->name->toString());
                    }
                }
            }
            // global scopes with raw ordering
            foreach ($finder->find($cls, fn (Node $n) => callName($n) === 'addGlobalScope') as $gs) {
                if (containsCall($gs, ['orderByRaw', 'selectRaw', 'whereRaw'])) {
                    add('MDL-08', 'M', $r, $gs->getStartLine(), 'global scope uses raw SQL — runs on every query of this model');
                }
            }
        }

        // ── jobs / listeners
        if (in_array($layer, ['job', 'listener'], true)) {
            $implements = array_map(fn ($i) => $i->toString(), $cls->implements);
            $queued = (bool) array_filter($implements, fn ($i) => str_ends_with($i, 'ShouldQueue'));
            $propNames = [];
            foreach ($cls->getProperties() as $p) {
                foreach ($p->props as $pp) {
                    $propNames[] = $pp->name->toString();
                }
            }
            if ($queued && $layer === 'job' && (! in_array('tries', $propNames, true) || ! in_array('timeout', $propNames, true))) {
                add('JOB-02', 'M', $r, $cls->getStartLine(), "$className is queued but missing \$tries/\$timeout");
            }
            if ($layer === 'listener' && ! $queued && containsCall($cls, ['send', 'queue', 'loadView', 'post', 'get', 'insert', 'upsert'])
                && preg_match('/Mail::|Pdf::|PDF::|Http::|Notification::send/', $printer->prettyPrint([$cls]))) {
                add('JOB-04', 'M', $r, $cls->getStartLine(), "$className does slow work (mail/pdf/http) synchronously — implement ShouldQueue");
            }
        }

        // ── method-level rules
        foreach ($methods as $m) {
            $mName = $m->name->toString();
            $stmts = $m->stmts ?? [];
            if (! $stmts) {
                continue;
            }
            $mLines = lines($m);
            $isRead = (bool) preg_match($readMethodRe, $mName);

            if (in_array($layer, ['controller', 'service'], true) && $mLines > 80) {
                add('CTL-02', $mLines > 150 ? 'H' : 'M', $r, $m->getStartLine(), "$mName() is $mLines lines", $mName, ['size' => $mLines]);
            }
            if ($isCtl && $m->isPublic() && ! $m->returnType && ! str_starts_with($mName, '__')) {
                add('CTL-04', 'L', $r, $m->getStartLine(), "$mName() has no return type", $mName);
            }

            // ERR-01: getMessage in a returned/flashed value — severity by what was caught
            $flagged = [];
            foreach ($finder->findInstanceOf($stmts, Stmt\Catch_::class) as $c) {
                $types = array_map(fn ($t) => substr($t->toString(), (int) strrpos('\\'.$t->toString(), '\\')), $c->types);
                $generic = (bool) array_intersect($types, ['Throwable', 'Exception', 'QueryException', 'PDOException', 'Error', 'ErrorException', 'RuntimeException']);
                foreach ($finder->findInstanceOf($c->stmts, Stmt\Return_::class) as $ret) {
                    if ($ret->expr && containsCall($ret->expr, ['getMessage'])) {
                        $flagged[$ret->getStartLine()] = true;
                        add('ERR-01', $generic ? 'B' : 'L', $r, $ret->getStartLine(), $generic ? 'raw exception message ('.implode('|', $types).') returned to the user' : 'domain exception message returned ('.implode('|', $types).') — intentional if the exception is user-facing', $mName, $generic ? [] : ['tag' => 'verify']);
                    }
                }
            }
            foreach ($finder->findInstanceOf($stmts, Stmt\Return_::class) as $ret) {
                if (! isset($flagged[$ret->getStartLine()]) && $ret->expr && containsCall($ret->expr, ['getMessage'])) {
                    add('ERR-01', 'M', $r, $ret->getStartLine(), 'exception message returned to the user outside a catch', $mName, ['tag' => 'verify']);
                }
            }
            // ERR-02: try blocks that swallow 404/403/422
            foreach ($finder->findInstanceOf($stmts, Stmt\TryCatch::class) as $try) {
                $caught = [];
                $generic = false;
                foreach ($try->catches as $c) {
                    foreach ($c->types as $t) {
                        $s = $t->toString();
                        $short = substr($s, strrpos('\\'.$s, '\\'));
                        $caught[] = $short;
                        if (in_array($short, ['Throwable', 'Exception'], true)) {
                            $rethrows = (bool) $finder->findFirst($c->stmts, fn (Node $n) => $n instanceof Expr\Throw_ || $n instanceof Stmt\Expression && $n->expr instanceof Expr\Throw_);
                            $generic = $generic || ! $rethrows;
                        }
                    }
                }
                if (! $generic) {
                    continue;
                }
                $checks = [
                    'ModelNotFoundException' => ['findOrFail', 'firstOrFail', 'sole'],
                    'ValidationException' => ['validate', 'validateWithBag'],
                    'AuthorizationException' => ['authorize'],
                    'HttpExceptionInterface' => ['abort', 'abort_if', 'abort_unless'],
                ];
                foreach ($checks as $exc => $calls) {
                    $alt = $exc === 'HttpExceptionInterface' ? ['HttpException', 'NotFoundHttpException'] : [];
                    if (containsCall($try->stmts, $calls) && ! array_intersect(array_merge([$exc], $alt), $caught)) {
                        $call = implode('/', $calls);
                        add('ERR-02', 'H', $r, $try->getStartLine(), "$call inside try; generic catch swallows $exc", $mName, ['tag' => 'H-only']);
                    }
                }
                if ($isRead && $isCtl) {
                    add('ERR-07', 'M', $r, $try->getStartLine(), "read method $mName() wrapped in try/catch", $mName);
                }
            }
            // ERR-03: declared View but returns redirect (or vice versa)
            if ($m->returnType instanceof Node\Name) {
                $rt = $m->returnType->getLast();
                foreach ($finder->findInstanceOf($stmts, Stmt\Return_::class) as $ret) {
                    if (! $ret->expr || $finder->findFirst($stmts, fn (Node $n) => $n instanceof Expr\Closure || $n instanceof Expr\ArrowFunction) && $ret->getStartLine() > 0 && false) {
                        continue;
                    }
                    $root2 = $ret->expr instanceof Expr ? chainRoot($ret->expr) : null;
                    $rootName = $root2 ? callName($root2) : null;
                    $returnsRedirect = in_array($rootName, ['redirect', 'back', 'to_route'], true);
                    $returnsView = $rootName === 'view';
                    $returnsJson = $rootName === 'response' && in_array('json', chainNames($ret->expr), true);
                    if (($rt === 'View' && ($returnsRedirect || $returnsJson)) || ($rt === 'RedirectResponse' && ($returnsView || $returnsJson)) || ($rt === 'JsonResponse' && ($returnsRedirect || $returnsView))) {
                        // ignore returns inside nested closures
                        $inClosure = $finder->findFirst($stmts, fn (Node $n) => ($n instanceof Expr\Closure || $n instanceof Expr\ArrowFunction) && $n->getStartLine() <= $ret->getStartLine() && $n->getEndLine() >= $ret->getEndLine());
                        if (! $inClosure) {
                            add('ERR-03', 'H', $r, $ret->getStartLine(), "declared : $rt but returns ".($returnsRedirect ? 'a redirect' : ($returnsView ? 'a view' : 'JSON')).' — TypeError at runtime', $mName);
                        }
                    }
                }
            }
            // ERR-04: mixes JSON and redirect without expectsJson
            if ($isCtl) {
                $body = $printer->prettyPrint($stmts);
                if (preg_match('/response\(\)\s*->\s*json/', $body) && preg_match('/\b(back|redirect)\(\)/', $body) && ! preg_match('/expectsJson|wantsJson|ajax\(\)|isJson/', $body)) {
                    add('ERR-04', 'M', $r, $m->getStartLine(), "$mName() returns both JSON and redirects with no expectsJson() branch", $mName);
                }
            }
            // ERR-05: logs getMessage without the exception
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'Log') as $lc) {
                $p = $printer->prettyPrintExpr($lc);
                if (str_contains($p, 'getMessage') && ! str_contains($p, "'exception'") && ! str_contains($p, 'getTraceAsString')) {
                    add('ERR-05', 'M', $r, $lc->getStartLine(), 'logs getMessage() without the exception/trace', $mName);
                }
                if (preg_match('/request\(\)->all\(\)|\$request->all\(\)/', $p)) {
                    add('SEC-04', 'H', $r, $lc->getStartLine(), 'logs the whole request body', $mName);
                }
            }
            // ERR-06: empty catch
            foreach ($finder->findInstanceOf($stmts, Stmt\Catch_::class) as $c) {
                if (count($c->stmts) === 0) {
                    add('ERR-06', 'H', $r, $c->getStartLine(), 'empty catch block swallows the failure', $mName);
                }
            }

            // TXN
            $txCalls = $finder->find($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'DB' && callName($n) === 'transaction');
            if ($finder->findFirst($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'DB' && callName($n) === 'beginTransaction')) {
                add('TXN-02', 'M', $r, $m->getStartLine(), "$mName() uses manual beginTransaction/commit", $mName);
            }
            foreach ($txCalls as $tx) {
                $closure = $tx->args[0]->value ?? null;
                if (! $closure instanceof Expr\Closure && ! $closure instanceof Expr\ArrowFunction) {
                    continue;
                }
                $cs = $closure instanceof Expr\Closure ? $closure->stmts : [$closure->expr];
                foreach ($finder->find($cs, fn (Node $n) => $n instanceof Stmt\Return_ && $n->expr) as $ret) {
                    $rn = callName(chainRoot($ret->expr));
                    if (in_array($rn, ['redirect', 'back', 'response', 'view', 'to_route'], true)) {
                        add('TXN-05', 'M', $r, $ret->getStartLine(), 'HTTP response built inside DB::transaction closure', $mName);
                        break;
                    }
                }
                $p = $printer->prettyPrint($cs);
                if (preg_match('/Storage::[a-z]*\)?->?delete|Storage::delete|->deleteFile\(|\bunlink\(|File::delete|Mail::|Http::|->notify\(|Notification::send/', $p)) {
                    add('TXN-03', 'B', $r, $tx->getStartLine(), 'irreversible side effect (file delete / mail / http / notify) inside a transaction', $mName, ['tag' => 'verify']);
                }
            }
            if ($txCalls) {
                foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\FuncCall && callName($n) === 'activityLog') as $al) {
                    $inside = false;
                    foreach ($txCalls as $tx) {
                        if ($al->getStartLine() >= $tx->getStartLine() && $al->getEndLine() <= $tx->getEndLine()) {
                            $inside = true;
                        }
                    }
                    if (! $inside) {
                        add('TXN-04', 'M', $r, $al->getStartLine(), 'activityLog() outside the transaction', $mName);
                    }
                }
            } elseif (in_array($layer, ['controller', 'service'], true)) {
                $writes = $finder->find($stmts, fn (Node $n) => in_array(callName($n), $writeNames, true) && ($n instanceof Expr\MethodCall || $n instanceof Expr\StaticCall) && ! ($n instanceof Expr\MethodCall && $n->var instanceof Expr\Variable && in_array($n->var->name, ['request', 'collection', 'items'], true)));
                $writes = array_filter($writes, fn ($n) => ! ($n instanceof Expr\StaticCall && in_array(staticClass($n), ['Cache', 'Session', 'Log', 'Storage', 'Arr', 'Str'], true)));
                $al = $finder->findFirst($stmts, fn (Node $n) => callName($n) === 'activityLog');
                if (count($writes) + ($al ? 1 : 0) >= 2 && ! containsCall($stmts, ['beginTransaction'])) {
                    add('TXN-01', 'H', $r, $m->getStartLine(), sprintf('%s() makes %d writes%s with no transaction', $mName, count($writes), $al ? ' + activityLog' : ''), $mName, ['tag' => 'verify']);
                }
            }

            // AUTH
            if ($isCtl && $m->isPublic() && ! str_starts_with($mName, '__') && $fq) {
                $key = $fq.'@'.$mName;
                $rows = $routed[$key] ?? null;
                $hasAuth = containsCall($stmts, $authCalls);
                $frParam = null;
                foreach ($m->params as $prm) {
                    if ($prm->type instanceof Node\Name) {
                        $tn = $prm->type->getLast();
                        if (isset($formRequests[$tn])) {
                            $frParam = $tn;
                        }
                    }
                }
                $ctorAuth = isset($classIndex[$fq]['methods']['__construct']) && preg_match('/middleware\(|authorizeResource/', $printer->prettyPrint($classIndex[$fq]['methods']['__construct']->stmts ?? []));
                if ($rows === null) {
                    if (isset($routedClasses[$fq])) {
                        add('RTE-03', 'M', $r, $m->getStartLine(), "public $mName() is not routed", $mName);
                    }
                } else {
                    $mw = implode(' ', array_merge(...array_map(fn ($x) => $x['middleware'] ?? [], $rows)));
                    $routeAuth = (bool) preg_match('/(^|\s)(can:|permission:|role:|role_or_permission:)|Spatie\\\\Permission|Portal|Role|Permission|Admin|EnsureUser|EnsureTeacher|EnsureStudent|EnsureParent|EnsureStaff|Can[A-Z]|Authorize/', $mw);
                    $frStrong = $frParam && $formRequests[$frParam] === 'strong';
                    if (! $hasAuth && ! $routeAuth && ! $frStrong && ! $ctorAuth) {
                        $sev = $isRead ? 'H' : 'B';
                        add('AUTH-01', $sev, $r, $m->getStartLine(), "routed $mName() has no authorization (no Gate/authorize/can middleware/strong FormRequest)".($frParam ? " — $frParam::authorize() is weak" : ''), $mName, ['routes' => array_values(array_unique(array_map(fn ($x) => $x['method'].' '.$x['uri'], $rows)))]);
                    }
                    if ($frStrong && $finder->findFirst($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'Gate' && callName($n) === 'authorize')) {
                        add('AUTH-04', 'L', $r, $m->getStartLine(), "$frParam::authorize() and Gate::authorize both check", $mName);
                    }
                }
                // AUTH-02 order: authorize after a load
                $firstAuth = $finder->findFirst($stmts, fn (Node $n) => in_array(callName($n), ['authorize'], true));
                $firstLoad = $finder->findFirst($stmts, fn (Node $n) => in_array(callName($n), ['findOrFail', 'find', 'firstOrFail'], true));
                if ($firstAuth && $firstLoad && $firstLoad->getStartLine() < $firstAuth->getStartLine()) {
                    add('AUTH-02', 'M', $r, $firstAuth->getStartLine(), 'record loaded before authorization', $mName);
                }
                foreach ($finder->findInstanceOf($stmts, Stmt\TryCatch::class) as $try) {
                    if ($finder->findFirst($try->stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'Gate' && callName($n) === 'authorize')) {
                        add('AUTH-02', 'M', $r, $try->getStartLine(), 'Gate::authorize inside try', $mName);
                        break;
                    }
                }
                $gateCalls = array_map('callName', $finder->find($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'Gate'));
                if (in_array('authorize', $gateCalls, true) && in_array('any', $gateCalls, true)) {
                    add('AUTH-05', 'M', $r, $m->getStartLine(), 'Gate::authorize then Gate::any — the any() is dead', $mName);
                }
            }

            // VAL
            foreach ($finder->find($stmts, fn (Node $n) => in_array(callName($n), ['create', 'update', 'fill', 'forceFill', 'insert', 'updateOrCreate', 'firstOrCreate'], true)) as $wc) {
                $p = $printer->prettyPrintExpr($wc);
                if (preg_match('/(\$request|request\(\))->(all|except|input)\(\s*(\)|\[|\')/', $p) && ! preg_match('/->input\(\s*\'[a-z_]+\'/', $p)) {
                    add('VAL-01', 'B', $r, $wc->getStartLine(), 'unvalidated request data written to a model: '.mb_substr(preg_replace('/\s+/', ' ', $p), 0, 120), $mName);
                }
            }
            if ($isCtl) {
                foreach ($finder->find($stmts, fn (Node $n) => (callName($n) === 'validate' && $n instanceof Expr\MethodCall) || ($n instanceof Expr\StaticCall && staticClass($n) === 'Validator' && callName($n) === 'make')) as $v) {
                    add('VAL-02', 'M', $r, $v->getStartLine(), 'inline validation in controller', $mName);
                }
                $hasValidation = containsCall($stmts, ['validate', 'validated', 'make', 'safe']) || ($m->params && array_filter($m->params, fn ($p) => $p->type instanceof Node\Name && isset($formRequests[$p->type->getLast()])));
                if (! $hasValidation) {
                    foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && in_array(staticClass($n), ['Carbon', 'CarbonImmutable'], true) && in_array(callName($n), ['parse', 'createFromFormat'], true)) as $cp) {
                        if (preg_match('/\$request|request\(/', $printer->prettyPrintExpr($cp))) {
                            add('VAL-05', 'H', $r, $cp->getStartLine(), 'Carbon parses unvalidated request input', $mName);
                        }
                    }
                }
            }

            // SVC-01 / SVC-02 / SVC-03
            if ($layer === 'service') {
                foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\FuncCall && in_array(callName($n), ['request', 'session', 'redirect', 'back', 'response'], true)) as $h) {
                    add('SVC-01', 'M', $r, $h->getStartLine(), 'service touches HTTP: '.callName($h).'()', $mName);
                }
            }
            if (in_array($layer, ['controller', 'service'], true) && $mName !== '__construct') {
                foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\New_ && $n->class instanceof Node\Name && preg_match('/(Service|Repository|Manager|Engine)$/', $n->class->getLast())) as $nw) {
                    add('SVC-02', 'M', $r, $nw->getStartLine(), 'new '.$nw->class->getLast().'() inside a method — inject it', $mName);
                }
            }
            if ($isRead && in_array($layer, ['controller', 'service'], true)) {
                foreach ($finder->find($stmts, fn (Node $n) => in_array(callName($n), ['updateOrCreate', 'firstOrCreate', 'insertOrIgnore'], true)) as $w) {
                    add('SVC-03', 'H', $r, $w->getStartLine(), "write ($w->name) inside read-path method $mName()", $mName, ['tag' => 'verify']);
                }
            }
            if (in_array($layer, ['controller', 'service'], true)) {
                foreach ($finder->find($stmts, fn (Node $n) => in_array(callName($n), ['ensureHomeworkStatusesExist'], true) || ($n instanceof Expr\MethodCall && $n->name instanceof Node\Identifier && preg_match('/^ensure[A-Z]\w*(Exist|Exists|Seeded)$/', $n->name->toString()))) as $w) {
                    add('SVC-03', 'H', $r, $w->getStartLine(), 'ensure*Exist() seeding call on a request path', $mName, ['tag' => 'verify']);
                }
            }

            // QRY-01 / QRY-07 queries & writes inside loops
            $loops = $finder->find($stmts, fn (Node $n) => $n instanceof Stmt\Foreach_ || $n instanceof Stmt\For_ || $n instanceof Stmt\While_ || $n instanceof Stmt\Do_
                || (($n instanceof Expr\MethodCall) && in_array(callName($n), ['map', 'each', 'transform', 'filter', 'flatMap', 'reject', 'mapWithKeys', 'sortBy', 'groupBy', 'sum', 'first'], true)
                    && $n->args && ($n->args[0]->value instanceof Expr\Closure || $n->args[0]->value instanceof Expr\ArrowFunction)));
            $seen = [];
            foreach ($loops as $loop) {
                $body = match (true) {
                    $loop instanceof Expr\MethodCall => [$loop->args[0]->value],
                    default => $loop->stmts,
                };
                foreach ($finder->find($body, fn (Node $n) => isModelCall($n)) as $q) {
                    $c = staticClass($q);
                    $nm = callName($q);
                    $line = $q->getStartLine();
                    if (isset($seen[$line])) {
                        continue;
                    }
                    $seen[$line] = true;
                    if (in_array($nm, $writeNames, true) || ($c === 'DB' && in_array($nm, ['insert', 'update', 'delete', 'statement'], true))) {
                        add('QRY-07', 'M', $r, $line, "$c::$nm() inside a loop — bulk insert/upsert/whereIn->update", $mName);
                    } elseif (in_array($nm, $queryStarters, true) || $c === 'DB') {
                        add('QRY-01', 'H', $r, $line, "$c::$nm() inside a loop — N+1 query", $mName);
                    }
                }
                foreach ($finder->find($body, fn (Node $n) => $n instanceof Expr\MethodCall && in_array(callName($n), ['save', 'update', 'delete', 'forceDelete', 'restore', 'increment', 'decrement'], true) && ! ($n->var instanceof Expr\Variable && in_array($n->var->name, ['request', 'collection'], true))) as $w) {
                    $line = $w->getStartLine();
                    if (! isset($seen[$line])) {
                        $seen[$line] = true;
                        add('QRY-07', 'M', $r, $line, '->'.callName($w).'() per row inside a loop', $mName);
                    }
                }
            }

            // QRY-02 / QRY-15 / QRY-04 / QRY-05 chains
            foreach ($finder->find($stmts, fn (Node $n) => isModelCall($n) && staticClass($n) !== 'DB' && callName($n) === 'all') as $a) {
                add('QRY-02', $isCtl ? 'H' : 'M', $r, $a->getStartLine(), staticClass($a).'::all() loads the whole table', $mName);
            }
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\MethodCall && callName($n) === 'get' && (count($n->args) === 0 || $n->args[0]->value instanceof Expr\Array_)) as $g) {
                $root3 = chainRoot($g);
                $rc = staticClass($root3);
                if (! $rc || ! isModelCall($root3) || $rc === 'DB') {
                    continue;
                }
                $names = chainNames($g);
                $filters = preg_grep('/^(where|whereIn|whereHas|whereNull|whereNotNull|whereBetween|whereDate|find|limit|take|when|active|current|forPage|ofType|scope|select|latest|for[A-Z]|by[A-Z]|of[A-Z]|whereRelation|has|doesntHave|whereBelongsTo)/', array_slice($names, 0, -1));
                $userScope = array_filter(array_slice($names, 0, -1), fn ($x) => ! in_array($x, ['query', 'with', 'withCount', 'orderBy', 'orderByDesc', 'get', 'withTrashed', 'onlyTrashed', 'distinct', 'withoutGlobalScopes', 'withSum', 'oldest', 'reorder'], true) && ! preg_match('/^where/', $x));
                if (! $filters && ! $userScope) {
                    add('QRY-15', $isCtl ? 'M' : 'L', $r, $g->getStartLine(), "$rc::".implode('->', $names).'() — no filter, loads every row', $mName);
                }
            }
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\MethodCall && $n->var instanceof Expr\MethodCall && callName($n->var) === 'get' && count($n->var->args) === 0 && isModelCall(chainRoot($n->var)) && staticClass(chainRoot($n->var)) !== 'DB') as $c2) {
                $nm = callName($c2);
                if (in_array($nm, ['count', 'isEmpty', 'isNotEmpty', 'pluck', 'first', 'sum', 'max', 'min', 'avg', 'contains', 'keys'], true)) {
                    add('QRY-04', 'M', $r, $c2->getStartLine(), "->get()->$nm() — let the DB do it (".($nm === 'isEmpty' || $nm === 'isNotEmpty' ? 'exists()' : $nm.'()').')', $mName);
                } elseif (in_array($nm, ['groupBy', 'filter', 'where', 'unique', 'sortBy', 'sortByDesc', 'whereIn'], true)) {
                    add('QRY-05', 'M', $r, $c2->getStartLine(), "->get()->$nm() — filter/aggregate in SQL instead", $mName);
                }
            }
            // QRY-08 leading wildcard LIKE
            $likeCount = 0;
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\MethodCall && in_array(callName($n), ['where', 'orWhere'], true) && count($n->args) === 3 && $n->args[1]->value instanceof Node\Scalar\String_ && strtolower($n->args[1]->value->value) === 'like') as $lk) {
                $v = $printer->prettyPrintExpr($lk->args[2]->value);
                if (preg_match('/^["\']%/', $v)) {
                    $likeCount++;
                    $likeLine ??= $lk->getStartLine();
                }
            }
            if ($likeCount) {
                add('QRY-08', 'L', $r, $likeLine, "$likeCount leading-wildcard LIKE search(es)", $mName);
                unset($likeLine);
            }
            // QRY-09 deep whereHas
            foreach ($finder->find($stmts, fn (Node $n) => in_array(callName($n), ['whereHas', 'orWhereHas', 'whereDoesntHave'], true) && isset($n->args[0]) && $n->args[0]->value instanceof Node\Scalar\String_ && substr_count($n->args[0]->value->value, '.') >= 2) as $wh) {
                add('QRY-09', 'M', $r, $wh->getStartLine(), "whereHas('".$wh->args[0]->value->value."') 3+ levels deep", $mName);
            }
            // QRY-10 many hand-written filters
            $filled = count($finder->find($stmts, fn (Node $n) => $n instanceof Expr\MethodCall && in_array(callName($n), ['filled', 'has'], true) && $n->var instanceof Expr\Variable && $n->var->name === 'request'));
            if ($filled > 10) {
                add('QRY-10', 'L', $r, $m->getStartLine(), "$mName() has $filled hand-written \$request->filled() branches — use when()/a filter scope", $mName);
            }
            // QRY-11 interpolated raw SQL
            foreach ($finder->find($stmts, fn (Node $n) => in_array(callName($n), ['raw', 'selectRaw', 'whereRaw', 'orWhereRaw', 'orderByRaw', 'havingRaw', 'groupByRaw', 'select', 'statement', 'unprepared', 'update', 'delete', 'insert'], true) && isset($n->args[0]) && ($n->args[0]->value instanceof Node\Scalar\InterpolatedString || $n->args[0]->value instanceof Expr\BinaryOp\Concat)) as $raw) {
                if (! ($raw instanceof Expr\StaticCall && staticClass($raw) === 'DB') && ! in_array(callName($raw), ['raw', 'selectRaw', 'whereRaw', 'orWhereRaw', 'orderByRaw', 'havingRaw', 'groupByRaw'], true)) {
                    continue;
                }
                $p = $printer->prettyPrintExpr($raw->args[0]->value);
                $fromRequest = preg_match('/\$request|request\(|\$_(GET|POST|REQUEST)|\$search|\$sort|\$order|\$filter|\$term|\$q\b/', $p);
                add('QRY-11', $fromRequest ? 'B' : 'M', $r, $raw->getStartLine(), ($fromRequest ? 'user input interpolated into raw SQL: ' : 'interpolated raw SQL (verify it is a constant): ').mb_substr(preg_replace('/\s+/', ' ', $p), 0, 110), $mName, $fromRequest ? [] : ['tag' => 'verify']);
            }
            // QRY-13 paginate without withQueryString on filtered lists
            if ($isCtl && $filled > 0) {
                foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\MethodCall && in_array(callName($n), ['paginate', 'simplePaginate'], true)) as $pg) {
                    $parent = $printer->prettyPrint($stmts);
                    if (! preg_match('/withQueryString|appends\(/', $parent)) {
                        add('QRY-13', 'L', $r, $pg->getStartLine(), 'filtered list paginated without ->withQueryString()', $mName);
                        break;
                    }
                }
            }
            // QRY-06 bulk loads in jobs/commands
            if (in_array($layer, ['job', 'command', 'listener'], true)) {
                foreach ($finder->find($stmts, fn (Node $n) => (($n instanceof Expr\MethodCall && callName($n) === 'get' && count($n->args) === 0) || ($n instanceof Expr\StaticCall && callName($n) === 'all')) && isModelCall(chainRoot($n)) && staticClass(chainRoot($n)) !== 'DB') as $bl) {
                    add('QRY-06', 'M', $r, $bl->getStartLine(), 'bulk ->get()/all() in '.$layer.' — use chunkById()/lazyById()', $mName, ['tag' => 'verify']);
                }
            }
            // CTL-07 extract / huge compact
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\FuncCall && in_array(callName($n), ['extract', 'compact'], true)) as $ec) {
                if (callName($ec) === 'extract') {
                    add('CTL-07', 'M', $r, $ec->getStartLine(), 'extract() creates variables invisibly', $mName);
                } elseif (count($ec->args) > 15) {
                    add('CTL-07', 'L', $r, $ec->getStartLine(), 'compact() of '.count($ec->args).' variables', $mName);
                }
            }
            // CTL-03 $id + findOrFail
            if ($isCtl && $m->isPublic()) {
                $idParams = array_filter($m->params, fn ($p) => ! $p->type instanceof Node\Name && $p->var instanceof Expr\Variable && is_string($p->var->name) && preg_match('/^(id|.+Id|.+_id)$/', $p->var->name));
                if ($idParams && containsCall($stmts, ['findOrFail', 'find'])) {
                    add('CTL-03', 'M', $r, $m->getStartLine(), "$mName(\$".implode(', $', array_map(fn ($p) => $p->var->name, $idParams)).') + findOrFail — use route model binding', $mName);
                }
                foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\FuncCall && callName($n) === 'request') as $rq) {
                    add('CTL-08', 'L', $r, $rq->getStartLine(), 'request() helper in controller', $mName);
                    break;
                }
            }
            // SEC-03 hard-coded id fallback
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\BinaryOp\Coalesce && $n->right instanceof Node\Scalar\Int_ && $n->right->value === 1) as $co) {
                $p = $printer->prettyPrintExpr($co->left);
                if (preg_match('/id\b|_id|Id\(|->id/i', $p)) {
                    add('SEC-03', 'M', $r, $co->getStartLine(), "hard-coded id fallback: $p ?? 1", $mName);
                }
            }
            // STY-03 PascalCase variables
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\Assign && $n->var instanceof Expr\Variable && is_string($n->var->name) && preg_match('/^[A-Z][a-z]/', $n->var->name)) as $pv) {
                add('STY-03', 'L', $r, $pv->getStartLine(), '$'.$pv->var->name.' — variables are camelCase', $mName);
                break;
            }
            // TEN-02 cache keys without tenant
            foreach ($finder->find($stmts, fn (Node $n) => $n instanceof Expr\StaticCall && staticClass($n) === 'Cache' && in_array(callName($n), ['remember', 'rememberForever', 'put', 'forever', 'get', 'add', 'flexible'], true)) as $ck) {
                $k = isset($ck->args[0]) ? $printer->prettyPrintExpr($ck->args[0]->value) : '';
                if ($k !== '' && ! preg_match('/tenant|Tenant|database\(\)|getTenantKey|tenancy/', $k)) {
                    add('TEN-02', 'H', $r, $ck->getStartLine(), "Cache::$ck->name key has no tenant component: ".mb_substr($k, 0, 90), $mName, ['tag' => 'verify']);
                }
            }
        }
    }

    // ── Form Request upload rules (VAL-06) — rules arrays anywhere
    if (in_array($layer, ['request', 'controller'], true)) {
        foreach ($finder->findInstanceOf($ast, Expr\ArrayItem::class) as $ai) {
            if (! $ai->key instanceof Node\Scalar\String_) {
                continue;
            }
            $v = $ai->value;
            $ruleStr = '';
            if ($v instanceof Node\Scalar\String_) {
                $ruleStr = $v->value;
            } elseif ($v instanceof Expr\Array_) {
                $ruleStr = implode('|', array_map(fn ($i) => $i?->value instanceof Node\Scalar\String_ ? $i->value->value : '?', $v->items));
            } else {
                continue;
            }
            $parts = explode('|', $ruleStr);
            if (array_intersect(['file', 'image'], $parts) && (! preg_grep('/^(mimes|mimetypes|extensions|image)/', $parts) || ! preg_grep('/^max:/', $parts))) {
                add('VAL-06', 'H', $r, $ai->getStartLine(), "upload '{$ai->key->value}' lacks mimes and/or max: $ruleStr");
            }
            if ($parts === ['sometimes'] || $parts === ['nullable'] || $parts === ['sometimes', 'nullable']) {
                add('VAL-05', 'M', $r, $ai->getStartLine(), "'{$ai->key->value}' => '$ruleStr' validates nothing");
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────── routes

foreach ($routes as $rt) {
    $a = $rt['action'] ?? '';
    $uri = $rt['uri'];
    $verbs = $rt['method'];
    if (str_contains($a, '@')) {
        [$cls, $meth] = explode('@', $a);
        if (str_starts_with($cls, 'Modules\\') || str_starts_with($cls, 'App\\')) {
            if (! isset($classIndex[$cls])) {
                add('RTE-02', 'B', 'routes', 0, "$verbs $uri → $a: controller class not found");
            } elseif (! isset($classIndex[$cls]['methods'][$meth])) {
                $parent = $classIndex[$cls]['node']->extends?->toString();
                $inherited = $parent && isset($classIndex[$parent]['methods'][$meth]);
                if (! $inherited && ! in_array($meth, ['__invoke', 'callAction'], true)) {
                    add('RTE-02', 'B', rel($classIndex[$cls]['file']), 0, "$verbs $uri → $meth(): method does not exist", $meth, ['route' => $rt['name']]);
                }
            }
        }
    }
    $isGet = str_starts_with($verbs, 'GET');
    $mutWord = '/(^|[\/\-_.])(restore|delete|destroy|remove|toggle|publish|approve|reject|sync|generate|reset|truncate|force-?delete|activate|deactivate|cancel|mark|assign|unassign|clear|purge|run|execute|send|lock|unlock)([\/\-_.]|$)/i';
    if ($isGet && (preg_match($mutWord, $uri) || preg_match($mutWord, (string) $rt['name']))) {
        $file = isset($cls, $classIndex[$cls]) ? rel($classIndex[$cls]['file']) : 'routes';
        $sure = preg_match('/(restore|delete|destroy|remove|toggle|force-?delete|truncate|purge|unlock|lock|activate|deactivate)/i', $uri.' '.($meth ?? ''));
        add('RTE-01', 'H', $file, 0, "GET $uri (".($rt['name'] ?? '-').') '.($sure ? 'changes state' : 'looks state-changing'), $meth ?? '', ($sure ? [] : ['tag' => 'verify']) + ['route' => $rt['name']]);
    }
    if (str_starts_with($verbs, 'POST') && isset($meth) && preg_match('/^(get|fetch|load|list|search)[A-Z]/', $meth)) {
        $file = isset($cls, $classIndex[$cls]) ? rel($classIndex[$cls]['file']) : 'routes';
        add('RTE-04', 'L', $file, 0, "POST $uri → $meth() is a read", $meth);
    }
    $mw = implode(' ', $rt['middleware'] ?? []);
    if ($rt['domain'] === null && ! preg_match('/Authenticate|auth|guest|Sanctum|ValidateMobileApiKey|signed|ValidateSignature/i', $mw) && str_contains($mw, 'Tenancy') && ! preg_match('#^(login|logout|register|password|forgot|reset|verify|sanctum|up|livewire|_debugbar|api/(login|auth)|webhook|payment/(callback|webhook)|razorpay)#i', $uri)) {
        add('RTE-05', 'H', 'routes', 0, "tenant route without auth middleware: $verbs $uri (".($rt['name'] ?? '-').')', '', ['tag' => 'verify']);
    }
    unset($cls, $meth);
}

// ─────────────────────────────────────────────────────────────── Blade

$bladeDirs = array_merge([$root.'/resources/views'], glob($root.'/Modules/*/resources/views', GLOB_ONLYDIR));
$nonModels = 'Str|Carbon|Auth|Route|Arr|Number|Js|Illuminate|Session|Request|Gate|Cache|Config|Lang|URL|Storage|App|Vite|Date|Crypt|Hash|Blade|View|Log|Http|File|Cookie|Validator|Response|Redirect|Schema';
foreach ($bladeDirs as $d) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        $p = $f->getPathname();
        if (! str_ends_with($p, '.blade.php')) {
            continue;
        }
        $r = rel($p);
        $loopDepth = 0;
        foreach (file($p) as $i => $l) {
            $loopDepth += preg_match_all('/@(foreach|for|forelse|while)\b/', $l) - preg_match_all('/@(endforeach|endfor|endforelse|endwhile)\b/', $l);
            if (preg_match('/\b(?!(?:'.$nonModels.')::)([A-Z][A-Za-z0-9_\\\\]+)::(where|find|findOrFail|all|query|with|count|first|get|select|orderBy|latest|pluck|whereIn|active|withCount|sum)\s*\(/', $l, $m) || preg_match('/\bDB::(table|select|raw)\b/', $l, $m)) {
                add('VIEW-01', $loopDepth > 0 ? 'H' : 'M', $r, $i + 1, ($loopDepth > 0 ? 'query inside @foreach: ' : 'query in Blade: ').trim(mb_substr($l, 0, 140)));
            } elseif ($loopDepth > 0 && preg_match('/->\w+\(\)->(where|count|get|first|exists|sum|pluck)\(/', $l)) {
                add('VIEW-01', 'H', $r, $i + 1, 'relation query inside @foreach: '.trim(mb_substr($l, 0, 140)));
            }
            if (preg_match('/\{!!\s*(?!csrf_field|json_encode|\$slot|.*->links\(|.*->render\(|.*Js::from|.*@json|.*__\(|.*trans\(|.*route\(|.*asset\(|.*svg|.*icon|.*nl2br\(e\()(.+?)!!\}/', $l, $m)) {
                add('VIEW-03', 'M', $r, $i + 1, 'unescaped output: '.trim(mb_substr($m[0], 0, 120)), '', ['tag' => 'verify']);
            }
            if (preg_match('#asset\(\s*[\'"]storage/#', $l)) {
                add('TEN-04', 'M', $r, $i + 1, "asset('storage/…') instead of tenant_asset()");
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────── output

$out = ['generated' => date('c'), 'stats' => $stats + ['routes' => count($routes), 'tables' => count($tables)], 'findings' => $findings];
file_put_contents($outFile, json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
fwrite(STDERR, sprintf("files %d, findings %d, parse errors %d\n", $stats['files'], count($findings), count($stats['parse_errors'])));
