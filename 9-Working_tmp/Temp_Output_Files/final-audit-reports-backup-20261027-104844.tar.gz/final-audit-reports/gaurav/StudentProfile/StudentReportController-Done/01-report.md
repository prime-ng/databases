# Final Audit — StudentProfile / StudentReportController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php` (223 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/reports` (Analytical Reports hub) and `http://test.localhost:8000/student-profile/reports/action-center` (Action Centers hub). Each tab also has its own GET URL: `.../reports/student-strength`, `.../demographics-quota`, `.../attendance-summary`, `.../medical-safety`, `.../profile-audit`, `.../chronic-absenteeism`, `.../document-deficiency`, `.../medical-followup`, `.../leave-review` |
| Menu path | Student Profile & Leave Mgmt. → Analytical Reports (menu id 68) and → Action Centers (menu id 69) |
| Who uses it | Roles that hold `tenant.student-profile.student.viewAny` — measured: Super Admin, School Admin |
| What a user does here | A school admin opens two read-only dashboards. The Analytical hub shows five report tabs (student strength matrix, UDISE+ demographics and quota, attendance register, medical and safety watchlist, profile/KYC completeness audit). The Action Centers hub shows four advisory queues (chronic absenteeism, document/KYC deficiency, medical follow-up, pending leave review). Every number on the page is computed live from the tenant's student, attendance and health tables. Nothing is saved from these screens. |
| Tables written | none — this controller and its service only read |
| Tables read | `std_students` (1,825), `std_student_academic_sessions` (9,759; 1,825 `is_current`), `std_student_attendance` (99,334), `std_student_health_profiles` (1,825), `std_student_profiles` (1,825), `std_student_documents` (5,475), `std_medical_incidents` (674), `std_leave_applications` (4), `std_guardians`, `sch_class_section_jnt` (43 active), `sch_classes`, `sch_sections`, `org_academic_sessions` |
| Live data | measured on tenant `xyz_school_00000000000040008000_202627` (database `test.localhost`) on 2026-10-10 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

The controller is a thin, well-guarded read-only hub: every routed method authorizes before loading, there are no writes, no try/catch and no exception text can reach a user, so the classic ERR/TXN/VAL families are clean. It is **not** production-ready on a real school because of performance, not correctness: the service builds analytics with queries inside loops and loads whole tables into PHP. On the live tenant the Attendance Register tab runs about 86 queries and pulls ~99,334 attendance rows, and the Chronic Absence queue runs one query per student (about 1,825 queries) — and because all tabs are rendered server-side in one request, a single page visit pays the full cost. The single worst finding is **SRP-02 / SRP-01** (per-row queries in `getAttendanceSummaryData()` and `getChronicAbsenteeismQueue()`). A second, correctness blocker is **SRP-08**: the `Student` model stores photos through Spatie Media Library but never overrides `getMediaModel()`, so media rows are written to the central database instead of the tenant's. Rough effort for the mechanical fixes: **M** (half a day) plus two deferred refactors.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 2 | 5 | 3 | 3 | 11 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | clean | F9 Queries/Perf | SRP-01, SRP-02, SRP-03 |
| F3 Authorization | SRP-07 | F10 Views | clean |
| F4 Validation | clean | F11 Security/Tenancy | SRP-09 |
| F5 Routes | SRP-04 | F12 Style | SRP-11 |
| F6 Controller shape | SRP-05, SRP-06 | F13 Deep read | table in §6 (no mutating methods) |
| F7 Models | SRP-08, SRP-10 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php` | controller | 223 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Services/StudentAnalyticsService.php` | service | 975 | this report | ✅ |
| 3 | `Modules/StudentProfile/app/Models/Student.php` | model | 472 | this report | ✅ |
| 4 | `Modules/StudentProfile/resources/views/reports/index.blade.php` | view | 140 | this report | ✅ |
| 5 | `Modules/StudentProfile/resources/views/reports/action-center.blade.php` | view | 106 | this report | ✅ |
| 6 | `Modules/StudentProfile/resources/views/reports/partials/` (9 partials) | views | 1,739 | this report | ✅ |
| 7 | `Modules/StudentProfile/app/Models/StudentAcademicSession.php` | model | - | ↗ [gaurav/StudentProfile/StudentController](../StudentController/01-report.md) | ↗ linked |
| 8 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | - | ↗ [gaurav/StudentProfile/AttendanceController](../AttendanceController/01-report.md) | ↗ linked |
| 9 | `Modules/StudentProfile/app/Models/StudentProfile.php` | model | - | ↗ [gaurav/StudentProfile/StudentProfileController](../StudentProfileController/01-report.md) | ↗ linked |
| 10 | `Modules/StudentProfile/app/Models/StudentHealthProfile.php` | model | - | ↗ [gaurav/StudentProfile/StudentController](../StudentController/01-report.md) | ↗ linked |
| 11 | `Modules/StudentProfile/app/Models/StudentDocument.php` | model | - | ↗ [gaurav/StudentProfile/StudentController](../StudentController/01-report.md) | ↗ linked |
| 12 | `Modules/StudentProfile/app/Models/Guardian.php` | model | - | ↗ [gaurav/StudentProfile/StudentController](../StudentController/01-report.md) | ↗ linked |
| 13 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | - | ↗ [gaurav/StudentProfile/StdLeaveController](../StdLeaveController/01-report.md) | ↗ linked |
| 14 | `Modules/StudentProfile/app/Models/MedicalIncident.php` | model | - | ↗ [gaurav/StudentProfile/MedicalIncidentController](../MedicalIncidentController/01-report.md) | ↗ linked |
| 15 | `Modules/StudentProfile/app/Models/PreviousEducation.php` | model | - | ↗ [gaurav/StudentProfile/StudentController](../StudentController/01-report.md) | ↗ linked |
| 16 | `Modules/SchoolSetup/app/Models/OrganizationAcademicSession.php` | model (common, other module) | - | common — not audited | ❌ common |
| 17 | `Modules/SchoolSetup/app/Models/SchoolClass.php` | model (common, other module) | - | common — not audited | ❌ common |
| 18 | `Modules/SchoolSetup/app/Models/Section.php` | model (common, other module) | - | common — not audited | ❌ common |
| 19 | `Modules/SchoolSetup/app/Models/ClassSection.php` | model (common, other module) | - | common — not audited | ❌ common |
| 20 | `config/permissionslist.php` | config (common) | - | common — checked, not audited | ❌ common |

The linked models 7–15 are owned by other, still-`CLAIMED` reports; they may not be finished yet. This report only judges how the controller/service uses them.

No pre-applied files (this module has no `PRE-APPLIED-*.md`).

## 4. Routes

```
GET|HEAD  student-profile/reports                              student-profile.reports.index              StudentReportController@index
GET|HEAD  student-profile/reports-mgt                          student-profile.reports.legacy             StudentReportController@index
GET|HEAD  student-profile/reports/action-center                student-profile.reports.actionCenter       StudentReportController@actionCenter
GET|HEAD  student-profile/reports/analytics                    student-profile.reports.analytics          StudentReportController@index
GET|HEAD  student-profile/reports/attendance-summary           student-profile.reports.attendanceSummary  StudentReportController@attendanceSummary
GET|HEAD  student-profile/reports/chronic-absenteeism          student-profile.reports.chronicAbsenteeism StudentReportController@chronicAbsenteeism
GET|HEAD  student-profile/reports/class-wise-student-strength  student-profile.reports.class-strength     StudentReportController@studentStrength
GET|HEAD  student-profile/reports/demographics-quota           student-profile.reports.demographicsQuota  StudentReportController@demographicsQuota
GET|HEAD  student-profile/reports/document-deficiency          student-profile.reports.documentDeficiency StudentReportController@documentDeficiency
GET|HEAD  student-profile/reports/leave-review                 student-profile.reports.leaveReview        StudentReportController@leaveReview
GET|HEAD  student-profile/reports/medical-followup             student-profile.reports.medicalFollowup    StudentReportController@medicalFollowup
GET|HEAD  student-profile/reports/medical-safety               student-profile.reports.medicalSafety      StudentReportController@medicalSafety
GET|HEAD  student-profile/reports/profile-audit                student-profile.reports.profileAudit       StudentReportController@profileAudit
GET|HEAD  student-profile/reports/student-strength             student-profile.reports.studentStrength    StudentReportController@studentStrength
```

All routes sit inside the module group `Route::middleware('module:STUDENT')` in `Modules/StudentProfile/routes/web.php`, which the module provider wraps with `web`, `InitializeTenancyByDomain`, `PreventAccessFromCentralDomains`, `EnsureTenantIsActive`, `auth` and `verified`. Tenant middleware is present (RTE-05 clean).

Unrouted public methods:
- `combinedStudentReport()` — `StudentReportController.php:211` (finding SRP-04)
- `classWiseStrengthReport()` — `StudentReportController.php:219` (finding SRP-04)

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 26 | GET student-profile/reports (+ reports-mgt, reports/analytics) | `tenant.student-profile.student.viewAny` | none | none | none | SRP-03 |
| `actionCenter` | 92 | GET student-profile/reports/action-center | `tenant.student-profile.student.viewAny` | none | none | none | SRP-03 |
| `studentStrength` | 139 | GET student-profile/reports/student-strength + class-wise-student-strength | via `index()` | none | none | none | SRP-02, SRP-03 |
| `demographicsQuota` | 147 | GET student-profile/reports/demographics-quota | via `index()` | none | none | none | SRP-03 |
| `attendanceSummary` | 155 | GET student-profile/reports/attendance-summary | via `index()` | none | none | none | SRP-02, SRP-03 |
| `medicalSafety` | 163 | GET student-profile/reports/medical-safety | via `index()` | none | none | none | SRP-03 |
| `profileAudit` | 171 | GET student-profile/reports/profile-audit | via `index()` | none | none | none | SRP-03 |
| `chronicAbsenteeism` | 179 | GET student-profile/reports/chronic-absenteeism | via `actionCenter()` | none | none | none | SRP-01, SRP-03 |
| `documentDeficiency` | 187 | GET student-profile/reports/document-deficiency | via `actionCenter()` | none | none | none | SRP-03 |
| `medicalFollowup` | 195 | GET student-profile/reports/medical-followup | via `actionCenter()` | none | none | none | SRP-03 |
| `leaveReview` | 203 | GET student-profile/reports/leave-review | via `actionCenter()` | none | none | none | SRP-03 |
| `combinedStudentReport` | 211 | not routed | none | none | none | none | SRP-04 |
| `classWiseStrengthReport` | 219 | not routed | none | none | none | none | SRP-04 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try[[:space:]]*\{|catch[[:space:]]*\(|getMessage|report\(' Modules/StudentProfile/app/Http/Controllers/StudentReportController.php Modules/StudentProfile/app/Services/StudentAnalyticsService.php` → no output. No try/catch, no `$e->getMessage()`, no swallowed failure (ERR-01..07 clean under D1).

### F2 — Transactions and audit

clean — `grep -nE 'save\(|create\(|delete\(|insert\(|upsert\(|activityLog\(' Modules/StudentProfile/app/Http/Controllers/StudentReportController.php Modules/StudentProfile/app/Services/StudentAnalyticsService.php` → no output. The controller and service contain no write of any kind, so no transaction is required (TXN-01..06 not applicable).

### F3 — Authorization

Every routed method authorizes before it loads a record. The nine standalone methods flagged by the scanner (`studentStrength` … `leaveReview`) delegate to `index()`/`actionCenter()`, which call `Gate::authorize(...)` as their first statement; the scanner flags them because it does not follow the delegation. The permission name `tenant.student-profile.student.viewAny` exists in `config/permissionslist.php` (key `student-profile.student`), in the live tenant database (permission id 816, held by Super Admin and School Admin), in the controller and in both Blade tab definitions. One maintainability finding:

#### SRP-07 · L · AUTH-06 — the permission string is a repeated literal

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M→L) — *permission strings live in one place — a Policy, or constants — not repeated as literals in every method* (lowered to L: only two occurrences, and the value is correct on all four surfaces) |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php:28` and `:94`, methods `index()` and `actionCenter()` |
| **Root cause** | The literal `tenant.student-profile.student.viewAny` is typed twice. A `StudentPolicy::viewAny()` already owns the same check, but the controller bypasses it with a raw Gate string. |
| **Consequence** | If the permission is ever renamed, this controller silently keeps the old name and the two hubs start returning 403 while every other surface moves to the new key. |
| **Reproduce** | static only — renaming a permission is not reproducible in the browser without changing config |
| **Fix approach** | Declare one private constant on the controller and use it in both methods (no behaviour change), or switch both calls to `Gate::authorize('viewAny', Student::class)`. |
| **Plan item** | none — see plan §10 |

```php
// StudentReportController.php:28 and :94 — CURRENT
        Gate::authorize('tenant.student-profile.student.viewAny');
```

**Evidence**
```
$ grep -n "tenant.student-profile.student.viewAny" Modules/StudentProfile/app/Http/Controllers/StudentReportController.php
28:        Gate::authorize('tenant.student-profile.student.viewAny');
94:        Gate::authorize('tenant.student-profile.student.viewAny');
```

### F4 — Validation and input

clean — the controller is read-only; the query-string values are report filters passed to Eloquent (no `$request->all()`, no `except()` into a model, no write path). `grep -nE 'request->all\(|->except\(|->validate\(' Modules/StudentProfile/app/Http/Controllers/StudentReportController.php` → no output.

### F5 — Routes

#### SRP-04 · M · RTE-03 — two public methods are not routed

| Field | Value |
|---|---|
| **Rule** | RTE-03 (M) — *every public controller method is routed, or is deliberately disabled (`abort(403)`, per the alignment tracker rule)* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php:211` `combinedStudentReport()` and `:219` `classWiseStrengthReport()` |
| **Root cause** | Both methods are documented as "legacy route compatibility" but no route in `Modules/StudentProfile/routes/web.php` points at them; the equivalent URLs are served by `index()` and `studentStrength()` instead. They remain reachable only through direct controller calls, not HTTP. |
| **Consequence** | They are dead reachable-looking code; a future developer can add a route to a method whose behaviour was never declared. Today no user is affected because the methods are unreachable. |
| **Reproduce** | static only — there is no URL that reaches these methods |
| **Fix approach** | Per D5, replace each body with `abort(403, ...)` plus a `NOT ROUTED` comment; keep the signatures. |
| **Plan item** | SRP-04 in `02-fix-plan.md` §5 |

```php
// StudentReportController.php:211-222 — CURRENT
    public function combinedStudentReport(Request $request): View
    {
        return $this->index($request);
    }

    /**
     * Legacy route compatibility
     */
    public function classWiseStrengthReport(Request $request): View
    {
        return $this->index($request->merge(['tab' => 'student-strength']));
    }
```

**Evidence**
```
$ grep -n "combinedStudentReport\|classWiseStrengthReport" Modules/StudentProfile/routes/web.php
(no output)
$ grep -n "public function combinedStudentReport\|public function classWiseStrengthReport" Modules/StudentProfile/app/Http/Controllers/StudentReportController.php
211:    public function combinedStudentReport(Request $request): View
219:    public function classWiseStrengthReport(Request $request): View
```

### F6 — Controller shape

#### SRP-05 · M · CTL-05 — the session-resolution block is copy-pasted

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste: dropdown loaders shared by create/edit, the same redirect string repeated, the same payload in store and update* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php:30-39` in `index()` and `:96-104` in `actionCenter()` |
| **Root cause** | Both hub methods independently load the active/current academic session, the class list and the resolved session id. The blocks differ only in that `index()` also loads sections. |
| **Consequence** | A fix to the session fallback (for example the `is_current` → latest fallback chain) must be made twice or the two hubs drift apart. |
| **Reproduce** | static only — duplication in the source |
| **Fix approach** | Extract a private `resolveReportContext(Request $request): array` returning the five shared values; both methods call it. Deferred here to keep the controller-shape change separate from the blocker fixes (see plan §9). |
| **Plan item** | SRP-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// StudentReportController.php:30-39 — CURRENT (index); the same block is at 96-104
        $academicSessions = OrganizationAcademicSession::where('is_active', true)->orderByDesc('id')->get();
        $classes = SchoolClass::active()->orderBy('ordinal')->get();
        $sections = Section::where('is_active', true)->orderBy('name')->get();

        $currentSession = OrganizationAcademicSession::where('is_current', 1)->first()
            ?? OrganizationAcademicSession::where('is_active', true)->orderByDesc('id')->first()
            ?? OrganizationAcademicSession::latest('id')->first();

        $activeSessionId = (int) ($request->input('academic_session_id') ?? $currentSession?->id ?? 0);
        $activeSession = OrganizationAcademicSession::find($activeSessionId) ?? $currentSession;
```

**Evidence**
```
$ grep -n "OrganizationAcademicSession::where('is_current', 1)->first()" Modules/StudentProfile/app/Http/Controllers/StudentReportController.php
34:        $currentSession = OrganizationAcademicSession::where('is_current', 1)->first()
99:        $currentSession = OrganizationAcademicSession::where('is_current', 1)->first()
```

#### SRP-06 · M · CTL-02 — five service methods exceed 80 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *method length: over 80 lines extract; over 150 lines is H* |
| **Where** | `Modules/StudentProfile/app/Services/StudentAnalyticsService.php:42` `getStrengthReportData()` (126), `:172` `getDemographicsQuotaData()` (149), `:325` `getAttendanceSummaryData()` (141), `:470` `getMedicalSafetyData()` (100), `:574` `getProfileAuditData()` (117) |
| **Root cause** | Each report builder loads its rows, does its classification and shapes the KPI/chart arrays in one method, so the data mapping and the query live together. |
| **Consequence** | Hard to test or change one KPI without reading the whole method; the N+1 defects (SRP-01/SRP-02) hide in the middle of these long bodies. |
| **Reproduce** | static only — source length |
| **Fix approach** | Deferred refactor (split query / mapping per report). The functional fixes SRP-01/SRP-02 are planned separately and do not depend on this. |
| **Plan item** | SRP-06 in `02-fix-plan.md` §9 (DECISION) |

```php
// StudentAnalyticsService.php:42-44 — CURRENT (start of the longest method)
    public function getStrengthReportData(?int $sessionId, array $filters = []): array
    {
        $sessionId = $this->resolveSessionId($sessionId);
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/StudentProfile/app/Services/StudentAnalyticsService.php
M  CTL-02   .../StudentAnalyticsService.php:42   getStrengthReportData — getStrengthReportData() is 126 lines
M  CTL-02   .../StudentAnalyticsService.php:172  getDemographicsQuotaData — getDemographicsQuotaData() is 149 lines
M  CTL-02   .../StudentAnalyticsService.php:325  getAttendanceSummaryData — getAttendanceSummaryData() is 141 lines
M  CTL-02   .../StudentAnalyticsService.php:470  getMedicalSafetyData — getMedicalSafetyData() is 100 lines
M  CTL-02   .../StudentAnalyticsService.php:574  getProfileAuditData — getProfileAuditData() is 117 lines
```

### F7 — Models

#### SRP-08 · B · MDL-05 — Student photos are written to the central database

| Field | Value |
|---|---|
| **Rule** | MDL-05 (B) — *every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()`, otherwise media rows go to the central DB (cross-tenant leak)* (identical rule TEN-01) |
| **Where** | `Modules/StudentProfile/app/Models/Student.php:21-26` (class + trait), media collections at `:340-351` |
| **Root cause** | `Student` uses `InteractsWithMedia` and registers the `student_photo` / `user_img` collections, but does not override `getMediaModel()`. Spatie therefore uses `config('media-library.media_model')`, which is `Modules\Prime\Models\Media` — a model pinned to the central `mysql` connection. Tenant models `User`, `Employee`, `Organization`, `Application` and `LibBookMaster` all override it to `App\Models\TenantMedia`. |
| **Consequence** | A student photo uploaded in a tenant is stored in the central `sys_media` table under the tenant's model id. Two tenants with the same student id share one media row, and the `singleFile()` collection lets one tenant's upload delete another's photo. |
| **Reproduce** | static only — needs a photo upload then a `sys_media` row check; not reproducible from the report screen |
| **Fix approach** | Add `getMediaModel(): string { return \App\Models\TenantMedia::class; }` to `Student`, mirroring `Modules/SchoolSetup/app/Models/User.php:214`. |
| **Plan item** | SRP-08 in `02-fix-plan.md` §1 |

```php
// Student.php:21-28 — CURRENT
class Student extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia {
        InteractsWithMedia::getFirstMediaUrl as traitGetFirstMediaUrl;
        InteractsWithMedia::hasMedia as traitHasMedia;
    }

    protected $table = 'std_students';
```

**Evidence**
```
$ grep -c "getMediaModel" Modules/StudentProfile/app/Models/Student.php
0
$ grep -n "public function getMediaModel" Modules/SchoolSetup/app/Models/User.php
214:    public function getMediaModel(): string
$ grep -n "'media_model'" config/media-library.php
73:    'media_model' => Media::class,
$ grep -n "protected \$connection" Modules/Prime/app/Models/Media.php
9:    protected $connection = 'mysql';
$ grep -n "addMediaCollection\|getFirstMedia" Modules/StudentProfile/app/Models/Student.php
342:        $this->addMediaCollection('student_photo')
347:        $this->addMediaCollection('user_img')
391:        $media = $this->getFirstMedia('student_photo') ?: $this->getFirstMedia('user_img');
```

#### SRP-10 · L · MDL-04 — relationship methods have no return type

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany` …)* |
| **Where** | `Modules/StudentProfile/app/Models/Student.php:89, 94, 99, 104, 123, 128, 140, 145, 150, 154, 163, 169, 174, 179, 184, 189, 194, 199, 204, 216, 221, 305, 310, 315, 321, 326, 331` |
| **Root cause** | Every relation method in `Student` is declared as a bare `public function name()` with no return type; the convention in this codebase is to type them. |
| **Consequence** | No user-visible effect; IDE and static analysis cannot resolve the relation, and a wrong relation call is caught only at runtime. |
| **Reproduce** | static only — style/typing |
| **Fix approach** | Add the matching `BelongsTo`/`HasMany`/`HasOne`/`HasOneThrough`/`BelongsToMany` return types. Best done as a single codemod, not by hand. |
| **Plan item** | none — see plan §10 |

```php
// Student.php:89-92 — CURRENT (representative; 27 relation methods share this shape)
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
```

**Evidence**
```
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/StudentProfile/app/Models/Student.php
L  MDL-04   .../Student.php:89  user — relation user() has no return type
L  MDL-04   .../Student.php:94  profile — relation profile() has no return type
L  MDL-04   .../Student.php:104 guardians — relation guardians() has no return type
L  MDL-04   .../Student.php:331 examGroupMemberships — relation examGroupMemberships() has no return type
(27 relation rows total)
```

### F8 — Services and jobs

clean — `grep -nE 'request\(|session\(|redirect\(|response\(|back\(' Modules/StudentProfile/app/Services/StudentAnalyticsService.php` → no output; the service is constructed with constructor injection and performs no writes (SVC-01..05 clean, no jobs in scope).

### F9 — Queries and performance

#### SRP-01 · H · QRY-01 — the chronic-absence queue runs one attendance query per student

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops; no `Model::where/find/create/update`, `->save()` or lazy relation access inside `foreach`, `for`, `->map()`, `->each()`* |
| **Where** | `Modules/StudentProfile/app/Services/StudentAnalyticsService.php:715-722`, method `getChronicAbsenteeismQueue()` |
| **Root cause** | The method loads every current `StudentAcademicSession` (1,825 rows on the live tenant), then for each one runs a separate `StudentAttendance::where(...)->get()`. |
| **Consequence** | Opening the Chronic Absence tab issues roughly one query per enrolled student (about 1,825 queries plus the session load), so the page can take many seconds or time out on a real school. |
| **Reproduce** | Open `http://test.localhost:8000/student-profile/reports/action-center?tab=chronic-absenteeism` and watch the query count (Laravel Telescope/DB log); expected one query for the whole queue. |
| **Fix approach** | One `StudentAttendance` query for all the session's students with `->groupBy('student_id')`, then read the group inside the loop. |
| **Plan item** | SRP-01 in `02-fix-plan.md` §6 |

```php
// StudentAnalyticsService.php:712-722 — CURRENT
        $sessions = $sessionsQuery->get();
        $queue = [];

        foreach ($sessions as $s) {
            $st = $s->student;
            if (!$st) continue;

            $attendances = StudentAttendance::where('academic_session_id', $sessionId)
                ->where('student_id', $st->id)
                ->orderByDesc('attendance_date')
                ->get();
```

**Evidence**
```
$ grep -n "StudentAttendance::where" Modules/StudentProfile/app/Services/StudentAnalyticsService.php
359:            $attQuery = StudentAttendance::where('academic_session_id', $sessionId)   # inside foreach at 346
418:        $workingDays = StudentAttendance::where(...)->distinct(...)->count(...)        # outside any loop
719:            $attendances = StudentAttendance::where('academic_session_id', $sessionId) # inside foreach at 715
$ php artisan tinker --execute '... DB::table("std_student_academic_sessions")->where("is_current",1)->count() ...'
current_sessions=1825
```

#### SRP-02 · H · QRY-01 — the attendance register runs two queries per class section

| Field | Value |
|---|---|
| **Rule** | QRY-01 (H) — *no queries inside loops* |
| **Where** | `Modules/StudentProfile/app/Services/StudentAnalyticsService.php:346-369`, method `getAttendanceSummaryData()` |
| **Root cause** | For each of the 43 active class sections the method runs one `StudentAcademicSession::where(...)->pluck()` and then one `StudentAttendance::where(...)->get()` that loads every attendance row of that section. |
| **Consequence** | The Attendance Register tab issues about 86 queries and, worse, loads roughly 99,334 attendance rows into PHP memory in a single request — the slowest page in the module. |
| **Reproduce** | Open `http://test.localhost:8000/student-profile/reports/attendance-summary` and watch memory/query count; expected two bulk queries. |
| **Fix approach** | Pre-fetch the enrolled student ids per section and the whole session's attendance in two queries, grouped by `student_id`, then read from the collections in the loop. |
| **Plan item** | SRP-02 in `02-fix-plan.md` §6 |

```php
// StudentAnalyticsService.php:346-369 — CURRENT
        foreach ($classSections as $cs) {
            $studentIds = StudentAcademicSession::where('academic_session_id', $sessionId)
                ->where('class_section_id', $cs->id)
                ->where('is_current', 1)
                ->pluck('student_id')
                ->toArray();

            $enrolled = count($studentIds);
            if ($enrolled === 0) {
                continue;
            }
            $totalEnrolledAll += $enrolled;

            $attQuery = StudentAttendance::where('academic_session_id', $sessionId)
                ->whereIn('student_id', $studentIds);

            if (!empty($filters['start_date'])) {
                $attQuery->whereDate('attendance_date', '>=', $filters['start_date']);
            }
            if (!empty($filters['end_date'])) {
                $attQuery->whereDate('attendance_date', '<=', $filters['end_date']);
            }

            $attRecords = $attQuery->get();
```

**Evidence**
```
$ php artisan tinker --execute '... DB::table("std_student_attendance")->count() ...'
students=1825 current_sessions=1825 attendance=99334 class_sections=43
$ grep -n "StudentAttendance::where" Modules/StudentProfile/app/Services/StudentAnalyticsService.php
359:            $attQuery = StudentAttendance::where('academic_session_id', $sessionId)
```

#### SRP-03 · M · QRY-02 — every tab's dataset is built on every request, unbounded

| Field | Value |
|---|---|
| **Rule** | QRY-02 (M) — *lists are paginated; no `Model::all()` or unbounded `->get()` feeding a list page* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StudentReportController.php:66-70` in `index()` and `:123` in `actionCenter()`; each service builder ends in `->get()` followed by `->toArray()` |
| **Root cause** | Both hubs compute and pass every tab's dataset in one request (`index` always calls five builders, `actionCenter` always calls the four-queue summary), and each builder loads its whole result set into PHP. The Blade paginates client-side with `array_slice`, so the database query is never limited. |
| **Consequence** | Even a user who opens the Student Strength tab pays for the Attendance Register and Medical Safety builds too; the unbounded `->get()` calls mean page weight grows linearly with the student body (1,825 today). |
| **Reproduce** | Open `http://test.localhost:8000/student-profile/reports` and note that all five datasets are queried although only one tab is visible. |
| **Fix approach** | This is a design decision, not a mechanical fix: the tabs are rendered server-side and switched client-side, so data for all tabs must be present unless the page moves to lazy per-tab loading. Recommended: fix SRP-01/SRP-02 first, then either accept the remaining cost or move to AJAX tab loading. |
| **Plan item** | SRP-03 in `02-fix-plan.md` §9 (DECISION) |

```php
// StudentReportController.php:66-70 — CURRENT
        $strengthData     = $this->analyticsService->getStrengthReportData($activeSessionId, $filters);
        $demographicsData = $this->analyticsService->getDemographicsQuotaData($activeSessionId, $filters);
        $attendanceData   = $this->analyticsService->getAttendanceSummaryData($activeSessionId, $filters);
        $medicalData      = $this->analyticsService->getMedicalSafetyData($activeSessionId, $filters);
        $profileAuditData = $this->analyticsService->getProfileAuditData($activeSessionId, $filters);
```

**Evidence**
```
$ grep -n "analyticsService->get" Modules/StudentProfile/app/Http/Controllers/StudentReportController.php
66:        $strengthData     = $this->analyticsService->getStrengthReportData($activeSessionId, $filters);
67:        $demographicsData = $this->analyticsService->getDemographicsQuotaData($activeSessionId, $filters);
68:        $attendanceData   = $this->analyticsService->getAttendanceSummaryData($activeSessionId, $filters);
69:        $medicalData      = $this->analyticsService->getMedicalSafetyData($activeSessionId, $filters);
70:        $profileAuditData = $this->analyticsService->getProfileAuditData($activeSessionId, $filters);
123:        $actionSummary = $this->analyticsService->getActionCenterSummary($activeSessionId, $filters);
```

### F10 — Views

clean — `grep -rnE 'Model::|DB::' Modules/StudentProfile/resources/views/reports/` and `grep -rn '{!!' Modules/StudentProfile/resources/views/reports/` both return no output. The partials iterate over arrays the controller passes; no relation is loaded in a loop in Blade.

### F11 — Security and tenancy

#### SRP-09 · M · TEN-04 — the student photo accessor uses `asset()` and a column that does not exist

| Field | Value |
|---|---|
| **Rule** | TEN-04 (M) — *tenant file URLs go through `tenant_asset()`, not `asset('storage/...')`* |
| **Where** | `Modules/StudentProfile/app/Models/Student.php:389-403`, method `getPhotoUrlAttribute()` |
| **Root cause** | The legacy fallback branch tests `$this->first_media_id`, which is not a column on `std_students` (the column is `media_id`), so the branch is never entered; and the branch it guards builds a URL with `asset('storage/students/...')`, which points at the central host, not the tenant host. |
| **Consequence** | A student whose photo exists only in the legacy `photo_file_name` field always shows the placeholder avatar, and if the branch ever ran it would emit a central-domain URL for a tenant file. |
| **Reproduce** | static only — the accessor is read by the mobile controllers, not the report screen; trigger requires a legacy-photo student in the mobile app. |
| **Fix approach** | Test `$this->photo_file_name` instead of the non-existent property and return `tenant_asset('storage/students/' . $this->photo_file_name)`. |
| **Plan item** | SRP-09 in `02-fix-plan.md` §5 |

```php
// Student.php:389-403 — CURRENT
    public function getPhotoUrlAttribute()
    {
        $media = $this->getFirstMedia('student_photo') ?: $this->getFirstMedia('user_img');

        if ($media) {
            return $media->getUrl();
        }

        // Fallback to old field or placeholder
        if ($this->first_media_id) {
            return asset('storage/students/' . $this->photo_file_name);
        } else {
            return asset('assets/images/avatar.png');
        }
    }
```

**Evidence**
```
$ grep -n "first_media_id" Modules/StudentProfile/app/Models/Student.php
398:        if ($this->first_media_id) {
$ grep -n "first_media_id" database/migrations/tenant/2026_06_15_151302_create_std_students_table.php
(no output — the column is media_id, line 34 of the migration)
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/StudentProfile/app/Models/Student.php
M  TEN-04   .../Student.php:399 — asset('storage/...') instead of tenant_asset()
```

### F12 — Style

#### SRP-11 · L · STY-01 — Student.php lacks `declare(strict_types=1)`

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/StudentProfile/app/Models/Student.php:1-3` |
| **Root cause** | The file predates the strict-types rule and was never touched since. |
| **Consequence** | None at runtime today; the model silently coerces scalar arguments, unlike the strict-typed controllers and services around it. |
| **Reproduce** | static only — typing style |
| **Fix approach** | Add the declaration after the opening tag. Deferred here because enabling strict types on a model with 1,825 live consumers can surface latent TypeErrors that this workflow cannot test (D4). |
| **Plan item** | none — see plan §10 |

```php
// Student.php:1-3 — CURRENT
<?php

namespace Modules\StudentProfile\Models;
```

**Evidence**
```
$ grep -n "strict_types" Modules/StudentProfile/app/Models/Student.php
(no output)
$ python3 final-audit-reports/_tools/scanfilter.py /tmp/fa-studentprofile.json Modules/StudentProfile/app/Models/Student.php
L  STY-01   .../Student.php:1 — missing declare(strict_types=1)
```

### F13 — Deep read (answer all 8 questions for every mutating method)

The controller and its service contain no mutating method; `Student.php` has a model-level `saving` hook (`<abbr>pii_aadhar_updated</abbr>` activity log) that is not called from this screen. The eight deep-read questions therefore have no mutating subject here:

| Mutating method | 1 wrong data | 2 delete before store | 3 duplicate impl | 4 soft-delete x unique | 5 race | 6 auth hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| none in scope | n/a | n/a | n/a | n/a | n/a | n/a (all routed methods gate) | n/a | n/a |

Notes: the service does classify data (defaults such as `'Asthma (Mild)'`, `68.5`, `9876543210` in `getMedicalSafetyData()` / `getChronicAbsenteeismQueue()`) — these are placeholder display values, not writes, so they change no stored record. They are recorded here, not as a finding, because the rulebook family for wrong data targets writes.

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules\Prime\Models\Media` | Pinned to the central `mysql` connection; every tenant model that does not override `getMediaModel()` writes media here. `Student` is one such model (finding SRP-08). | MDL-05 / TEN-01 | owner of each tenant media model; `Student` is fixed in this plan |
| `Modules\SchoolSetup\Models\OrganizationAcademicSession`, `SchoolClass`, `Section`, `ClassSection` | Read directly from tenant context inside the controller/service; not audited (other module). | - | SchoolSetup module owner |

## 8. Not covered, and why

- The nine Blade partials under `reports/partials/` were checked for queries and raw output only; their chart JavaScript and print CSS were not executed.
- The linked models (rows 7–15) are audited by other, still-`CLAIMED` reports; their internals are out of scope here.
- No queue job, command or listener is reachable from this controller, so F8's job rules and JOB-01..05 were not exercised.
- Runtime query counts were reasoned from the source and the live row counts; they were not measured with Telescope because D4 forbids running the screen.
- `Student` strict-types enablement (SRP-11) is deferred and therefore unverified.
