# Final Audit — StudentProfile / MedicalIncidentController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php` (339 lines, 13 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/medical-incidents` — index (linked from the dashboard "Medical Incidents" button) · `.../create` — create form · `.../{id}` — show · `.../{id}/edit` — edit form · `.../trash/view` — trash list · `.../{id}/restore`, `.../{id}/force-delete`, `.../{id}/toggle-follow-up`, `.../{id}/toggle-parent-notified` — row actions. The live school screen is the **Medical Incident tab inside Bulk Attendance** (`student-profile/attendance.bulk?tab=medical-incident`), which is rendered by `AttendanceController::bulkAttendanceIndex()` and includes this controller's `index` blade. |
| Menu path | Student Profile → (dashboard) Medical Incidents / Bulk Attendance → Medical Incident tab |
| Who uses it | Roles holding `tenant.student-profile.medical-incident.viewAny` on `test.localhost`, measured via `sys_role_has_permissions_jnt`: **Super Admin, School Admin** |
| What a user does here | Records a medical incident for a student (date, type, location, description, first aid, action taken, reporter, parent-notified and follow-up flags, optional closure date), edits it, deletes/restores it, and toggles follow-up / parent-notified flags. The form also offers a "Medical Document" image upload that the backend never saves. |
| Tables written | `std_medical_incidents` (INSERT/UPDATE/DELETE), `sys_activity_logs` via `activityLog()` (UPDATE/DELETE/RESTORE/TOGGLE paths only — not on create) |
| Tables read | `std_medical_incidents`, `std_students`, `sys_users`, `sys_dropdown_table`, `sch_class_section_jnt` + `sch_classes` + `sch_sections` |
| Live data | `std_medical_incidents`: **674 live, 0 trashed** on `test.localhost` (tenant `xyz_school_00000000000040008000_202627`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The single worst defect is that the controller's own list route (`GET /student-profile/medical-incidents`, linked from the dashboard) renders a partial that expects three variables the controller never passes, so the page 500s with an undefined-variable error; the trash page renders an empty 0-byte blade, and the two mutation families (transactions/audit, media) are broken or dead. The plan is roughly M/L-sized (about one developer day): 5 high findings are mechanical (transactions, one GET restore route, one unbounded query, one blank blade, one silent upload), and 4 of the 20 findings are DECISION items where Tarun must pick an option. Nothing here blocks fixing: every fix is contained in the controller, its model/policy, the module views, and one shared route file.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 2 | 5 | 9 | 4 | 4 | 20 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | clean | F8 Services/Jobs | clean |
| F2 Transactions/Audit | MIC-01, MIC-02 | F9 Queries/Perf | MIC-14, MIC-15 |
| F3 Authorization | MIC-03 | F10 Views | MIC-16, MIC-17, MIC-18 |
| F4 Validation | MIC-04, MIC-06 | F11 Security/Tenancy | clean |
| F5 Routes | MIC-07 | F12 Style | MIC-19 |
| F6 Controller shape | MIC-05, MIC-08, MIC-09, MIC-10, MIC-11 | F13 Deep read | MIC-20 |
| F7 Models | MIC-12, MIC-13 | | |

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php` | controller | 339 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Models/MedicalIncident.php` | model | 81 | this report | ✅ |
| 3 | `Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php` | policy | 49 | this report | ✅ |
| 4 | `Modules/StudentProfile/resources/views/medical-incident/index.blade.php` | view | 208 | this report (also included by AttendanceController) | ✅ |
| 5 | `Modules/StudentProfile/resources/views/medical-incident/create.blade.php` | view | 193 | this report | ✅ |
| 6 | `Modules/StudentProfile/resources/views/medical-incident/edit.blade.php` | view | 174 | this report | ✅ |
| 7 | `Modules/StudentProfile/resources/views/medical-incident/show.blade.php` | view | 206 | this report | ✅ |
| 8 | `Modules/StudentProfile/resources/views/medical-incident/trash.blade.php` | view | 0 | this report | ✅ (empty on purpose) |
| 9 | `Modules/StudentProfile/app/Models/Student.php` | model (used: `active()`, `user()`, `full_name`) | — | ↗ [gaurav/StudentProfile/StudentReportController](../StudentReportController/01-report.md) | ↗ linked |
| 10 | `Modules/StudentProfile/app/Models/StudentAcademicSession.php` | model (unused import only) | — | ↗ [gaurav/StudentProfile/StudentController](../StudentController/01-report.md) | ↗ linked |
| 11 | `Modules/SystemConfig/app/Models/Dropdown.php` | model (used: `where('key',...)`) | — | common (different module) | ✅ usage only |
| 12 | `Modules/SchoolSetup/app/Models/User.php` | model (used: `active()`) | — | common (different module) | ✅ usage only |
| 13 | `Modules/SchoolSetup/app/Models/ClassSection.php` | model (used: class/section join) | — | common (different module) | ✅ usage only |
| 14 | `Modules/StudentProfile/routes/web.php` | routes | — | shared route file | ✅ usage only |

No pre-applied files (no `PRE-APPLIED-2026-10-10.md` for this module).

## 4. Routes

```
GET|HEAD  student-profile/ajax/medical-incidents/get-students          student-profile.medical-incidents.ajax.get-students     MedicalIncidentController@ajaxGetStudents
GET|HEAD  student-profile/medical-incidents                            student-profile.medical-incidents.index                 MedicalIncidentController@index
POST      student-profile/medical-incidents                            student-profile.medical-incidents.store                 MedicalIncidentController@store
GET|HEAD  student-profile/medical-incidents/create                     student-profile.medical-incidents.create                MedicalIncidentController@create
GET|HEAD  student-profile/medical-incidents/trash/view                 student-profile.medical-incidents.trashed               MedicalIncidentController@trashed
DELETE    student-profile/medical-incidents/{id}/force-delete          student-profile.medical-incidents.forceDelete           MedicalIncidentController@forceDelete
GET|HEAD  student-profile/medical-incidents/{id}/restore               student-profile.medical-incidents.restore               MedicalIncidentController@restore
POST      student-profile/medical-incidents/{id}/toggle-follow-up      student-profile.medical-incidents.toggleFollowUp        MedicalIncidentController@toggleFollowUp
POST      student-profile/medical-incidents/{id}/toggle-parent-notified student-profile.medical-incidents.toggleParentNotified  MedicalIncidentController@toggleParentNotified
GET|HEAD  student-profile/medical-incidents/{medical_incident}         student-profile.medical-incidents.show                  MedicalIncidentController@show
PUT|PATCH student-profile/medical-incidents/{medical_incident}         student-profile.medical-incidents.update                MedicalIncidentController@update
DELETE    student-profile/medical-incidents/{medical_incident}         student-profile.medical-incidents.destroy               MedicalIncidentController@destroy
GET|HEAD  student-profile/medical-incidents/{medical_incident}/edit    student-profile.medical-incidents.edit                  MedicalIncidentController@edit
```

Source: `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list --json` (uncached, 2026-10-10).

Unrouted public methods: none — all 13 public methods are routed.

Note the parameter mismatch: the resource routes bind `{medical_incident}` while the controller methods take `$id` (see MIC-08), and `restore` is a GET route that mutates (see MIC-07).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 22 | GET /student-profile/medical-incidents | `tenant.student-profile.medical-incident.viewAny` | none (read) | none | — | MIC-16 |
| `create` | 38 | GET .../create | `tenant.student-profile.medical-incident.create` | none (read) | none | — | MIC-14, MIC-05 (loader dup) |
| `ajaxGetStudents` | 71 | GET ajax/medical-incidents/get-students | `tenant.student-profile.medical-incident.view` | none (read) | none | — | MIC-15 |
| `store` | 97 | POST /student-profile/medical-incidents | `tenant.student-profile.medical-incident.create` | none | none — **missing** | `std_medical_incidents` | MIC-02, MIC-04, MIC-05, MIC-06 |
| `show` | 125 | GET {medical_incident} | `tenant.student-profile.medical-incident.view` | none (read) | none | — | MIC-08, MIC-09, MIC-11 |
| `edit` | 145 | GET {medical_incident}/edit | `tenant.student-profile.medical-incident.update` | none (read) | none | — | MIC-08, MIC-14, MIC-05 (loader dup) |
| `update` | 168 | PUT {medical_incident} | `tenant.student-profile.medical-incident.update` | **none** | `'Updated'` after the write | `std_medical_incidents`, `sys_activity_logs` | MIC-01, MIC-04, MIC-05, MIC-08 |
| `destroy` | 215 | DELETE {medical_incident} | `tenant.student-profile.medical-incident.delete` | **none** | `'Deleted'` after the delete | `std_medical_incidents`, `sys_activity_logs` | MIC-01, MIC-08 |
| `trashed` | 234 | GET .../trash/view | `tenant.student-profile.medical-incident.restore` | none (read) | none | — | MIC-17 |
| `restore` | 253 | **GET** {id}/restore | `tenant.student-profile.medical-incident.restore` | **none** | `'Restored'` after the write | `std_medical_incidents`, `sys_activity_logs` | MIC-01, MIC-07 |
| `forceDelete` | 272 | DELETE {id}/force-delete | `tenant.student-profile.medical-incident.forceDelete` | **none** | `'Force Deleted'` after the write | `std_medical_incidents`, `sys_activity_logs` | MIC-01 |
| `toggleFollowUp` | 291 | POST {id}/toggle-follow-up | `tenant.student-profile.medical-incident.update` | **none** | `'Toggled'` after the write | `std_medical_incidents`, `sys_activity_logs` | MIC-01, MIC-20 |
| `toggleParentNotified` | 317 | POST {id}/toggle-parent-notified | `tenant.student-profile.medical-incident.update` | **none** | `'Toggled'` after the write | `std_medical_incidents`, `sys_activity_logs` | MIC-01, MIC-20 |

## 6. Findings

### F1 — Errors

clean — `grep -nE 'try|catch|getMessage' Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php` → no output (rc=1). No try/catch anywhere (D1 compliant), no `$e->getMessage()` reaching the user, no `Log::error` with exception text.

### F2 — Transactions and audit

#### MIC-01 · H · TXN-01/TXN-04 — six mutating methods write + audit-log outside any transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (a model + its audit row) runs inside one `DB::transaction`* and TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:168-210`, methods `update()`, `destroy()` (215-229), `restore()` (253-267), `forceDelete()` (272-286), `toggleFollowUp()` (291-312), `toggleParentNotified()` (317-338) |
| **Root cause** | Each of the six methods performs one model write (`update()`, `delete()`, `restore()`, `forceDelete()`, two `save()`) followed by an `activityLog()` call. `activityLog()` inserts a row into `sys_activity_logs` (verified in `app/Helpers/activityLog.php:45-50`), so each method really is a two-table write — and none of them uses `DB::transaction`. The controller imports `DB` (line 8) but never calls it, so the write and the audit row can diverge: a failed audit insert after a successful delete leaves the record deleted with no log, and there is no rollback on any failure. |
| **Consequence** | A failure between the model write and the audit insert leaves the school's data changed with a missing audit trail — exactly the divergence the transaction rule exists to prevent. |
| **Reproduce** | Static only — the divergence needs a simulated failure after the write. The code shape (write then `activityLog`, no `DB::transaction`) is visible in all six methods. |
| **Fix approach** | Wrap each method's model write + `activityLog()` in one `DB::transaction(function () { ... })` closure, keeping `findOrFail()` outside the closure (D1/D2: no try/catch). Activity log stays after the write, inside the closure. |
| **Plan item** | MIC-01 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "activityLog\|DB::transaction" <controller>` — six `activityLog` calls, zero `DB::transaction` |

```php
// MedicalIncidentController.php:189-205 — CURRENT (update())
        $incident->update($validated);

        $changes = [];
        foreach ($incident->getChanges() as $field => $newValue) {
            if ($field === 'updated_at')
                continue;
            $changes[$field] = [
                'old' => $original[$field] ?? null,
                'new' => $newValue,
            ];
        }

        activityLog($incident, 'Updated', [
            'message' => 'Medical incident updated.',
            'changes' => $changes,
            'performed_by' => Auth::user()->name ?? null,
        ]);
```

**Evidence**
```
$ grep -n "activityLog\|DB::transaction" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
201:        activityLog($incident, 'Updated', [
222:        activityLog($incident, 'Deleted', [
260:        activityLog($incident, 'Restored', [
279:        activityLog($incident, 'Force Deleted', [
303:        activityLog($incident, 'Toggled', [
329:        activityLog($incident, 'Toggled', [
```

#### MIC-02 · M · TXN-04 — `store()` writes the incident with no activity log while every other mutation logs

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) — *`activityLog()` sits inside the transaction, after the write it describes* — the checklist (audit §6 F2) requires every mutating method to have one |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:97-120`, method `store()` |
| **Root cause** | `store()` creates the record (`MedicalIncident::create($validated)`, line 115) and redirects. Unlike `update`/`destroy`/`restore`/`forceDelete`/both toggles, it never calls `activityLog()`. There is no audit trail for the most common action on this screen — creating an incident. |
| **Consequence** | History lookups (Activity Log / audit screens) cannot show who created an incident or when, even though every other change to the same table is audited. |
| **Reproduce** | Create an incident in the browser, then open the activity log for the record: no "Created" entry exists (no create-side log is written anywhere for this table). |
| **Fix approach** | Add the same shaped `activityLog($incident, 'Created', ['message' => ...])` inside a `DB::transaction` with the `create`. Keep the event literal `'Created'` consistent with the other events. |
| **Plan item** | MIC-02 in `02-fix-plan.md` §3 |
| **Evidence** | `grep -n "activityLog" <controller>` — first call is line 201 (`update`), nothing between `store` (97-120) and the update |

```php
// MedicalIncidentController.php:115-120 — CURRENT store() tail
        MedicalIncident::create($validated);

        return redirect()
            ->route('student-profile.attendance.bulk', ['tab' => 'medical-incident'])
            ->with('success', flash('created.medical_incident'));
    }
```

**Evidence**
```
$ grep -n "activityLog" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
201:        activityLog($incident, 'Updated', [
222:        activityLog($incident, 'Deleted', [
260:        activityLog($incident, 'Restored', [
279:        activityLog($incident, 'Force Deleted', [
303:        activityLog($incident, 'Toggled', [
329:        activityLog($incident, 'Toggled', [
```

### F3 — Authorization

#### MIC-03 · M · AUTH-06 — `MedicalIncidentPolicy` is registered but nothing ever consults it

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *Permission strings live in one place — a Policy or constants — not repeated as literals in every method*; the F3 checklist also says "Report every Policy that nothing consults" |
| **Where** | `Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php:10-13` (whole 49-line policy), registered at `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:65` |
| **Root cause** | The controller authorizes every method with `Gate::authorize('tenant.student-profile.medical-incident.<action>')` — a permission string resolved by Spatie's Gate registration. Spatie resolves the string before Laravel policy resolution, so `MedicalIncidentPolicy` (all eight methods, each returning the same `$user->can('tenant...')`) is never invoked. The permission names are literal-repeated in the controller, the policy, and three blades. The policy is dead code that duplicates the literals. |
| **Consequence** | No user-visible defect — every method is still authorized — but a developer reading the policy believes it guards the resource when it never runs; edits to the policy (e.g. adding a record-ownership check) silently do nothing. |
| **Reproduce** | Static only — `grep -rn "MedicalIncidentPolicy"` shows only the provider registration and the class itself; no `authorize('view', $incident)` or `$this->authorize(... , MedicalIncident::class)` call exists anywhere. |
| **Fix approach** | DECISION: remove the dead policy class and its `Gate::policy()` registration (touches the shared provider), or keep it as documentation and record the string duplication as accepted. |
| **Plan item** | MIC-03 in `02-fix-plan.md` §4 |
| **Evidence** | `grep -rn "MedicalIncidentPolicy" Modules/StudentProfile --include=*.php` (excluding the class file) → only the provider line |

```php
// MedicalIncidentPolicy.php:10-13 — CURRENT
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.student-profile.medical-incident.viewAny');
    }
```

**Evidence**
```
$ grep -rn "MedicalIncidentPolicy" Modules/StudentProfile --include=*.php | grep -v "Policies/MedicalIncidentPolicy.php:"
Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:19:use Modules\StudentProfile\Policies\MedicalIncidentPolicy;
Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:65:        Gate::policy(MedicalIncident::class, MedicalIncidentPolicy::class);
```

### F4 — Validation and input

#### MIC-04 · M · VAL-02 — validation lives inline in the controller, not in a FormRequest

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *Validation lives in a Form Request (project rule), not inline `$request->validate()` — except one-field AJAX toggles* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:101-113`, methods `store()` and `update()` (175-187) |
| **Root cause** | `store()` and `update()` each call `$request->validate([...11 rules...])` inline. The two toggle methods (line 295, 321) also validate inline but are one-field AJAX toggles, which the rule explicitly allows. `store`/`update` are full CRUD write paths and should use a per-resource FormRequest (the project pattern, cf. `StudentLeaveTypeRequest`). |
| **Consequence** | Validation logic is duplicated in the controller and cannot be reused or unit-tested independently; any rule change must be made twice (see MIC-05). |
| **Reproduce** | Static only — the 11-rule arrays sit at lines 101 and 175. |
| **Fix approach** | Extract a `MedicalIncidentRequest` (rules for store + update) under `Modules/StudentProfile/app/Http/Requests/`, type-hint it in `store()` and `update()`, and use `$request->validated()`. The two one-field toggles keep their inline `validate()` per the rule. |
| **Plan item** | MIC-04 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "request->validate" <controller>` → 101, 175 (full), 295, 321 (single-field toggles, allowed) |

```php
// MedicalIncidentController.php:101-113 — CURRENT store() validation
        $validated = $request->validate([
            'student_id' => 'required|exists:std_students,id',
            'incident_date' => 'required|date',
            'incident_type_id' => 'required|exists:sys_dropdown_table,id',
            'location' => 'required|string|max:100',
            'description' => 'required|string',
            'first_aid_given' => 'nullable|string|max:512',
            'action_taken' => 'nullable|string|max:255',
            'reported_by' => 'required|exists:sys_users,id',
            'parent_notified' => 'boolean',
            'closure_date' => 'nullable|date|after_or_equal:incident_date',
            'follow_up_required' => 'boolean',
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
101:        $validated = $request->validate([
175:        $validated = $request->validate([
295:        $request->validate([
321:        $request->validate([
```

#### MIC-06 · H · VAL-06 — the "Medical Document" upload is accepted by the form and silently discarded

| Field | Value |
|---|---|
| **Rule** | VAL-06 (H) — *Every upload has `file` + `mimes:`/`mimetypes:` + `max:`* — plus the deep-read dead-feature check |
| **Where** | `Modules/StudentProfile/resources/views/medical-incident/create.blade.php:143-145` (and `edit.blade.php:149-151`, `show.blade.php:126-141`), methods `store()`/`update()` |
| **Root cause** | Both forms are `enctype="multipart/form-data"` and render `<x-backend.form.image-with-preview name="medical_document">`, but `store()` and `update()` never validate `medical_document` and never call `addMedia`/`addMediaFromRequest`. The model registers a media collection named **`medical_documents`** (plural, `MedicalIncident.php:67`) while every view reads **`medical_document`** (singular) via `getFirstMediaUrl('medical_document', ...)`, so even a stored file would never render. The upload control is pure decoration: a user's chosen image is dropped on save. |
| **Consequence** | A user who picks a document sees it in the form, submits, and the file is silently gone — the success flash ("created") lies about the upload. |
| **Reproduce** | Open the create form, pick an image in the Medical Document preview, save. No media row appears for the record and the image is not re-shown on the show page. |
| **Fix approach** | DECISION: either (a) implement the upload (requires MIC-12 `getMediaModel()` first, plus `file|mimes|max` rules in a FormRequest and `addMediaFromRequest('medical_document')` in `store`/`update`), or (b) remove the upload control, the `enctype`, and the show-page media block so the form stops promising a feature it does not have. |
| **Plan item** | MIC-06 in `02-fix-plan.md` §2 |
| **Evidence** | `grep -rn "medical_document" create.blade.php edit.blade.php MedicalIncident.php <controller>` → view uses singular, model registers plural, controller never mentions the field |

```php
// create.blade.php:143-145 — CURRENT upload control
                            <x-backend.form.image-with-preview name="medical_document" id="medical_document"
                                image="{{ isset($medicalIncident) ? $medicalIncident->getFirstMediaUrl('medical_document', 'medium') : '' }}"
                                label="Medical Document" />
```

**Evidence**
```
$ grep -rn "medical_document" Modules/StudentProfile/resources/views/medical-incident/create.blade.php Modules/StudentProfile/resources/views/medical-incident/edit.blade.php Modules/StudentProfile/app/Models/MedicalIncident.php Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
create.blade.php:143:  <x-backend.form.image-with-preview name="medical_document" id="medical_document"
create.blade.php:144:  image="{{ isset($medicalIncident) ? $medicalIncident->getFirstMediaUrl('medical_document', 'medium') : '' }}"
edit.blade.php:149:  <x-backend.form.image-with-preview name="medical_document" id="medical_document"
edit.blade.php:150:  image="{{ $incident->getFirstMediaUrl('medical_document', 'medium') }}"
MedicalIncident.php:67:  $this->addMediaCollection('medical_documents')->singleFile();
```

### F5 — Routes

#### MIC-07 · H · RTE-01 — `restore` mutates state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *No state change over GET (`restore`, `delete`, `toggle`, ...). GET has no CSRF protection, and link prefetchers trigger it* |
| **Where** | `Modules/StudentProfile/routes/web.php:170` |
| **Root cause** | `Route::get('medical-incidents/{id}/restore', [MedicalIncidentController::class, 'restore'])` restores a soft-deleted row (writes `deleted_at = null`) and writes an activity log — two writes — over an un-CSRF-protected GET verb. |
| **Consequence** | The route can be triggered by a prefetcher or a crafted `<img>`/link without any token or confirmation; a logged-in user browsing a page that embeds such a link restores records they never intended to. |
| **Reproduce** | `curl -i 'http://test.localhost:8000/student-profile/medical-incidents/999999/restore'` (with a valid session) restores the record on a plain GET. |
| **Fix approach** | Change the verb to `POST`/`PATCH` (route file is `⚠ SHARED`) and call it from a small form with `@method('PATCH')` + `@csrf` in the trash view once MIC-17 gives the trash page a real body. |
| **Plan item** | MIC-07 in `02-fix-plan.md` §5 |
| **Evidence** | `APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list` → `GET|HEAD student-profile/medical-incidents/{id}/restore` |

```php
// web.php:170 — CURRENT
    Route::get('medical-incidents/{id}/restore', [MedicalIncidentController::class, 'restore'])->name('medical-incidents.restore');
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list 2>/dev/null | grep "medical-incidents/{id}/restore"
  GET|HEAD        student-profile/medical-incidents/{id}/restore student-prof…
```

### F6 — Controller shape

#### MIC-05 · M · CTL-05 — the same 11-rule validation array and the same dropdown loaders are copy-pasted

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *No copy-paste: dropdown loaders shared by `create`/`edit`, the same redirect string repeated 10×, the same 30-line payload in `store` and `update`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:175-187` (second copy) and `create()`/`edit()` dropdown loaders (42-47 vs 150-155) |
| **Root cause** | `store()` (101-113) and `update()` (175-187) carry the identical 11-item validation array. `create()` loads students/types/users (42-47) and `edit()` loads the same three collections again (150-155), including the same `Dropdown::where('key', 'std_medical_incidents.incident_type_id')` query. Any rule or loader change must be made two or three places. |
| **Consequence** | The two write paths can drift (different rules for the same fields); a rule added to `store` but not `update` lets the edit screen save data the create screen rejects. |
| **Reproduce** | Static only — compare lines 101-113 with 175-187; they are identical except the `$validated` variable. |
| **Fix approach** | Extracting the FormRequest (MIC-04) removes the array duplication in one move; the create/edit loaders should be a shared private method or a single query builder reused by both methods. |
| **Plan item** | MIC-05 in `02-fix-plan.md` §5 |
| **Evidence** | `grep -n "request->validate" <controller>` — two identical full arrays (101, 175) |

```php
// MedicalIncidentController.php:175-187 — CURRENT update() validation (identical to store's)
        $validated = $request->validate([
            'student_id' => 'required|exists:std_students,id',
            'incident_date' => 'required|date',
            'incident_type_id' => 'required|exists:sys_dropdown_table,id',
            'location' => 'required|string|max:100',
            'description' => 'required|string',
            'first_aid_given' => 'nullable|string|max:512',
            'action_taken' => 'nullable|string|max:255',
            'reported_by' => 'required|exists:sys_users,id',
            'parent_notified' => 'boolean',
            'closure_date' => 'nullable|date|after_or_equal:incident_date',
            'follow_up_required' => 'boolean',
        ]);
```

**Evidence**
```
$ grep -n "request->validate" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
101:        $validated = $request->validate([
175:        $validated = $request->validate([
295:        $request->validate([
321:        $request->validate([
```

#### MIC-08 · M · CTL-03 — resource routes bind `{medical_incident}` but the methods take `$id` + `findOrFail`

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *Route model binding (`show(Homework $homework)`, `->withTrashed()` on trash routes), not `$id` + `findOrFail`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:125-133`, methods `show()`, `edit()` (145), `update()` (168), `destroy()` (215) |
| **Root cause** | The `Route::resource` registers `{medical_incident}` as the parameter name, but every controller method declares `$id` and calls `findOrFail($id)` itself. Laravel therefore passes the raw id and skips model binding, so binding (404 handling, trashed-model rules, type safety) never happens. |
| **Consequence** | No functional crash today, but a 404 for a missing row is only reached after `findOrFail` in the method; the framework's binding conventions are bypassed and a future developer who renames the parameter to `$medical_incident` (or adds a non-existent segment) would change behaviour silently. |
| **Reproduce** | Static only — `route:list` shows `{medical_incident}`, the signatures show `$id` + `findOrFail`. |
| **Fix approach** | Change the four signatures to `show(MedicalIncident $medicalIncident)` (etc.) and drop the explicit `findOrFail`; import `MedicalIncident` (already imported). `restore`/`forceDelete` keep `$id` + `onlyTrashed()->findOrFail` unless trash routes are given `->withTrashed()` binding. |
| **Plan item** | MIC-08 in `02-fix-plan.md` §5 |
| **Evidence** | `php artisan route:list | grep "medical-incidents/{"` vs `sed -n '125p;145p;168p;215p'` |

```php
// MedicalIncidentController.php:125-133 — CURRENT show()
    public function show($id)
    {
        Gate::authorize('tenant.student-profile.medical-incident.view');

        $incident = MedicalIncident::with([
            'student',
            'reporter',
            'incidentType'
        ])->findOrFail($id);
```

**Evidence**
```
$ APP_ROUTES_CACHE=/tmp/fa-nocache.php php artisan route:list 2>/dev/null | grep "medical-incidents/{"
  GET|HEAD     student-profile/medical-incidents/{medical_incident} ...
  PUT|PATCH    student-profile/medical-incidents/{medical_incident} ...
  DELETE       student-profile/medical-incidents/{medical_incident} ...
  GET|HEAD     student-profile/medical-incidents/{medical_incident}/edit ...
$ sed -n '125p;145p;168p;215p' Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
    public function show($id)
    public function edit($id)
    public function update(Request $request, $id)
    public function destroy($id)
```

#### MIC-09 · L · CTL-08 — `request()` helper used instead of the injected `Request`

| Field | Value |
|---|---|
| **Rule** | CTL-08 (L) — *Inject `Request`; don't call the `request()` helper inside controller methods* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:135`, method `show()` |
| **Root cause** | `show($id)` calls `request()->ajax()` instead of accepting a `Request` and reading it. |
| **Consequence** | Style inconsistency; the method silently depends on the global helper, which is harder to stub and reason about. |
| **Reproduce** | Static only — line 135. |
| **Fix approach** | Change the signature to `show(Request $request, MedicalIncident $medicalIncident)` (with MIC-08) and read `$request->ajax()`. |
| **Plan item** | MIC-09 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n "request()" <controller>` → `135:        if (request()->ajax()) {` |

```php
// MedicalIncidentController.php:135 — CURRENT
        if (request()->ajax()) {
```

**Evidence**
```
$ grep -n "request()" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
135:        if (request()->ajax()) {
```

#### MIC-10 · L · CTL-04 — no return types on any of the 13 public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *Return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:22-33` (and all 13 methods) |
| **Root cause** | None of the 13 public methods declares a return type, so a future refactor can silently change a method from redirect to view (or the reverse) without a TypeError. |
| **Consequence** | Purely maintainability; no current behaviour defect. |
| **Reproduce** | Static only — `grep -n "public function"` shows 13 signature lines, none typed. |
| **Fix approach** | Add `: View`, `: RedirectResponse`, `: JsonResponse` (and `: \Illuminate\Http\JsonResponse` for the JSON methods) to each method in one pass. |
| **Plan item** | MIC-10 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n "public function" <controller>` — 13 untyped signatures |

```php
// MedicalIncidentController.php:22-33 — CURRENT index()
    public function index()
    {
        Gate::authorize('tenant.student-profile.medical-incident.viewAny');

        $incidents = MedicalIncident::with([
            'student',
            'reporter',
            'incidentType'
        ])->latest('incident_date')->paginate(10);

        return view('studentprofile::medical-incident.index', compact('incidents'));
    }
```

**Evidence**
```
$ grep -n "public function" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
22:    public function index()
38:    public function create()
71:    public function ajaxGetStudents(Request $request)
97:    public function store(Request $request)
125:    public function show($id)
145:    public function edit($id)
168:    public function update(Request $request, $id)
215:    public function destroy($id)
234:    public function trashed()
253:    public function restore($id)
272:    public function forceDelete($id)
291:    public function toggleFollowUp(Request $request, $id)
317:    public function toggleParentNotified(Request $request, $id)
```

#### MIC-11 · M · CTL-10 — dead code: unused `DB`/`StudentAcademicSession` imports and an if/else whose branches return the same view

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *No dead code: unused private methods, unused properties, commented-out blocks longer than 3 lines* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:135-139`, method `show()` (imports at lines 8 and 15) |
| **Root cause** | `use Illuminate\Support\Facades\DB;` (line 8) and `use Modules\StudentProfile\Models\StudentAcademicSession;` (line 15) are never referenced — `DB::` appears nowhere and the session model is only imported (it was probably left from an earlier version of `ajaxGetStudents`). In `show()`, the `if (request()->ajax())` / `return view(...)` and the following `return view(...)` (lines 135-139) are identical, so the branch is dead logic that exists to distinguish a request that behaves no differently. |
| **Consequence** | Readers assume `DB`, `StudentAcademicSession` and an AJAX-specific show render exist; dead branches hide the real intent (a modal fetch that renders the same fragment as the page). |
| **Reproduce** | Static only — no `DB::` or `StudentAcademicSession::` call exists; both branches of the if/else return the same string. |
| **Fix approach** | Remove the two unused imports; collapse the if/else into a single `return view('studentprofile::medical-incident.show', compact('incident'));` (keep the ajax distinction only if a JSON/different fragment is actually planned — none exists today). |
| **Plan item** | MIC-11 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -n "DB::\|StudentAcademicSession" <controller>` → only the use line at 15 (`DB::` absent); `sed -n '135,139p'` shows both branches identical |

```php
// MedicalIncidentController.php:135-139 — CURRENT show() tail
        if (request()->ajax()) {
            return view('studentprofile::medical-incident.show', compact('incident'));
        }

        return view('studentprofile::medical-incident.show', compact('incident'));
```

**Evidence**
```
$ grep -n "DB::\|StudentAcademicSession" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
15:use Modules\StudentProfile\Models\StudentAcademicSession;
$ sed -n '135,139p' Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
        if (request()->ajax()) {
            return view('studentprofile::medical-incident.show', compact('incident'));
        }

        return view('studentprofile::medical-incident.show', compact('incident'));
```

### F7 — Models

#### MIC-12 · B · MDL-05 — `MedicalIncident` uses `InteractsWithMedia` without overriding `getMediaModel()`

| Field | Value |
|---|---|
| **Rule** | MDL-05 (B) — *Every model using Spatie `InteractsWithMedia` in tenant context overrides `getMediaModel()` — otherwise media rows go to the **central** DB (cross-tenant leak)* |
| **Where** | `Modules/StudentProfile/app/Models/MedicalIncident.php:11-17` |
| **Root cause** | The model implements `HasMedia` and uses `InteractsWithMedia` and registers the `medical_documents` collection, but does not define `getMediaModel()`. The project's own reference (`app/Models/TenantMedia.php` and nine sibling models: ChatMessage, Library, Admission, etc.) pins this as a required override; without it, Spatie writes/reads media rows against the default `config('media-library.media_model')` — the **central** DB — leaking tenant uploads across the platform. Today the audited controller never saves media (MIC-06), so the leak is latent, not live — but the model advertises a media collection and both forms render an upload control, so any future `addMedia` call (or a fix of MIC-06 that forgets this) writes tenant files to the central schema. |
| **Consequence** | If this feature ever stores a document, the file metadata lands in the central `prime_db` and the tenant's own media rows stay orphaned — the exact cross-tenant leak scenario documented in `app/Models/TenantMedia.php`. |
| **Reproduce** | Static only — `grep -n "getMediaModel" MedicalIncident.php` returns nothing; the override exists in nine sibling tenant models. |
| **Fix approach** | Add `public function getMediaModel(): string { return \App\Models\TenantMedia::class; }` to the model. Must land before any media is ever saved (i.e. before MIC-06's option a). |
| **Plan item** | MIC-12 in `02-fix-plan.md` §2 |
| **Evidence** | `grep -n "getMediaModel" <model>` → no output; `grep -rln "function getMediaModel" Modules/*/app/Models/` lists nine tenant models that have it |

```php
// MedicalIncident.php:11-17 — CURRENT
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class MedicalIncident extends Model implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ grep -n "getMediaModel" Modules/StudentProfile/app/Models/MedicalIncident.php   (no output, rc=1)
$ grep -rln "function getMediaModel" Modules/*/app/Models/ | head -5
Modules/Admission/app/Models/ApplicationDocument.php
Modules/Admission/app/Models/Application.php
Modules/Admission/app/Models/ApplicationDocumentVersion.php
Modules/CommonChat/app/Models/ChatMessage.php
Modules/Library/app/Models/LibDigitalResource.php
```

#### MIC-13 · L · MDL-04 — relationship methods have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *Relationship methods return-typed (`: BelongsTo`, `: HasMany`…)* |
| **Where** | `Modules/StudentProfile/app/Models/MedicalIncident.php:47-60` |
| **Root cause** | `student()`, `reporter()`, `incidentType()` all lack `: BelongsTo`. All three resolve (verified in tinker: student "Sneha Bose", reporter NULL on the first row, incidentType "Half-Day"), but the lack of a type defeats static analysis. |
| **Consequence** | Maintainability only; no behavioural defect. |
| **Reproduce** | Static only — lines 47/52/57. |
| **Fix approach** | Add `: BelongsTo` to the three methods. |
| **Plan item** | MIC-13 in `02-fix-plan.md` §5 |
| **Evidence** | `sed -n '47p;52p;57p'` → `public function student()`, `public function reporter()`, `public function incidentType()` — no types |

```php
// MedicalIncident.php:47-60 — CURRENT
    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    public function reporter()
    {
        return $this->belongsTo(User::class, 'reported_by');
    }

    public function incidentType()
    {
        return $this->belongsTo(Dropdown::class, 'incident_type_id');
    }
```

**Evidence**
```
$ sed -n '47p;52p;57p' Modules/StudentProfile/app/Models/MedicalIncident.php
    public function student()
    public function reporter()
    public function incidentType()
```

### F8 — Services and jobs

clean — the controller uses no services, jobs, listeners or commands (`grep -oE '...Service'` over the controller returned nothing).

### F9 — Queries and performance

#### MIC-14 · M · QRY-15 — create/edit pages load every active student and user for dropdowns

| Field | Value |
|---|---|
| **Rule** | QRY-15 (M) — *Don't load every row of a big table for a form: `Student::get()`, `Topic::get()` with no filter on a create/edit page* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:42-47` (also `edit()` 150-155) |
| **Root cause** | `create()` does `Student::where('is_active', true)->get()` (all active students, 42), `Dropdown::where('key', 'std_medical_incidents.incident_type_id')->get()` (43-46, small and fine), and `User::active()->get()` (all active users, 47). `edit()` repeats all three (150-155). A school with thousands of active students and hundreds of staff ships the entire list into the form HTML twice (create and edit are separate requests, but each carries the full set). |
| **Consequence** | Each create/edit page grows with the whole student/user population — a real performance tax on large schools and a heavy initial page for the reporter dropdown. |
| **Reproduce** | Open `.../medical-incidents/create` and inspect the network payload: every active student renders in the `#student_id` select. |
| **Fix approach** | Delegate the student list to the existing `ajaxGetStudents` filter (the create form already calls it on class-section change) and load only students for the initial render; for users, use a `pluck('name', 'id')` select of reporters — or move the student/user loading behind the class-section filter entirely. |
| **Plan item** | MIC-14 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n "Student::where\|Student::active()\|User::active()" <controller>` → 42, 47, 150, 155 |

```php
// MedicalIncidentController.php:42-47 — CURRENT create() loaders
        $students = Student::where('is_active', true)->get();
        $incidentTypes = Dropdown::where('key', 'std_medical_incidents.incident_type_id')
            ->where('is_active', 1)
            ->orderBy('ordinal')
            ->get();
        $users = User::active()->get();
```

**Evidence**
```
$ grep -n "Student::where\|Student::active()\|User::active()" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
42:        $students = Student::where('is_active', true)->get();
47:        $users = User::active()->get();
150:        $students = Student::active()->get();
155:        $users = User::active()->get();
```

#### MIC-15 · H · QRY-02 — `ajaxGetStudents` returns the entire active student list with no pagination or bound

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *Lists are paginated. No `Model::all()` or unbounded `->get()` feeding a list page or JSON list* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:76-91`, method `ajaxGetStudents()` |
| **Root cause** | When no `class_section_id` is sent (the drop-down's default "All Classes & Sections"), the query reduces to `Student::active()->with(['user'])->get()` — every active student, eager-loaded with the user — serialised whole into JSON. The list is unbounded; the AJAX endpoint powers the create form's class filter but has no pagination, no `limit`, no search and no `select` on the returned columns beyond the post-map. |
| **Consequence** | On a large school the create page fires a mega-response (all students and their user rows) every time the class filter is cleared, slowing the page and the network. |
| **Reproduce** | Open `.../medical-incidents/create`, clear the class-section filter (or reload with no selection): the `get-students` AJAX call returns every active student. |
| **Fix approach** | Either require `class_section_id` (return an empty list or a 422 when absent), or server-side filter by a search term and paginate/limit the result — never the full table. |
| **Plan item** | MIC-15 in `02-fix-plan.md` §6 |
| **Evidence** | `grep -n -- "->get()" <controller>` → line 84 `$students = $query->get()->map(...)` with no paginator |

```php
// MedicalIncidentController.php:76-91 — CURRENT ajaxGetStudents()
        $query = Student::active()->with(['user']);

        if ($classSectionId) {
            $query->whereHas('currentAcademicSession', function ($q) use ($classSectionId) {
                $q->where('class_section_id', $classSectionId);
            });
        }

        $students = $query->get()->map(function ($student) {
            return [
                'id' => $student->id,
                'name' => ($student->user->name ?? $student->full_name) . ' - ' . $student->admission_no
            ];
        });

        return response()->json($students);
```

**Evidence**
```
$ grep -n -- "->get()" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php
84:        $students = $query->get()->map(function ($student) {
```

### F10 — Views

#### MIC-16 · B · VIEW — `index()` renders a partial that needs `$incidentsExport`, which it never passes — the list route 500s

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) family + the F10 rule *"A `??` on a column that does not exist is silent forever"* / undefined-variable crash — a page-killer on the route the dashboard links to (severity raised to B: crash on a normal user path) |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:26-32`, method `index()` (blade: `Modules/StudentProfile/resources/views/medical-incident/index.blade.php:47`) |
| **Root cause** | `index()` returns `view('studentprofile::medical-incident.index', compact('incidents'))`. That blade is a **tab fragment** — it is included at `resources/views/index.blade.php:18` by `AttendanceController::bulkAttendanceIndex()`, which passes `$incidentsExport`, `$incidentStudents` and `$incidentTypes`. Line 47 uses `:data="$incidentsExport"` unguarded (the other two are guarded with `?? []` / `isset()`). The controller's own route passes only `$incidents`, so a direct visit evaluates an undefined variable, which Laravel's error handler turns into an ErrorException → 500. |
| **Consequence** | The dashboard's "Medical Incidents" button (and the edit page's "Back to List") land on a 500 error page. |
| **Reproduce** | Visit `http://test.localhost:8000/student-profile/medical-incidents` while logged in (dashboard link "Medical Incidents"). |
| **Fix approach** | DECISION: either (a) redirect `index()` to `student-profile.attendance.bulk` with `['tab' => 'medical-incident']` (the tab is the real screen and already renders this partial correctly) leaving the shared blade alone, or (b) make `index()` supply `$incidentsExport`/`$incidentStudents`/`$incidentTypes` the way `AttendanceController` does — a bigger, duplicating fix. |
| **Plan item** | MIC-16 in `02-fix-plan.md` §1 |
| **Evidence** | `grep -n "incidentsExport" <index.blade>` → `47: :data="$incidentsExport"` (unguarded), and `grep -rn "share(" ...` shows no global assignment |

```php
// MedicalIncidentController.php:26-32 — CURRENT index() (only $incidents is passed)
        $incidents = MedicalIncident::with([
            'student',
            'reporter',
            'incidentType'
        ])->latest('incident_date')->paginate(10);

        return view('studentprofile::medical-incident.index', compact('incidents'));
```

**Evidence**
```
$ grep -n "incidentsExport" Modules/StudentProfile/resources/views/medical-incident/index.blade.php
47:                :data="$incidentsExport"
$ grep -rn "incidentsExport" Modules/StudentProfile/app --include=*.php
Modules/StudentProfile/app/Http/Controllers/AttendanceController.php:358:        $incidentsExport = (clone $incidentsQuery);
```

#### MIC-17 · H · VIEW — the trash page renders an empty (0-byte) blade

| Field | Value |
|---|---|
| **Rule** | VIEW (F10) — blades must render the resource they claim; an empty partial is a dead screen (severity H: a real routed screen shows nothing) |
| **Where** | `Modules/StudentProfile/resources/views/medical-incident/trash.blade.php:1-0` (whole file, 0 bytes), used by `trashed()` (controller 234-248) |
| **Root cause** | `trashed()` queries `onlyTrashed()->paginate(10)` and returns `view('studentprofile::medical-incident.trash')`, but the blade file is empty. The route exists (`GET .../medical-incidents/trash/view`) and `restore()`/`forceDelete()` redirect to `student-profile.medical-incidents.trashed`, so the flow lands on a completely blank page. |
| **Consequence** | A user who reaches the trash list (or restores/purges a record) sees a blank screen; the restore and force-delete actions are effectively unreachable from any working UI, and nothing tells an auditor the trash screen exists. |
| **Reproduce** | Visit `http://test.localhost:8000/student-profile/medical-incidents/trash/view` — an empty white page. |
| **Fix approach** | Write a real `trash.blade.php` (listing, restore and force-delete buttons posting to the routes with `@method` tokens), or, if the trash feature is deliberately shelved, remove the `trashed`/`restore`/`forceDelete` routes as a team decision. |
| **Plan item** | MIC-17 in `02-fix-plan.md` §7 |
| **Evidence** | `wc -c <trash.blade.php>` → `0 Modules/StudentProfile/resources/views/medical-incident/trash.blade.php` |

```php
// trash.blade.php — CURRENT (whole file, 0 bytes — nothing renders)
```

**Evidence**
```
$ wc -c Modules/StudentProfile/resources/views/medical-incident/trash.blade.php
0 Modules/StudentProfile/resources/views/medical-incident/trash.blade.php
```

#### MIC-18 · M · VIEW — fallback reads `dropdown_name`/`name`/`student->name`, columns that do not exist — silent forever

| Field | Value |
|---|---|
| **Rule** | VIEW (F10) — *"A `??` on a column that does not exist is silent forever"* |
| **Where** | `Modules/StudentProfile/resources/views/medical-incident/edit.blade.php:48-51` (and 24; `show.blade.php:45`, `30`) |
| **Root cause** | The views fall back to attributes the models do not have. `sys_dropdown_table` columns are `id, ordinal, key, value, type, additional_info, is_active, ...` — there is no `dropdown_name` and no `name` — yet `edit.blade.php:51` and `show.blade.php:45` render `$type->dropdown_name ?? $type->name`, which is always blank. `edit.blade.php:24` uses `$student->name` (Student has `full_name`, not `name`) and `show.blade.php:30` dereferences `$incident->student->user->name` / `->name` on a relation that is null once the student is soft-deleted. The `??` fallbacks never print a useful value and hide the missing column forever. |
| **Consequence** | The incident-type select on the edit page shows empty option labels (a user selects a type by position), the show page's type badge is blank, and a soft-deleted student crashes the show page (null property access on the fallback side of `??`). |
| **Reproduce** | Open `.../medical-incidents/{id}/edit` — every Incident Type option label is empty. Open show with a record whose student was soft-deleted after logging — 500. |
| **Fix approach** | Replace the fallbacks with the real columns: `$type->value`, `$student->full_name` (and `$student->user?->name`), and guard relation chains with `$incident->student?->user?->name ?? $incident->student?->full_name`. |
| **Plan item** | MIC-18 in `02-fix-plan.md` §7 |
| **Evidence** | tinker listing of `sys_dropdown_table` columns (no `dropdown_name`/`name`) + `sed -n '48,51p'` |

```php
// edit.blade.php:48-51 — CURRENT (type option label)
                                        @foreach ($incidentTypes as $type)
                                            <option value="{{ $type->id }}"
                                                {{ old('incident_type_id', $incident->incident_type_id) == $type->id ? 'selected' : '' }}>
                                                {{ $type->dropdown_name ?? $type->name }}
```

**Evidence**
```
$ php artisan tinker --execute '... Schema::getColumnListing("sys_dropdown_table") ...'
id,ordinal,key,value,type,additional_info,is_active,created_at,updated_at,deleted_at
```

### F11 — Security and tenancy

clean — `grep -n 'env('` over the controller, model and policy → no output; no hard-coded ids or `?? 1`; `ajaxGetStudents` returns mapped `['id','name']` arrays, not full models; no personal data over-exposed; no cache keys involved.

### F12 — Style

#### MIC-19 · L · STY-01 — no `declare(strict_types=1)` in the three owned PHP files

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files (new files mandatory; old files when touched)* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:1-2` (also model `MedicalIncident.php:1`, policy `MedicalIncidentPolicy.php:1`) |
| **Root cause** | None of the three files opens with `declare(strict_types=1);`. |
| **Consequence** | Stylistic only; loose typing can mask subtle scalar coercion bugs. |
| **Reproduce** | Static only — `grep -c "declare(strict_types"` returns 0 for all three. |
| **Fix approach** | Add the declare line as the first statement after `<?php` in each file when the F12-style pass touches them (Pint-safe). |
| **Plan item** | MIC-19 in `02-fix-plan.md` §8 |
| **Evidence** | `grep -rc "declare(strict_types"` → `...:0` for all three files |

```php
// MedicalIncidentController.php:1-2 — CURRENT
<?php

```

**Evidence**
```
$ grep -rc "declare(strict_types" Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php Modules/StudentProfile/app/Models/MedicalIncident.php Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php
Modules/StudentProfile/app/Http/Controllers/MedicalIncidentController.php:0
Modules/StudentProfile/app/Models/MedicalIncident.php:0
Modules/StudentProfile/app/Policies/MedicalIncidentPolicy.php:0
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Mutation method | 1 overwrite wrong data | 2 delete before store | 3 duplicate impl | 4 soft-del × unique | 5 race | 6 authz hole | 7 lying message | 8 dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | MIC-05 | ok | ok | ok | MIC-06 (upload silently dropped) | MIC-06 |
| `update` | ok | ok | MIC-05 | ok | ok | ok | ok | MIC-06 |
| `destroy` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | MIC-07 (GET verb) |
| `forceDelete` | ok | ok | ok | ok | ok | ok | ok | ok |
| `toggleFollowUp` | ok | ok | ok | ok | ok | ok | ok | MIC-20 (no UI caller) |
| `toggleParentNotified` | ok | ok | ok | ok | ok | ok | ok | MIC-20 (no UI caller) |

#### MIC-20 · M · F13#8 — the two toggle buttons have no JavaScript handler, so the toggle endpoints are unreachable from the UI

| Field | Value |
|---|---|
| **Rule** | Deep-read #8 (dead feature) — *a screen whose saved data no consumer reads* |
| **Where** | `Modules/StudentProfile/resources/views/medical-incident/show.blade.php:172-180`, methods `toggleFollowUp()` / `toggleParentNotified()` |
| **Root cause** | `show.blade.php` renders two buttons with classes `.toggle-follow-up` and `.toggle-parent-notified` and a `data-id`, but no script anywhere binds them — `grep -rln "toggle-follow-up"` finds only this blade. The POST endpoints exist and work via curl, but no user can click the buttons and see an effect; the endpoints and their `activityLog` rows are dead code. (Also note the POST body the endpoint expects is `follow_up_required` / `parent_notified` — no JS exists to send it.) |
| **Consequence** | Two working server endpoints that no screen reaches; a UI that promises toggles that do nothing when clicked. |
| **Reproduce** | Open `.../medical-incidents/{id}` and click "Toggle Follow-up" — nothing happens (no handler attached). |
| **Fix approach** | DECISION: either add the small fetch/axios handler to `show.blade.php` (sending the boolean the endpoint validates), or remove the two buttons if the flags are meant to be edited only via the edit form. |
| **Plan item** | MIC-20 in `02-fix-plan.md` §9 |
| **Evidence** | `grep -rln "toggle-follow-up"` over the module + resources views → only `show.blade.php` |

```php
// show.blade.php:172-180 — CURRENT buttons (no handler anywhere)
                                <button type="button" class="btn btn-sm btn-info toggle-follow-up"
                                    data-id="{{ $incident->id }}">
                                    <i class="fas fa-sync-alt"></i> Toggle Follow-up
                                </button>

                                <button type="button" class="btn btn-sm btn-info toggle-parent-notified"
                                    data-id="{{ $incident->id }}">
                                    <i class="fas fa-bell"></i> Toggle Parent Notification
                                </button>
```

**Evidence**
```
$ grep -rln "toggle-follow-up" Modules/StudentProfile/resources/views resources/views 2>/dev/null
Modules/StudentProfile/resources/views/medical-incident/show.blade.php
```

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/StudentProfile/resources/views/medical-incident/index.blade.php` | This blade is included by `AttendanceController::bulkAttendanceIndex()` at `resources/views/index.blade.php:18` and therefore shared. Any edit to it (e.g. MIC-16 option b, MIC-18) must be coordinated with AttendanceController's variables. MIC-16's option (a) avoids touching it. | CTL/VIEW | AttendanceController report if changed here |
| `Modules/SystemConfig/app/Models/Dropdown.php` | Its actual columns (`value`, not `dropdown_name`/`name`) are misread by this module's edit/show blades. The model is a different-module common class; the fix belongs in this module's views (MIC-18). | VIEW | this report's plan |
| `Modules/StudentProfile/app/Models/Student.php` | Has `full_name`, not `name`; `edit.blade.php:24` reads the wrong attribute. Owned by StudentReportController — usage fix is in this report's MIC-18. | VIEW | this report's plan |

## 8. Not covered, and why

- **Blade compile/render** — the five blades were read statically and their queries/escaping checked; a full HTTP render (browser/curl) was not run (D4: no tests; no browser paid session), so MIC-16's 500 and MIC-17's blank page are proven by code shape, not by a captured HTTP response.
- **Policy invocation** — `MedicalIncidentPolicy` was never executed (nothing calls it); the claim that it is dead is by exhaustive grep for `authorize(...MedicalIncident::class)` calls.
- **Media upload behaviour** — no media write was exercised; MIC-12 relies on the documented `app/Models/TenantMedia.php` reasoning and the nine sibling overrides.
- **Live pagination/perf** — the unbounded queries in MIC-14/MIC-15 are proven from source; no timing measurement was taken.
- **Route middleware depth** — the group middleware (`module:STUDENT` plus the global web/tenant stack) was confirmed present but not exercised end-to-end; RTE-05 is marked clean on shape only.