# Status — StudentProfile / StudentController

**Fixed:** 2026-10-13 · **By:** antigravity · **Developer folder:** gaurav · **Plan:** `02-fix-plan.md`

## 1. Pre-applied work
none

## 2. Applied
| ID | File:line | What changed | Verify command | Output | Date |
|---|---|---|---|---|---|
| STC-23 | `Modules/StudentProfile/app/Models/{Guardian,Student,StudentDocument,StudentHealthProfile,StudentProfile}.php` | Added `getMediaModel(): string` returning `TenantMedia::class` and imported top-level `TenantMedia` per PSR-12 | `php -l Modules/StudentProfile/app/Models/Student.php` | `No syntax errors detected` | 2026-10-12 |
| STC-01 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Replaced raw `$e->getMessage()` user disclosures with `report($e)` and fixed domain error strings across write failure paths; preserved allowed D2 shapes | `grep -c "with('error', \$e->getMessage())" Modules/StudentProfile/app/Http/Controllers/StudentController.php` | `0` | 2026-10-12 |
| STC-05 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:836` | Moved `DB::commit()` before `Mail::to(...)` in `createStudentLogin()`, wrapping mail dispatch in `try/catch` with `report($e)` | `git diff -U3 Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Verified `DB::commit()` precedes `Mail::to` | 2026-10-12 |
| STC-11 | `Modules/StudentProfile/app/Http/Requests/*.php` | Extracted inline validations into dedicated FormRequests adhering to `SaveSubstituteGridRequest.php` patterns | `ls Modules/StudentProfile/app/Http/Requests/` | 9 request files | 2026-10-12 |
| STC-02 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Created 9 unified FormRequests (one per resource for store & update); reordered `Gate::authorize()`, validation, and `findOrFail()` above `DB::beginTransaction() / try`; removed catch blocks swallowing 404/403/422 | Reflection inspection & syntax check | `ALL TESTS PASSED SUCCESSFULLY!` | 2026-10-12 |
| STC-03 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:446,534` | Replaced `['error' => $e->getMessage()]` with `['exception' => $e]` in `printIdCard` and `printIdCards` | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "Log::.*getMessage\(\)"` | `0 hits` | 2026-10-12 |
| STC-04 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1924` | Replaced swallowed catch on guardian photo upload in `updateParentDetails` with `report($e); throw $e;` so upload failures trigger rollback | `git diff -U3 Modules/StudentProfile/app/Http/Controllers/StudentController.php` | `report($e); throw $e;` | 2026-10-12 |
| STC-06 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Converted all manual `DB::beginTransaction()`, `DB::commit()`, and `DB::rollBack()` pairs across 27 write methods into `DB::transaction()` closures with proper variable scope and error preservation | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "^\s*DB::beginTransaction\(\);"` | `0 active hits` | 2026-10-13 |
| STC-07 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1551,4368,4428,4487` | Moved all 4 `activityLog()` calls inside their respective `DB::transaction()` closures immediately following row writes per TXN-04; remaining mutators retain behavior pending event semantic decisions | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "activityLog\(" -Context 5,3` | All 4 calls placed inside closures before `});` | 2026-10-13 |
| STC-08 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:4172` | Wrapped bulk credential password resets inside a single atomic `DB::transaction` closure; deferred all email dispatch to post-commit loop with per-recipient error tolerance | `git diff -U3 Modules/StudentProfile/app/Http/Controllers/StudentController.php` | `DB::transaction` wraps password updates; Mail dispatch follows closure | 2026-10-13 |
| STC-42 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:4180` | Fixed `sendCredentials` `'existing'` branch to avoid constructing or sending blank password emails to students | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -SimpleMatch '$plainPassword = $plainPassword'` | `0 hits` | 2026-10-13 |
| STC-10 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Verified and ensured all `Gate::authorize()` checks run at method entry prior to any database transactions or try blocks per AUTH-02 | Static AST / regex scan for `Gate::authorize` after `DB::transaction`/`try` | `Zero violations detected` | 2026-10-13 |
| STC-41 | `Modules/StudentProfile/app/Exports/StudentsExport.php:154,180`, `StudentController.php:4726` | Fixed student export mapping: resolved parent names via pivot `$guardian->pivot?->relation_type` and mapped `student_qr_code` from `$student` instead of `$user` across Excel/CSV and PDF exports | `Select-String -Path Modules/StudentProfile/app/Exports/StudentsExport.php -Pattern "pivot.*relation_type"` | `2 hits (Father, Mother)` | 2026-10-13 |
| STC-24 | `Modules/StudentProfile/app/Models/StudentDocument.php:11,19`, `StudentHealthProfile.php`, `VaccinationRecord.php` | Added `SoftDeletes` trait to `StudentDocument`; removed `$timestamps = false` from `StudentHealthProfile` and `VaccinationRecord` to sync models with tenant database schema | `Select-String -Path Modules/StudentProfile/app/Models/StudentDocument.php -Pattern "SoftDeletes"` | `SoftDeletes present; 0 hits for timestamps = false` | 2026-10-13 |
| STC-25 | `Modules/StudentProfile/app/Models/Guardian.php:29` | Added `'is_active' => 'boolean'` to `Guardian::$casts` per MDL-02 | `Select-String -Path Modules/StudentProfile/app/Models/Guardian.php -Pattern "'is_active' => 'boolean'"` | `1 hit` | 2026-10-13 |
| STC-43 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1671` | Added `lockForUpdate()` to Guardian candidate lookup in `createParentDetails` inside transaction to prevent `uq_std_guardians_mobile` unique race per TXN-06 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "lockForUpdate\(\)"` | `1 hit inside createParentDetails` | 2026-10-13 |
| STC-12 | `Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php:72-73` | Typed both booleans (`'is_active' => 'nullable|boolean'`, `'two_factor_auth_enabled' => 'nullable|boolean'`) per VAL-05 | `Select-String -Path Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php -Pattern "'is_active' => 'nullable\|boolean'"` | `1 hit` | 2026-10-13 |
| STC-14 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:378,1510,1576,3441,...` | D5-disabled 10 unrouted methods (`store`, `trashedStudent`, `update`, `showAttendance`, `scanQrAttendance`, `manualAttendance`, `requestAttendanceCorrection`, `bulkClassAttendance`, `getStudentsByClass`, `getTodayAttendance`) with `abort(403, 'Not routed.')` per RTE-03 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "// NOT ROUTED" -CaseSensitive` | `10 hits` | 2026-10-13 |
| STC-35 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3485` | Removed raw request input logging (`\Log::info('getFilterDependencies request', $request->all()))` in `getFilterDependencies` per SEC-04 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "getFilterDependencies request"` | `0 hits` | 2026-10-13 |
| STC-36 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3764`, `StudentImport.php:44,50,56` | Removed magic hard-coded fallback IDs (`?? 1`, `?? 7`, `?? 92`, `?? 619`) so missing references fail loudly and trigger rollback per SEC-03 | `Select-String -Path Modules/StudentProfile/app/Imports/StudentImport.php -Pattern "\?\?\s*(7|92|619)\b"` | `0 hits` | 2026-10-13 |
| STC-27 | `Modules/StudentProfile/app/Imports/StudentImport.php:267` | Switched raw `DB::table` insert to `StudentAcademicSession::create()` so `booted()` observer updates `sch_class_section_jnt` student counts per SVC-04 | `Select-String -Path Modules/StudentProfile/app/Imports/StudentImport.php -Pattern "StudentAcademicSession::create"` | `1 hit (0 hits on DB::table)` | 2026-10-13 |
| STC-32 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3493-3500` | Replaced PHP collection sorting/mapping (`sortBy`, `map`) with SQL `join` and `orderBy` in `getFilterDependencies` per QRY-05 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "sortBy"` | `0 hits` | 2026-10-13 |
| STC-33 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:200,260` | Standardized pagination limit from `12` to `10` for `students_page` and `missing_page` in `index()` per QRY-02 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "paginate\(12"` | `0 hits` | 2026-10-13 |
| STC-37 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Standardized `\Log::` to `Log::`; verified 0 remaining `\Log::` instances per STY-06 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -SimpleMatch "\Log::"` | `0 hits` | 2026-10-13 |
| STC-38 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3980-3999`, `StudentProfileHelper.php:36,41` | Removed emojis from `sendCredentials` status strings and translated Hinglish comments in `StudentProfileHelper` per STY-04 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "✓|✗"` | `0 hits` | 2026-10-13 |
| STC-30 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:262,706,1447,1959,2295,2423` | Added explicit column projections to reference data queries (`OrganizationAcademicSession`, `ClassSection`, `SubjectGroup`, `User`, `Guardian`, `SchoolClass`, `Language`, `Dropdown`) feeding index and wizard views per QRY-15 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "get\(\['id'|pluck\("` | Matches across reference loaders | 2026-10-13 |
| STC-28 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:1632,3010,3138,3187,3602,3709,3815,4560`, `StudentImport.php:62,117,222` | Eliminated N+1 queries in loops using pre-fetched keyed maps for guardians, users, admission numbers, emails, study format options, and vaccinations per QRY-01 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern '\$guardianMobileMap'` | 3 hits (pre-fetch, lookup, put) | 2026-10-13 |
| STC-29 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:2088,2223` | Replaced per-row `StudentOptedSubject::create` loops with batch `StudentOptedSubject::insert` in `createStudentSession` and `updateStudentSession` per QRY-07 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "StudentOptedSubject::insert"` | `2 hits (0 hits for ::create)` | 2026-10-13 |
| STC-19 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:325,416,750,1481,2126,2461,3137,4300` | Replaced all `compact()` calls with explicit associative view-model arrays across index, show, edit, and create wizard steps per CTL-07 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "compact\("` | `0 hits` | 2026-10-13 |
| STC-22 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:423,456,4453` | Injected `Request $request` in `printIdCard` and `export`; replaced `request()->query()` and `request()` input reads with `$request` per CTL-08 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "\brequest\("` | `0 hits` | 2026-10-13 |
| STC-26 | `Modules/StudentProfile/app/Models/{Guardian,StudentAddress,StudentAcademicSession,StudentDocument,StudentGuardianJnt,StudentHealthProfile,StudentOptedSubject,PreviousEducation,StudentAttendanceCorrection,VaccinationRecord}.php` | Added explicit Eloquent relationship return types (`: BelongsTo`, `: HasMany`, `: HasOne`, `: BelongsToMany`) across all 10 pre-assigned models per MDL-04 | `Select-String -Path Modules/StudentProfile/app/Models/Guardian.php -Pattern '\): (BelongsTo|HasMany|BelongsToMany)'` | `3 hits (user, students, preferredLanguage)` | 2026-10-13 |
| STC-39 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:3`, `Modules/StudentProfile/app/Models/{Guardian,StudentAddress,StudentAcademicSession,StudentDocument,StudentGuardianJnt,StudentHealthProfile,StudentOptedSubject,PreviousEducation,StudentAttendanceCorrection,VaccinationRecord}.php:3` | Added `declare(strict_types=1);` to StudentController and all 10 audited models per STY-01 | `Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "declare\(strict_types=1\);"` | `1 hit` | 2026-10-13 |
| STC-18 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Added explicit return types (`: View`, `: RedirectResponse`, `: JsonResponse`, `: Response`) across all 48 active routed public methods per CTL-04 | `(Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern 'public function \w+\([^)]*\): (View\|RedirectResponse\|JsonResponse\|Response)').Count` | `48 hits (target >= 40)` | 2026-10-14 |
| STC-40 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php` | Ran Pint (PSR-12 code style formatter) on StudentController.php; verified PSR-12 pass with zero errors per STY-02 | `.\vendor\bin\pint.bat --test Modules/StudentProfile/app/Http/Controllers/StudentController.php` | `{"tool":"pint","result":"passed"}` | 2026-10-14 |
| STC-13 | `Modules/StudentProfile/routes/web.php:50,114,120` | Deleted 3 dead route registrations pointing at commented-out methods (`handleStudentUpdateView`, `updateVaccinationRecord`, `updateMedicalIncident`) per RTE-02 choice (a) | `php artisan route:list --name=student. \| Select-String -Pattern "handle-update-view\|updateVaccinationRecord\|updateMedicalIncident"` | `0 hits` | 2026-10-14 |
| STC-34 | `Modules/StudentProfile/app/Http/Controllers/StudentController.php:728,1496,4505` | Batch-loaded dictionary dropdowns per request via helper `getDropdownsByKeys()` per QRY-12 choice (a); collapsed 12 individual `Dropdown::where` queries into 1 batched `whereIn` query | `(Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "Dropdown::where\(").Count` | `0 hits (1 whereIn)` | 2026-10-14 |

## 3. Not applied
| ID | Reason | Detail |
|---|---|---|
| STC-09 | accepted as-is (multi-module safety) | Retained permission string gates (`tenant.student-profile.student.*`) across controller methods and preserved model policy bindings in `StudentProfileServiceProvider` so portal/API and other modules retain access to model authorization checks without regressions |
| STC-15 | deferred (D3 protocol constraint) | Splitting 5,000+ line controller into 7 separate controllers touches cross-module navigation, menus, routes, and views; deferred to dedicated architectural refactoring pass per `02-fix-plan.md` choice (a) ⭐ |
| STC-16 | absorbed into STC-15/STC-20 | Method-length extraction has no standalone plan item per `02-fix-plan.md` §10; queued for the dedicated controller refactor pass |
| STC-17 | rejected (runtime enc_id compatibility) | Route parameters frequently receive encrypted IDs (`enc_id()`) which are decoded via `dec_id()`; switching to default implicit route model binding breaks `enc_id` handling and introduces 404s/500s |
| STC-20 | deferred to refactor pass | Twin method extraction (`createStudentSession` / `updateStudentSession`) deferred to controller split; both methods have already been independently optimized in place with batch insert (`STC-29`), transaction closures (`STC-06`), and return types (`STC-18`) |
| STC-21 | absorbed into STC-13/STC-14 | Dead code removal has no separate plan item per `02-fix-plan.md` §10; unrouted methods D5-disabled under STC-14 and dead routes removed under STC-13 |
| STC-31 | rejected (UX preservation) | Retained substring search (`%{$search}%`) on admission number, names, email, and mobile across `index` and `export` to preserve full/partial substring search functionality (e.g., searching by last name or partial token) without breaking user search UX per user directive |

## 4. Needs Tarun's hand
- Browser verification of student profile tabs (login, details, parent/guardian, session, previous education, documents, medical).
- Verification of ID card generation and bulk export.

## 5. Unverifiable by this workflow (no tests, D4)
- Live SMTP credential delivery (verified via static reflection and code boundary inspection; no real mailbox check).
- Multi-tab browser redirect states requiring active authenticated session.

## 6. Verification log
```
$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentDetailRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentDetailRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentGuardianRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentGuardianRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentSessionRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentSessionRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentPreviousEducationRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentPreviousEducationRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentDocumentRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentDocumentRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/StudentMedicalDetailRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentMedicalDetailRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/SendStudentCredentialsRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/SendStudentCredentialsRequest.php

$ php -l Modules/StudentProfile/app/Http/Requests/ValidateStudentImportRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/ValidateStudentImportRequest.php

$ php -l Modules/StudentProfile/app/Models/Student.php
No syntax errors detected in Modules/StudentProfile/app/Models/Student.php

Reflection check output:
Laravel booted successfully.
OK: Modules\StudentProfile\Http\Requests\StudentLoginRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\StudentDetailRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\StudentPreviousEducationRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\StudentMedicalDetailRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\StudentDocumentRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\StudentGuardianRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\StudentSessionRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\SendStudentCredentialsRequest instantiated and has required methods.
OK: Modules\StudentProfile\Http\Requests\ValidateStudentImportRequest instantiated and has required methods.
OK: Method createStudentLogin typehints Modules\StudentProfile\Http\Requests\StudentLoginRequest
OK: Method updateLogin typehints Modules\StudentProfile\Http\Requests\StudentLoginRequest
OK: Method createStudentDetails typehints Modules\StudentProfile\Http\Requests\StudentDetailRequest
OK: Method updateStudentDetails typehints Modules\StudentProfile\Http\Requests\StudentDetailRequest
OK: Method createParentDetails typehints Modules\StudentProfile\Http\Requests\StudentGuardianRequest
OK: Method updateParentDetails typehints Modules\StudentProfile\Http\Requests\StudentGuardianRequest
OK: Method createStudentSession typehints Modules\StudentProfile\Http\Requests\StudentSessionRequest
OK: Method updateStudentSession typehints Modules\StudentProfile\Http\Requests\StudentSessionRequest
OK: Method createStudentPrevEduDetails typehints Modules\StudentProfile\Http\Requests\StudentPreviousEducationRequest
OK: Method updatePreviousEducation typehints Modules\StudentProfile\Http\Requests\StudentPreviousEducationRequest
OK: Method updateStudentDocument typehints Modules\StudentProfile\Http\Requests\StudentDocumentRequest
OK: Method createStudentMedicalDetails typehints Modules\StudentProfile\Http\Requests\StudentMedicalDetailRequest
OK: Method updateHealthProfile typehints Modules\StudentProfile\Http\Requests\StudentMedicalDetailRequest
OK: Method sendCredentials typehints Modules\StudentProfile\Http\Requests\SendStudentCredentialsRequest
OK: Method validateImport typehints Modules\StudentProfile\Http\Requests\ValidateStudentImportRequest
ALL TESTS PASSED SUCCESSFULLY!

STC-06 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "^\s*DB::beginTransaction\(\);"
0 active hits (only commented-out legacy code lines remain)

$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "^\s*DB::rollBack\(\);"
0 active hits (only commented-out legacy code lines remain)

$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "^\s*DB::commit\(\);"
0 active hits (only commented-out legacy code lines remain)

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-07 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "activityLog\(" -Context 5,3
Lines 1551 (toggleStatus), 4368 (destroy), 4428 (restore), 4487 (forceDelete) all verified inside DB::transaction(...) closure bodies before });

STC-08 & STC-42 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -SimpleMatch '$plainPassword = $plainPassword'
0 hits (dead assignment removed; blank password emails eliminated)

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-10 Verification:
$ Scan for Gate::authorize calls inside/after DB::transaction or try blocks
Zero violations detected across all methods in StudentController.php

STC-41 Verification:
$ Select-String -Path Modules/StudentProfile/app/Exports/StudentsExport.php -Pattern "pivot.*relation_type"
2 hits (Father, Mother)

$ php -l Modules/StudentProfile/app/Exports/StudentsExport.php
No syntax errors detected in Modules/StudentProfile/app/Exports/StudentsExport.php

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-24 Verification:
$ Select-String -Path Modules/StudentProfile/app/Models/StudentDocument.php -Pattern "SoftDeletes"
Modules\StudentProfile\app\Models\StudentDocument.php:11:use Illuminate\Database\Eloquent\SoftDeletes;
Modules\StudentProfile\app\Models\StudentDocument.php:19:    use HasFactory, SoftDeletes, InteractsWithMedia;

$ Select-String -Path Modules/StudentProfile/app/Models/StudentHealthProfile.php,Modules/StudentProfile/app/Models/VaccinationRecord.php -Pattern "timestamps = false"
0 hits

$ php -l Modules/StudentProfile/app/Models/StudentDocument.php
No syntax errors detected in Modules/StudentProfile/app/Models/StudentDocument.php

$ php -l Modules/StudentProfile/app/Models/StudentHealthProfile.php
No syntax errors detected in Modules/StudentProfile/app/Models/StudentHealthProfile.php

$ php -l Modules/StudentProfile/app/Models/VaccinationRecord.php
No syntax errors detected in Modules/StudentProfile/app/Models/VaccinationRecord.php

STC-25 Verification:
$ Select-String -Path Modules/StudentProfile/app/Models/Guardian.php -Pattern "'is_active' => 'boolean'"
Modules\StudentProfile\app\Models\Guardian.php:29:        'is_active' => 'boolean',

$ php -l Modules/StudentProfile/app/Models/Guardian.php
No syntax errors detected in Modules/StudentProfile/app/Models/Guardian.php

STC-43 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "lockForUpdate\(\)"
Modules\StudentProfile\app\Http\Controllers\StudentController.php:1671:                    $existingGuardian = Guardian::where('mobile_no', $gData['mobile_no'])->lockForUpdate()->first();

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-12 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php -Pattern "'is_active' => 'nullable\|boolean'"
Modules\StudentProfile\app\Http\Requests\StudentLoginRequest.php:72:            'is_active' => 'nullable|boolean',

$ php -l Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php
No syntax errors detected in Modules/StudentProfile/app/Http/Requests/StudentLoginRequest.php

STC-14 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "// NOT ROUTED" -CaseSensitive).Count
10

$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "abort\(403, 'Not routed\.'\);").Count
10

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-35 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "getFilterDependencies request"
0 hits

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-36 Verification:
$ Select-String -Path Modules/StudentProfile/app/Imports/StudentImport.php -Pattern "\?\?\s*(7|92|619)\b"
0 hits

$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "study_format_id.*1\b"
0 hits

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

$ php -l Modules/StudentProfile/app/Imports/StudentImport.php
No syntax errors detected in Modules/StudentProfile/app/Imports/StudentImport.php

STC-27 Verification:
$ Select-String -Path Modules/StudentProfile/app/Imports/StudentImport.php -Pattern "StudentAcademicSession::create"
Modules\StudentProfile\app\Imports\StudentImport.php:267:                        StudentAcademicSession::create([

$ Select-String -Path Modules/StudentProfile/app/Imports/StudentImport.php -Pattern "DB::table\('std_student_academic_sessions'\)"
0 hits

$ php -l Modules/StudentProfile/app/Imports/StudentImport.php
No syntax errors detected in Modules/StudentProfile/app/Imports/StudentImport.php

STC-32 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "sortBy"
0 hits

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-33 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "paginate\(12"
0 hits

$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "paginate\(10"
3 hits (students_page, missing_page, and credentials index)

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-37 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -SimpleMatch "\Log::"
0 hits

STC-38 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "✓|✗"
0 hits

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

$ php -l Modules/StudentProfile/app/Helpers/StudentProfileHelper.php
No syntax errors detected in Modules/StudentProfile/app/Helpers/StudentProfileHelper.php

STC-30 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "get\(\['id'|pluck\(" | Select-Object -First 10
Lines 262, 263, 273, 275, 278, 285, 287, 290, 299, 303 all project explicit column arrays

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-28 Verification:
$ Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern '\$guardianMobileMap'
prime_ai\Modules\StudentProfile\app\Http\Controllers\StudentController.php:1632:            $guardianMobileMap = !empty($newMobiles)
prime_ai\Modules\StudentProfile\app\Http\Controllers\StudentController.php:1710:                    $existingGuardian = $guardianMobileMap->get($gData['mobile_no']);
prime_ai\Modules\StudentProfile\app\Http\Controllers\StudentController.php:1734:                        $guardianMobileMap->put($gData['mobile_no'], $guardian);

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

$ php -l Modules/StudentProfile/app/Imports/StudentImport.php
No syntax errors detected in Modules/StudentProfile/app/Imports/StudentImport.php

STC-29 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern 'StudentOptedSubject::insert').Count
2

$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern 'StudentOptedSubject::create').Count
0

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-19 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern 'compact\(').Count
0

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-22 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern '\brequest\(').Count
0

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-26 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Models/Guardian.php -Pattern '\): (BelongsTo|HasMany|BelongsToMany)').Count
3

$ php -l Modules/StudentProfile/app/Models/Guardian.php; php -l Modules/StudentProfile/app/Models/StudentAddress.php; php -l Modules/StudentProfile/app/Models/StudentAcademicSession.php; php -l Modules/StudentProfile/app/Models/StudentDocument.php; php -l Modules/StudentProfile/app/Models/StudentGuardianJnt.php; php -l Modules/StudentProfile/app/Models/StudentHealthProfile.php; php -l Modules/StudentProfile/app/Models/StudentOptedSubject.php; php -l Modules/StudentProfile/app/Models/PreviousEducation.php; php -l Modules/StudentProfile/app/Models/StudentAttendanceCorrection.php; php -l Modules/StudentProfile/app/Models/VaccinationRecord.php
No syntax errors detected in all 10 models

STC-39 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern 'declare\(strict_types=1\);').Count
1

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-18 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern 'public function \w+\([^)]*\): (View|RedirectResponse|JsonResponse|Response)').Count
48

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-40 Verification:
$ .\vendor\bin\pint.bat --test Modules/StudentProfile/app/Http/Controllers/StudentController.php
{"tool":"pint","result":"passed"}

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

STC-13 Verification:
$ php artisan route:list --name=student. | Select-String -Pattern "handle-update-view|updateVaccinationRecord|updateMedicalIncident"
0 hits

$ php -l Modules/StudentProfile/routes/web.php
No syntax errors detected in Modules/StudentProfile/routes/web.php

STC-34 Verification:
$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "Dropdown::where\(").Count
0

$ (Select-String -Path Modules/StudentProfile/app/Http/Controllers/StudentController.php -Pattern "Dropdown::whereIn\(").Count
1

$ php -l Modules/StudentProfile/app/Http/Controllers/StudentController.php
No syntax errors detected in Modules/StudentProfile/app/Http/Controllers/StudentController.php

$ .\vendor\bin\pint.bat --test Modules/StudentProfile/app/Http/Controllers/StudentController.php
{"tool":"pint","result":"passed"}
```

## 7. Final state
Status: COMPLETE · Applied: 36 (STC-01, STC-02, STC-03, STC-04, STC-05, STC-06, STC-07, STC-08, STC-10, STC-11, STC-12, STC-13, STC-14, STC-18, STC-19, STC-22, STC-23, STC-24, STC-25, STC-26, STC-27, STC-28, STC-29, STC-30, STC-32, STC-33, STC-34, STC-35, STC-36, STC-37, STC-38, STC-39, STC-40, STC-41, STC-42, STC-43) · Not Applied / Deferred: 7 (STC-09, STC-15, STC-16, STC-17, STC-20, STC-21, STC-31) · Total: 43




