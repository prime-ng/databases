# Final Audit — StudentProfile / StdLeaveController

**Audited:** 2026-10-10 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php` (419 lines, 9 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/student-profile/student-leave?tab=leave-type` (Leave Type tab) · `.../student-leave?tab=application-review` (Application Review tab) · `.../student-leave?tab=documents` (Documents tab) · `.../student-leave?tab=leave-remarks` (Leave Remarks / chat tab) · `.../student-leave/{id}/review` (process an application) · `.../student-leave/{id}/edit` (edit an application) · `GET .../student-profile/ajax/student-leave/students` · `GET .../ajax/student-leave/review-students` · `GET .../ajax/student-leave/applications` · `POST .../student-leave/remarks/store` |
| Menu path | Student Management → Student Leave |
| Who uses it | School Admin and Super Admin. Both roles hold all 8 `tenant.student-profile.student-leave.*` permissions in the tenant DB `xyz_school_00000000000040008000_202627` (measured in `sys_role_has_permissions_jnt`). |
| What a user does here | Views a four-tab screen: the leave-type list, a paginated list of student leave applications with class/section/student/status filters, the uploaded leave documents, and a chat-style remark thread per application. From the Application Review tab the user opens a review page and sets a decision (Under Review / Approved / Rejected / Info Requested / Doc Requested), edits an application's dates/type/reason, and posts remarks with file attachments. |
| Tables written | `std_leave_application_remarks` (remarks + status-change log), `std_leave_application_documents` (documents, serviced by Spatie MediaLibrary), `std_leave_applications` (via `LeaveService::review()` / `updateApplication()`), `std_student_attendance` (via `LeaveService::markAttendanceOnApproval()`), `sys_activity_logs` (audit rows via `activityLog()`), `sys_media` (media rows) |
| Tables read | `std_leave_applications`, `std_leave_types`, `std_leave_application_remarks`, `std_leave_application_documents`, `std_students`, `sys_users`, `sch_classes`, `sch_sections`, `sch_class_section_jnt`, `sys_media` |
| Live data | `std_leave_applications` 4 live / 0 trashed · `std_leave_application_remarks` 2 · `std_leave_application_documents` 0 · `std_leave_types` 10 · `sys_media` 1 · `std_student_attendance` 99,334 (9 rows with status `Leave`) |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

This controller is **not production-ready**. It is a read-heavy dashboard with four mutations, and it does authorize every method and paginate its main list, but it has one blocker and a cluster of transaction defects. The single worst finding is **SLV-11**: `LeaveApplicationDocument` uses Spatie `InteractsWithMedia` without the mandatory `getMediaModel()` override, so every leave-document upload writes its `sys_media` row to the **central** database while `media_id` points at the tenant database — exactly the cross-tenant defect the `TenantMedia` class was created to fix. The second cluster is transactional: `storeRemark` performs three writes with no transaction, and `updateReview`/`update` write their audit row outside the service's transaction, so a failure can leave data changed with no audit trail. There is also a query inside a Blade loop (N+1) and two JS files that inject student names through `innerHTML`. Rough effort to apply the ticked plan: **M** (about one developer-day), most of it controller- and model-local.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 6 | 8 | 4 | 4 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | SLV-01 | F8 Services/Jobs | SLV-13, SLV-14 |
| F2 Transactions/Audit | SLV-02, SLV-03, SLV-04 | F9 Queries/Perf | SLV-15 |
| F3 Authorization | SLV-05 | F10 Views | SLV-16, SLV-17, SLV-18 |
| F4 Validation | SLV-06, SLV-07 | F11 Security/Tenancy | SLV-11, SLV-17 |
| F5 Routes | clean | F12 Style | SLV-19 |
| F6 Controller shape | SLV-08, SLV-09, SLV-10 | F13 Deep read | see table |
| F7 Models | SLV-11, SLV-12 | | |

DECISION items: SLV-01, SLV-05, SLV-08, SLV-13.

## 3. Scope — every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php` | controller | 419 | this report | ✅ |
| 2 | `Modules/StudentProfile/app/Models/LeaveApplication.php` | model | 130 | this report | ✅ |
| 3 | `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php` | model | 72 | this report | ✅ |
| 4 | `Modules/StudentProfile/app/Models/LeaveApplicationRemark.php` | model | 67 | this report | ✅ |
| 5 | `Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php` | policy | 51 | this report | ✅ |
| 6 | `Modules/StudentProfile/app/Services/LeaveService.php` | service | 683 | this report | ✅ |
| 7 | `Modules/StudentProfile/resources/views/leave-management/index.blade.php` | view | 44 | this report | ✅ |
| 8 | `Modules/StudentProfile/resources/views/leave-management/application-review/index.blade.php` | view | 221 | this report | ✅ |
| 9 | `Modules/StudentProfile/resources/views/leave-management/application-review/review.blade.php` | view | 210 | this report | ✅ |
| 10 | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/index.blade.php` | view | 185 | this report | ✅ |
| 11 | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php` | view | 113 | this report | ✅ |
| 12 | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/edit.blade.php` | view | 206 | this report | ✅ |
| 13 | `Modules/StudentProfile/resources/views/leave-management/documents/index.blade.php` | view | 136 | this report | ✅ |
| 14 | `Modules/StudentProfile/resources/views/leave-management/leave-types/index.blade.php` | view | 143 | this report | ✅ |
| 15 | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php` | view | 160 | this report | ✅ |
| 16 | `Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php` | view | 42 | this report | ✅ |
| 17 | `Modules/StudentProfile/resources/views/leave-management/application-review/_js.blade.php` | view | 55 | this report | ✅ |
| 18 | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_edit_js.blade.php` | view | 52 | this report | ✅ |
| 19 | `Modules/StudentProfile/resources/views/leave-management/{application-review,documents,leave-remarks}/_css.blade.php`, `leave-remarks/_edit_css.blade.php` | view (CSS only) | 868 | this report | ✅ (no PHP logic; clean — see F10) |
| 20 | `Modules/StudentProfile/app/Models/LeaveType.php` | model | 57 | ↗ [gaurav/StudentProfile/StudentLeaveTypeController](../StudentLeaveTypeController/01-report.md) | ↗ linked |
| 21 | `Modules/StudentProfile/app/Models/Student.php` | model | - | ↗ [gaurav/StudentProfile/StudentReportController](../StudentReportController/01-report.md) | ↗ linked |
| 22 | `Modules/StudentProfile/app/Models/StudentAttendance.php` | model | - | ↗ [gaurav/StudentProfile/AttendanceController](../AttendanceController/01-report.md) | ↗ linked |
| 23 | `Modules/SchoolSetup/app/Models/{SchoolClass,Section,ClassSection,User}.php` | model (other module) | - | common (other module) | ✅ usage checked |
| 24 | `Modules/Prime/app/Models/Dropdown.php` | model (other module) | - | common (other module) | ✅ usage checked |
| 25 | `app/Helpers/activityLog.php` | helper (common) | 51 | common | ✅ usage checked |

No pre-applied files (no `PRE-APPLIED-2026-10-10.md` row names any file above).

## 4. Routes

```
GET|HEAD      /student-profile/ajax/student-leave/applications student-profile.student-leave.ajax.applications  getApplicationsByStudent
GET|HEAD      /student-profile/ajax/student-leave/review-students student-profile.student-leave.ajax.review-students getStudentsByClassSection
GET|HEAD      /student-profile/ajax/student-leave/students  student-profile.student-leave.ajax.students      getStudentsBySection
GET|HEAD      /student-profile/student-leave                student-profile.student-leave.index              index
POST          /student-profile/student-leave/remarks/store  student-profile.student-leave.remarks.store      storeRemark
GET|HEAD      /student-profile/student-leave/{id}/edit      student-profile.student-leave.edit               edit
GET|HEAD      /student-profile/student-leave/{id}/review    student-profile.student-leave.review             review
PUT           /student-profile/student-leave/{id}/update    student-profile.student-leave.update             update
PUT           /student-profile/student-leave/{id}/update-review student-profile.student-leave.update-review      updateReview
```

Unrouted public methods: none — all 9 public methods are routed.

Middleware on every route (measured from `route:list --json`): `web`, `Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains`, `Stancl\Tenancy\Middleware\InitializeTenancyByDomain`, `App\Http\Middleware\EnsureTenantIsActive`, `Illuminate\Auth\Middleware\Authenticate`, `Illuminate\Auth\Middleware\EnsureEmailIsVerified`, `App\Http\Middleware\EnsureTenantHasModule:STUDENT`. Tenant middleware is present (RTE-05 clean).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 23 | GET /student-profile/student-leave | `tenant.student-profile.student-leave.viewAny` | none | none | none | SLV-08, SLV-10 |
| `getStudentsByClassSection` | 214 | GET /ajax/student-leave/review-students | `tenant.student-profile.student-leave.view` | none | none | none | SLV-10 |
| `getStudentsBySection` | 226 | GET /ajax/student-leave/students | `tenant.student-profile.student-leave.view` | none | none | none | SLV-10 |
| `getApplicationsByStudent` | 245 | GET /ajax/student-leave/applications | `tenant.student-profile.student-leave.view` | none | none | none | SLV-10 |
| `storeRemark` | 266 | POST /student-leave/remarks/store | `tenant.student-profile.student-leave.update` | none | `Remark Added` (line 318, outside any tx) | std_leave_application_remarks, std_leave_application_documents, sys_media, sys_activity_logs | SLV-02, SLV-06, SLV-07, SLV-10 |
| `review` | 334 | GET /student-leave/{id}/review | `tenant.student-profile.student-leave.review` | none | none | none | SLV-09, SLV-10 |
| `updateReview` | 347 | PUT /student-leave/{id}/update-review | `tenant.student-profile.student-leave.update` | service `review()` (LeaveService:571) | `Reviewed` (line 365, outside the service tx) | std_leave_applications, std_leave_application_remarks, std_student_attendance, sys_activity_logs | SLV-03, SLV-07, SLV-09, SLV-10 |
| `edit` | 375 | GET /student-leave/{id}/edit | `tenant.student-profile.student-leave.update` | none | none | none | SLV-09, SLV-10 |
| `update` | 387 | PUT /student-leave/{id}/update | `tenant.student-profile.student-leave.update` | service `updateApplication()` (LeaveService:493) | `Updated` (line 405, outside the service tx) | std_leave_applications, std_leave_application_remarks, sys_activity_logs | SLV-01, SLV-03, SLV-07, SLV-09, SLV-10 |

## 6. Findings

### F1 — Errors

#### SLV-01 · M · ERR-01 — the controller catches `\InvalidArgumentException` and sends `getMessage()` to the user

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B default, lowered to **M**) — *never send exception text to the user*, and under D1 a controller try/catch is itself a finding; D2 requires business-rule exceptions to be `\DomainException`, not `\InvalidArgumentException`. Lowered because the message here is a fixed business string from the service (no SQL/column text), so nothing sensitive leaks. |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:402-408`, method `update()`; the exception is thrown at `Modules/StudentProfile/app/Services/LeaveService.php:490` |
| **Root cause** | `LeaveService` signals business-rule failures (overlapping dates) with `\InvalidArgumentException`. The controller catches that concrete class and pipes `$e->getMessage()` straight into `withErrors()`. Under settled decision D2 the service should throw `\DomainException`, and D1 removes the catch from the controller entirely. The codebase is split: four other controllers (`ParentPortal`, `StudentPortal`, mobile) also catch `\InvalidArgumentException`, so this is not a one-line local fix. |
| **Consequence** | Today the message is a safe fixed string, so no data leaks and the user sees a field error. The defect is architectural: the exception contract contradicts D2, and any future `InvalidArgumentException` carrying a parameter or SQL fragment would be shown verbatim to the user. |
| **Reproduce** | Open `/student-profile/student-leave/{id}/edit`, set a date range that overlaps another live application, save. The service throws; the form re-displays the overlap message in the `leave_type_id` field. |
| **Fix approach** | Migrate the whole `LeaveService` business contract to `\DomainException` and update all five catching controllers in one coordinated pass; or accept the current pattern explicitly. Because the change reaches four controllers outside this report, it is a DECISION. |
| **Plan item** | SLV-01 in `02-fix-plan.md` §9 |
| **Evidence** | see the two commands below |

```php
        try {
            $leaveService->updateApplication($application, $validated);

            activityLog($application, 'Updated', ['message' => 'Leave application updated']);
        } catch (\InvalidArgumentException $e) {
            return back()->withInput()->withErrors(['leave_type_id' => $e->getMessage()]);
        }
```

**Evidence**
```
$ grep -nE 'try \{|catch \(|getMessage' Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
402:        try {
406:        } catch (\InvalidArgumentException $e) {
407:            return back()->withInput()->withErrors(['leave_type_id' => $e->getMessage()]);

$ grep -n 'throw new InvalidArgumentException' Modules/StudentProfile/app/Services/LeaveService.php | tail -1
490:            throw new InvalidArgumentException('A leave application already exists for the selected date range.');
```

### F2 — Transactions and audit

#### SLV-02 · H · TXN-01 — `storeRemark()` makes three writes plus its audit row with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write (two models, a model + its audit row) runs inside ONE `DB::transaction`*; TXN-04 — *`activityLog()` sits inside the transaction, after the write* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:289-318`, method `storeRemark()` |
| **Root cause** | The method creates the remark, then creates and updates one `LeaveApplicationDocument` per attachment (plus its `sys_media` row), then calls `activityLog()`. There is no `DB::transaction()` anywhere in the file (confirmed below), so each write commits on its own. |
| **Consequence** | A failure after the remark is inserted (a media write failure, an oversized file, a DB hiccup) leaves a comment with no attachment and no audit row; a failed attachment in the middle of a multi-file upload leaves a partial set. The user sees a success banner for a partial result. |
| **Reproduce** | Static only — the defect is the missing transaction, not a button; any POST to `/student-profile/student-leave/remarks/store` exercises it. |
| **Fix approach** | Wrap the remark + document loop + `activityLog()` in one `DB::transaction(function () { ... })`, keeping the status guard and the file/attachment guard before the closure. |
| **Plan item** | SLV-02 in `02-fix-plan.md` §3 |
| **Evidence** | see below |

```php
        $remark = LeaveApplicationRemark::create([
            'leave_application_id' => $validated['leave_application_id'],
            'remark_type' => LeaveApplicationRemark::TYPE_COMMENT,
            'message' => $messageText,
            'is_from_teacher' => true,
            'remarked_by' => auth()->id(),
        ]);

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $document = LeaveApplicationDocument::create([
                    'leave_application_id' => $validated['leave_application_id'],
                    'document_name' => $file->getClientOriginalName(),
                    'document_type_id' => $validated['document_type_id'] ?? null,
                    'description' => $validated['description'] ?? null,
                    'file_name' => $file->hashName(),
                    'uploaded_by' => auth()->id(),
                    'is_in_response_to_request' => false,
                    'request_remark_id' => $remark->id,
                ]);

                $document->addMedia($file)
                    ->usingFileName($file->hashName())
                    ->toMediaCollection('leave-documents');

                $document->update(['media_id' => $document->getFirstMedia('leave-documents')?->id]);
            }
        }

        activityLog($application, 'Remark Added', ['leave_application_id' => $application->id]);
```

**Evidence**
```
$ grep -n "activityLog\|DB::transaction" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
318:        activityLog($application, 'Remark Added', ['leave_application_id' => $application->id]);
365:        activityLog($application, 'Reviewed', ['status' => $validated['status']]);
405:            activityLog($application, 'Updated', ['message' => 'Leave application updated']);

(The output has no `DB::transaction` line: the controller contains none at all.)
```

#### SLV-03 · H · TXN-04 — `updateReview()` and `update()` write the audit row after the service transaction commits

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M default, raised to **H**) — *`activityLog()` sits inside the transaction, after the write it describes*; TXN-01 — the write and its audit row are two writes. Raised because on `updateReview` the missing audit row hides a status decision that cannot be reconstructed. |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:363-365` (`updateReview`) and `:403-405` (`update`) |
| **Root cause** | `LeaveService::review()` and `LeaveService::updateApplication()` each open their own `DB::transaction` and return. The controller then calls `activityLog()` on the next statement, outside that transaction. The two commits are independent. |
| **Consequence** | If the audit insert fails (FK or DB error) the application's status/dates are already changed but the school can never prove who changed them. The audit log is the only trace of a leave decision. |
| **Reproduce** | Static only — no button shows the split, but every approve/reject/edit exercises it. |
| **Fix approach** | Wrap the service call **and** its `activityLog()` in one controller-level `DB::transaction(function () { ... })`. Laravel nests this inside the service transaction as a savepoint, so both rows commit together. |
| **Plan item** | SLV-03 in `02-fix-plan.md` §3 |
| **Evidence** | see below |

```php
        $leaveService->review($application, $validated);

        activityLog($application, 'Reviewed', ['status' => $validated['status']]);
```

**Evidence**
```
$ grep -n "DB::transaction" Modules/StudentProfile/app/Services/LeaveService.php | grep -E "571|493"
493:        return DB::transaction(function () use ($application, $data) {
571:        return DB::transaction(function () use ($application, $data, $newStatus) {

$ grep -n "activityLog" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
318:        activityLog($application, 'Remark Added', ['leave_application_id' => $application->id]);
365:        activityLog($application, 'Reviewed', ['status' => $validated['status']]);
405:            activityLog($application, 'Updated', ['message' => 'Leave application updated']);
```

#### SLV-04 · H · TXN-01 — `LeaveService::deleteLeaveType()` makes two writes with no transaction

| Field | Value |
|---|---|
| **Rule** | TXN-01 (H) — *more than one write runs inside ONE `DB::transaction`* |
| **Where** | `Modules/StudentProfile/app/Services/LeaveService.php:180-184`, method `deleteLeaveType()` |
| **Root cause** | The method deactivates the leave type and then soft-deletes it as two separate statements. Only `destroy()` in the sibling `StudentLeaveTypeController` calls it, and that controller has no transaction either. |
| **Consequence** | If the second write fails, the leave type is left `is_active = false` but **not** soft-deleted: it disappears from the active dropdown while still occupying the live list and never appearing in the trash to restore. |
| **Reproduce** | Static only — this is the missing transaction; reachable from `/student-profile/student-leave-types/{id}` delete. |
| **Fix approach** | Wrap both statements in one `DB::transaction(function () use ($leaveType) { ... })`. |
| **Plan item** | SLV-04 in `02-fix-plan.md` §3 |
| **Evidence** | see below |

```php
    public function deleteLeaveType(LeaveType $leaveType): void
    {
        $leaveType->update(['is_active' => false]);
        $leaveType->delete();
    }
```

**Evidence**
```
$ grep -n 'function deleteLeaveType' -A4 Modules/StudentProfile/app/Services/LeaveService.php
180:    public function deleteLeaveType(LeaveType $leaveType): void
181-    {
182-        $leaveType->update(['is_active' => false]);
183-        $leaveType->delete();
184-    }
```

### F3 — Authorization

#### SLV-05 · M · AUTH-05 — the registered `LeaveApplicationPolicy` is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — *no dead permission logic*; `Gate::authorize('some.string')` never reaches a Policy, so a Policy that nothing consults must be reported |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:25` (first of nine string checks), policy registered at `Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:67` |
| **Root cause** | The provider registers `Gate::policy(LeaveApplication::class, LeaveApplicationPolicy::class)`, but every check in the controller passes a **string** ability (`Gate::authorize('tenant.student-profile.student-leave.review')`). Laravel only consults a Policy when the ability is checked against the model class or an instance, so none of the policy's nine methods ever runs. |
| **Consequence** | Editing the policy changes nothing. A future developer can tighten `LeaveApplicationPolicy::review()` and believe access changed, while the string abilities remain the only thing enforced. |
| **Reproduce** | Static only — no browser action changes the outcome because the policy is never entered. |
| **Fix approach** | Decide the mechanism: either wire the controller to the policy with the model instance, or accept the string abilities and remove the unused registration. Because wiring it changes every method's authorization call and touches the shared provider, it is a DECISION. |
| **Plan item** | SLV-05 in `02-fix-plan.md` §9 |
| **Evidence** | see below |

```php
        Gate::authorize('tenant.student-profile.student-leave.viewAny');
```

**Evidence**
```
$ grep -rn "LeaveApplicationPolicy" Modules/StudentProfile/app
Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php:8:class LeaveApplicationPolicy
Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:17:use Modules\StudentProfile\Policies\LeaveApplicationPolicy;
Modules/StudentProfile/app/Providers/StudentProfileServiceProvider.php:67:        Gate::policy(LeaveApplication::class, LeaveApplicationPolicy::class);

$ grep -rn "LeaveApplicationPolicy" Modules/StudentProfile/app/Http/Controllers
(no output — the controller never names the policy)
```

### F4 — Validation and input

#### SLV-06 · H · VAL-06 — the attachment upload has `file` and `max` but no `mimes` allow-list

| Field | Value |
|---|---|
| **Rule** | VAL-06 (H) — *every upload has `file` + `mimes:`/`mimetypes:` + `max:`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:272`, method `storeRemark()` |
| **Root cause** | The rule is `'attachments.*' => 'nullable|file|max:5120'`. The only type restriction is the `accept` attribute on the HTML file input and the Spatie collection's `acceptsMimeTypes()`; neither is a server-side validation rule, so a crafted POST can store any file type up to 5 MB. |
| **Consequence** | A user can upload executables, HTML or scripts as a "leave document". Combined with SLV-17 (documents are linked with a public URL), a stored `.html`/`.svg` file becomes a stored-XSS vector on the school domain. |
| **Reproduce** | Open the Leave Remarks tab, choose an application, attach any non-image/non-PDF file via the API (the accept attribute is client-side only), submit. The file is accepted. |
| **Fix approach** | Add an allow-list mirroring the Spatie collection: `'attachments.*' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120'`. |
| **Plan item** | SLV-06 in `02-fix-plan.md` §5 |
| **Evidence** | see below |

```php
            'attachments.*' => 'nullable|file|max:5120', // 5MB max
```

**Evidence**
```
$ grep -n "attachments" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
272:            'attachments.*' => 'nullable|file|max:5120', // 5MB max
277:        if (empty($validated['message']) && !$request->hasFile('attachments')) {
282:        $messageText = $validated['message'] ?? 'Attached ' . count($request->file('attachments', [])) . ' file(s)';
297:        if ($request->hasFile('attachments')) {
298:            foreach ($request->file('attachments') as $file) {

$ grep -n "acceptsMimeTypes" -A5 Modules/StudentProfile/app/Models/LeaveApplicationDocument.php
42:            ->acceptsMimeTypes([
```

#### SLV-07 · M · VAL-02 — three multi-field validations live inline in the controller

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — *validation lives in a FormRequest, not inline `$request->validate()` — except a one-field AJAX toggle* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:269` (`storeRemark`, 5 fields), `:352` (`updateReview`, 3 fields), `:392` (`update`, 7 fields) |
| **Root cause** | All three payloads are validated with inline `$request->validate()`. None is a one-field toggle: the smallest is a three-field review decision and the largest a seven-field edit form. |
| **Consequence** | The rules are not reusable by tests or by the policy layer, and `updateReview`'s `max:' . $application->total_days` depends on a record loaded just above, so the rule cannot be validated in isolation. |
| **Reproduce** | Static only — the validations are correct today, so no user-visible difference. |
| **Fix approach** | Extract `StoreLeaveRemarkRequest`, `UpdateLeaveReviewRequest` and `UpdateLeaveApplicationRequest` and call the injected request's `validated()`. Deferred to the FormRequest pass (plan §10) because it adds three files and is behaviour-neutral. |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | see below |

```php
        $validated = $request->validate([
            'leave_application_id' => 'required|exists:std_leave_applications,id',
            'message' => 'nullable|string',
            'attachments.*' => 'nullable|file|max:5120', // 5MB max
            'document_type_id' => 'nullable|integer|exists:sys_dropdown_table,id',
            'description' => 'nullable|string|max:255',
        ]);
```

**Evidence**
```
$ grep -n 'validate(' Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
269:        $validated = $request->validate([
352:        $validated = $request->validate([
392:        $validated = $request->validate([
```

### F5 — Routes

Clean — all nine public methods are routed, every route points at an existing method, no state change is served over GET (the four GETs are `index`, `review`, `edit` and three AJAX lookups; the two state changes are POST/PUT), custom routes precede nothing they conflict with (there is no `Route::resource` for student-leave), and tenant middleware is present on all. Proven by:
```
$ grep -nE "Route::(get|post|put|patch|delete).*StdLeaveController" Modules/StudentProfile/routes/web.php
176:    Route::get('student-leave', [StdLeaveController::class, 'index'])->name('student-leave.index');
177:    Route::get('student-leave/{id}/review', [StdLeaveController::class, 'review'])->name('student-leave.review');
178:    Route::put('student-leave/{id}/update-review', [StdLeaveController::class, 'updateReview'])->name('student-leave.update-review');
179:    Route::get('student-leave/{id}/edit', [StdLeaveController::class, 'edit'])->name('student-leave.edit');
180:    Route::put('student-leave/{id}/update', [StdLeaveController::class, 'update'])->name('student-leave.update');
183:    Route::get('ajax/student-leave/students', [StdLeaveController::class, 'getStudentsBySection'])->name('student-leave.ajax.students');
186:    Route::get('ajax/student-leave/review-students', [StdLeaveController::class, 'getStudentsByClassSection'])->name('student-leave.ajax.review-students');
187:    Route::get('ajax/student-leave/applications', [StdLeaveController::class, 'getApplicationsByStudent'])->name('student-leave.ajax.applications');
188:    Route::post('student-leave/remarks/store', [StdLeaveController::class, 'storeRemark'])->name('student-leave.remarks.store');
```

### F6 — Controller shape

#### SLV-08 · M · CTL-02 — `index()` is 137 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted; over 150 is H* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:23-159`, method `index()` |
| **Root cause** | One method builds filters, four independent tab data sets (leave types, review applications, remarks tree, document tree) and the class/section dropdowns, then renders. Each tab's loader is a self-contained block. |
| **Consequence** | The method is hard to review and, more importantly, loads the data of **every** tab on every request even though only one tab is active — the remarks/document queries run on a page the user may never open. |
| **Reproduce** | Static only — no user-visible failure, but every tab pays for all four queries. |
| **Fix approach** | Extract one private loader per tab (e.g. `loadRemarksTab`, `loadDocumentsTab`) and call only the active tab's loader. Because it is a behaviour-preserving refactor of a 137-line method, it is a DECISION (D3 splits are deferred). |
| **Plan item** | SLV-08 in `02-fix-plan.md` §9 |
| **Evidence** | see below |

```php
    public function index(Request $request, LeaveService $leaveService)
    {
        Gate::authorize('tenant.student-profile.student-leave.viewAny');
        $activeTab = $request->get('tab', 'leave-type');
```

**Evidence**
```
$ php -r '$s=file("Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php"); echo (159-23+1)." lines 23-159\n";'
137 lines 23-159

$ grep -n "Student::whereHas('academicSessions'\|LeaveApplication::where('student_id'\|LeaveApplicationRemark::where\|LeaveApplicationDocument::where" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
87:            $remarksStudents = Student::whereHas('academicSessions', function ($q) use ($remarksClassSectionId) {
93:            $remarksApplications = LeaveApplication::where('student_id', $remarksStudentId)
99:            $remarks = LeaveApplicationRemark::where('leave_application_id', $remarksApplicationId)
104:            $remarks = LeaveApplicationRemark::whereHas('leaveApplication', function ($q) use ($remarksStudentId) {
119:            $docStudents = Student::whereHas('academicSessions', function ($q) use ($docClassSectionId) {
125:            $docApplications = LeaveApplication::where('student_id', $docStudentId)
131:            $documents = LeaveApplicationDocument::where('leave_application_id', $docApplicationId)
136:            $documents = LeaveApplicationDocument::whereHas('leaveApplication', function ($q) use ($docStudentId) {
```

#### SLV-09 · M · CTL-03 — no route model binding on review/edit/update/updateReview

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *use route model binding, not `$id` + `findOrFail`* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:334` (`review`), `:347` (`updateReview`), `:375` (`edit`), `:387` (`update`) |
| **Root cause** | The four methods take an untyped `$id` (or `int $id`) and load the model manually. Because the argument is not type-hinted, Laravel's `SubstituteBindings` cannot bind `{id}`, so each method repeats the load and (in `edit`/`review`) the eager-load list. |
| **Consequence** | Four copies of the same load boilerplate; a forgotten relation in one copy silently produces lazy-loaded N+1s on that page. No user-visible failure today (the loads succeed). |
| **Reproduce** | Static only — the load succeeds; the concern is duplicated loading logic and a broken binding contract. |
| **Fix approach** | Type-hint the model against the existing `{id}` parameter name (`LeaveApplication $id`) so implicit binding works without touching the shared route file, then delete the manual `findOrFail()`. |
| **Plan item** | SLV-09 in `02-fix-plan.md` §5 |
| **Evidence** | see below |

```php
    public function review($id, LeaveService $leaveService)
    {
        Gate::authorize('tenant.student-profile.student-leave.review');

        $application = LeaveApplication::with(['student.user', 'leaveType', 'classSection.class', 'classSection.section', 'reviewedBy', 'appliedBy'])
            ->findOrFail($id);
```

**Evidence**
```
$ grep -nE 'public function (review|updateReview|edit|update)\(' Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
334:    public function review($id, LeaveService $leaveService)
347:    public function updateReview(Request $request, int $id, LeaveService $leaveService)
375:    public function edit($id, LeaveService $leaveService)
387:    public function update(Request $request, int $id, LeaveService $leaveService)
```

#### SLV-10 · L · CTL-04 — no return types on the public methods

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:23`, all 9 public methods |
| **Root cause** | Every method was written without a return type. `php -l` therefore cannot catch a method that returns the wrong thing at runtime. |
| **Consequence** | IDE and static analysis get no help; a future edit that returns `back()` from a method whose callers expect JSON would only fail at runtime. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the correct return type to each method (`index/review/edit`: `View`; ajax methods: `JsonResponse`; `storeRemark`: `JsonResponse|RedirectResponse`; `updateReview/update`: `RedirectResponse`). Deferred to the style pass (plan §10) — nine signatures is a broad, mechanical edit. |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | see below |

```php
    public function index(Request $request, LeaveService $leaveService)
```

**Evidence**
```
$ grep -nE 'public function ' Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
23:    public function index(Request $request, LeaveService $leaveService)
214:    public function getStudentsByClassSection(Request $request)
226:    public function getStudentsBySection(Request $request)
245:    public function getApplicationsByStudent(Request $request)
266:    public function storeRemark(Request $request)
334:    public function review($id, LeaveService $leaveService)
347:    public function updateReview(Request $request, int $id, LeaveService $leaveService)
375:    public function edit($id, LeaveService $leaveService)
387:    public function update(Request $request, int $id, LeaveService $leaveService)
```

### F7 — Models

#### SLV-11 · B · MDL-05 — `LeaveApplicationDocument` writes media to the central database

| Field | Value |
|---|---|
| **Rule** | MDL-05 / TEN-01 (**B**) — *every model using Spatie `InteractsWithMedia` in tenant context must override `getMediaModel()`; otherwise media rows go to the central DB (cross-tenant leak)* |
| **Where** | `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php:15-17` |
| **Root cause** | The model implements `HasMedia` with `InteractsWithMedia` but does not override `getMediaModel()`. `config('media-library.media_model')` is `Modules\Prime\Models\Media` (central, `prime_db.sys_media`), and Spatie resolves the media class per subject via `getMediaModel()`. Peer tenant models such as `Modules\Admission\Models\ApplicationDocument` do override it to `\App\Models\TenantMedia`. The comment block in `app/Models/TenantMedia.php` documents this exact defect class (`CHAT-MOD-08`). |
| **Consequence** | Uploading a leave document writes a `sys_media` row in the **central** database, while `std_leave_application_documents.media_id` and the file's own row live in the tenant database. Media ids collide across tenants and the document's media can be served to or from the wrong tenant. |
| **Reproduce** | Static only — the config and the missing override are the proof; the live tenant currently holds 0 documents, so the defect has not yet produced visible data. |
| **Fix approach** | Add `public function getMediaModel(): string { return \App\Models\TenantMedia::class; }` to the model. |
| **Plan item** | SLV-11 in `02-fix-plan.md` §1 |
| **Evidence** | see below |

```php
class LeaveApplicationDocument extends Model implements HasMedia
{
    use SoftDeletes, InteractsWithMedia;
```

**Evidence**
```
$ grep -n "getMediaModel" Modules/StudentProfile/app/Models/LeaveApplicationDocument.php
(no output)

$ grep -n "media_model" config/media-library.php
72:    // 'media_model' => Spatie\MediaLibrary\MediaCollections\Models\Media::class,
73:    'media_model' => Media::class,
$ grep -n "use Modules\\\\Prime\\\\Models\\\\Media" config/media-library.php
6:use Modules\Prime\Models\Media;

$ grep -n "getMediaModel" Modules/Admission/app/Models/ApplicationDocument.php
65:    public function getMediaModel(): string
```

#### SLV-12 · L · MDL-04 — relationship methods have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods are return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/StudentProfile/app/Models/LeaveApplication.php:76-120` (9 relations), `Modules/StudentProfile/app/Models/LeaveApplicationDocument.php:54-70` (4 relations), `Modules/StudentProfile/app/Models/LeaveApplicationRemark.php:45-65` (5 relations) |
| **Root cause** | All eighteen relationship methods return `$this->belongsTo(...)` / `$this->hasMany(...)` without declaring the relation type. |
| **Consequence** | No runtime failure — the relations resolve — but the models lose IDE and static-analysis support. |
| **Reproduce** | Static only. |
| **Fix approach** | Add the correct return type to each relation and import `HasMany`/`BelongsTo`. Deferred to the style pass (plan §10): eighteen signatures across three files. |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | see below |

```php
    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }
```

**Evidence**
```
$ grep -nE 'public function (student|leaveType|classSection|academicSession|appliedBy|reviewedBy|documents|remarks|openRequests)\(' Modules/StudentProfile/app/Models/LeaveApplication.php
76:    public function student()
81:    public function leaveType()
86:    public function classSection()
91:    public function academicSession()
96:    public function appliedBy()
101:    public function reviewedBy()
106:    public function documents()
111:    public function remarks()
117:    public function openRequests()
```

### F8 — Services and jobs

#### SLV-13 · M · CTL-02 — two `LeaveService` methods exceed 80 lines

| Field | Value |
|---|---|
| **Rule** | CTL-02 (M) — *a method over 80 lines should be extracted* |
| **Where** | `Modules/StudentProfile/app/Services/LeaveService.php:235-361`, method `createAndSubmit()` (127 lines); `:459-566`, method `updateApplication()` (108 lines) |
| **Root cause** | Both methods inline a long chain of business-rule checks (advance notice, half-day, caps, annual quota, overlap) before the write. |
| **Consequence** | Hard to review and easy to drift: `createAndSubmit` and `updateApplication` each contain a near-identical ~30-line overlap query, so a rule change in one can miss the other. |
| **Reproduce** | Static only. |
| **Fix approach** | Extract the shared overlap check into one private method and the rule checks into small guards. Because it rewrites two large service methods, it is a DECISION (fix-in-place, extraction deferred). |
| **Plan item** | SLV-13 in `02-fix-plan.md` §9 |
| **Evidence** | see below |

```php
    public function createAndSubmit(
        Student $student,
        array $data,
        ?UploadedFile $file = null,
        array $documentMeta = []
    ): LeaveApplication {
```

**Evidence**
```
$ php -r '
$lines=file("Modules/StudentProfile/app/Services/LeaveService.php");
$starts=[];
foreach($lines as $i=>$l){ if(preg_match("/^    (public|private|protected) function (\w+)/",$l,$m)) $starts[]=[$i+1,$m[2]]; }
for($k=0;$k<count($starts);$k++){ $end=($k+1<count($starts))?$starts[$k+1][0]-1:count($lines); printf("L%-4d %-28s %d lines\n",$starts[$k][0],$starts[$k][1],$end-$starts[$k][0]+1); }'
L235  createAndSubmit              127 lines
L459  updateApplication            108 lines
```

#### SLV-14 · M · QRY-07 — `markAttendanceOnApproval()` writes one row per day in a loop

| Field | Value |
|---|---|
| **Rule** | QRY-07 (M) — *bulk writes: prefer `insert()`/`upsert()`/`whereIn(...)->update()` over per-row `create()`/`update()` in a loop* |
| **Where** | `Modules/StudentProfile/app/Services/LeaveService.php:605-619`, method `markAttendanceOnApproval()` (called from `review()`, therefore from `updateReview()`) |
| **Root cause** | For every calendar day in the approved range the method issues a separate `StudentAttendance::updateOrCreate()` — two SQL statements each (SELECT + INSERT/UPDATE). A 30-day leave is 60 statements inside the review transaction. |
| **Consequence** | Approving a long leave holds the transaction open for dozens of round-trips; on a busy school it lengthens the lock window on `std_student_attendance`. |
| **Reproduce** | Static only — approve a multi-week leave and count the statements for the day loop. |
| **Fix approach** | Build the day array once and issue a single `upsert($rows, ['student_id', 'attendance_date', 'attendance_period'], ['status', 'remarks', 'marked_by'])` per chunk. |
| **Plan item** | SLV-14 in `02-fix-plan.md` §6 |
| **Evidence** | see below |

```php
        foreach ($period as $day) {
            \Modules\StudentProfile\Models\StudentAttendance::updateOrCreate(
                [
                    'student_id'          => $application->student_id,
                    'attendance_date'     => $day->format('Y-m-d'),
                    'academic_session_id' => $application->academic_session_id,
                ],
                [
                    'class_section_id' => $application->class_section_id,
                    'status'           => 'Leave',
                    'remarks'          => "Leave approved — Application #{$application->id}",
                    'marked_by'        => auth()->id(),
                ]
            );
        }
```

**Evidence**
```
$ grep -n 'updateOrCreate' Modules/StudentProfile/app/Services/LeaveService.php
606:            \Modules\StudentProfile\Models\StudentAttendance::updateOrCreate(
```

### F9 — Queries and performance

#### SLV-15 · L · QRY-08 — leading-wildcard `LIKE` searches in the service

| Field | Value |
|---|---|
| **Rule** | QRY-08 (M default, lowered to **L**) — *leading-wildcard `LIKE '%x%'` cannot use an index*; acceptable on small tables. Lowered because the searched tables are tiny (`std_leave_types` has 10 rows) and the pattern is the project's established search idiom. |
| **Where** | `Modules/StudentProfile/app/Services/LeaveService.php:74-79` (`getLeaveTypes`) and `:120-129` (`getApplicationReviews`) |
| **Root cause** | Both search branches wrap the term in `%...%`, which prevents index use. |
| **Consequence** | No visible effect at current volumes; it becomes a full scan only if the table grows large. |
| **Reproduce** | Static only. |
| **Fix approach** | Accept for now (plan §10); revisit only if `std_leave_types` grows. |
| **Plan item** | none — see `02-fix-plan.md` §10 |
| **Evidence** | see below |

```php
            $query->where(function ($q) use ($search) {
                $q->where('code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            });
```

**Evidence**
```
$ grep -n "'like'" Modules/StudentProfile/app/Services/LeaveService.php
75:                $q->where('code', 'like', "%{$search}%")
76:                    ->orWhere('name', 'like', "%{$search}%")
77:                    ->orWhere('description', 'like', "%{$search}%");
124:                    $sq->where('name', 'like', "%{$search}%")
125:                        ->orWhere('email', 'like', "%{$search}%");
127:                    $sq->where('admission_no', 'like', "%{$search}%");
```

### F10 — Views

#### SLV-16 · H · VIEW-01 — `_chat_item.blade.php` runs a database query inside the remark loop

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H) — *no queries in Blade, especially inside a loop* |
| **Where** | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php:74-83` |
| **Root cause** | The partial issues `LeaveApplicationDocument::where('request_remark_id', ...)->get()` directly. It is included once per remark by `leave-remarks/index.blade.php:130` (`@include(... '_chat_item', ['remark' => $remark])`), and the controller eager-loads `remarks` with only `remarkedBy`, not the documents relation. |
| **Consequence** | Opening the Leave Remarks tab fires one extra query per remark — an N+1. A thread with 30 remarks adds 30 queries. |
| **Reproduce** | Open `/student-profile/student-leave?tab=leave-remarks&remarks_application_id=1` and watch the query log: one `SELECT ... std_leave_application_documents` per remark. |
| **Fix approach** | Eager-load `remarks.responseDocuments` (and the parent-remark documents) in `index()`, and read the already-loaded relation in the partial instead of querying. |
| **Plan item** | SLV-16 in `02-fix-plan.md` §7 |
| **Evidence** | see below |

```php
            @php
                $docs = collect();
                if($remark->remark_type === $TYPE_RESPONSE && $remark->parent_remark_id) {
                    $docs = \Modules\StudentProfile\Models\LeaveApplicationDocument::where('request_remark_id', $remark->parent_remark_id)
                        ->where('uploaded_by', $remark->remarked_by) // ensure it's their uploaded doc
                        ->get();
                } else {
                    $docs = \Modules\StudentProfile\Models\LeaveApplicationDocument::where('request_remark_id', $remark->id)->get();
                }
            @endphp
```

**Evidence**
```
$ grep -n "LeaveApplicationDocument::where" Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php
77:                    $docs = \Modules\StudentProfile\Models\LeaveApplicationDocument::where('request_remark_id', $remark->parent_remark_id)
81:                    $docs = \Modules\StudentProfile\Models\LeaveApplicationDocument::where('request_remark_id', $remark->id)->get();

$ sed -n '130p' Modules/StudentProfile/resources/views/leave-management/leave-remarks/index.blade.php
                @include('studentprofile::leave-management.leave-remarks._chat_item', ['remark' => $remark])
```

#### SLV-17 · M · TEN-04 — documents are linked with `asset('storage/…')` instead of `tenant_asset()`

| Field | Value |
|---|---|
| **Rule** | TEN-04 (M) — *tenant file URLs go through `tenant_asset()`, not `asset('storage/…')`* |
| **Where** | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php:89` and `Modules/StudentProfile/resources/views/leave-management/documents/index.blade.php:59` |
| **Root cause** | Both views fall back to `asset('storage/' . $doc->file_name)` when `getFirstMediaUrl()` returns nothing. `asset()` resolves against the central app URL, not the tenant's file path, so the fallback points at the wrong host/path for a tenant upload. |
| **Consequence** | When the media URL is missing the "View"/"Download" link 404s (or resolves to another tenant's path). The fallback should be a tenant URL. |
| **Reproduce** | Static only — reached only when `getFirstMediaUrl()` is empty for a document. |
| **Fix approach** | Replace the fallback with `tenant_asset('storage/' . $doc->file_name)` in both views. |
| **Plan item** | SLV-17 in `02-fix-plan.md` §7 |
| **Evidence** | see below |

```php
                            $url = $doc->getFirstMediaUrl('leave-documents') ?: asset('storage/' . $doc->file_name);
```

**Evidence**
```
$ grep -rn "asset('storage" Modules/StudentProfile/resources/views/leave-management
Modules/StudentProfile/resources/views/leave-management/leave-remarks/_chat_item.blade.php:89:                            $url = $doc->getFirstMediaUrl('leave-documents') ?: asset('storage/' . $doc->file_name);
Modules/StudentProfile/resources/views/leave-management/documents/index.blade.php:59:                $url = $doc->getFirstMediaUrl('leave-documents') ?: asset('storage/' . $doc->file_name);
```

#### SLV-18 · H · VIEW-03 — student names are injected into the DOM with `innerHTML`

| Field | Value |
|---|---|
| **Rule** | VIEW-03 (H) — *untrusted text must not be written as HTML*; here the vector is JavaScript `innerHTML` rather than Blade `{!! !!}`. |
| **Where** | `Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php:31,49` and `Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php:18,36` |
| **Root cause** | The dependent-dropdown JS builds options with `innerHTML += \`...${s.name}...\``, where `s.name` is `user->name . ' (' . admission_no . ')'` and `a.label` embeds the admin-entered leave-type name. Both are user/admin data rendered as HTML. The sibling `application-review/_js.blade.php` avoids this deliberately: it uses `document.createElement` and `textContent`, and its own comment says "textContent, not innerHTML — student names are user data". |
| **Consequence** | A student or leave-type name containing HTML/script markup executes in the browser of any staff member who opens the Leave Remarks or Documents tab and changes the class/section dropdown — a stored-XSS path. |
| **Reproduce** | Set a student's name to `<img src=x onerror=alert(1)>`, open `/student-profile/student-leave?tab=documents`, change the "Select class section" dropdown. The payload runs. |
| **Fix approach** | Build each option with `document.createElement('option')` and assign `textContent` (as `application-review/_js.blade.php` already does). |
| **Plan item** | SLV-18 in `02-fix-plan.md` §7 |
| **Evidence** | see below |

```php
                        studentSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`;
```

**Evidence**
```
$ grep -n "innerHTML +=" Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php
Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php:31:                        studentSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`;
Modules/StudentProfile/resources/views/leave-management/leave-remarks/_js.blade.php:49:                        applicationSelect.innerHTML += `<option value="${a.id}">${a.label}</option>`;
Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php:18:                        studentSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`;
Modules/StudentProfile/resources/views/leave-management/documents/_js.blade.php:36:                        applicationSelect.innerHTML += `<option value="${a.id}">${a.label}</option>`;
```

### F11 — Security and tenancy

Not clean in isolation, but the two defects are recorded where they belong: **SLV-11** (Spatie media written to the central database — MDL-05/TEN-01) and **SLV-17** (`asset('storage/…')` instead of `tenant_asset()` — TEN-04). No `env()`, no hard-coded ids or `?? 1`, no secrets logged, and no central model reached outside tenant context were found. Proven by:
```
$ grep -nE "env\(|\?\? 1|Log::|tenancy\(\)->central" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
(no output)
```

### F12 — Style

#### SLV-19 · L · STY-01 — missing `declare(strict_types=1)` and an emoji in a comment

| Field | Value |
|---|---|
| **Rule** | STY-01 (L) — *`declare(strict_types=1);` in PHP files*; STY-04 (L) — *comments in English, no emoji markers* |
| **Where** | `Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php:1` and `:168`; `Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php:1` |
| **Root cause** | Neither new PHP file declares `strict_types` (the three models do). The controller's `studentsForClassSection()` docblock also carries a `⚠` emoji marker. |
| **Consequence** | The files drift from the project style; the emoji violates the comment rule and the missing declaration removes strict argument typing. |
| **Reproduce** | Static only. |
| **Fix approach** | Add `declare(strict_types=1);` after the opening tag in both files and replace the `⚠` comment marker with the word "Note:". |
| **Plan item** | SLV-19 in `02-fix-plan.md` §8 |
| **Evidence** | see below |

```php
<?php

namespace Modules\StudentProfile\Http\Controllers;
```

**Evidence**
```
$ grep -n "declare(strict_types" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php Modules/StudentProfile/app/Policies/LeaveApplicationPolicy.php
(no output)

$ grep -n "⚠" Modules/StudentProfile/app/Http/Controllers/StdLeaveController.php
168:     * ⚠ NOT the same lookup as getStudentsBySection() below. That one takes a
```

### F13 — Deep read (answer all 8 questions for every mutating method)

Questions: (1) wrong overwrite (2) delete before replace (3) duplicate implementation (4) soft-delete × unique index (5) race (6) authorization hole (7) message lies (8) dead feature.

| Method | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| `storeRemark` | ok | ok | ok | ok | ok | ok | ok | ok |
| `updateReview` | ok | ok | SLV-13 | ok | ok | ok | ok | SLV-05 |
| `update` | ok | ok | SLV-13 | ok | ok | ok | ok | SLV-05 |
| `LeaveService::deleteLeaveType` | ok | ok | ok | SLV-04 note | ok | ok | ok | ok |
| `LeaveService::markAttendanceOnApproval` | SLV-14 note | ok | ok | ok | SLV-14 note | ok | ok | ok |

Notes on the answers:
- (1) wrong overwrite: `markAttendanceOnApproval()` matches `StudentAttendance` on `(student_id, attendance_date, academic_session_id)` while the table's unique index is `(student_id, attendance_date, attendance_period)` — `attendance_period` is `NOT NULL DEFAULT 0` and is neither matched nor set. An existing period-specific attendance row for the same day can therefore be re-matched and overwritten. `StudentAttendance` is owned by the `AttendanceController` report, so this is recorded as a cross-cutting note in §7, not fixed here.
- (3) duplicate implementation: `createAndSubmit()` and `updateApplication()` each contain a near-identical ~30-line overlap query (SLV-13).
- (4) soft-delete × unique index: `deleteLeaveType()` deactivates then soft-deletes without a transaction (SLV-04).
- (5) race: `markAttendanceOnApproval()` performs SELECT-then-write per day with no lock (SLV-14); benign for a single approver, recorded with the loop finding.
- (8) dead feature: `LeaveApplicationPolicy` is registered but never consulted (SLV-05).

## 7. Cross-cutting notes (common or other-module classes — not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/SchoolSetup/app/Http/Controllers/StudentLeaveTypeController.php` | A second controller with the same class name and near-identical CRUD exists for the `/school-setup/student-leave-types` routes — two implementations of one operation. | SVC-04 | outside this report's scope |
| `Modules/SchoolSetup/app/Http/Controllers/StudentLeaveTypeController.php` (caller) | Calls `LeaveService::deleteLeaveType()` with no transaction; SLV-04 wraps it, which also makes that caller atomic. | TXN-01 | gaurav/StudentProfile/StudentLeaveTypeController (relies on this fix) |
| `Modules/StudentProfile/app/Models/StudentAttendance.php` (usage) | `markAttendanceOnApproval()` matches on `(student_id, attendance_date, academic_session_id)` but the unique key is `(student_id, attendance_date, attendance_period)`; `attendance_period` is not set. A period-specific row can be overwritten. | MDL-03 / TXN-06 | gaurav/StudentProfile/AttendanceController |
| `Modules/ParentPortal/...`, `Modules/StudentPortal/...` (4 controllers) | Each catches `\InvalidArgumentException` from `LeaveService`, so migrating the service to `\DomainException` (D2) must include all four. Recorded by SLV-01. | ERR-01 | outside this report's scope |
| `database/migrations/tenant/..._create_std_leave_applications_table.php` | No unique index on `(student_id, from_date, to_date)`; the overlap check is application-level only, so concurrent submissions can race. | TXN-06 | schema owner (migrations are never edited by this workflow) |
| `app/Helpers/activityLog.php` | Writes to `sys_activity_logs`; every controller call must be inside the same transaction as the write it describes (SLV-02, SLV-03). | TXN-04 | inform only |

## 8. Not covered, and why

- The `LeaveService` methods that this controller does **not** call (`createAndSubmit`, `cancel`, `respondToInfoRequest`, `respondToDocRequest`, `addParentComment`, all `*LeaveType` methods) were read for the shared-class audit but only `deleteLeaveType`, `review`, `updateApplication` and `markAttendanceOnApproval` are on this controller's path; the rest are exercised by the portal/API controllers and belong to their reports.
- `Student.php`, `StudentAttendance.php`, `LeaveType.php` and the `SchoolSetup` models are owned by other reports and were checked only for how this controller uses them.
- The eleven shared `x-backend.*` / `x-tenantcore::*` components, the layout and the breadcrumb component are common and were not audited.
- Queue jobs, mail, notifications and exports: none are reached by this controller.
- No runtime screen was opened and no test was run (D4). All findings are static or measured with read-only SQL/tinker.
