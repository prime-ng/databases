# Fix Plan — Accounting / CostCenterController

**From:** `01-report.md` (2026-10-19) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`

> **How to approve** — Tarun ticks; the developer runs the fixer (final-audit.md §3.0, D8).
> 1. Tick `[ ]` → `[x]` on each item to apply.
> 2. On every ticked **DECISION** item, write your choice after `➜ Choice:`.
> 3. Each `⚠ SHARED` item touches a file other controllers use. It needs its own explicit tick — "tick all" does not cover it.
> 4. Run the fixer on `Modules/Accounting/app/Http/Controllers/CostCenterController.php` for developer `gaurav`. It applies **only** ticked items, in this order.

## 0. Do not touch

The fixer edits ONLY the files named in ticked items. In particular, these are out of bounds for this plan:

| File | Why |
|---|---|
| `Modules/Accounting/routes/web.php` | shared route file — only CSCT-07, if approved |
| `resources/views/components/backend/table/action-trashed.blade.php` | shared table component, 373 call sites |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` | owned by [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) |
| `Modules/Accounting/app/Models/CostCategory.php` | owned by [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) |
| `Modules/Accounting/app/Models/Campus.php` | owned by [gaurav/Accounting/CampusController](../CampusController/01-report.md) |
| `Modules/SchoolSetup/app/Models/User.php` | owned by [tarun/TeacherPortal-done/MobileTeacherDashboardController](../../TeacherPortal/MobileTeacherDashboardController/01-report.md) |
| `Modules/Accounting/app/Services/AccountingContext.php` | unclaimed shared service; cross-cutting note §7 of the report |
| `Modules/GlobalMaster/app/Models/ActivityLog.php` | shared model; cross-cutting note §7 of the report |
| `database/migrations/tenant/*` | migrations are out of bounds for every final-audit fix |

## 1. Blockers reachable today

- [ ] **CSCT-01** · B · ERR-01 · `CostCenterController.php:39-252` — replace the six hand-rolled try/catch transactions with `DB::transaction` closures, stop showing exception text, and stop swallowing 404s. This one item fixes CSCT-01, CSCT-02, CSCT-03, CSCT-04 and CSCT-10.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCenterController.php`
  - **Before** (`CostCenterController.php:7-16`):
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\CostCenterRequest;
use Modules\Accounting\Models\Campus;
use Modules\Accounting\Models\CostCategory;
use Modules\Accounting\Models\CostCenter;
use Modules\SchoolSetup\Models\User;
```
  - **After:**
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Modules\Accounting\Http\Requests\CostCenterRequest;
use Modules\Accounting\Models\Campus;
use Modules\Accounting\Models\CostCategory;
use Modules\Accounting\Models\CostCenter;
use Modules\SchoolSetup\Models\User;
```
  - **Before** (`CostCenterController.php:39-70`, method `store`):
```php
    public function store(CostCenterRequest $request)
    {
        Gate::authorize('tenant.accounting.cost-center.create');

        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        DB::beginTransaction();
        try {
            $costCenter = CostCenter::create($validated);

            activityLog($costCenter, 'Created', [
                'message'      => 'Cost Center created: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers'])
                ->with('success', 'Cost Center created successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cost Center', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create Cost Center: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function store(CostCenterRequest $request)
    {
        $validated = $request->validated();
        $validated['created_by'] = auth()->id();

        $costCenter = DB::transaction(function () use ($validated) {
            $costCenter = CostCenter::create($validated);

            activityLog($costCenter, 'Created', [
                'message'      => 'Cost Center created: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);

            return $costCenter;
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers'])
            ->with('success', 'Cost Center created successfully.');
    }
```
  - **Before** (`CostCenterController.php:101-129`, method `update`):
```php
    public function update(CostCenterRequest $request, CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.update');

        DB::beginTransaction();
        try {
            $costCenter->update($request->validated());

            activityLog($costCenter, 'Updated', [
                'message'      => 'Cost Center updated: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers'])
                ->with('success', 'Cost Center updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update Cost Center', [
                'id'    => $costCenter->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update Cost Center: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function update(CostCenterRequest $request, CostCenter $costCenter)
    {
        DB::transaction(function () use ($request, $costCenter) {
            $costCenter->update($request->validated());

            activityLog($costCenter, 'Updated', [
                'message'      => 'Cost Center updated: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers'])
            ->with('success', 'Cost Center updated successfully.');
    }
```
  - **Before** (`CostCenterController.php:131-161`, method `destroy`):
```php
    public function destroy(CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.delete');

        DB::beginTransaction();
        try {
            $costCenter->is_active = false;
            $costCenter->save();
            $costCenter->delete();

            activityLog($costCenter, 'Trashed', [
                'message'      => 'Cost Center trashed: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers'])
                ->with('success', 'Cost Center moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to trash Cost Center', [
                'id'    => $costCenter->id,
                'error' => $e->getMessage(),
            ]);

            return back()->with('error', 'Failed to delete Cost Center: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function destroy(CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.delete');

        DB::transaction(function () use ($costCenter) {
            $costCenter->is_active = false;
            $costCenter->save();
            $costCenter->delete();

            activityLog($costCenter, 'Trashed', [
                'message'      => 'Cost Center trashed: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'name'         => $costCenter->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers'])
            ->with('success', 'Cost Center moved to trash.');
    }
```
  - **Before** (`CostCenterController.php:163-189`, method `toggleStatus`):
```php
    public function toggleStatus(Request $request, CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $costCenter->is_active = $request->input('is_active');
            $costCenter->save();

            activityLog($costCenter, 'Toggled', [
                'message'      => 'Cost Center status toggled: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $costCenter->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle Cost Center status', ['id' => $costCenter->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
```
  - **After:**
```php
    public function toggleStatus(Request $request, CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($request, $costCenter) {
            $costCenter->is_active = $request->boolean('is_active');
            $costCenter->save();

            activityLog($costCenter, 'Toggled', [
                'message'      => 'Cost Center status toggled: ' . $costCenter->name,
                'code'         => $costCenter->code,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $costCenter->is_active, 'message' => 'Status updated.']);
    }
```
  - **Before** (`CostCenterController.php:200-225`, method `restore`):
```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cost-center.restore');

        DB::beginTransaction();
        try {
            $model = CostCenter::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Cost Center restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cost-center.trashed')->with('success', 'Cost Center restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore Cost Center', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore Cost Center: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cost-center.restore');

        $model = CostCenter::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model) {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'Cost Center restored: ' . $model->name,
                'name'         => $model->name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cost-center.trashed')->with('success', 'Cost Center restored successfully.');
    }
```
  - **Before** (`CostCenterController.php:227-252`, method `forceDelete`):
```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cost-center.forceDelete');

        DB::beginTransaction();
        try {
            $model = CostCenter::withTrashed()->findOrFail($id);
            $name = $model->name;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cost Center permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.cost-center.trashed')->with('success', 'Cost Center permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete Cost Center', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete Cost Center: ' . $e->getMessage());
        }
    }
```
  - **After:**
```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cost-center.forceDelete');

        $model = CostCenter::withTrashed()->findOrFail($id);
        $name = $model->name;

        DB::transaction(function () use ($model, $name) {
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'Cost Center permanently deleted: ' . $name,
                'name'         => $name,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.cost-center.trashed')->with('success', 'Cost Center permanently deleted.');
    }
```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "beginTransaction|getMessage|try \{|catch \(" ; if ($?) { "no output expected" }`
  - **Expect:** no output (the counts of `beginTransaction`, `getMessage`, `try {` and `catch (` are all zero).
  - **Effort:** M

## 2. Fixes that arm a latent defect (sequenced)

None.

## 3. Errors & transactions (F1/F2)

All F1/F2 findings (CSCT-01, CSCT-02, CSCT-03, CSCT-04) are fixed by CSCT-01 in §1.

## 4. Authorization (F3)

CSCT-10 has no separate item: the CSCT-01 rewrite removes the duplicate `Gate::authorize()` lines from `store()` and `update()`; the FormRequest still authorizes both.

## 5. Validation, routes, models

- [ ] **CSCT-05** · H · VAL-04 · `CostCenterRequest.php:27-41` — make the unique rules mirror the real unique indexes by dropping the `whereNull('deleted_at')` filters.
  - **Touches:** `Modules/Accounting/app/Http/Requests/CostCenterRequest.php`
  - **Before** (`CostCenterRequest.php:27-41`):
```php
            'code'              => [
                'required',
                'string',
                'max:20',
                Rule::unique('acc_cost_centers', 'code')->ignore($id)->whereNull('deleted_at'),
            ],
            'name'              => [
                'required',
                'string',
                'max:120',
                Rule::unique('acc_cost_centers', 'name')
                    ->where(fn ($q) => $q->where('cost_category_id', $this->input('cost_category_id')))
                    ->ignore($id)
                    ->whereNull('deleted_at'),
            ],
```
  - **After:**
```php
            'code'              => [
                'required',
                'string',
                'max:20',
                Rule::unique('acc_cost_centers', 'code')->ignore($id),
            ],
            'name'              => [
                'required',
                'string',
                'max:120',
                Rule::unique('acc_cost_centers', 'name')
                    ->where(fn ($q) => $q->where('cost_category_id', $this->input('cost_category_id')))
                    ->ignore($id),
            ],
```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Requests\CostCenterRequest.php" -Pattern "whereNull"`
  - **Expect:** no output.
  - **Effort:** S

- [ ] **CSCT-06** · H · VAL-07 · `CostCenterRequest.php:42-46` — reject a parent that is the record itself or one of its descendants.
  - **Touches:** `Modules/Accounting/app/Http/Requests/CostCenterRequest.php`
  - **Before** (`CostCenterRequest.php:7-9`):
```php
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
```
  - **After:**
```php
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;
```
  - **Before** (`CostCenterRequest.php:53-65`):
```php
    public function attributes(): array
    {
        return [
            'cost_category_id' => 'Cost Category',
            'code'             => 'Cost Center Code',
            'name'             => 'Cost Center Name',
            'parent_id'        => 'Parent Cost Center',
            'campus_id'        => 'Campus',
            'incharge_user_id' => 'In-Charge User',
        ];
    }

    protected function prepareForValidation(): void
```
  - **After:**
```php
    public function attributes(): array
    {
        return [
            'cost_category_id' => 'Cost Category',
            'code'             => 'Cost Center Code',
            'name'             => 'Cost Center Name',
            'parent_id'        => 'Parent Cost Center',
            'campus_id'        => 'Campus',
            'incharge_user_id' => 'In-Charge User',
        ];
    }

    public function after(): array
    {
        return [
            function (Validator $validator): void {
                $costCenter = $this->route('cost_center');
                $id = is_object($costCenter) ? $costCenter->id : $costCenter;
                $parentId = $this->input('parent_id');

                if (! $id || ! $parentId) {
                    return;
                }

                $current = \Modules\Accounting\Models\CostCenter::withTrashed()->find($id);
                $parent = \Modules\Accounting\Models\CostCenter::withTrashed()->find($parentId);

                if ($current && $current->path && $parent && $parent->path && str_starts_with($parent->path, $current->path)) {
                    $validator->errors()->add('parent_id', 'A cost center cannot be placed under itself or one of its descendants.');
                }
            },
        ];
    }

    protected function prepareForValidation(): void
```
  - **Verify:** `php -l "Modules\Accounting\app\Http\Requests\CostCenterRequest.php" ; Select-String -Path "Modules\Accounting\app\Http\Requests\CostCenterRequest.php" -Pattern "public function after"`
  - **Expect:** `No syntax errors detected in Modules\Accounting\app\Http\Requests\CostCenterRequest.php` and one match for `public function after`.
  - **Effort:** M

- [ ] **CSCT-09** · M · CTL-05 · `CostCenterController.php:31-34, 93-96` — extract the duplicated create/edit loaders into one private method.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCenterController.php`
  - **Before** (`CostCenterController.php:20-27`):
```php
    public function index()
    {
        Gate::authorize('tenant.accounting.cost-center.viewAny');

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers']);
    }

    public function create()
```
  - **After:**
```php
    public function index()
    {
        Gate::authorize('tenant.accounting.cost-center.viewAny');

        return redirect()->route('accounting.menu.setupMasters', ['tab' => 'cost-centers']);
    }

    private function formData(?int $excludeId = null): array
    {
        return [
            'costCenters'    => CostCenter::selectableParents($excludeId),
            'costCategories' => CostCategory::where('is_active', true)->orderBy('name')->get(),
            'campuses'       => Campus::where('is_active', true)->orderBy('ordinal')->get(),
            'users'          => User::orderBy('name')->get(),
        ];
    }

    public function create()
```
  - **Before** (`CostCenterController.php:27-37`):
```php
    public function create()
    {
        Gate::authorize('tenant.accounting.cost-center.create');

        $costCenters    = CostCenter::selectableParents();
        $costCategories = CostCategory::where('is_active', true)->orderBy('name')->get();
        $campuses       = Campus::where('is_active', true)->orderBy('ordinal')->get();
        $users          = User::orderBy('name')->get();

        return view('accounting::cost-center.create', compact('costCenters', 'costCategories', 'campuses', 'users'));
    }
```
  - **After:**
```php
    public function create()
    {
        Gate::authorize('tenant.accounting.cost-center.create');

        return view('accounting::cost-center.create', $this->formData());
    }
```
  - **Before** (`CostCenterController.php:89-99`):
```php
    public function edit(CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.update');

        $costCenters    = CostCenter::selectableParents($costCenter->id);
        $costCategories = CostCategory::where('is_active', true)->orderBy('name')->get();
        $campuses       = Campus::where('is_active', true)->orderBy('ordinal')->get();
        $users          = User::orderBy('name')->get();

        return view('accounting::cost-center.edit', compact('costCenter', 'costCenters', 'costCategories', 'campuses', 'users'));
    }
```
  - **After:**
```php
    public function edit(CostCenter $costCenter)
    {
        Gate::authorize('tenant.accounting.cost-center.update');

        return view('accounting::cost-center.edit', ['costCenter' => $costCenter] + $this->formData((int) $costCenter->id));
    }
```
  - **Verify:** `php -l "Modules\Accounting\app\Http\Controllers\CostCenterController.php" ; (Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "formData").Count`
  - **Expect:** `No syntax errors detected` and the count is 3 (the private method plus two calls).
  - **Effort:** S

## 6. Queries & performance (F9)

None. CSCT-08 is a DECISION in §9; CSCT-12 is accepted in §10.

## 7. Views (F10)

None. CSCT-13 is an orphaned view recorded in §10.

## 8. Style (F12) — one item per file

- [ ] **CSCT-11** · L · CTL-04 · `CostCenterController.php:20-163` — add return types to the eight public methods that lack them.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCenterController.php`
  - **Before** (`CostCenterController.php:20`):
```php
    public function index()
```
  - **After:**
```php
    public function index(): \Illuminate\Http\RedirectResponse
```
  - **Before** (`CostCenterController.php:27`):
```php
    public function create()
```
  - **After:**
```php
    public function create(): \Illuminate\View\View
```
  - **Before** (`CostCenterController.php:39`):
```php
    public function store(CostCenterRequest $request)
```
  - **After:**
```php
    public function store(CostCenterRequest $request): \Illuminate\Http\RedirectResponse
```
  - **Before** (`CostCenterController.php:72`):
```php
    public function show(CostCenter $costCenter)
```
  - **After:**
```php
    public function show(CostCenter $costCenter): \Illuminate\View\View
```
  - **Before** (`CostCenterController.php:89`):
```php
    public function edit(CostCenter $costCenter)
```
  - **After:**
```php
    public function edit(CostCenter $costCenter): \Illuminate\View\View
```
  - **Before** (`CostCenterController.php:101`):
```php
    public function update(CostCenterRequest $request, CostCenter $costCenter)
```
  - **After:**
```php
    public function update(CostCenterRequest $request, CostCenter $costCenter): \Illuminate\Http\RedirectResponse
```
  - **Before** (`CostCenterController.php:131`):
```php
    public function destroy(CostCenter $costCenter)
```
  - **After:**
```php
    public function destroy(CostCenter $costCenter): \Illuminate\Http\RedirectResponse
```
  - **Before** (`CostCenterController.php:163`):
```php
    public function toggleStatus(Request $request, CostCenter $costCenter)
```
  - **After:**
```php
    public function toggleStatus(Request $request, CostCenter $costCenter): \Illuminate\Http\JsonResponse
```
  - **Verify:** `Select-String -Path "Modules\Accounting\app\Http\Controllers\CostCenterController.php" -Pattern "public function (index|create|store|show|edit|update|destroy|toggleStatus)\("`
  - **Expect:** eight matches, each ending with `:` and a return type.
  - **Effort:** S

- [ ] **CSCT-15** · L · STY-02 · `CostCenterController.php`, `CostCenterRequest.php`, `CostCenter.php` — make the three files Pint-clean.
  - **Touches:** `Modules/Accounting/app/Http/Controllers/CostCenterController.php`, `Modules/Accounting/app/Http/Requests/CostCenterRequest.php`, `Modules/Accounting/app/Models/CostCenter.php`
  - **Before** (`CostCenterController.php:7-16`):
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\CostCenterRequest;
use Modules\Accounting\Models\Campus;
use Modules\Accounting\Models\CostCategory;
use Modules\Accounting\Models\CostCenter;
use Modules\SchoolSetup\Models\User;
```
  - **After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\CostCenterController.php Modules\Accounting\app\Http\Requests\CostCenterRequest.php Modules\Accounting\app\Models\CostCenter.php --format agent`. Pint rewrites the files in place (it adds the `View` / `RedirectResponse` imports, sorts imports, removes the unused `Log` import, and normalises spacing). Do not hand-edit; the command is the change.
  - **Verify:** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\CostCenterController.php Modules\Accounting\app\Http\Requests\CostCenterRequest.php Modules\Accounting\app\Models\CostCenter.php --format agent`
  - **Expect:** `{"tool":"pint","result":"pass","files":[...]}` with no `"result":"fail"`.
  - **Effort:** S

## 9. Deferred / decisions

- [ ] **CSCT-07** · H · DECISION · RTE-01 — restore is a GET that changes state. ⚠ SHARED
  - **Why it is a decision:** moving it to POST/DELETE touches `Modules/Accounting/routes/web.php` and the shared `x-backend.table.action-trashed` component (373 call sites); route and shared-component changes are a stop-and-ask.
  - (a) ⭐ leave the GET route for this pass and record the risk; schedule one module-wide POST/DELETE change for all trash actions
  - (b) change the route to POST and update the shared trash component for all 373 call sites now
  - (c) add a POST route and change only the Cost Center trash view to post a form, keeping the old GET route for the shared component (the GET hole remains)
  - ➜ Choice: ____

- [ ] **CSCT-08** · M · DECISION · QRY-15 — the In-Charge picker loads all 5,636 users on create/edit.
  - **Why it is a decision:** the proper fix is a UI/behaviour change (searchable AJAX picker); the quick variants only reduce the payload.
  - (a) ⭐ convert the In-Charge picker to a searchable AJAX select (new lookup endpoint; touches the controller and the create/edit views)
  - (b) keep the select but load only active users with `select('id','name','email','username')` — still 5,636 rows, smaller payload
  - (c) accept; the form stays slow for this tenant
  - ➜ Choice: ____

- [ ] **CSCT-14** · M · DECISION · F13-Q1 — trashing a parent leaves its active children orphaned.
  - **Why it is a decision:** it is a behaviour change; choose block or cascade.
  - (a) ⭐ block the trash when active children exist and show a business message
  - (b) cascade the soft delete to every descendant
  - (c) accept; children stay active but disappear from the tree
  - ➜ Choice: ____

## 10. Findings with no plan item

| ID | Why there is no fix here |
|---|---|
| CSCT-02 | Fixed by CSCT-01: `findOrFail()` moves outside the try in `restore()` and `forceDelete()`, so a missing id is a 404, not a flash message. |
| CSCT-03 | Fixed by CSCT-01: the try/catch blocks are removed; the log call no longer records only the message string. |
| CSCT-04 | Fixed by CSCT-01: every mutation uses `DB::transaction(fn () => ...)` and the manual `beginTransaction`/`commit`/`rollBack` calls are gone. |
| CSCT-10 | Fixed by CSCT-01: the store/update rewrite removes the duplicate `Gate::authorize()` lines; the FormRequest still authorizes. |
| CSCT-12 | Accepted at current volume (12 rows, no hierarchy). Revisit `recalculateChildrenTree()` when the tree grows. |
| CSCT-13 | Orphaned `cost-center/index.blade.php`; no reference exists and no user can reach it. Delete it in a cleanup pass or repair it if the list is meant to move there. |
