# Final Audit — Accounting / FundController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/FundController.php` (241 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/setup-masters?tab=funds` (live list + create modal); `http://test.localhost:8000/accounting/fund/{id}/edit` (edit page); `http://test.localhost:8000/accounting/fund/{id}` (read-only show); `http://test.localhost:8000/accounting/fund/trash/view` (trash); `http://test.localhost:8000/accounting/fund/create` (orphaned full-page form) |
| Menu path | Accounting → Setup Masters → Funds |
| Who uses it | Account Manager, Account Staff, Management, School Admin, Super Admin hold `tenant.accounting.fund.*` in the tenant DB |
| What a user does here | A finance user maintains the fund master: creates a fund with a code, name, type, optional campus and grantor/fund ledgers, a sanctioned amount and an overspend rule; edits it; switches it active/inactive; moves it to the trash; restores it, or permanently deletes it. Funds are then picked by budgets, vouchers, donations, grants and fixed assets. |
| Tables written | `acc_funds` (INSERT, UPDATE, soft DELETE, restore, hard DELETE) |
| Tables read | `acc_funds`, `acc_fund_balances` (eager-loaded but unused), `acc_campuses`, `acc_ledgers` |
| Live data | tenant DB `xyz_school_00000000000040008000_202627`: `acc_funds` 4 rows (0 trashed, 4 active), `acc_fund_balances` 0 rows, `acc_ledgers` 56 rows, `acc_campuses` 4 rows |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

No — not production-ready. The happy path works, but a failed write prints raw database/exception text to the user (**FUND-01**, the worst finding), and every edit silently resets a fund's status to `Active`, can coerce a `Corpus`/`Designated` type to `Restricted`, and re-activates it (**FUND-10**). Re-using the code of a trashed fund passes validation and then hits the plain unique index (**FUND-09**). The six write methods also carry the old manual-transaction + catch-everything shape that D1 forbids. Effort to clear the plan: **M** — about one developer-day for the blocker and the two high validation/UI decisions, plus a short review of the shared route change.

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 5 | 7 | 11 | 6 | 24 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | FUND-01, FUND-02, FUND-03, FUND-04 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | FUND-05, FUND-06 | F9 Queries/Perf | FUND-19, FUND-20 |
| F3 Authorization | FUND-07, FUND-08 | F10 Views | clean |
| F4 Validation | FUND-09, FUND-10 | F11 Security/Tenancy | clean |
| F5 Routes | FUND-11 | F12 Style | FUND-21, FUND-22, FUND-23 |
| F6 Controller shape | FUND-12, FUND-13, FUND-14, FUND-15 | F13 Deep read | FUND-24 |
| F7 Models | FUND-16, FUND-17, FUND-18 | | |

`DECISION` counts the six items that Tarun must choose: FUND-08, FUND-09, FUND-10, FUND-11, FUND-14, FUND-24.

## 3. Scope - every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/FundController.php` | controller | 241 | this report | ✅ |
| 2 | `Modules/Accounting/app/Http/Requests/FundRequest.php` | form request | 95 | this report | ✅ |
| 3 | `Modules/Accounting/app/Models/Fund.php` | model | 68 | this report | ✅ |
| 4 | `Modules/Accounting/app/Models/FundBalance.php` | model | 63 | not in `00-CLASS-OWNERS.md` — reviewed here | ✅ |
| 5 | `Modules/Accounting/app/Policies/FundPolicy.php` | policy | 46 | not in `00-CLASS-OWNERS.md` — reviewed here | ✅ |
| 6 | `Modules/Accounting/app/Models/Campus.php` | model | 83 | ↗ [CampusController](../CampusController/01-report.md) | ↗ linked |
| 7 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [LedgerController](../LedgerController/01-report.md) | ↗ linked |
| 8 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | model base | 74 | ↗ [AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 9 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | ↗ [AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 10 | `app/Helpers/activityLog.php` | helper | 52 | ↗ [CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 11 | `Modules/Accounting/routes/web.php` | routes | 536 | shared — no single owner | ⚠ read-only |
| 12 | `config/permissionslist.php` | config | — | shared config | ⚠ read-only |
| 13 | `Modules/Accounting/resources/views/fund/create.blade.php` | view | 209 | this report | ✅ |
| 14 | `Modules/Accounting/resources/views/fund/edit.blade.php` | view | 242 | this report | ✅ |
| 15 | `Modules/Accounting/resources/views/fund/show.blade.php` | view | 167 | this report | ✅ |
| 16 | `Modules/Accounting/resources/views/fund/trash.blade.php` | view | 77 | this report | ✅ |
| 17 | `Modules/Accounting/resources/views/fund/index.blade.php` | view (dead) | 105 | this report | ✅ |
| 18 | `Modules/Accounting/resources/views/pages/partials/setup-masters/_funds.blade.php` | view partial | 293 | ↗ [AccDashboardController](../AccDashboardController/01-report.md) | ↗ linked |
| 19 | `resources/views/components/backend/table/action-trashed.blade.php` | common component | 116 | common | ✅ |
| 20 | `resources/views/components/backend/tab/search-bar.blade.php` + `x-backend.layouts.app`, `x-backend.components.breadcrum`, `x-tenantcore::export-buttons` | common components | — | common | ✅ |
| 21 | `database/migrations/tenant/2026_09_16_100020_create_acc_funds_table.php` and the 12 `fund_id` FK migrations | migrations | — | read-only | ✅ |

No pre-applied files (`PRE-APPLIED-*.md`) touch these files.

## 4. Routes

Uncached `route:list` through the router probe (`php artisan route:list --json | php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\routesprobe.php "Fund"`). The middleware column is omitted for width; every row carries the same chain: `web`, `PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive`, `EnsureTenantHasModule:Accounting`, `Authenticate`, `EnsureEmailIsVerified`.

```
GET|HEAD  accounting/fund                       accounting.fund.index        FundController@index
POST      accounting/fund                       accounting.fund.store        FundController@store
GET|HEAD  accounting/fund/create                accounting.fund.create       FundController@create
GET|HEAD  accounting/fund/trash/view            accounting.fund.trashed      FundController@trashed
GET|HEAD  accounting/fund/{fund}                accounting.fund.show         FundController@show
PUT|PATCH accounting/fund/{fund}                accounting.fund.update       FundController@update
DELETE    accounting/fund/{fund}                accounting.fund.destroy      FundController@destroy
GET|HEAD  accounting/fund/{fund}/edit           accounting.fund.edit         FundController@edit
POST      accounting/fund/{fund}/toggle-status  accounting.fund.toggleStatus FundController@toggleStatus
DELETE    accounting/fund/{id}/force-delete     accounting.fund.forceDelete  FundController@forceDelete
GET|HEAD  accounting/fund/{id}/restore          accounting.fund.restore      FundController@restore
```

Unrouted public methods: none (11 of 11 are routed).

Route notes: the custom `trash/view`, `restore` and `force-delete` routes are registered before `Route::resource` in `routes/web.php:131-133`; `toggle-status` is registered after the resource at line 135, but its extra path segment cannot collide with any resource route. The `restore` route is the only write over GET (**FUND-11**).

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 19 | GET `accounting/fund` | `tenant.accounting.fund.viewAny` | none | none | none | FUND-13 |
| `create` | 26 | GET `accounting/fund/create` | `tenant.accounting.fund.create` | none | none | none | FUND-13, FUND-14 |
| `store` | 36 | POST `accounting/fund` | `tenant.accounting.fund.create` | controller, manual | `'Created'` | `acc_funds` | FUND-01, FUND-02, FUND-03, FUND-04, FUND-05, FUND-07, FUND-09 |
| `show` | 69 | GET `accounting/fund/{fund}` | `tenant.accounting.fund.view` | none | none | none | FUND-13, FUND-20 |
| `edit` | 83 | GET `accounting/fund/{fund}/edit` | `tenant.accounting.fund.update` | none | none | none | FUND-10, FUND-13, FUND-20 |
| `update` | 93 | PUT/PATCH `accounting/fund/{fund}` | `tenant.accounting.fund.update` | controller, manual | `'Updated'` | `acc_funds` | FUND-01, FUND-02, FUND-03, FUND-04, FUND-05, FUND-07, FUND-09, FUND-10 |
| `destroy` | 125 | DELETE `accounting/fund/{fund}` | `tenant.accounting.fund.delete` | controller, manual | `'Deleted'` (wrong) | `acc_funds` (soft delete) | FUND-01, FUND-02, FUND-03, FUND-04, FUND-05, FUND-06 |
| `toggleStatus` | 151 | POST `accounting/fund/{fund}/toggle-status` | `tenant.accounting.fund.update` | controller, manual | `'Toggled'` | `acc_funds` | FUND-01, FUND-02, FUND-03, FUND-04, FUND-05, FUND-13 |
| `trashed` | 179 | GET `accounting/fund/trash/view` | `tenant.accounting.fund.restore` | none | none | none | FUND-13, FUND-19 |
| `restore` | 188 | GET `accounting/fund/{id}/restore` | `tenant.accounting.fund.restore` | controller, manual | `'Restored'` | `acc_funds` | FUND-01, FUND-02, FUND-03, FUND-04, FUND-05, FUND-11, FUND-12 |
| `forceDelete` | 215 | DELETE `accounting/fund/{id}/force-delete` | `tenant.accounting.fund.forceDelete` | controller, manual | `'Deleted'` | `acc_funds` (hard delete) | FUND-01, FUND-02, FUND-03, FUND-04, FUND-05, FUND-06, FUND-12, FUND-24 |

## 6. Findings

### F1 — Errors

#### FUND-01 · B · ERR-01 — Raw exception text is shown to the user on every failed write

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — *never send exception text to the user; SQL, table and column names leak* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:65,121,147,175,211,238` — methods `store()`, `update()`, `destroy()`, `toggleStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Each `catch (\Throwable $e)` builds the flash/JSON message by concatenating `$e->getMessage()`. A `QueryException` message contains the SQL statement, the table name and the column name. |
| **Consequence** | Any failed save shows a raw database error such as `SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'GEN' for key 'uq_acc_fund_code'` instead of a friendly message. |
| **Reproduce** | Create a fund with code `GEN`, move it to trash, then create another fund with code `GEN`. FUND-09 lets validation pass and the DB unique index fires; the red flash prints the SQL text. |
| **Fix approach** | Remove all six `catch` blocks (D1). Let the central handler log and render the failure; no message is composed from the exception. |
| **Plan item** | FUND-01 in `02-fix-plan.md` §1 (the same rewrite resolves FUND-02, FUND-03, FUND-04, FUND-05 and FUND-06) |

```php
// FundController.php:58-66 — CURRENT
} catch (\Throwable $e) {
    DB::rollBack();
    Log::error('Failed to create Fund', [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
    ]);

    return back()->withInput()->with('error', 'Failed to create Fund: ' . $e->getMessage());
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'getMessage\(\)'
61: 'error' => $e->getMessage(),
65: return back()->withInput()->with('error', 'Failed to create Fund: ' . $e->getMessage());
118: 'error' => $e->getMessage(),
121: return back()->withInput()->with('error', 'Failed to update Fund: ' . $e->getMessage());
145: Log::error('Failed to delete Fund', ['id' => $fund->id, 'error' => $e->getMessage()]);
147: return back()->with('error', 'Failed to delete Fund: ' . $e->getMessage());
173: Log::error('Failed to toggle Fund status', ['id' => $fund->id, 'error' => $e->getMessage()]);
175: return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
209: Log::error('Failed to restore Fund', ['id' => $id, 'error' => $e->getMessage()]);
211: return back()->with('error', 'Failed to restore Fund: ' . $e->getMessage());
236: Log::error('Failed to force delete Fund', ['id' => $id, 'error' => $e->getMessage()]);
238: return back()->with('error', 'Failed to delete Fund: ' . $e->getMessage());
```

#### FUND-02 · H · ERR-02 — `findOrFail()` inside the try turns a 404 into a flash

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — *a catch must never turn a 404/403/422 into a redirect or 500* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:192-212` (`restore()`) and `:219-239` (`forceDelete()`); the lookups are at lines 194 and 221 |
| **Root cause** | `Fund::onlyTrashed()->findOrFail($id)` and `Fund::withTrashed()->findOrFail($id)` sit inside the `try`, and the generic `catch (\Throwable $e)` swallows `ModelNotFoundException`. |
| **Consequence** | A stale trash link for a fund that no longer exists shows "Failed to restore Fund: No query results for model [Modules\Accounting\Models\Fund] 999999" instead of a 404. |
| **Reproduce** | Open `/accounting/fund/999999/restore` while signed in. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Move both lookups above the transaction and remove the catch (D1). |
| **Plan item** | resolved by FUND-01 in `02-fix-plan.md` §1 |

```php
// FundController.php:192-212 — CURRENT
DB::beginTransaction();
try {
    $model = Fund::onlyTrashed()->findOrFail($id);
    $model->restore();
    $model->update(['is_active' => true]);

    activityLog($model, 'Restored', [
        'message'      => 'Fund restored: ' . $model->name,
        'name'         => $model->name,
        'performed_by' => auth()->id(),
    ]);

    DB::commit();

    return redirect()->route('accounting.fund.trashed')->with('success', 'Fund restored successfully.');
} catch (\Throwable $e) {
    DB::rollBack();
    Log::error('Failed to restore Fund', ['id' => $id, 'error' => $e->getMessage()]);

    return back()->with('error', 'Failed to restore Fund: ' . $e->getMessage());
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'findOrFail|catch \('
58: } catch (\Throwable $e) {
114: } catch (\Throwable $e) {
143: } catch (\Throwable $e) {
171: } catch (\Throwable $e) {
194: $model = Fund::onlyTrashed()->findOrFail($id);
207: } catch (\Throwable $e) {
221: $model = Fund::withTrashed()->findOrFail($id);
234: } catch (\Throwable $e) {
```

#### FUND-03 · M · ERR-05 — The log records the message and trace string, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — *log the exception, not the message: `report($e)` or `Log::error('.', ['exception' => $e])`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:60-63,116-119,145,173,209,236` |
| **Root cause** | Every catch builds an ad-hoc array from `getMessage()` and, in `store()`/`update()`, `getTraceAsString()`; the exception object is never handed to the logger. |
| **Consequence** | The log loses the exception class, code, previous exception and structured context, so a production failure cannot be traced from the log entry to the code path. |
| **Reproduce** | Force a duplicate-code insert, then open `storage/logs/laravel.log`: the entry has `error` and `trace` strings, not an `exception` object. |
| **Fix approach** | Remove the catches; the central handler logs the exception object. No `Log::error` remains in this controller. |
| **Plan item** | resolved by FUND-01 in `02-fix-plan.md` §1 |

```php
// FundController.php:60-63 — CURRENT
Log::error('Failed to create Fund', [
    'error' => $e->getMessage(),
    'trace' => $e->getTraceAsString(),
]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'Log::error'
60: Log::error('Failed to create Fund', [
116: Log::error('Failed to update Fund', [
145: Log::error('Failed to delete Fund', ['id' => $fund->id, 'error' => $e->getMessage()]);
173: Log::error('Failed to toggle Fund status', ['id' => $fund->id, 'error' => $e->getMessage()]);
209: Log::error('Failed to restore Fund', ['id' => $id, 'error' => $e->getMessage()]);
236: Log::error('Failed to force delete Fund', ['id' => $id, 'error' => $e->getMessage()]);
```

#### FUND-04 · M · ERR-00 — Six write methods keep a controller try/catch that D1 forbids

| Field | Value |
|---|---|
| **Rule** | ERR-00 (M) — *D1 settled: the Laravel idiom; no try/catch in controllers* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:42-66,97-122,129-148,157-176,192-212,219-239` |
| **Root cause** | The older house pattern (`DB::beginTransaction()` + `try` + `catch (\Throwable $e)`) is still present in every mutating method. |
| **Consequence** | Every failure is converted into a page-specific flash or a 500 JSON body, bypassing the central handler; 404/403/422 responses are hidden (see FUND-02) and each catch is a place to leak text (FUND-01). |
| **Reproduce** | Submit the edit form with a code that collides with a trashed fund: the controller catch handles it instead of Laravel's validation/exception pipeline. |
| **Fix approach** | Delete all six `try`/`catch` blocks and use `DB::transaction(fn () => ...)` (or the closure form) for the write + audit pair. |
| **Plan item** | resolved by FUND-01 in `02-fix-plan.md` §1 |

```php
// FundController.php:42-66 — CURRENT
DB::beginTransaction();
try {
    $validated['created_by'] = auth()->id();
    $fund = Fund::create($validated);

    activityLog($fund, 'Created', [
        'message'      => 'Fund created: ' . $fund->name,
        'code'         => $fund->code,
        'name'         => $fund->name,
        'performed_by' => auth()->id(),
    ]);

    DB::commit();

    return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds'])
        ->with('success', 'Fund created successfully.');
} catch (\Throwable $e) {
    DB::rollBack();
    Log::error('Failed to create Fund', [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
    ]);

    return back()->withInput()->with('error', 'Failed to create Fund: ' . $e->getMessage());
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'catch \('
58: } catch (\Throwable $e) {
114: } catch (\Throwable $e) {
143: } catch (\Throwable $e) {
171: } catch (\Throwable $e) {
207: } catch (\Throwable $e) {
234: } catch (\Throwable $e) {
```

### F2 — Transactions and audit

#### FUND-05 · M · TXN-02 — Six manual transactions instead of `DB::transaction`

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — *use `DB::transaction(fn () => ...)`, not manual `beginTransaction`/`commit`/`rollBack`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:42,54,59,97,110,115,129,139,144,157,168,172,192,204,208,219,231,235` |
| **Root cause** | Each method opens, commits and rolls back its own transaction by hand; the rollback lives only in the catch. |
| **Consequence** | A future early return or a throw outside the catch leaves an open transaction, and the write + audit pair is only atomic as long as every branch remembers to commit. |
| **Reproduce** | Add a `return` between `DB::beginTransaction()` and `DB::commit()` in any method; the connection stays in a transaction for the rest of the request. |
| **Fix approach** | Replace each manual transaction with the closure form; the closure rolls back on any throw. |
| **Plan item** | resolved by FUND-01 in `02-fix-plan.md` §1 |

```php
// FundController.php:42-54 — CURRENT
DB::beginTransaction();
try {
    $validated['created_by'] = auth()->id();
    $fund = Fund::create($validated);

    activityLog($fund, 'Created', [
        'message'      => 'Fund created: ' . $fund->name,
        'code'         => $fund->code,
        'name'         => $fund->name,
        'performed_by' => auth()->id(),
    ]);

    DB::commit();
```

**Evidence**
```
$ $f='Modules\Accounting\app\Http\Controllers\FundController.php'
$ "begin=" + (Select-String -Path $f -Pattern 'beginTransaction').Count + " commit=" + (Select-String -Path $f -Pattern 'DB::commit').Count + " rollback=" + (Select-String -Path $f -Pattern 'rollBack').Count
begin=6 commit=6 rollback=6
```

#### FUND-06 · M · TXN-04/Q7 — `destroy()` and `forceDelete()` both log the event `'Deleted'`

| Field | Value |
|---|---|
| **Rule** | TXN-04 (M) / deep-read Q7 — *the audit event must describe what actually happened; messages must not lie* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:133` (`destroy()`) and `:225` (`forceDelete()`) |
| **Root cause** | The soft-delete path was copied from the hard-delete path and kept the event literal `'Deleted'`; the house convention is `'Trashed'` for a soft delete (for example `CampusController.php:181`). |
| **Consequence** | The activity log cannot distinguish "moved to trash" from "permanently deleted" for a fund, so an auditor reading `event = Deleted` cannot tell whether the row is recoverable. |
| **Reproduce** | Trash a fund, open the activity log: the row says `Deleted` even though `deleted_at` was set and the fund is still in the trash. |
| **Fix approach** | Change the `destroy()` event to `'Trashed'`; keep `'Deleted'` for `forceDelete()`. |
| **Plan item** | resolved by FUND-01 in `02-fix-plan.md` §1 |

```php
// FundController.php:133-137 — CURRENT
activityLog($fund, 'Deleted', [
    'message'      => 'Fund moved to trash: ' . $fund->name,
    'code'         => $fund->code,
    'performed_by' => auth()->id(),
]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern "activityLog\(.*'Deleted'"
133: activityLog($fund, 'Deleted', [
225: activityLog($model, 'Deleted', [
$ Select-String -Path Modules\Accounting\app\Http\Controllers\CampusController.php -Pattern "'Trashed'"
181: activityLog($campus, 'Trashed', [
```

### F3 — Authorization

#### FUND-07 · L · AUTH-04 — `store()` and `update()` authorize the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — *do not authorize the same permission twice (Form Request `authorize()` + `Gate::authorize`); keep one* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:38,95` and `Modules/Accounting/app/Http/Requests/FundRequest.php:17` |
| **Root cause** | `FundRequest::authorize()` already calls `authorizeByCrudPermission('tenant.accounting.fund')`, which maps POST to `create` and PUT/PATCH to `update`; the controller repeats the identical `Gate::authorize` call. |
| **Consequence** | Two checks run for every create/update; if one is later changed, the other silently remains and the effective rule is no longer obvious. |
| **Reproduce** | Temporarily remove the permission from a role: the FormRequest rejects the request before the controller line is reached, proving the controller check is redundant. |
| **Fix approach** | Remove the two `Gate::authorize` lines from `store()` and `update()`; keep the FormRequest as the single gate. |
| **Plan item** | FUND-07 in `02-fix-plan.md` §4 |

```php
// FundController.php:36-40 — CURRENT
public function store(FundRequest $request)
{
    Gate::authorize('tenant.accounting.fund.create');

    $validated = $request->validated();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'Gate::authorize'
21: Gate::authorize('tenant.accounting.fund.viewAny');
28: Gate::authorize('tenant.accounting.fund.create');
38: Gate::authorize('tenant.accounting.fund.create');
71: Gate::authorize('tenant.accounting.fund.view');
85: Gate::authorize('tenant.accounting.fund.update');
95: Gate::authorize('tenant.accounting.fund.update');
127: Gate::authorize('tenant.accounting.fund.delete');
153: Gate::authorize('tenant.accounting.fund.update');
181: Gate::authorize('tenant.accounting.fund.restore');
190: Gate::authorize('tenant.accounting.fund.restore');
217: Gate::authorize('tenant.accounting.fund.forceDelete');
$ Select-String -Path Modules\Accounting\app\Http\Requests\FundRequest.php -Pattern 'authorizeByCrudPermission'
17: return $this->authorizeByCrudPermission('tenant.accounting.fund');
```

#### FUND-08 · M · AUTH-06 — Permission strings are repeated 11 times and the registered policy is never consulted

| Field | Value |
|---|---|
| **Rule** | AUTH-06 (M) — *permission strings live in one place, a Policy or constants, not repeated as literals in every method* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:21,28,38,71,85,95,127,153,181,190,217`; `Modules/Accounting/app/Providers/AccountingServiceProvider.php:165`; `Modules/Accounting/app/Policies/FundPolicy.php:12-46` |
| **Root cause** | The controller calls `Gate::authorize('tenant.accounting.fund.*')` with a literal in each method. `FundPolicy` is registered for `Fund` and implements all seven abilities, but the controller never calls a policy ability, so the policy is dead code. |
| **Consequence** | A permission rename needs 11 controller edits plus the FormRequest; the policy can drift from the controller and no one notices, because nothing exercises it. |
| **Reproduce** | Rename `accounting.fund` in `config/permissionslist.php` and sync: the controller still calls the old strings, while the policy (which no one calls) is the only file that would have followed the model-based convention. |
| **Fix approach** | Decision: introduce a `FundPermissions` constants class and use it in the controller, `FundRequest` and `FundPolicy` (recommended), route the controller through the registered policy (leaves `trashed()` without an ability), or leave the literals. |
| **Plan item** | FUND-08 in `02-fix-plan.md` §9 |

```php
// FundController.php:19-24 — CURRENT
public function index()
{
    Gate::authorize('tenant.accounting.fund.viewAny');

    return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds']);
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Providers\AccountingServiceProvider.php -Pattern 'FundPolicy'
60: use Modules\Accounting\Policies\FundPolicy;
165: Gate::policy(Fund::class, FundPolicy::class);
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'FundPolicy|->can\('
(no output)
$ (Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'Gate::authorize').Count
11
```

### F4 — Validation and input

#### FUND-09 · H · VAL-04 — The validation rule hides trashed rows but the DB unique index does not

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — *uniqueness rules must mirror the DB unique index, including soft-delete semantics* |
| **Where** | `database/migrations/tenant/2026_09_16_100020_create_acc_funds_table.php:43-44`; `Modules/Accounting/app/Http/Requests/FundRequest.php:25-26` |
| **Root cause** | The table has plain `unique('code', 'uq_acc_fund_code')` and `unique('name', 'uq_acc_fund_name')`, which include trashed rows. The request adds `->withoutTrashed()`, which excludes them. The two rules disagree. |
| **Consequence** | After a fund is trashed, a new fund with the same code or name passes validation and then the DB rejects the INSERT; with FUND-01 the user sees the raw SQL text, without it the user sees a generic 500. |
| **Reproduce** | Create code `GEN`, trash it, create code `GEN` again: validation passes, the request fails at the database. Today `acc_funds` has 0 trashed rows, so the first trashed fund makes this reachable. |
| **Fix approach** | Decision: (a) drop `->withoutTrashed()` so validation mirrors the index exactly (recommended, no migration), or (b) add an additive migration that enforces uniqueness only among live rows with a generated column, or (c) accept the 500. |
| **Plan item** | FUND-09 in `02-fix-plan.md` §9 |

```php
// FundRequest.php:25-26 — CURRENT
'code'                => ['required', 'string', 'max:30', Rule::unique('acc_funds', 'code')->ignore($id)->withoutTrashed()],
'name'                => ['required', 'string', 'max:150', Rule::unique('acc_funds', 'name')->ignore($id)->withoutTrashed()],
```

**Evidence**
```
$ Select-String -Path database\migrations\tenant\2026_09_16_100020_create_acc_funds_table.php -Pattern 'unique'
43: $table->unique('code', 'uq_acc_fund_code');
44: $table->unique('name', 'uq_acc_fund_name');
$ Select-String -Path Modules\Accounting\app\Http\Requests\FundRequest.php -Pattern 'withoutTrashed'
25: 'code'                => ['required', 'string', 'max:30', Rule::unique('acc_funds', 'code')->ignore($id)->withoutTrashed()],
26: 'name'                => ['required', 'string', 'max:150', Rule::unique('acc_funds', 'name')->ignore($id)->withoutTrashed()],
```

#### FUND-10 · H · VAL-07/VAL-05 — Every edit rewrites the fund's status and can change its type

| Field | Value |
|---|---|
| **Rule** | VAL-07 (M) / VAL-05 (M) — *cross-field/business defaults belong in the FormRequest, and every submitted field is typed*; rated **H** locally because the result is silent data loss on every edit |
| **Where** | `Modules/Accounting/app/Http/Requests/FundRequest.php:77-84`; `Modules/Accounting/resources/views/fund/edit.blade.php:78-82,213` |
| **Root cause** | `prepareForValidation()` invents defaults for fields the edit form never submits: `$status = $this->input('status') ?: 'Active'` and `$this->boolean('is_active', true)`. `edit.blade.php` has no `name="status"` input, and an unchecked HTML checkbox is absent, so `boolean(..., true)` forces `true`. The same form's `fund_type` select has no `Corpus` or `Designated` option, so a stored `Corpus`/`Designated` value falls through to the first option (`Grant`), which the request maps to `Restricted`. |
| **Consequence** | Editing the name of a `Suspended`, `Closed` or `Fully_Utilised` fund silently reopens it as `Active`; a `Corpus` or `Designated` fund silently becomes `Restricted`; and unchecking "Active Status" saves the fund as active anyway, so a user cannot deactivate a fund from the edit page. |
| **Reproduce** | Create a fund with status `Closed` and type `Corpus` in the modal, open its edit page, change only the name and save: the list shows `Active` and `Restricted`. Uncheck "Active Status", save, reopen: it is still checked. |
| **Fix approach** | Decision: (a) add the `status` select, the two missing `fund_type` options and a hidden `is_active=0` to the edit form, and make the request preserve the bound model's status when the field is absent (recommended), (b) add only the `status` select and the hidden `is_active` zero, leaving the missing `Corpus`/`Designated` options, or (c) leave. |
| **Plan item** | FUND-10 in `02-fix-plan.md` §9 |

```php
// FundRequest.php:77-84 — CURRENT
$status = $this->input('status') ?: 'Active';

$mergeData = [
    'is_active'        => $this->boolean('is_active', true),
    'status'           => $status,
    'fund_type'        => $mappedType,
    'overspend_action' => $mappedOverspend ?: 'Block',
];
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\fund\edit.blade.php -Pattern 'name="status"'
(no output)
$ Select-String -Path Modules\Accounting\resources\views\fund\edit.blade.php -Pattern 'option value="Corpus"|option value="Designated"'
(no output)
$ Select-String -Path Modules\Accounting\resources\views\fund\edit.blade.php -Pattern 'name="is_active"'
213: <input type="checkbox" name="is_active" id="is_active"
$ Select-String -Path Modules\Accounting\app\Http\Requests\FundRequest.php -Pattern "'status'|boolean\("
77: $status = $this->input('status') ?: 'Active';
80: 'is_active'        => $this->boolean('is_active', true),
81: 'status'           => $status,
$ Select-String -Path Modules\Accounting\resources\views\pages\partials\setup-masters\_funds.blade.php -Pattern 'option value="Corpus"|option value="Designated"'
193: <option value="Corpus" {{ old('fund_type') == 'Corpus' ? 'selected' : '' }}>Corpus</option>
194: <option value="Designated" {{ old('fund_type') == 'Designated' ? 'selected' : '' }}>Designated</option>
```

### F5 — Routes

#### FUND-11 · H · RTE-01 — `GET /accounting/fund/{id}/restore` changes state

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — *no state change over GET; GET has no CSRF protection and link prefetchers trigger it* |
| **Where** | `Modules/Accounting/routes/web.php:132`; `Modules/Accounting/app/Http/Controllers/FundController.php:188` |
| **Root cause** | Restore is registered with `Route::get`, and the shared `x-backend.table.action-trashed` component already chooses the form method from the route, so the route verb is the only thing keeping this on GET. |
| **Consequence** | A crawler, a link prefetcher, an email scanner or a user with a stale tab can restore a trashed fund without an intentional POST or a CSRF token. |
| **Reproduce** | While signed in, request `GET /accounting/fund/{id}/restore` for a trashed fund: the fund is restored immediately, with no form and no token. |
| **Fix approach** | Decision: (a) change the route to `Route::post` (the shared component already submits a CSRF POST form when the route is POST; no component edit), (b) keep GET and add a confirmation/CSRF guard (does not meet RTE-01), or (c) accept. |
| **Plan item** | FUND-11 in `02-fix-plan.md` §9 |

```php
// routes/web.php:132 — CURRENT
Route::get('/fund/{id}/restore', [FundController::class, 'restore'])->name('fund.restore');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\routes\web.php -Pattern 'fund/'
131: Route::get('/fund/trash/view', [FundController::class, 'trashed'])->name('fund.trashed');
132: Route::get('/fund/{id}/restore', [FundController::class, 'restore'])->name('fund.restore');
133: Route::delete('/fund/{id}/force-delete', [FundController::class, 'forceDelete'])->name('fund.forceDelete');
134: Route::resource('fund', FundController::class);
135: Route::post('/fund/{fund}/toggle-status', [FundController::class, 'toggleStatus'])->name('fund.toggleStatus');
```

### F6 — Controller shape

#### FUND-12 · L · CTL-03 — `restore()` and `forceDelete()` use `$id` + `findOrFail` instead of route-model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (M) — *route model binding, not `$id` + `findOrFail`*; rated **L** locally because `restore()` must still 404 for a live id, so the explicit `onlyTrashed()` lookup is intentional and the only gain is a route parameter rename. |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:188,194,215,221`; `Modules/Accounting/routes/web.php:132-133` |
| **Root cause** | Both trash routes use `{id}` and the methods accept `$id`; the model is fetched by hand inside the method. |
| **Consequence** | The route parameter name does not match the model, and the lookup logic is duplicated; there is no binding-level 404 and the method must remember `onlyTrashed()`/`withTrashed()`. |
| **Reproduce** | `php artisan route:list` shows `{id}` for both routes, unlike `show`/`edit`/`update`/`destroy`, which use `{fund}`. |
| **Fix approach** | Deferred: renaming the parameter is a shared route re-scope for an L-severity shape issue; keep the explicit trashed lookups. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// FundController.php:188 — CURRENT
public function restore($id): \Illuminate\Http\RedirectResponse
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\routes\web.php -Pattern 'fund/\{id\}'
132: Route::get('/fund/{id}/restore', [FundController::class, 'restore'])->name('fund.restore');
133: Route::delete('/fund/{id}/force-delete', [FundController::class, 'forceDelete'])->name('fund.forceDelete');
```

#### FUND-13 · L · CTL-04 — Eight public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — *return types on public methods (`: View`, `: RedirectResponse`, `: JsonResponse`)* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:19,26,36,69,83,93,125,151` |
| **Root cause** | Only `trashed()`, `restore()` and `forceDelete()` declare a return type; the other eight public methods do not. |
| **Consequence** | Static analysis and refactoring tools cannot prove the response shape, and the file mixes typed and untyped methods. |
| **Reproduce** | `Select-String ... -Pattern 'public function'` shows eight signatures ending in `)`. |
| **Fix approach** | Add `RedirectResponse`, `View` and `JsonResponse` types and import the three classes. |
| **Plan item** | FUND-13 in `02-fix-plan.md` §8 |

```php
// FundController.php:19,26,36,69,83,93,125,151 — CURRENT
public function index()
public function create()
public function store(FundRequest $request)
public function show(Fund $fund)
public function edit(Fund $fund)
public function update(FundRequest $request, Fund $fund)
public function destroy(Fund $fund)
public function toggleStatus(Request $request, Fund $fund)
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'public function'
19: public function index()
26: public function create()
36: public function store(FundRequest $request)
69: public function show(Fund $fund)
83: public function edit(Fund $fund)
93: public function update(FundRequest $request, Fund $fund)
125: public function destroy(Fund $fund)
151: public function toggleStatus(Request $request, Fund $fund)
179: public function trashed(): \Illuminate\View\View
188: public function restore($id): \Illuminate\Http\RedirectResponse
215: public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### FUND-14 · L · CTL-05 — Two "create fund" forms exist and they disagree

| Field | Value |
|---|---|
| **Rule** | CTL-05 (M) — *no copy-paste; the same form duplicated*; rated **L** locally because the second form is orphaned from the live UI |
| **Where** | `Modules/Accounting/resources/views/pages/partials/setup-masters/_funds.blade.php:174` (modal posts to `accounting.fund.store`); `Modules/Accounting/app/Http/Controllers/FundController.php:26-33` and `Modules/Accounting/resources/views/fund/create.blade.php` (routed form) |
| **Root cause** | The live Fund tab uses a create modal, but the resource also exposes a full-page `create` action. The only link to that page is inside the dead `fund/index.blade.php:93`. |
| **Consequence** | The two forms have drifted: the modal submits `status` and `is_active`, the page submits neither, so the same fund created from the page always starts `Active`/active. A user who reaches the URL directly gets a different form from the one the menu offers. |
| **Reproduce** | Open `/accounting/fund/create` directly: the page has no Status or Active controls, unlike the modal on `/accounting/setup-masters?tab=funds`. |
| **Fix approach** | Decision: (a) delete the routed page and `create()` method (keep the modal), (b) keep both and link the page from the live list, or (c) leave. |
| **Plan item** | FUND-14 in `02-fix-plan.md` §9 |

```php
// FundController.php:26-33 — CURRENT
public function create()
{
    Gate::authorize('tenant.accounting.fund.create');

    $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get();
    $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get();

    return view('accounting::fund.create', compact('campuses', 'ledgers'));
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\pages\partials\setup-masters\_funds.blade.php -Pattern 'fund.store|fnd_status|fnd_is_active'
174: :action="route('accounting.fund.store')"
267: <select name="status" id="fnd_status" class="form-select form-select-sm">
283: <input type="checkbox" name="is_active" id="fnd_is_active"
$ Select-String -Path Modules\Accounting\resources\views\fund\index.blade.php -Pattern 'fund.create'
93: <a href="{{ route('accounting.fund.create') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus me-1"></i> Add Fund</a>
```

#### FUND-15 · L · CTL-10 — `fund/index.blade.php` is dead

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M) — *no dead code: unused methods, unused properties, unused files*; rated **L** locally because an unreferenced Blade file has no runtime effect |
| **Where** | `Modules/Accounting/resources/views/fund/index.blade.php` (105 lines, 7,143 bytes); `Modules/Accounting/app/Http/Controllers/FundController.php:19-24` |
| **Root cause** | `index()` returns a redirect to Setup Masters and never renders the view; the old list page was left behind when the Funds tab moved. |
| **Consequence** | Maintainers can edit the dead page and see no effect, and it still contains the only link to the orphaned create page (FUND-14). |
| **Reproduce** | `Select-String` over `Modules/Accounting/resources` and `Modules/Accounting/app` for `fund.index` finds only `Exception.php:142` (a route call), never a `view()` call. |
| **Fix approach** | Delete `fund/index.blade.php`; keep the `index()` redirect and the route name, because `Exception.php:142` calls `route('accounting.fund.index')`. |
| **Plan item** | FUND-15 in `02-fix-plan.md` §5 |

```php
// FundController.php:19-24 — CURRENT
public function index()
{
    Gate::authorize('tenant.accounting.fund.viewAny');

    return redirect()->route('accounting.menu.setupMasters', ['tab' => 'funds']);
}
```

**Evidence**
```
$ Get-ChildItem Modules\Accounting\resources,Modules\Accounting\app -Recurse -Include *.php,*.blade.php | Select-String -Pattern 'fund\.index|fund/index'
C:\laragon\www\PG\prime_ai\Modules\Accounting\app\Models\Exception.php:142: return route('accounting.fund.index');
```

### F7 — Models

#### FUND-16 · L · MDL-04 — The four `Fund` relations have no return types

| Field | Value |
|---|---|
| **Rule** | MDL-04 (L) — *relationship methods return-typed (`: BelongsTo`, `: HasMany`)* |
| **Where** | `Modules/Accounting/app/Models/Fund.php:42-60` |
| **Root cause** | `grantorLedger()`, `fundLedger()`, `campus()` and `balances()` return the relation object without a declared type. |
| **Consequence** | The model is weaker for static analysis, and `campus()` uses a fully-qualified class name instead of the imported model. |
| **Reproduce** | `Select-String ... -Pattern 'public function (grantorLedger|fundLedger|campus|balances)'` shows no `: BelongsTo`/`: HasMany`. |
| **Fix approach** | Add `: BelongsTo` to the three `belongsTo` methods, `: HasMany` to `balances()`, and import both relation classes. |
| **Plan item** | FUND-16 in `02-fix-plan.md` §5 |

```php
// Fund.php:42-60 — CURRENT
public function grantorLedger()
{
    return $this->belongsTo(Ledger::class, 'grantor_ledger_id');
}

public function fundLedger()
{
    return $this->belongsTo(Ledger::class, 'fund_ledger_id');
}

public function campus()
{
    return $this->belongsTo(\Modules\Accounting\Models\Campus::class);
}

public function balances()
{
    return $this->hasMany(FundBalance::class);
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\Fund.php -Pattern 'public function (grantorLedger|fundLedger|campus|balances)'
42: public function grantorLedger()
47: public function fundLedger()
52: public function campus()
57: public function balances()
```

#### FUND-17 · L · CTL-10 — `Fund` re-declares `use SoftDeletes`, already applied by its parent

| Field | Value |
|---|---|
| **Rule** | CTL-10 (M), extended to redundant declarations — *no dead/redundant code*; rated **L** locally because the duplicate trait is harmless today |
| **Where** | `Modules/Accounting/app/Models/Fund.php:8,12`; `Modules/Accounting/app/Models/BaseAccountingModel.php:14` |
| **Root cause** | `Fund extends BaseAccountingModel`, and the parent already declares `use SoftDeletes`; the child imports and declares it again. |
| **Consequence** | Two declarations of the same trait mask a future change to the parent and add a misleading import to the model. |
| **Reproduce** | Open `BaseAccountingModel.php:14` and `Fund.php:12`: both declare `use SoftDeletes`. |
| **Fix approach** | Remove the `SoftDeletes` import and the `use SoftDeletes;` line from `Fund`; inherit the parent trait. |
| **Plan item** | FUND-17 in `02-fix-plan.md` §5 |

```php
// Fund.php:7-12 — CURRENT
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Fund extends BaseAccountingModel
{
    use SoftDeletes;
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Models\Fund.php -Pattern 'SoftDeletes'
8: use Illuminate\Database\Eloquent\SoftDeletes;
12: use SoftDeletes;
$ Select-String -Path Modules\Accounting\app\Models\BaseAccountingModel.php -Pattern 'SoftDeletes'
14: use SoftDeletes;
```

#### FUND-18 · L · MDL-09 — Fund type, status and overspend literals are duplicated and one view compares the pre-mapping values

| Field | Value |
|---|---|
| **Rule** | MDL-09 (L) — *status/type strings are PHP enums or model constants, not literals repeated across files* |
| **Where** | `Modules/Accounting/app/Http/Requests/FundRequest.php:27,34,35,65-75`; `Modules/Accounting/resources/views/fund/create.blade.php:60-64`; `edit.blade.php:78-82`; `show.blade.php:52-58`; `_funds.blade.php:14,28,191-197,268-271` |
| **Root cause** | There is no enum or constants class. The request maps `Grant`/`Donation` to `Restricted` and `Endowment` to `Corpus`, but `show.blade.php` still compares the stored value to `Grant`/`Donation`/`Endowment`, and the live filter offers values (`Capital`, `Scholarship`, `Research`, `General`, `Allow`, `Transfer`) that are never stored. |
| **Consequence** | The Grant/Donation/Endowment badge branches never run (the generic badge is shown instead), and several filter options always return an empty list. |
| **Reproduce** | Create a fund with type `Grant`; it is stored as `Restricted`, so `show.blade.php` takes the `@else` branch and renders the generic badge. |
| **Fix approach** | Deferred: introduce a `FundType`/`FundStatus`/`OverspendAction` enum (or model constants) and use it in the request, models, views and filters. This is a module-wide enum pass, not a single-controller edit. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// FundRequest.php:65-75 — CURRENT (mapping that the view ignores)
$mappedType = match ($fundType) {
    'Grant', 'Donation' => 'Restricted',
    'Endowment' => 'Corpus',
    default => $fundType,
};
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\fund\show.blade.php -Pattern 'fund_type =='
52: @if($fund->fund_type == 'Grant')
54: @elseif($fund->fund_type == 'Donation')
56: @elseif($fund->fund_type == 'Endowment')
$ Select-String -Path Modules\Accounting\app\Http\Requests\FundRequest.php -Pattern "'fund_type'|'overspend_action'|'status'"
27: 'fund_type'           => 'required|in:Unrestricted,Restricted,Corpus,Designated',
34: 'overspend_action'    => 'required|in:Block,Approve,Warn',
35: 'status'              => 'required|in:Active,Fully_Utilised,Suspended,Closed',
```

### F8 — Services and jobs

clean — `Get-ChildItem Modules\Accounting\app\Services,Modules\Accounting\app\Jobs -Recurse -Filter "*Fund*"` → no output, and the controller contains no `dispatch(`, `Job` or service injection.

### F9 — Queries and performance

#### FUND-19 · M · QRY-02 — The trash list paginates at 15 with the default page name

| Field | Value |
|---|---|
| **Rule** | QRY-02 (H) — *lists are paginated; the standard page size is 10 with a distinct `pageName` per list*; rated **M** locally because only the trash screen uses it, it has one paginator, and the live table has 0 trashed rows. |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:183` |
| **Root cause** | `paginate(15)` uses a non-standard size and the default page name (`page`). |
| **Consequence** | The trash screen shows 15 rows instead of the house standard 10, and the page name can collide if another paginator is added to the same screen. |
| **Reproduce** | Open `/accounting/fund/trash/view` with more than 10 trashed funds: the pager uses `?page=` and 15 rows. |
| **Fix approach** | `paginate(10, ['*'], 'funds_page')`; `$funds->links()` in `trash.blade.php` already follows the paginator's page name. |
| **Plan item** | FUND-19 in `02-fix-plan.md` §6 |

```php
// FundController.php:183 — CURRENT
$funds = Fund::onlyTrashed()->orderBy('code')->paginate(15);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'paginate\('
183: $funds = Fund::onlyTrashed()->orderBy('code')->paginate(15);
$ php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\fundprobe.php
TENANT_DB=xyz_school_00000000000040008000_202627
acc_funds={"total":4,"trashed":"0","active":"4"}
```

#### FUND-20 · M · QRY-03 — The controller loads more columns and one more relation than it uses

| Field | Value |
|---|---|
| **Rule** | QRY-03 (M) — *select only what you use; dropdowns use `pluck('name', 'id')` or `get(['id', 'name'])`* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:30-31,73-78,87-88` |
| **Root cause** | `create()` and `edit()` call `Campus::...->get()` and `Ledger::...->get()` with every column, although the views use only `id` and `name`; `show()` eager-loads `balances`, but no Fund view reads it. |
| **Consequence** | The two forms load all columns of 56 ledgers and 4 campuses for two-field dropdowns, and `show()` runs an extra query on `acc_fund_balances` whose result is discarded. |
| **Reproduce** | `Select-String -Path Modules\Accounting\resources\views\fund\*.blade.php -Pattern 'balances'` → no output; the only `balances` reference is the eager-load string at line 77. |
| **Fix approach** | Remove `'balances'` from the `show()` load; change both dropdown queries to `get(['id', 'name'])`. |
| **Plan item** | FUND-20 in `02-fix-plan.md` §6 |

```php
// FundController.php:30-31 — CURRENT
$campuses = Campus::where('is_active', true)->orderBy('ordinal')->get();
$ledgers  = Ledger::where('is_active', true)->orderBy('name')->get();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php -Pattern 'balances|->get\(\)'
30: $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get();
31: $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get();
77: 'balances',
87: $campuses = Campus::where('is_active', true)->orderBy('ordinal')->get();
88: $ledgers  = Ledger::where('is_active', true)->orderBy('name')->get();
$ Get-ChildItem Modules\Accounting\resources\views\fund -Filter *.blade.php | Select-String -Pattern 'balances'
(no output)
```

### F10 — Views

clean — `Get-ChildItem Modules\Accounting\resources\views\fund -Filter *.blade.php | Select-String -Pattern '::where|::all|DB::|->get\(\)'` → no output (no queries or raw model reads in the Fund views). The dead `index.blade.php` is reported as FUND-15, not as a view-query defect.

### F11 — Security and tenancy

clean in scope — `Select-String -Path Modules\Accounting\app\Http\Controllers\FundController.php,Modules\Accounting\app\Http\Requests\FundRequest.php,Modules\Accounting\app\Models\Fund.php -Pattern 'env\(|Auth::id\(\) \?\? 1'` → no output, and every route carries `InitializeTenancyByDomain` + `EnsureTenantIsActive` + `EnsureTenantHasModule:Accounting`. The hard-coded id fallback lives in the shared `BaseAccountingModel`/`AccountingContext` and is logged in §7.

### F12 — Style

#### FUND-21 · L · STY-02 — `FundController.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset): sorted imports, `fn ()` spacing, no stray blank lines* |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php` |
| **Root cause** | The file predates the Pint pass: imports are out of order, `concat_space` and `binary_operator_spaces` differ from the preset, and FQCN return types trigger `fully_qualified_strict_types`. |
| **Consequence** | A style check fails and future diffs carry unrelated formatting noise. |
| **Reproduce** | `vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Controllers\FundController.php` |
| **Fix approach** | Run Pint on this file (after the functional items, so it normalizes the final code). |
| **Plan item** | FUND-21 in `02-fix-plan.md` §8 |

```php
// Pint output — CURRENT
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\FundController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]}]}
```

**Evidence**
```
$ vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Controllers\FundController.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\FundController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces"]}]}
```

#### FUND-22 · L · STY-02 — `Fund.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Models/Fund.php` |
| **Root cause** | Unused `App\Models\BaseModel` import, a fully-qualified `Campus` reference, and alignment spacing in `$casts` differ from the preset. |
| **Consequence** | The file fails the style check and the unused import misleads readers. |
| **Reproduce** | `vendor\bin\pint --test --format agent Modules\Accounting\app\Models\Fund.php` |
| **Fix approach** | Run Pint on this file; it removes the unused import and normalizes the FQCN and spacing. |
| **Plan item** | FUND-22 in `02-fix-plan.md` §8 |

```php
// Pint output — CURRENT
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Fund.php","fixers":["fully_qualified_strict_types","no_unused_imports","binary_operator_spaces"]}]}
```

**Evidence**
```
$ vendor\bin\pint --test --format agent Modules\Accounting\app\Models\Fund.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Models\\Fund.php","fixers":["fully_qualified_strict_types","no_unused_imports","binary_operator_spaces"]}]}
```

#### FUND-23 · L · STY-02 — `FundRequest.php` is not Pint-clean

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — *Pint-clean (PSR-12 + Laravel preset)* |
| **Where** | `Modules/Accounting/app/Http/Requests/FundRequest.php` |
| **Root cause** | Import order and `binary_operator_spaces` in the rules array differ from the preset. |
| **Consequence** | The form request fails the style check and carries noisy alignment. |
| **Reproduce** | `vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Requests\FundRequest.php` |
| **Fix approach** | Run Pint on this file. |
| **Plan item** | FUND-23 in `02-fix-plan.md` §8 |

```php
// Pint output — CURRENT
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\FundRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

**Evidence**
```
$ vendor\bin\pint --test --format agent Modules\Accounting\app\Http\Requests\FundRequest.php
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Requests\\FundRequest.php","fixers":["ordered_imports","binary_operator_spaces"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data? | 2 Irreversible order? | 3 Duplicate impl? | 4 Soft-delete x unique? | 5 Races? | 6 Auth hole? | 7 Message lies? | 8 Dead feature? |
|---|---|---|---|---|---|---|---|---|
| `store` | ok | ok | ok | FUND-09 | ok | ok | ok | ok |
| `update` | FUND-10 | ok | ok | FUND-09 | ok | ok | ok | ok |
| `destroy` | ok | ok | ok | ok | ok | ok | FUND-06 | ok |
| `toggleStatus` | ok | ok | ok | ok | ok | ok | ok | ok |
| `restore` | ok | ok | ok | ok | ok | ok | ok | ok |
| `forceDelete` | FUND-24 | ok | ok | ok | ok | ok | ok | ok |

#### FUND-24 · H · CTL-06 — `forceDelete()` has no usage guard and the FKs disagree on what happens

| Field | Value |
|---|---|
| **Rule** | CTL-06 (M) — *business logic lives in a service/action; a controller method reads input, calls one service, returns a response*; rated **H** locally because the result is either a raw 500 or silent loss of balance rows |
| **Where** | `Modules/Accounting/app/Http/Controllers/FundController.php:215-239`; 13 `fund_id` foreign keys in `database/migrations/tenant` |
| **Root cause** | `forceDelete()` calls `$model->forceDelete()` without checking whether any other table references the fund. Nine FKs use `restrictOnDelete`, one (`acc_fund_balances`) uses `cascadeOnDelete`, and three use `nullOnDelete`. |
| **Consequence** | Permanently deleting a fund that is used by a budget, grant, donation, fixed asset, voucher fund allocation or similar returns a raw FK error (a 500 after FUND-01), while a fund with balance rows silently loses those rows through the cascade. |
| **Reproduce** | Create a budget line for a fund, trash the fund, then force-delete it: the `fk_acc_bl_fund` restrict constraint fails. With a row in `acc_fund_balances`, the same action deletes the balance rows without asking. |
| **Fix approach** | Decision: (a) pre-check the nine restrict tables and `acc_fund_balances` and block with a friendly flash (recommended), (b) let the database reject it and catch the `QueryException` (D2 forbids catching `RuntimeException` shapes in a controller), or (c) change the FK behaviour in a migration. |
| **Plan item** | FUND-24 in `02-fix-plan.md` §9 |

```php
// FundController.php:219-233 — CURRENT
DB::beginTransaction();
try {
    $model = Fund::withTrashed()->findOrFail($id);
    $name = $model->name;
    $model->forceDelete();

    activityLog($model, 'Deleted', [
        'message'      => 'Fund permanently deleted: ' . $name,
        'name'         => $name,
        'performed_by' => auth()->id(),
    ]);

    DB::commit();

    return redirect()->route('accounting.fund.trashed')->with('success', 'Fund permanently deleted.');
```

**Evidence**
```
$ Get-ChildItem database\migrations\tenant -Filter *.php | Select-String -Pattern "foreign\('fund_id'"
2026_09_16_100033_create_acc_budget_lines_table.php:55: $table->foreign('fund_id', 'fk_acc_bl_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100034_create_acc_event_voucher_configs_table.php:49: $table->foreign('fund_id', 'fk_acc_evc_fund')->references('id')->on('acc_funds')->nullOnDelete();
2026_09_16_100035_create_acc_fund_balances_table.php:49: $table->foreign('fund_id', 'fk_acc_fb_fund')->references('id')->on('acc_funds')->cascadeOnDelete();
2026_09_16_100036_create_acc_ledger_period_balances_table.php:61: $table->foreign('fund_id', 'fk_acc_lpb_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100044_create_acc_donations_table.php:75: $table->foreign('fund_id', 'fk_acc_don_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100046_create_acc_event_voucher_line_templates_table.php:51: $table->foreign('fund_id', 'fk_acc_evlt_fund')->references('id')->on('acc_funds')->nullOnDelete();
2026_09_16_100049_create_acc_fixed_assets_table.php:74: $table->foreign('fund_id', 'fk_acc_fa_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100050_create_acc_grants_table.php:63: $table->foreign('fund_id', 'fk_acc_grant_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100051_create_acc_opening_balances_table.php:62: $table->foreign('fund_id', 'fk_acc_ob_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100052_create_acc_recurring_template_lines_table.php:50: $table->foreign('fund_id', 'fk_acc_rtl_fund')->references('id')->on('acc_funds')->nullOnDelete();
2026_09_16_100063_create_acc_bill_references_table.php:66: $table->foreign('fund_id', 'fk_acc_billref_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100066_create_acc_expense_claim_lines_table.php:58: $table->foreign('fund_id', 'fk_acc_ecl_fund')->references('id')->on('acc_funds')->restrictOnDelete();
2026_09_16_100069_create_acc_voucher_item_funds_table.php:38: $table->foreign('fund_id', 'fk_acc_vif_fund')->references('id')->on('acc_funds')->restrictOnDelete();
$ "restrict=" + (Get-ChildItem database\migrations\tenant -Filter *.php | Select-String -Pattern "foreign\('fund_id'" | Select-String -Pattern 'restrictOnDelete').Count
restrict=9
```

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/app/Http/Controllers/AccDashboardController.php:232,254` | The live Funds tab builds `Fund::with('campus')->orderBy('name')` and then calls `->get()` — an unbounded list; it also filters `fund_type`/`overspend_action` with the values from `_funds.blade.php`, which do not match the stored values. | QRY-02 | AccDashboardController report |
| `Modules/Accounting/resources/views/pages/partials/setup-masters/_funds.blade.php:14,28,283` | Filter options offer `Endowment`, `Capital`, `Scholarship`, `Research`, `General` (stored values are `Unrestricted`, `Restricted`, `Corpus`, `Designated`) and `Allow`, `Transfer` (stored values are `Block`, `Warn`, `Approve`); the create-modal `is_active` checkbox has no hidden `0`, so unchecking it still submits `true`. | MDL-09 / VAL-05 | AccDashboardController report |
| `Modules/Accounting/app/Models/BaseAccountingModel.php` and `Modules/Accounting/app/Services/AccountingContext.php` | Hard-coded `Auth::id() ?? 1` fallback for `created_by`/`updated_by`/`campus_id`; shared by every accounting model. | SEC-03 | AccountingStatusMasterController report / AccountGroupController report |
| `Modules/Accounting/app/Models/FundBalance.php:44`, `BudgetLine.php:55`, `VoucherItemFund.php:34` | The `fund()` `belongsTo` relations do not add `withTrashed()`, so a trashed fund disappears from allocation and voucher displays instead of showing its code. | MDL-03 (soft-delete visibility, analogue) | The report that owns each model |
| `Modules/Accounting/app/Policies/FundBalancePolicy.php` and `FundPolicy.php` | Both are registered in `AccountingServiceProvider.php:165-166`; `FundPolicy` is not consulted by this controller and `FundBalancePolicy` is not in the class registry. | AUTH-06 | Module-wide policy pass |

## 8. Not covered, and why

- **Scanner and self-check were skipped.** The binding override for this audit says `final-audit-reports/_tools/scanfilter.py` and `selfcheck.py` are missing and `scan.php` must not run. F1-F13 were therefore worked by hand with `Select-String`, `Get-Content`, the route probe and Pint. A scanner pass would need the two missing tools.
- **No tests were run** (D4). No browser session was opened; the Blade files were checked statically and the HTTP outcomes for duplicate codes, stale restore links and the unchecked `is_active` box follow from the code and Laravel's `Request::boolean($key, true)` semantics.
- **Live write paths were not exercised.** `acc_funds` has 4 rows, 0 trashed and `acc_fund_balances` is empty, so restore and force-delete were audited from code, migrations and FK definitions, not by deleting a real fund.
- **The `activityLog()` helper was read, not run.** Its tenant-context branch and `Auth::id()` behaviour were verified statically; no log row was produced.
- **The `FundPolicy` abilities were read but never invoked**, because the controller does not call them (FUND-08).
- **A direct `php -r` autoload probe for `Request::boolean()` crashed with exit `-1073741819`** on this machine and was not retried; the absence-of-key behaviour is taken from the framework source and the static form markup.
- **`fund/index.blade.php` was not rendered** (it is dead, FUND-15); it was inspected as a file only.
- **Line numbers** come from the commands quoted in each finding, run on 2026-10-24 against the working tree.
