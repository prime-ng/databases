# Fix Plan — Accounting / AssetDisposalController

**For:** gaurav · **From:** 2026-10-23 audit · **Companion:** `01-report.md`
**Phase:** FIX PLAN ONLY — no application code was changed. Apply items in the order below.

## 0. Before you start

| | |
|---|---|
| App root | `C:\laragon\www\PG\prime_ai` |
| Files touched | `AssetDisposalController.php`, `AssetDisposalService.php`, `AssetDisposalRequest.php`, **new** `AssetDisposalPreviewRequest.php`, `routes/web.php`, `AssetDisposal.php` (Pint only) |
| Untouched | `show.blade.php`, the dashboard listing partial, migrations, permissions |
| Decisions needed | **None** — every item is mechanical except the two ⚠ UNVERIFIED policy notes in report §8 (`FinancialYear` fallback, `approved_by` self-approval) |
| Rulebook | `.claude/rules/final-audit.md`, `final-audit-reports/_tools/00-RULEBOOK.md` |
| Do not | run tests (D4); run `scan.php`; edit `00-CLASS-OWNERS.md` or `00-INDEX.md` |

**Suggested order:** §1 (blockers) → §3 → §4 → §5 → §6 → §8. §2 is empty.

## 1. Blockers / essentials (🔴 B)

### ASDI-01 · ERR-01 — remove the catch that leaks exception text

**File:** `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php` · **Method:** `store`
**Find:** `try {` at line 32 and the `catch (\Throwable $e) { ... }` block at lines 44-47.
**After:** delete the `try` wrapper and the whole catch. The call stays direct; `DB::transaction()` in the service rolls back and rethrows, and the central handler reports it. ASDI-02 closes with the same edit.

```php
    public function store(AssetDisposalRequest $request)
    {
        Gate::authorize('tenant.accounting.fixed-asset.update');

        $validated = $request->validated();
        $asset = FixedAsset::findOrFail($validated['fixed_asset_id']);

        $disposal = $this->service->dispose($asset, $validated);

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-disposals'])
            ->with('success', "Asset [{$asset->asset_code}] disposed successfully. Voucher posted.");
    }
```

**Why:** ERR-01 (no exception text to the user), ERR-02 (404/409 must not become a redirect), D1 (no `try/catch` in controllers).

**Verify:** dispose a valid asset → success flash; submit with an id that does not exist → real 404; dispose the same asset twice → rendered 409/422, no raw SQL in the page.

---

### ASDI-04 · AUTH-01 — authorize and validate the preview endpoint

**New file:** `Modules/Accounting/app/Http/Requests/AssetDisposalPreviewRequest.php`

```php
<?php

declare(strict_types=1);

namespace Modules\Accounting\Http\Requests;

use App\Traits\AuthorizesTenantFeature;
use Illuminate\Foundation\Http\FormRequest;

class AssetDisposalPreviewRequest extends FormRequest
{
    use AuthorizesTenantFeature;

    public function authorize(): bool
    {
        return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset', 'view');
    }

    public function rules(): array
    {
        return [
            'fixed_asset_id' => 'required|integer|exists:acc_fixed_assets,id',
            'sale_proceeds'  => 'nullable|numeric|min:0',
            'disposal_cost'  => 'nullable|numeric|min:0',
        ];
    }

    public function attributes(): array
    {
        return [
            'fixed_asset_id' => 'Fixed Asset',
            'sale_proceeds'  => 'Sale Proceeds',
            'disposal_cost'  => 'Disposal Cost',
        ];
    }
}
```

**Controller:** replace the `Request $request` signature and the three cast lines.

```php
    public function preview(AssetDisposalPreviewRequest $request)
    {
        $validated = $request->validated();
        $saleProceeds = (float) ($validated['sale_proceeds'] ?? 0);
        $disposalCost = (float) ($validated['disposal_cost'] ?? 0);

        $asset = FixedAsset::with(['assetCategory', 'depreciationEntries'])->find($validated['fixed_asset_id']);
        if (! $asset) {
            return response()->json(['success' => false, 'message' => 'Asset not found.'], 404);
        }
```

Add `use Modules\Accounting\Http\Requests\AssetDisposalPreviewRequest;` and remove the now-unused `use Illuminate\Http\Request;` (only `preview` used it). Everything from line 61 onward stays; ASDI-09 and ASDI-11 edit it later.
**Why:** AUTH-01 (no unauthenticated read of cost/NBV), VAL-05 (typed input; closes ASDI-07).
**Verify:** as a user without `tenant.accounting.fixed-asset.view`, `POST /accounting/asset-disposal/preview` → 403; as an allowed user with `fixed_asset_id=[1]` → 422; valid request → 200 with the same figures as before.

---

### ASDI-08 · RTE-02 — stop registering methods that do not exist

**File:** `Modules/Accounting/routes/web.php` · **Line:** 287 · ⚠ SHARED (route file)
**Find:** `Route::resource('asset-disposal', \Modules\Accounting\Http\Controllers\AssetDisposalController::class);`
**After:**

```php
Route::resource('asset-disposal', \Modules\Accounting\Http\Controllers\AssetDisposalController::class)
    ->only(['index', 'store', 'show']);
```

**Why:** RTE-02 — `create/edit/update/destroy` have no controller method; disposals are immutable in the UI.
**Verify:** `php artisan route:list --name=asset-disposal` shows 5 routes (index, store, preview, show + the `assetsIntegration` redirect is a different name); `GET /accounting/asset-disposal/create` → 404, not 500.

## 2. High (🟠 H)

None of its own. ASDI-02 is closed by ASDI-01; ASDI-06 is in §5 and ASDI-09 in §5 because it shares the service with ASDI-03.

## 3. Transactions and audit (🟡 M)

### ASDI-03 · TXN-04 — move the audit row inside the disposal transaction

**File:** `Modules/Accounting/app/Services/AssetDisposalService.php` · **Method:** `dispose` · **Find:** `return $disposal;` at line 181, after the `$asset->update([...])` block.
**After:** insert the log before the return, still inside `DB::transaction`.

```php
            $asset->update([
                'status'     => $newStatus,
                'updated_by' => auth()->id(),
            ]);

            activityLog($disposal, 'Disposed', [
                'message'          => 'Fixed Asset disposed.',
                'asset_code'       => $asset->asset_code,
                'disposal_type'    => $disposal->disposal_type,
                'gain_loss_amount' => $disposal->gain_loss_amount,
            ]);

            return $disposal;
```

**Controller:** the `activityLog(...)` block is gone with ASDI-01; since `$disposal` is then unused in `store`, change line 33 to `$this->service->dispose($asset, $validated);` (drop the assignment).

**Why:** TXN-04 — the audit row must commit or roll back with the disposal it describes.
**Verify:** after a disposal, `sys_activity_logs` has exactly one `Disposed` row whose `subject_id` is the new disposal id; force the log insert to fail (temporarily) and confirm the asset is still Active and no voucher exists.

## 4. Authorization (🟡 M)

### ASDI-05 · AUTH-04 — check `update`, not `create`, for a disposal

**File:** `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php` · **Line:** 16
**Find:** `return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset');`
**After:**

```php
        return $this->authorizeByCrudPermission('tenant.accounting.fixed-asset', 'update');
```

**Controller:** delete `Gate::authorize('tenant.accounting.fixed-asset.update');` from `store()` (line 27) — the request now owns the check.

```php
    public function store(AssetDisposalRequest $request)
    {
        $validated = $request->validated();
        $asset = FixedAsset::findOrFail($validated['fixed_asset_id']);

        $this->service->dispose($asset, $validated);

        return redirect()->route('accounting.menu.assetsIntegration', ['tab' => 'asset-disposals'])
            ->with('success', "Asset [{$asset->asset_code}] disposed successfully. Voucher posted.");
    }
```

**Why:** AUTH-04 — one action, one gate; disposing an existing asset is an update, and a role with `update` but not `create` must not be blocked.
**Verify:** with a test role holding only `tenant.accounting.fixed-asset.update`, the Dispose button shows and submission succeeds; a role with only `.create` is refused; `store` no longer calls `Gate::authorize`.

## 5. Validation and business rules (🟡 M / 🟠 H)

### ASDI-06 · VAL-07 — require a settlement account when money moves

**File:** `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php` · add after `rules()`
**After:**

```php
    public function after(): array
    {
        return [
            function (Validator $validator) {
                $proceeds = (float) $this->input('sale_proceeds', 0);
                $cost = (float) $this->input('disposal_cost', 0);

                if (($proceeds > 0 || $cost > 0) && ! $this->input('buyer_ledger_id')) {
                    $validator->errors()->add(
                        'buyer_ledger_id',
                        'Select a Buyer / Settlement Account when sale proceeds or disposal cost is entered.'
                    );
                }
            },
        ];
    }
```

Add `use Illuminate\Validation\Validator;`.
**Why:** VAL-07 — without the ledger the service omits the proceeds/cost line and `VoucherService` throws on the imbalance.
**Verify:** Sale + proceeds `500` + no settlement account → 422 on `buyer_ledger_id`, no voucher, asset still Active; with the account → succeeds. Same for disposal cost only.

---

### ASDI-09 · CTL-06 — one gain/loss calculation

**File:** `Modules/Accounting/app/Services/AssetDisposalService.php` · **New method** (place after `dispose()`, before `resolveGainLossLedger()`):

```php
    /**
     * @return array{cost_at_disposal: float, accumulated_depreciation: float, net_book_value: float, gain_loss_amount: float}
     */
    public function calculateFigures(FixedAsset $asset, float $saleProceeds = 0.0, float $disposalCost = 0.0): array
    {
        $cost = (float) $asset->purchase_cost;
        $accum = (float) $asset->accumulated_depreciation;
        $netBookValue = max(0.0, round($cost - $accum, 2));

        return [
            'cost_at_disposal'         => $cost,
            'accumulated_depreciation' => $accum,
            'net_book_value'           => $netBookValue,
            'gain_loss_amount'         => round($saleProceeds - $disposalCost - $netBookValue, 2),
        ];
    }
```

**Service `dispose()`:** replace lines 38-43 with:

```php
        $figures = $this->calculateFigures($asset, $saleProceeds, $disposalCost);
        $costAtDisposal = $figures['cost_at_disposal'];
        $accumDep = $figures['accumulated_depreciation'];
        $netBookValue = $figures['net_book_value'];
        $gainLoss = $figures['gain_loss_amount'];
```

**Controller `preview()`:** replace lines 61-64 with `$figures = $this->service->calculateFigures($asset, $saleProceeds, $disposalCost);` and return the four `$figures[...]` values where `$cost`, `$accum`, `$nbv`, `$gainLoss` are used now.

**Why:** CTL-06 — preview and posted voucher must use one formula.
**Verify:** preview an asset with known cost/accum and confirm the JSON equals the disposal row's `cost_at_disposal`, `accumulated_depreciation`, `net_book_value`, `gain_loss_amount` after submission.

## 6. Queries and performance (🟡 M)

### ASDI-11 · QRY-03 — drop the unused eager load

**File:** `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php` · **Line:** 56 (after ASDI-04 it reads `->find($validated['fixed_asset_id'])`)
**After:**

```php
        $asset = FixedAsset::find($validated['fixed_asset_id']);
```

**Why:** QRY-03 — `assetCategory` and `depreciationEntries` are never read in `preview()`; `accumulated_depreciation` is an accessor that runs its own `sum()`.
**Verify:** preview request still returns the same numbers; with query logging, the request runs one asset query plus the accessor's aggregate, and no category/depreciation-entry query.

## 7. Models (none)

No model change is required. ASDI-15's unused import is removed by Pint in §8.

## 8. Low and style (🟢 L)

### ASDI-10 · CTL-04 — add return types

**File:** `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php`
**Imports:** add `use Illuminate\Http\JsonResponse;`, `use Illuminate\Http\RedirectResponse;`, `use Illuminate\View\View;` (and remove the unused `Illuminate\Http\Request` per ASDI-04).
**After:**

```php
    public function index(): RedirectResponse
    public function store(AssetDisposalRequest $request): RedirectResponse
    public function preview(AssetDisposalPreviewRequest $request): JsonResponse
    public function show(AssetDisposal $assetDisposal): View
```

**Verify:** `php -l` passes; each action returns its declared type.

---

### ASDI-12 · STY-02 — Pint the controller

**File:** `Modules/Accounting/app/Http/Controllers/AssetDisposalController.php`
**After:** run `vendor\bin\pint Modules\Accounting\app\Http\Controllers\AssetDisposalController.php --format agent`
Resolves `fully_qualified_strict_types`, `single_import_per_statement`, `concat_space`, `unary_operator_spaces`, `braces_position`, `no_unused_imports`, `not_operator_with_successor_space`, `single_line_empty_body`, `blank_line_before_statement`, `ordered_imports`, `binary_operator_spaces`.

### ASDI-13 · STY-02 — Pint the service

**File:** `Modules/Accounting/app/Services/AssetDisposalService.php`
**After:** run `vendor\bin\pint Modules\Accounting\app\Services\AssetDisposalService.php --format agent`
Resolves `single_space_around_construct`, `single_import_per_statement`, `method_chaining_indentation`, `unary_operator_spaces`, `braces_position`, `not_operator_with_successor_space`, `single_line_empty_body`, `binary_operator_spaces`.

### ASDI-14 · STY-02 — Pint the request

**File:** `Modules/Accounting/app/Http/Requests/AssetDisposalRequest.php`
**After:** run `vendor\bin\pint Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php --format agent`
Resolves `ordered_imports`, `binary_operator_spaces`.

### ASDI-15 · STY-02 — Pint the model (removes the unused import)

**File:** `Modules/Accounting/app/Models/AssetDisposal.php`
**After:** run `vendor\bin\pint Modules\Accounting\app\Models\AssetDisposal.php --format agent`
Resolves `fully_qualified_strict_types`, `no_unused_imports` (drops `use App\Models\BaseModel;`), `single_line_after_imports`, `binary_operator_spaces`.

**Verify (all four):** `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\AssetDisposalController.php Modules\Accounting\app\Services\AssetDisposalService.php Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php Modules\Accounting\app\Models\AssetDisposal.php --format agent` returns `pass`.

## 9. Deferred / decisions

**None.** The two ⚠ UNVERIFIED items in report §8 are policy questions, not code defects:

| Item | Question for the product/accounting owner | If the answer is "no fallback / no self-approval" |
|---|---|---|
| `AssetDisposalService.php:59-63` | Is disposing in a date outside every active financial year allowed by falling back to the latest year? | Reject the disposal instead of falling back; becomes a new finding. |
| `AssetDisposalService.php:162-163` | Is an approval step required for BR-FA-05? | Stop stamping `approved_by`/`approved_at` at creation; becomes a new finding. |

## 10. Not fixed here

- **ASDI-02** has no separate edit: it is closed by the ASDI-01 catch removal (the 404 from `findOrFail` and the service's `DomainException` then surface with their real status).
- **Dashboard listing** (`_asset-disposals.blade.php`, `AccDashboardController::assetsIntegration()`): owned by `gaurav/Accounting/AccDashboardController`; the unbounded dropdown (QRY-15) and the `.dashboard.view` page gate (AUTH-06) are recorded in report §7.
- **`BaseAccountingModel` / `AccountingContext`** hard-coded user 1: owned by other reports (§7).
- **`VoucherService`** internals: owned by `VoucherController`, not yet audited.

## 11. Verification (no tests — D4)

```powershell
# 1. Syntax
php -l Modules\Accounting\app\Http\Controllers\AssetDisposalController.php
php -l Modules\Accounting\app\Services\AssetDisposalService.php
php -l Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php
php -l Modules\Accounting\app\Http\Requests\AssetDisposalPreviewRequest.php
php -l Modules\Accounting\app\Models\AssetDisposal.php

# 2. Routes — expect 5 with the asset-disposal prefix
php artisan route:list --name=asset-disposal

# 3. Style
vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\AssetDisposalController.php Modules\Accounting\app\Services\AssetDisposalService.php Modules\Accounting\app\Http\Requests\AssetDisposalRequest.php Modules\Accounting\app\Models\AssetDisposal.php --format agent
```

**DB check (tenant `xyz_school_00000000000040008000_202627`):**

```sql
-- Every disposal has its voucher
SELECT COUNT(*) AS disposals_without_voucher
FROM acc_asset_disposals d LEFT JOIN acc_vouchers v ON v.id = d.voucher_id
WHERE v.id IS NULL;

-- Every disposal has exactly one audit row
SELECT COUNT(*) AS disposals_without_audit
FROM acc_asset_disposals d
LEFT JOIN sys_activity_logs a
       ON a.subject_type = 'Modules\\Accounting\\Models\\AssetDisposal' AND a.subject_id = d.id
WHERE a.id IS NULL;

-- No unbalanced voucher was created by a disposal run
SELECT v.id, SUM(CASE WHEN i.entry_type='Dr' THEN i.amount ELSE -i.amount END) AS diff
FROM acc_vouchers v JOIN acc_voucher_items i ON i.voucher_id = v.id
GROUP BY v.id HAVING diff <> 0;
```

**Manual:** dispose one asset end-to-end (modal preview → submit → show page → voucher in Accounting), then repeat the ASDI-04 403 check with a permission-less user.
