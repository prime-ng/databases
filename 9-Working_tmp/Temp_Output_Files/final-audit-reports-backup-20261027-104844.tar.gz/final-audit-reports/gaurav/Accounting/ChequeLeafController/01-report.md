# Final Audit — Accounting / ChequeLeafController

**Audited:** 2026-10-24 · **By:** opencode · **Developer folder:** gaurav
**Controller:** `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php` (237 lines, 11 public methods)
**Rulebook:** `final-audit-reports/_tools/00-RULEBOOK.md` · **Protocol:** `.claude/rules/final-audit.md`
**Phase:** AUDIT. Read-only: no application code was changed to produce this report.

## 0. The screen in plain words

| | |
|---|---|
| URL(s) | `http://test.localhost:8000/accounting/cheque-leaf` (redirects to the tab); `http://test.localhost:8000/accounting/cheque-leaf/create` (500 today); `http://test.localhost:8000/accounting/cheque-leaf/{id}`; `http://test.localhost:8000/accounting/cheque-leaf/{id}/edit`; `http://test.localhost:8000/accounting/cheque-leaf/{id}/restore`; `http://test.localhost:8000/accounting/cheque-leaf/trash/view`; `http://test.localhost:8000/accounting/cheque-leaf/{id}/force-delete`; `http://test.localhost:8000/accounting/cheque-leaf/{cheque_leaf}/change-status` |
| Menu path | Finance → Accounting → Cheques & Reconciliation → Cheque Leaves tab (`glb_menus` id 91, route `accounting.menu.chequesReconciliation`) |
| Who uses it | Roles holding `tenant.accounting.cheque-leaf.create` in the live tenant: Super Admin, School Admin, Management, Account Staff, Account Manager |
| What a user does here | The Cheque Leaves tab lists the numbered leaves that belong to each cheque book. A user adds a single leaf (normally leaves are auto-generated when a cheque book is created), changes a leaf's status (Unused, Issued, Cancelled, Spoiled, Lost), opens a leaf's detail page, and restores or permanently deletes leaves from the trash page. |
| Tables written | `acc_cheque_leaves`, `sys_activity_logs` |
| Tables read | `acc_cheque_leaves`, `acc_cheque_registers`, `acc_ledgers`, `acc_vouchers` (directly and through the linked voucher), `sys_activity_logs` |
| Live data | Tenant `xyz_school_00000000000040008000_202627`: `acc_cheque_leaves` 45 live, 0 trashed; `acc_cheque_registers` 2; leaf id 1 has `voucher_id` 7 |

**How to reach each bug in the browser:** listed per finding under **Reproduce**.

## 1. Verdict

Not production-ready. The single worst finding is CHQF-01: all six mutating methods catch `\Throwable` and put `$e->getMessage()` in the flash, so any database error (including the duplicate leaf that the missing unique rule makes easy to trigger) shows raw SQL to the user. CHQF-15 (a routed page that renders a Blade file which does not exist) and CHQF-18 (a permanent delete that can orphan a voucher reference) are the other two that need a decision before go-live. The rest is mechanical: one controller rewrite, one FormRequest rewrite, one route verb, and a Pint pass, roughly half a day (M).

## 2. Counts

| B | H | M | L | DECISION | Total |
|---|---|---|---|---|---|
| 1 | 5 | 6 | 7 | 3 | 19 |

| Family | Findings | Family | Findings |
|---|---|---|---|
| F1 Errors | CHQF-01, CHQF-02, CHQF-03 | F8 Services/Jobs | clean |
| F2 Transactions/Audit | CHQF-04 | F9 Queries/Perf | CHQF-13, CHQF-14 |
| F3 Authorization | CHQF-05, CHQF-06 | F10 Views | CHQF-15, CHQF-16 |
| F4 Validation | CHQF-07, CHQF-08 | F11 Security/Tenancy | clean |
| F5 Routes | CHQF-10 | F12 Style | CHQF-17 |
| F6 Controller shape | CHQF-11, CHQF-12 | F13 Deep read | CHQF-18, CHQF-19 |
| F7 Models | CHQF-09 | | |

## 3. Scope - every file this controller uses

| # | File | Kind | Lines | Owner | Audited |
|---|---|---|---|---|---|
| 1 | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php` | controller | 237 | this report | ✅ |
| 2 | `Modules/Accounting/app/Models/ChequeLeaf.php` | model | 44 | this report (pre-assigned) | ✅ |
| 3 | `Modules/Accounting/app/Http/Requests/ChequeLeafRequest.php` | form request | 36 | this report (pre-assigned) | ✅ |
| 4 | `Modules/Accounting/app/Policies/ChequeLeafPolicy.php` | policy | 21 | unclaimed (no claim line written; registry edits were forbidden by the brief) | ✅ |
| 5 | `Modules/Accounting/resources/views/cheque-leaf/show.blade.php` | view | 118 | this report | ✅ |
| 6 | `Modules/Accounting/resources/views/cheque-leaf/edit.blade.php` | view | 84 | this report | ✅ |
| 7 | `Modules/Accounting/resources/views/cheque-leaf/trash.blade.php` | view | 71 | this report | ✅ |
| 8 | `Modules/Accounting/app/Models/ChequeRegister.php` | model | 79 | ↗ [gaurav/Accounting/ChequeRegisterController](../ChequeRegisterController/01-report.md) | ↗ linked |
| 9 | `Modules/Accounting/app/Models/Ledger.php` | model | 408 | ↗ [gaurav/Accounting/LedgerController](../LedgerController/01-report.md) (report not written yet) | ↗ linked |
| 10 | `Modules/Accounting/app/Models/Voucher.php` | model | 415 | ↗ [gaurav/Accounting/VoucherController](../VoucherController/01-report.md) (report not written yet) | ↗ linked |
| 11 | `Modules/Accounting/app/Models/BaseAccountingModel.php` | base model | 74 | ↗ [gaurav/Accounting/AccountingStatusMasterController](../AccountingStatusMasterController/01-report.md) | ↗ linked |
| 12 | `Modules/Accounting/app/Services/AccountingContext.php` | service | 110 | ↗ [gaurav/Accounting/AccountGroupController](../AccountGroupController/01-report.md) | ↗ linked |
| 13 | `Modules/GlobalMaster/app/Models/ActivityLog.php` | model | 50 | ↗ [gaurav/Accounting/CostCategoryController](../CostCategoryController/01-report.md) | ↗ linked |
| 14 | `Modules/Accounting/resources/views/cheque-leaf/create.blade.php` | view | 0 | does not exist — see CHQF-15 | ❌ missing |
| 15 | `Modules/Accounting/routes/web.php` | routes | 536 | shared route file (not audited here) | ↗ linked |

No pre-applied files in a module `PRE-APPLIED-*.md`.

## 4. Routes

```
GET|HEAD  accounting/cheque-leaf                                  accounting.cheque-leaf.index        Modules\Accounting\Http\Controllers\ChequeLeafController@index  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cheque-leaf                                  accounting.cheque-leaf.store        Modules\Accounting\Http\Controllers\ChequeLeafController@store  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-leaf/create                           accounting.cheque-leaf.create       Modules\Accounting\Http\Controllers\ChequeLeafController@create  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-leaf/trash/view                       accounting.cheque-leaf.trashed      Modules\Accounting\Http\Controllers\ChequeLeafController@trashed  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-leaf/{cheque_leaf}                    accounting.cheque-leaf.show         Modules\Accounting\Http\Controllers\ChequeLeafController@show  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
PUT|PATCH accounting/cheque-leaf/{cheque_leaf}                    accounting.cheque-leaf.update       Modules\Accounting\Http\Controllers\ChequeLeafController@update  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cheque-leaf/{cheque_leaf}                    accounting.cheque-leaf.destroy      Modules\Accounting\Http\Controllers\ChequeLeafController@destroy  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
POST      accounting/cheque-leaf/{cheque_leaf}/change-status      accounting.cheque-leaf.changeStatus Modules\Accounting\Http\Controllers\ChequeLeafController@changeStatus  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-leaf/{cheque_leaf}/edit               accounting.cheque-leaf.edit         Modules\Accounting\Http\Controllers\ChequeLeafController@edit  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
DELETE    accounting/cheque-leaf/{id}/force-delete                accounting.cheque-leaf.forceDelete  Modules\Accounting\Http\Controllers\ChequeLeafController@forceDelete  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
GET|HEAD  accounting/cheque-leaf/{id}/restore                     accounting.cheque-leaf.restore      Modules\Accounting\Http\Controllers\ChequeLeafController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
```

Unrouted public methods: none (all 11 public methods appear above). Route order is correct: the custom `trash/view`, `{id}/restore`, `{id}/force-delete` and `{cheque_leaf}/change-status` routes are registered at `Modules/Accounting/routes/web.php:145-148`, before `Route::resource` at line 149.

## 5. Per-method table

| Method | Line | Routed (verb uri) | Gate (exact string) | Tx (where) | activityLog (event) | Writes tables | Findings |
|---|---|---|---|---|---|---|---|
| `index` | 19 | GET /accounting/cheque-leaf | `tenant.accounting.cheque-leaf.viewAny` | none | none | none | CHQF-11 |
| `create` | 26 | GET /accounting/cheque-leaf/create | `tenant.accounting.cheque-leaf.create` | none | none | none | CHQF-15, CHQF-11 |
| `store` | 36 | POST /accounting/cheque-leaf | `tenant.accounting.cheque-leaf.create` (FormRequest + controller) | controller, manual | `Created` | `acc_cheque_leaves`, `sys_activity_logs` | CHQF-01, CHQF-03, CHQF-04, CHQF-06, CHQF-07 |
| `show` | 64 | GET /accounting/cheque-leaf/{cheque_leaf} | `tenant.accounting.cheque-leaf.view` | none | none | none | CHQF-11, CHQF-16 |
| `edit` | 73 | GET /accounting/cheque-leaf/{cheque_leaf}/edit | `tenant.accounting.cheque-leaf.update` | none | none | none | CHQF-13, CHQF-11 |
| `update` | 84 | PUT/PATCH /accounting/cheque-leaf/{cheque_leaf} | `tenant.accounting.cheque-leaf.update` (FormRequest + controller) | controller, manual | `Updated` | `acc_cheque_leaves`, `sys_activity_logs` | CHQF-01, CHQF-03, CHQF-04, CHQF-06, CHQF-07 |
| `destroy` | 112 | DELETE /accounting/cheque-leaf/{cheque_leaf} | `tenant.accounting.cheque-leaf.delete` | controller, manual | `Deleted` | `acc_cheque_leaves`, `sys_activity_logs` | CHQF-01, CHQF-03, CHQF-04 |
| `changeStatus` | 139 | POST /accounting/cheque-leaf/{cheque_leaf}/change-status | `tenant.accounting.cheque-leaf.update` | controller, manual | `StatusChanged` | `acc_cheque_leaves`, `sys_activity_logs` | CHQF-01, CHQF-03, CHQF-04, CHQF-08 |
| `trashed` | 175 | GET /accounting/cheque-leaf/trash/view | `tenant.accounting.cheque-leaf.restore` | none | none | none | CHQF-14 |
| `restore` | 184 | GET /accounting/cheque-leaf/{id}/restore | `tenant.accounting.cheque-leaf.restore` | controller, manual | `Restored` | `acc_cheque_leaves`, `sys_activity_logs` | CHQF-01, CHQF-02, CHQF-03, CHQF-04, CHQF-10 |
| `forceDelete` | 210 | DELETE /accounting/cheque-leaf/{id}/force-delete | `tenant.accounting.cheque-leaf.forceDelete` | controller, manual | `Deleted` | `acc_cheque_leaves`, `sys_activity_logs` | CHQF-01, CHQF-02, CHQF-03, CHQF-04, CHQF-18, CHQF-19 |

## 6. Findings

### F1 — Errors

#### CHQF-01 · B · ERR-01 — Raw exception text is shown to the user in all six mutating methods

| Field | Value |
|---|---|
| **Rule** | ERR-01 (B) — never send exception text to the user; SQL, table and column names leak |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:56-61, 104-109, 131-136, 167-172, 202-207, 229-234`; methods `store()`, `update()`, `destroy()`, `changeStatus()`, `restore()`, `forceDelete()` |
| **Root cause** | Each mutation wraps the write in `catch (\Throwable $e)` and interpolates `$e->getMessage()` into a flash message. The generic catch converts every database exception, including the duplicate-leaf error that CHQF-07 makes easy to trigger, into a user-visible SQL message. |
| **Consequence** | A user who submits a leaf that already exists sees `SQLSTATE[23000]` plus the table and column names instead of "this leaf already exists". |
| **Reproduce** | Open the Cheque Leaves tab, click Add, pick a bank ledger and a leaf number that already exists (registers auto-generate leaves, so most numbers exist), submit. Expected a validation message; actual a red flash containing SQL. |
| **Fix approach** | Remove the hand-rolled try/catch (D1). Let the central handler log and render. Add the unique rule (CHQF-07) so the common case is a 422, not an exception. |
| **Plan item** | CHQF-01 in `02-fix-plan.md` §1 (five methods); `changeStatus()` is CHQF-08 in §5 |

```php
// ChequeLeafController.php:56-61 — CURRENT (store; the other five differ only in text)
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create Cheque Leaf', ['error' => $e->getMessage()]);

            return back()->withInput()->with('error', 'Failed to create Cheque Leaf: ' . $e->getMessage());
        }
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "getMessage" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
58:             Log::error('Failed to create Cheque Leaf', ['error' => $e->getMessage()]);
60:             return back()->withInput()->with('error', 'Failed to create Cheque Leaf: ' . $e->getMessage());
106:             Log::error('Failed to update Cheque Leaf', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);
108:             return back()->withInput()->with('error', 'Failed to update Cheque Leaf: ' . $e->getMessage());
133:             Log::error('Failed to delete Cheque Leaf', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);
135:             return back()->with('error', 'Failed to delete Cheque Leaf: ' . $e->getMessage());
169:             Log::error('Failed to change Cheque Leaf status', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);
171:             return back()->with('error', 'Failed to update status: ' . $e->getMessage());
204:             Log::error('Failed to restore Cheque Leaf', ['id' => $id, 'error' => $e->getMessage()]);
206:             return back()->with('error', 'Failed to restore Cheque Leaf: ' . $e->getMessage());
231:             Log::error('Failed to force delete Cheque Leaf', ['id' => $id, 'error' => $e->getMessage()]);
233:             return back()->with('error', 'Failed to delete Cheque Leaf: ' . $e->getMessage());
```

#### CHQF-02 · H · ERR-02 — A missing leaf becomes a redirect with a red flash instead of a 404

| Field | Value |
|---|---|
| **Rule** | ERR-02 (H) — a catch must never turn a 404/403/422/`abort()` into a redirect or 500 |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:188-208` (`restore()`), `214-235` (`forceDelete()`); `findOrFail` at lines 190 and 216 |
| **Root cause** | `findOrFail()` sits inside the `try`. `ModelNotFoundException` is a `Throwable`, so the generic catch turns the intended 404 into a 302 back with a red "Failed to restore/delete" flash. |
| **Consequence** | A user who opens a restore/force-delete link for an id that is not in the trash stays on the page and cannot tell "already restored" from "server error". |
| **Reproduce** | As an account role open `http://test.localhost:8000/accounting/cheque-leaf/999999/restore`. Expected 404; actual redirect with a red flash. |
| **Fix approach** | Load with `findOrFail()` before `DB::transaction` and outside any catch (CHQF-01 does this). |
| **Plan item** | CHQF-01 in `02-fix-plan.md` §1 |

```php
// ChequeLeafController.php:188-200 — CURRENT
        DB::beginTransaction();
        try {
            $model = ChequeLeaf::onlyTrashed()->findOrFail($id);
            $model->restore();

            activityLog($model, 'Restored', [
                'message'      => 'Cheque Leaf restored: ' . $model->leaf_no,
                'leaf_no'      => $model->leaf_no,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "findOrFail|onlyTrashed|withTrashed" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
190:             $model = ChequeLeaf::onlyTrashed()->findOrFail($id);
216:             $model = ChequeLeaf::withTrashed()->findOrFail($id);
```

#### CHQF-03 · M · ERR-05 — The log stores only the message, not the exception

| Field | Value |
|---|---|
| **Rule** | ERR-05 (M) — log the exception, not the message; `getMessage()` alone loses the trace |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:58, 106, 133, 169, 204, 231` |
| **Root cause** | `Log::error('Failed to create Cheque Leaf', ['error' => $e->getMessage()])` records a string. The class, stack trace and previous exceptions are discarded. |
| **Consequence** | A production failure cannot be traced to the failing statement from the log, which slows every incident. |
| **Reproduce** | Static only — the log content is not visible in the browser. |
| **Fix approach** | Delete the six `Log::error` calls. `report($e)` in the central handler already logs the exception object with its trace (D1). |
| **Plan item** | CHQF-01 in `02-fix-plan.md` §1 (same rewrite); `changeStatus()` is CHQF-08 in §5 |

```php
// ChequeLeafController.php:58 — CURRENT
            Log::error('Failed to create Cheque Leaf', ['error' => $e->getMessage()]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "Log::error" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
58:             Log::error('Failed to create Cheque Leaf', ['error' => $e->getMessage()]);
106:             Log::error('Failed to update Cheque Leaf', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);
133:             Log::error('Failed to delete Cheque Leaf', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);
169:             Log::error('Failed to change Cheque Leaf status', ['id' => $chequeLeaf->id, 'error' => $e->getMessage()]);
204:             Log::error('Failed to restore Cheque Leaf', ['id' => $id, 'error' => $e->getMessage()]);
231:             Log::error('Failed to force delete Cheque Leaf', ['id' => $id, 'error' => $e->getMessage()]);
```

### F2 — Transactions and audit

#### CHQF-04 · M · TXN-02 — Six mutations use the manual transaction API with a hand-rolled catch

| Field | Value |
|---|---|
| **Rule** | TXN-02 (M) — use `DB::transaction(fn () => …)`, not manual `beginTransaction`/`commit`/`rollBack`; D1 adds that a controller must have no try/catch |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:42-52, 90-100, 116-127, 148-163, 188-199, 214-226` |
| **Root cause** | Each of the six mutators opens a transaction by hand, commits inside a try, and rolls back in the catch. Any early return between begin and commit leaks an open transaction, and the catch is exactly the construct D1 forbids. |
| **Consequence** | A failure in one mutation can leave the connection inside a transaction for the rest of the request; the same write requires three statements instead of one closure. |
| **Reproduce** | Static only — the failure needs a database error during a save. |
| **Fix approach** | Wrap each write in `DB::transaction(function () { … })`. The closure commits on return and rolls back on throw. CHQF-01 rewrites five methods; CHQF-08 rewrites `changeStatus()`. |
| **Plan item** | CHQF-01 in §1 and CHQF-08 in §5 |

```php
// ChequeLeafController.php:42-52 — CURRENT (store)
        DB::beginTransaction();
        try {
            $leaf = ChequeLeaf::create($validated);

            activityLog($leaf, 'Created', [
                'message'      => 'Cheque Leaf created: ' . $leaf->leaf_no,
                'leaf_no'      => $leaf->leaf_no,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "beginTransaction|catch \(" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
42:         DB::beginTransaction();
56:         } catch (\Throwable $e) {
90:         DB::beginTransaction();
104:         } catch (\Throwable $e) {
116:         DB::beginTransaction();
131:         } catch (\Throwable $e) {
148:         DB::beginTransaction();
167:         } catch (\Throwable $e) {
188:         DB::beginTransaction();
202:         } catch (\Throwable $e) {
214:         DB::beginTransaction();
229:         } catch (\Throwable $e) {
```

### F3 — Authorization

#### CHQF-05 · M · AUTH-05 — The registered policy is never consulted and implements only two abilities

| Field | Value |
|---|---|
| **Rule** | AUTH-05 (M) — no dead permission logic; a policy nothing consults is dead logic |
| **Where** | `Modules/Accounting/app/Policies/ChequeLeafPolicy.php:1-21`; `Modules/Accounting/app/Providers/AccountingServiceProvider.php:169`; `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:21-212` |
| **Root cause** | `Gate::policy(ChequeLeaf::class, ChequeLeafPolicy::class)` registers the policy, but every controller check passes a permission string (`Gate::authorize('tenant.accounting.cheque-leaf.view')`) and no check passes the model (`Gate::authorize('view', $chequeLeaf)`). The policy also has only `viewAny` and `view`. |
| **Consequence** | A developer who writes `$this->authorize('update', $leaf)` gets a 403 for every user because the policy method does not exist, while the real enforcement silently lives in the Spatie permission gate. |
| **Reproduce** | Static only — no browser path calls the policy. |
| **Fix approach** | DECISION — leave the policy as redundant but harmless, or move all checks into the policy. See `02-fix-plan.md` §9. |
| **Plan item** | CHQF-05 in `02-fix-plan.md` §9 (DECISION) |

```php
// ChequeLeafPolicy.php:10-21 — CURRENT
class ChequeLeafPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('tenant.accounting.cheque-leaf.viewAny');
    }

    public function view(User $user, ChequeLeaf $chequeLeaf): bool
    {
        return $user->can('tenant.accounting.cheque-leaf.view');
    }
}
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Policies\ChequeLeafPolicy.php -Pattern "public function" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
12:     public function viewAny(User $user): bool
17:     public function view(User $user, ChequeLeaf $chequeLeaf): bool
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "Gate::authorize" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
21:         Gate::authorize('tenant.accounting.cheque-leaf.viewAny');
28:         Gate::authorize('tenant.accounting.cheque-leaf.create');
38:         Gate::authorize('tenant.accounting.cheque-leaf.create');
66:         Gate::authorize('tenant.accounting.cheque-leaf.view');
75:         Gate::authorize('tenant.accounting.cheque-leaf.update');
86:         Gate::authorize('tenant.accounting.cheque-leaf.update');
114:         Gate::authorize('tenant.accounting.cheque-leaf.delete');
141:         Gate::authorize('tenant.accounting.cheque-leaf.update');
177:         Gate::authorize('tenant.accounting.cheque-leaf.restore');
186:         Gate::authorize('tenant.accounting.cheque-leaf.restore');
212:         Gate::authorize('tenant.accounting.cheque-leaf.forceDelete');
```

#### CHQF-06 · L · AUTH-04 — store, update and changeStatus check the same permission twice

| Field | Value |
|---|---|
| **Rule** | AUTH-04 (L) — do not authorize the same permission twice (FormRequest `authorize()` + `Gate::authorize`); keep one |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:38, 86, 141`; `Modules/Accounting/app/Http/Requests/ChequeLeafRequest.php:12-19` |
| **Root cause** | The FormRequest's `authorize()` runs first and checks create or update, then the controller checks the identical permission again. |
| **Consequence** | Two places to change when the permission name changes; no user-visible effect today. |
| **Reproduce** | Static only — both checks allow the same roles. |
| **Fix approach** | Remove the controller `Gate::authorize` from `store()` and `update()`. Keep the FormRequest, which runs first. `changeStatus()` gets the same cleanup in CHQF-08. |
| **Plan item** | CHQF-06 in `02-fix-plan.md` §4 (changeStatus part in CHQF-08 §5) |

```php
// ChequeLeafController.php:36-40 — CURRENT (store)
    public function store(ChequeLeafRequest $request)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.create');

        $validated = $request->validated();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Requests\ChequeLeafRequest.php -Pattern "Gate::allows" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
15:             return Gate::allows('tenant.accounting.cheque-leaf.create');
18:         return Gate::allows('tenant.accounting.cheque-leaf.update');
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "Gate::authorize" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
38:         Gate::authorize('tenant.accounting.cheque-leaf.create');
86:         Gate::authorize('tenant.accounting.cheque-leaf.update');
141:         Gate::authorize('tenant.accounting.cheque-leaf.update');
```

### F4 — Validation and input

#### CHQF-07 · H · VAL-04 — The unique index has no matching validation rule

| Field | Value |
|---|---|
| **Rule** | VAL-04 (H) — uniqueness rules mirror the DB unique index, including soft-delete semantics |
| **Where** | `Modules/Accounting/app/Http/Requests/ChequeLeafRequest.php:21-35`; index `uq_acc_chqleaf` in `database/migrations/tenant/2026_09_16_100042_create_acc_cheque_leaves_table.php:33` |
| **Root cause** | The table has a unique index on `(bank_ledger_id, leaf_no)`, but `leaf_no` is only `required|integer|min:1`. `$leafId` is computed at line 23 and never used. A create with an existing pair, or an update that renames onto one, raises a duplicate-key `QueryException`. |
| **Consequence** | The duplicate key becomes a 500 after CHQF-01 removes the catch, and today becomes a red flash with raw SQL from the catch that CHQF-01 removes. Because the unique index includes soft-deleted rows, re-adding a previously deleted leaf also fails. The create modal makes this common: registers already auto-generate every leaf. |
| **Reproduce** | Add a leaf for bank ledger 4 with leaf number 1 (leaf id 1 already uses that pair in the live tenant). Expected a validation message; actual a SQL error. |
| **Fix approach** | Add `Rule::unique('acc_cheque_leaves', 'leaf_no')->where(bank_ledger_id)->ignore($leafId)`. The default unique query does not exclude trashed rows, so it matches the index. |
| **Plan item** | CHQF-07 in `02-fix-plan.md` §1 (apply before CHQF-01) |

```php
// ChequeLeafRequest.php:21-35 — CURRENT
    public function rules(): array
    {
        $leafId = $this->route('cheque_leaf') ? $this->route('cheque_leaf')->id : null;

        return [
            'cheque_register_id' => 'required|exists:acc_cheque_registers,id',
            'bank_ledger_id'     => 'required|exists:acc_ledgers,id',
            'leaf_no'            => 'required|integer|min:1',
            'status'             => 'required|in:Unused,Issued,Cancelled,Spoiled,Lost',
            'voucher_id'         => 'nullable|exists:acc_vouchers,id',
            'issued_date'        => 'nullable|date',
            'cancelled_reason'   => 'nullable|string|max:500',
            'is_active'          => 'nullable|boolean',
        ];
    }
```

**Evidence**
```
$ php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\fa-probe2.php
indexes=
PRIMARY|id|unique=1
uq_acc_chqleaf|bank_ledger_id|unique=1
uq_acc_chqleaf|leaf_no|unique=1
idx_acc_chqleaf_register|cheque_register_id|unique=0
idx_acc_chqleaf_register|status|unique=0
idx_acc_chqleaf_voucher|voucher_id|unique=0
idx_acc_chqleaf_status|status|unique=0
idx_acc_chqleaf_status|bank_ledger_id|unique=0
columns=id,cheque_register_id,bank_ledger_id,leaf_no,status,voucher_id,issued_date,cancelled_reason,created_at,updated_at,is_active,deleted_at
```

#### CHQF-08 · M · VAL-02 — changeStatus validates a two-field form inline

| Field | Value |
|---|---|
| **Rule** | VAL-02 (M) — validation lives in a FormRequest; inline `validate()` is allowed only for a one-field AJAX toggle |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:143-153` |
| **Root cause** | The status modal has two fields (`status`, `cancelled_reason`) but `changeStatus()` calls `$request->validate()` inline and then reads `$request->input()` instead of `validated()`. |
| **Consequence** | The status endpoint has a second, divergent validation surface; a rule added to `ChequeLeafRequest` will never apply here, and the controller reads unvalidated input. |
| **Reproduce** | Static only — both fields are validated today, so no wrong value can be submitted through the modal. |
| **Fix approach** | Add `ChequeLeafStatusRequest` (authorize = update; rules status and cancelled_reason) and inject it. |
| **Plan item** | CHQF-08 in `02-fix-plan.md` §5 |

```php
// ChequeLeafController.php:139-153 — CURRENT
    public function changeStatus(Request $request, ChequeLeaf $chequeLeaf)
    {
        Gate::authorize('tenant.accounting.cheque-leaf.update');

        $request->validate([
            'status'           => 'required|in:Unused,Issued,Cancelled,Spoiled,Lost',
            'cancelled_reason' => 'nullable|string|max:500',
        ]);

        DB::beginTransaction();
        try {
            $chequeLeaf->status = $request->input('status');
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "request->validate|->input\(" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
143:         $request->validate([
150:             $chequeLeaf->status = $request->input('status');
152:                 $chequeLeaf->cancelled_reason = $request->input('cancelled_reason');
```

### F5 — Routes

#### CHQF-10 · H · RTE-01 — Restore changes state over GET

| Field | Value |
|---|---|
| **Rule** | RTE-01 (H) — no state change over GET; GET has no CSRF protection and link prefetchers trigger it |
| **Where** | `Modules/Accounting/routes/web.php:146`; `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:184-208` |
| **Root cause** | `Route::get('/cheque-leaf/{id}/restore', …)` restores a soft-deleted leaf. The trash page's `x-backend.table.action-trashed` component reads the route verb and therefore emits a GET form. |
| **Consequence** | A reload, a crawler or a browser prefetch can restore a leaf with no user intent and no CSRF token. |
| **Reproduce** | Open `http://test.localhost:8000/accounting/cheque-leaf/trash/view`, click Restore on a deleted leaf; the URL bar shows `/accounting/cheque-leaf/{id}/restore` and the request is GET. |
| **Fix approach** | Register the route with `Route::delete`. The shared action component already emits POST plus `@method('DELETE')` when the route verb is DELETE, so no component edit is needed. |
| **Plan item** | CHQF-10 in `02-fix-plan.md` §1 (⚠ SHARED route file) |

```php
// routes/web.php:146 — CURRENT
Route::get('/cheque-leaf/{id}/restore', [ChequeLeafController::class, 'restore'])->name('cheque-leaf.restore');
```

**Evidence**
```
$ php artisan route:list --json | php routesprobe.php "Modules\Accounting\Http\Controllers\ChequeLeafController"
GET|HEAD  accounting/cheque-leaf/{id}/restore                     accounting.cheque-leaf.restore      Modules\Accounting\Http\Controllers\ChequeLeafController@restore  [web,Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains,Stancl\Tenancy\Middleware\InitializeTenancyByDomain,App\Http\Middleware\EnsureTenantIsActive,App\Http\Middleware\EnsureTenantHasModule:Accounting,Illuminate\Auth\Middleware\Authenticate,Illuminate\Auth\Middleware\EnsureEmailIsVerified]
$ Select-String -Path resources\views\components\backend\table\action-trashed.blade.php -Pattern "restoreMethod|@method"
19:     $restoreMethods = collect($restoreRoute?->methods() ?? ['GET'])->reject(fn ($method) => $method === 'HEAD')->values();
20:     $restoreMethod = strtoupper($restoreMethods->first() ?? 'GET');
30:           method="{{ $restoreMethod === 'GET' ? 'GET' : 'POST' }}"
35:                 @method($restoreMethod)
```

### F6 — Controller shape

#### CHQF-11 · L · CTL-04 — Six public methods have no return type

| Field | Value |
|---|---|
| **Rule** | CTL-04 (L) — return types on public methods |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:19, 36, 64, 73, 84, 112` |
| **Root cause** | `index()`, `store()`, `show()`, `edit()`, `update()` and `destroy()` declare no return type, while `trashed()`, `restore()` and `forceDelete()` do. |
| **Consequence** | Static analysis and the IDE cannot verify the response type; the file is inconsistent. |
| **Reproduce** | Static only. |
| **Fix approach** | Add FQCN return types; Pint normalizes them into imports. `create()` waits for CHQF-15 and `changeStatus()` gets its type in CHQF-08. |
| **Plan item** | Style item in `02-fix-plan.md` §8 |

```php
// ChequeLeafController.php:19 — CURRENT
    public function index()
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "public function" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
19:     public function index()
26:     public function create()
36:     public function store(ChequeLeafRequest $request)
64:     public function show(ChequeLeaf $chequeLeaf)
73:     public function edit(ChequeLeaf $chequeLeaf)
84:     public function update(ChequeLeafRequest $request, ChequeLeaf $chequeLeaf)
112:     public function destroy(ChequeLeaf $chequeLeaf)
139:     public function changeStatus(Request $request, ChequeLeaf $chequeLeaf)
175:     public function trashed(): \Illuminate\View\View
184:     public function restore($id): \Illuminate\Http\RedirectResponse
210:     public function forceDelete($id): \Illuminate\Http\RedirectResponse
```

#### CHQF-12 · L · CTL-03 — Restore and forceDelete use a raw id instead of route model binding

| Field | Value |
|---|---|
| **Rule** | CTL-03 (L) — route model binding, not `$id` + `findOrFail` |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:184, 190, 210, 216` |
| **Root cause** | The other resource methods bind `ChequeLeaf $chequeLeaf`; these two take `$id` and run their own query. |
| **Consequence** | The controller repeats the lookup and the route parameter is untyped. No user-visible effect. |
| **Reproduce** | Static only. |
| **Fix approach** | Deferred: implicit binding for a trashed row needs `->withTrashed()` on two route entries, which is a shared route change for no user-visible gain. |
| **Plan item** | none — see `02-fix-plan.md` §10 |

```php
// ChequeLeafController.php:190 — CURRENT
            $model = ChequeLeaf::onlyTrashed()->findOrFail($id);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "findOrFail" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
190:             $model = ChequeLeaf::onlyTrashed()->findOrFail($id);
216:             $model = ChequeLeaf::withTrashed()->findOrFail($id);
```

### F7 — Models

#### CHQF-09 · L · MDL-02 — `is_active` has no boolean cast and is validated but not fillable

| Field | Value |
|---|---|
| **Rule** | MDL-02 (L, lowered from M: no user-visible defect today) — `$casts` cover every boolean column |
| **Where** | `Modules/Accounting/app/Models/ChequeLeaf.php:25-28`; `Modules/Accounting/app/Http/Requests/ChequeLeafRequest.php:33`; column `is_active` from `database/migrations/tenant/2026_09_16_130001_add_soft_deletes_and_is_active_to_accounting_tables.php:53` |
| **Root cause** | `acc_cheque_leaves.is_active` is a boolean column, but the model has no `'is_active' => 'boolean'` cast and the model's `$fillable` does not include `is_active`, while the FormRequest validates it. The validated value is silently dropped. |
| **Consequence** | `is_active` reads as `0`/`1` instead of `true`/`false`, and a caller who posts `is_active=1` gets no error and no effect — a dead input field. |
| **Reproduce** | Static plus live read: `gettype($leaf->is_active)` returns `integer`. |
| **Fix approach** | Add the boolean cast; remove the dead `is_active` rule from the FormRequest (CHQF-07 does the request side). |
| **Plan item** | CHQF-07 (request rule) in §1 and CHQF-09 in `02-fix-plan.md` §5 (cast) |

```php
// ChequeLeaf.php:25-28 — CURRENT
    protected $casts = [
        'leaf_no'      => 'integer',
        'issued_date'  => 'date',
    ];
```

**Evidence**
```
$ php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\fa-probe5.php
leaf=1
register=1
bankLedger=4
voucher=7
is_active_type=integer
voucher_bank_details_with_leaf=0
```

### F8 — Services and jobs

Clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "Service|Job|dispatch|Queue|ShouldQueue"` → no output. The controller calls no service and dispatches no job.

### F9 — Queries and performance

#### CHQF-13 · M · QRY-01 — The edit page's cheque-book dropdown lazily loads each register's bank ledger

| Field | Value |
|---|---|
| **Rule** | QRY-01 (M, lowered from H: 2 registers live) — no queries inside loops (N+1) |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:78`; `Modules/Accounting/resources/views/cheque-leaf/edit.blade.php:32`; `create()` at line 30 if it survives CHQF-15 |
| **Root cause** | `ChequeRegister::orderBy('book_number')->get()` is not eager-loaded with `bankLedger`, and the Blade loops the registers and reads `$reg->bankLedger->name`. Each register is a separate query. |
| **Consequence** | The edit page runs 1 + N queries for the dropdown; it grows linearly with the book count and will become visible as the school buys more books. |
| **Reproduce** | Open `/accounting/cheque-leaf/1/edit` with query logging. The register options trigger one select per book. |
| **Fix approach** | Add `->with('bankLedger')` to the register query. |
| **Plan item** | CHQF-13 in `02-fix-plan.md` §6 |

```php
// ChequeLeafController.php:78 — CURRENT
        $registers   = ChequeRegister::orderBy('book_number')->get();
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "ChequeRegister::" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
30:         $registers   = ChequeRegister::where('status', 'Active')->orderBy('book_number')->get();
78:         $registers   = ChequeRegister::orderBy('book_number')->get();
$ Select-String -Path Modules\Accounting\resources\views\cheque-leaf\edit.blade.php -Pattern "bankLedger" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
32:                                                 Book #{{ $reg->book_number }} ({{ $reg->bankLedger->name ?? 'Bank' }})
```

#### CHQF-14 · L · QRY-02 — The trash list paginates at 15 and has no distinct page name

| Field | Value |
|---|---|
| **Rule** | QRY-02 (L, lowered from H: low-traffic trash screen) — lists paginate at 10, with a distinct `pageName` |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:179` |
| **Root cause** | `paginate(15)` uses the standard page size of 15 and the default `page` parameter. |
| **Consequence** | The trash page shows more rows than the UI standard and its page links can collide with another paginator rendered in the same request. |
| **Reproduce** | Open `/accounting/cheque-leaf/trash/view` with more than 15 deleted leaves; the page shows 15. |
| **Fix approach** | `paginate(10, ['*'], 'leaves_page')`. |
| **Plan item** | CHQF-14 in `02-fix-plan.md` §6 |

```php
// ChequeLeafController.php:179 — CURRENT
        $leaves = ChequeLeaf::onlyTrashed()->with(['chequeRegister', 'bankLedger'])->orderBy('leaf_no')->paginate(15);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "paginate" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
179:         $leaves = ChequeLeaf::onlyTrashed()->with(['chequeRegister', 'bankLedger'])->orderBy('leaf_no')->paginate(15);
```

### F10 — Views

#### CHQF-15 · H · VIEW-01 — The routed create page renders a Blade file that does not exist

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (H, lowered from B: no UI link points at the route; the tab uses the create modal) — every routed page must resolve to a real template |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:26-34`; missing `Modules/Accounting/resources/views/cheque-leaf/create.blade.php` |
| **Root cause** | `create()` returns `view('accounting::cheque-leaf.create', …)`, but that file does not exist. The real create UI is the `#createChequeLeafModal` in the host tab, so nothing links to the route and the defect was never seen. |
| **Consequence** | Visiting `/accounting/cheque-leaf/create` throws `View [accounting::cheque-leaf.create] not found` (HTTP 500). The route is registered and permission-gated, so it looks supported. |
| **Reproduce** | As an account role open `http://test.localhost:8000/accounting/cheque-leaf/create`. Expected a create form; actual a 500. |
| **Fix approach** | DECISION — redirect `create()` to the reconciliation tab (matches `index()` and the modal UI) or add the missing Blade. See `02-fix-plan.md` §1. |
| **Plan item** | CHQF-15 in `02-fix-plan.md` §1 (DECISION) |

```php
// ChequeLeafController.php:26-34 — CURRENT
    public function create()
    {
        Gate::authorize('tenant.accounting.cheque-leaf.create');

        $registers   = ChequeRegister::where('status', 'Active')->orderBy('book_number')->get();
        $bankLedgers = Ledger::selectableBankAccounts();

        return view('accounting::cheque-leaf.create', compact('registers', 'bankLedgers'));
    }
```

**Evidence**
```
$ php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\fa-probe6.php
accounting::cheque-leaf.create=NO
accounting::cheque-leaf.edit=yes
accounting::cheque-leaf.show=yes
accounting::cheque-leaf.trash=yes
```

#### CHQF-16 · M · VIEW-01 — The detail page reads a column that does not exist

| Field | Value |
|---|---|
| **Rule** | VIEW-01 (M) — a template must only read columns that exist; a missing attribute renders silently |
| **Where** | `Modules/Accounting/resources/views/cheque-leaf/show.blade.php:84-87` |
| **Root cause** | The view reads `$chequeLeaf->cancelled_date`, but `acc_cheque_leaves` has no `cancelled_date` column (the columns are `id`, `cheque_register_id`, `bank_ledger_id`, `leaf_no`, `status`, `voucher_id`, `issued_date`, `cancelled_reason`, `created_at`, `updated_at`, `is_active`, `deleted_at`). Eloquent returns null for an unknown attribute. |
| **Consequence** | The detail page always shows `Cancelled Date: -`, so users believe no cancellation date was recorded even when the reason and status are present. |
| **Reproduce** | Open `/accounting/cheque-leaf/{id}` for any cancelled leaf; the row shows `-`. |
| **Fix approach** | Remove the dead row; there is no column to display. |
| **Plan item** | CHQF-16 in `02-fix-plan.md` §7 |

```php
// show.blade.php:84-87 — CURRENT
                                        <tr>
                                            <td class="text-muted">Cancelled Date:</td>
                                            <td class="fw-semibold">{{ $chequeLeaf->cancelled_date ? date('d M Y', strtotime($chequeLeaf->cancelled_date)) : '-' }}</td>
                                        </tr>
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\resources\views\cheque-leaf\show.blade.php -Pattern "cancelled_date" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
86:                                             <td class="fw-semibold">{{ $chequeLeaf->cancelled_date ? date('d M Y', strtotime($chequeLeaf->cancelled_date)) : '-' }}</td>
$ php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\fa-probe2.php
columns=id,cheque_register_id,bank_ledger_id,leaf_no,status,voucher_id,issued_date,cancelled_reason,created_at,updated_at,is_active,deleted_at
```

### F11 — Security and tenancy

Clean — `Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "env\(|DB::raw|whereRaw|orderByRaw|selectRaw|\?\? 1|password|token"` → no output. All 11 routes carry the tenancy middleware `PreventAccessFromCentralDomains`, `InitializeTenancyByDomain`, `EnsureTenantIsActive` and `EnsureTenantHasModule:Accounting` (route output in §4).

### F12 — Style

#### CHQF-17 · L · STY-02 — Pint fails on the controller

| Field | Value |
|---|---|
| **Rule** | STY-02 (L) — Pint-clean (PSR-12 + Laravel preset) |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php` (whole file) |
| **Root cause** | Pint reports five fixers: `fully_qualified_strict_types`, `concat_space`, `ordered_imports`, `binary_operator_spaces`, `single_blank_line_at_eof`. |
| **Consequence** | The file fails the project style gate; no runtime effect. |
| **Reproduce** | `vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ChequeLeafController.php --format agent`. |
| **Fix approach** | Run Pint on the touched file after the other edits. |
| **Plan item** | Style item in `02-fix-plan.md` §8 |

```php
// ChequeLeafController.php:47-49 — CURRENT (string concatenation with spaces, one of the Pint hits)
                'message'      => 'Cheque Leaf created: ' . $leaf->leaf_no,
                'leaf_no'      => $leaf->leaf_no,
                'performed_by' => auth()->id(),
```

**Evidence**
```
$ vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\ChequeLeafController.php --format agent
{"tool":"pint","result":"fail","files":[{"path":"Modules\\Accounting\\app\\Http\\Controllers\\ChequeLeafController.php","fixers":["fully_qualified_strict_types","concat_space","ordered_imports","binary_operator_spaces","single_blank_line_at_eof"]}]}
```

### F13 — Deep read (answer all 8 questions for every mutating method)

| Method | 1 Wrong data | 2 Delete before replace | 3 Duplicate implementation | 4 Soft-delete x unique | 5 Race | 6 Auth hole | 7 Lying message | 8 Dead feature |
|---|---|---|---|---|---|---|---|---|
| `store` | CHQF-07 | ok | ok | CHQF-07 | CHQF-07 | ok (FormRequest + Gate) | ok | ok |
| `update` | CHQF-07 | ok | ok | CHQF-07 | CHQF-07 | ok (FormRequest + Gate) | ok | ok |
| `destroy` | ok (soft delete is reversible) | ok | ok | ok | ok | ok | ok | ok |
| `changeStatus` | ok (no transition matrix exists in the DDL) | ok | CHQF-08 (second validation surface) | ok | ok | CHQF-06 | ok | ok |
| `restore` | ok | ok | ok | CHQF-07 (unique index includes trashed rows) | ok | ok | ok | ok |
| `forceDelete` | CHQF-18 | CHQF-18 | ok | ok | ok | ok | CHQF-19 | ok |

#### CHQF-18 · H · TXN-03 — Permanent delete can orphan a voucher reference

| Field | Value |
|---|---|
| **Rule** | TXN-03 (H) — no irreversible side effect before the write succeeds; a permanent delete must not leave a referenced row dangling |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:210-235`; `Modules/Accounting/app/Models/ChequeLeaf.php:20` (`voucher_id`); `database/migrations/tenant/2026_09_16_100057_create_acc_voucher_bank_details_table.php:32` |
| **Root cause** | `forceDelete()` permanently removes a leaf without checking whether a voucher still references it. `acc_cheque_leaves.voucher_id` is set when the leaf is used (leaf id 1 has voucher 7 in the live tenant), and `acc_voucher_bank_details.cheque_leaf_id` has an index but no foreign key ("application-enforced" in the migration comment at `2026_09_16_100042_create_acc_cheque_leaves_table.php:9`). |
| **Consequence** | A permanent delete can leave a posted voucher's bank details pointing at a leaf row that no longer exists; the leaf-to-voucher link cannot be rebuilt. |
| **Reproduce** | Open the trash page, permanently delete leaf id 1 (it has `voucher_id` 7 in the live tenant); the voucher keeps the id but the leaf row is gone. |
| **Fix approach** | DECISION — refuse the permanent delete when `voucher_id` is not null, or record it as accepted, or add a DB foreign key (needs a migration). See `02-fix-plan.md` §1. |
| **Plan item** | CHQF-18 in `02-fix-plan.md` §1 (DECISION) |

```php
// ChequeLeafController.php:210-220 — CURRENT
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.cheque-leaf.forceDelete');

        DB::beginTransaction();
        try {
            $model = ChequeLeaf::withTrashed()->findOrFail($id);
            $leafNo = $model->leaf_no;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
```

**Evidence**
```
$ php C:\Users\GAURAV~1\AppData\Local\Temp\opencode\fa-probe5.php
leaf=1
register=1
bankLedger=4
voucher=7
is_active_type=integer
voucher_bank_details_with_leaf=0
$ Select-String -Path database\migrations\tenant\2026_09_16_100057_create_acc_voucher_bank_details_table.php -Pattern "cheque_leaf_id" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
32:             $table->unsignedBigInteger('cheque_leaf_id')->nullable();
43:             $table->index('cheque_leaf_id', 'idx_acc_vbd_leaf');
```

#### CHQF-19 · L · TXN-04 — Permanent delete writes the same audit event as a soft delete

| Field | Value |
|---|---|
| **Rule** | TXN-04 (L) — the activity event literal is recorded verbatim; the audit trail must not lie |
| **Where** | `Modules/Accounting/app/Http/Controllers/ChequeLeafController.php:220` (forceDelete) and `121` (destroy) |
| **Root cause** | `forceDelete()` logs the literal `'Deleted'`, identical to the soft delete in `destroy()`. |
| **Consequence** | The audit trail cannot distinguish a recoverable soft delete from a permanent delete. |
| **Reproduce** | Static only — inspect `sys_activity_logs.event` for the two paths. |
| **Fix approach** | Use `'ForceDeleted'` in `forceDelete()`. |
| **Plan item** | CHQF-19 in `02-fix-plan.md` §3 |

```php
// ChequeLeafController.php:220-224 — CURRENT
            activityLog($model, 'Deleted', [
                'message'      => 'Cheque Leaf permanently deleted: ' . $leafNo,
                'leaf_no'      => $leafNo,
                'performed_by' => auth()->id(),
            ]);
```

**Evidence**
```
$ Select-String -Path Modules\Accounting\app\Http\Controllers\ChequeLeafController.php -Pattern "activityLog\(" | ForEach-Object { "$($_.LineNumber): $($_.Line)" }
46:             activityLog($leaf, 'Created', [
94:             activityLog($chequeLeaf, 'Updated', [
121:             activityLog($chequeLeaf, 'Deleted', [
156:             activityLog($chequeLeaf, 'StatusChanged', [
193:             activityLog($model, 'Restored', [
220:             activityLog($model, 'Deleted', [
```

## 7. Cross-cutting notes (common or other-module classes - not fixed here)

| Class | Defect | Rule | Who should fix |
|---|---|---|---|
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-leaves.blade.php:162-170` | The create modal labels the Cheque Book "(Optional)" and leaves the select non-required, but `ChequeLeafRequest` requires `cheque_register_id` and the column is NOT NULL. Submitting the modal without a book returns a 422 for a field the form says is optional. | VAL-05 | the `AccDashboardController` / ChequeReconciliation report (the host page renders this partial) |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-leaves.blade.php:240` | The status modal action is hard-coded as `'/accounting/cheque-leaf/' + leafId + '/change-status'` instead of `route('accounting.cheque-leaf.changeStatus', …)`. It breaks when the app is served from a subdirectory and bypasses route-name changes. | STY-07 | the `AccDashboardController` / ChequeReconciliation report |
| `Modules/Accounting/app/Models/ChequeRegister.php:51-66` | The `created` hook inserts one `ChequeLeaf` row per leaf inside a loop, outside the register's own transaction. A 500-leaf book is 500 INSERT statements, and a failure midway leaves a partial book with no rollback. | QRY-07 | ChequeRegisterController report (class owned there) |
| `Modules/Accounting/resources/views/pages/partials/cheques-reconciliation/_cheque-leaves.blade.php:5-54` | The tab search bar passes `permissions="tenant.accounting.cheque-leaf"` and relies on the default `.restore` ability for the trash button; that is correct today, but the `.restore` and `.delete` abilities are easy to confuse for a future controller. Informational. | AUTH-06 | ChequeReconciliation report (informational) |

## 8. Not covered, and why

- **Scanner and self-check skipped.** `final-audit-reports/_tools/scanfilter.py` and `selfcheck.py` are missing and the brief forbids running `scan.php`. F1-F13 were done manually with the read/grep commands quoted above.
- **No tests.** Protocol D4 forbids running `php artisan test`, Pest or Dusk. Nothing in this report relies on a test run.
- **No browser render.** The three existing Blade files were read line by line but not rendered; the view-existence probe (`view()->exists`) proves which templates resolve. `create.blade.php` is the only missing one.
- **Host page out of scope.** `/accounting/cheques-reconciliation?tab=cheque-leaves` is rendered by `AccDashboardController`, and the create/status modals live in its partial. §7 records the two defects that affect this controller's writes.
- **Linked classes were not re-audited.** `ChequeRegister`, `Ledger`, `Voucher`, `BaseAccountingModel`, `AccountingContext` and the activity-log model are owned by other reports; only this controller's use of them was checked. The LedgerController and VoucherController reports are not written yet; the ChequeRegisterController report exists.
- **FormRequest not executed.** `ChequeLeafRequest` has no cross-field rule; the unique index it must mirror was checked directly against the live tenant schema instead.
- **Live data sample.** Counts and the leaf 1 voucher link were read from tenant `xyz_school_00000000000040008000_202627` at audit time; they can change.
