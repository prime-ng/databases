# Fix Plan — Accounting / TdsDeductionController

**From:** `01-report.md` (2026-10-23) · **Developer folder:** gaurav · **Applied by:** `final-audit-fixer`
**Environment:** `C:\laragon\www\PG\prime_ai` (PowerShell). Verification is `php -l` + `vendor\bin\pint` + the manual scenarios in §11; **no test suite** (D4).
**Rule:** 17 findings → 0 left. Apply **top to bottom**. Do not commit unless asked.

---

## 0. Do not touch

| File | Why |
|---|---|
| `config/permissionslist.php` | ⚠ SHARED — only the `TDSD-03` DECISION may edit it, and only after sign-off. |
| `Modules/Accounting/resources/views/pages/partials/tds-management/_tds-deductions.blade.php` | ⚠ SHARED — owned by `AccDashboardController`; `TDSD-04` is a hand-off. |
| `Modules/Accounting/routes/web.php` | ⚠ SHARED — only the `TDSD-08` DECISION may change the restore verb. |
| `database/migrations/tenant/2026_09_16_100067_create_acc_tds_deductions_table.php` | Schema is source of truth; do not add a migration. |
| Sibling TDS controllers/models | Out of scope; the permission gap is noted in the report §7. |
| `_tools/scanfilter.py`, `selfcheck.py`, `scan.php` | Missing / must not run. |

## 1. Blockers reachable today

### TDSD-06 · High · Validation mirrors schema (`VAL-04`)

| Field | Value |
|---|---|
| **Finding** | `voucher_item_id` is `nullable` but `NOT NULL`; no unique rule for `(voucher_item_id, section_code)` |
| **File:line** | `Modules/Accounting/app/Http/Requests/TdsDeductionRequest.php:20-27` |
| **Change** | Make `voucher_item_id` required and add a scoped unique rule that ignores the current row and **does not** hide trashed rows (mirrors `uq_acc_tdsded`). |
| **Touches** | `Modules/Accounting/app/Http/Requests/TdsDeductionRequest.php` |
| **Expect** | The second create for the same line + section returns **422** on `voucher_item_id`; no `SQLSTATE` / 500. |
| **Effort** | S |

**Before**
```php
    public function rules(): array
    {
        $id = $this->route('tds_deduction')?->id ?? $this->route('tds_deduction') ?? $this->route('tds-deduction');

        return [
            'voucher_id'              => ['required', 'exists:acc_vouchers,id'],
            'voucher_item_id'         => ['nullable', 'exists:acc_voucher_items,id'],
```

**After**
```php
    public function rules(): array
    {
        $id = $this->route('tds_deduction')?->id ?? $this->route('tds_deduction') ?? $this->route('tds-deduction');

        return [
            'voucher_id'              => ['required', 'exists:acc_vouchers,id'],
            'voucher_item_id'         => [
                'required',
                'exists:acc_voucher_items,id',
                Rule::unique('acc_tds_deductions', 'voucher_item_id')
                    ->where(fn ($query) => $query->where('section_code', $this->input('section_code')))
                    ->ignore($id),
            ],
```

**Verify** — submit twice for the same line + section: the second must return a **422** on `voucher_item_id`, not a 500/`SQLSTATE`. Submit a voucher with no matching item: must be a 422, not a NOT NULL error.

---

### TDSD-01 · Blocker · Remove the 7 hand-rolled transactions and raw messages (`ERR-01`)

| Field | Value |
|---|---|
| **Finding** | `DB::beginTransaction()` + `catch (\Throwable) { … return …$e->getMessage(); }` in 7 methods; `findOrFail` inside the `try` in restore/forceDelete |
| **File:line** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php:47-88, 140-168, 170-193, 195-220, 222-248, 259-283, 285-309` |
| **Change** | Rewrite each method to `DB::transaction(fn () => …)`; resolve the trashed model before the transaction; delete every `catch`/`Log::error`/`getMessage`. Add one private certificate helper used by `store` (TDSD-02 wires the other four). |
| **Touches** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` |
| **Expect** | `Select-String -Pattern "beginTransaction\|catch \(\\Throwable\|getMessage"` → no output; a missing restore id → **404**; the helper exists and `store` calls it. |
| **Effort** | L |

**Before — store (47-88)**
```php
    public function store(TdsDeductionRequest $request)
    {
        Gate::authorize('tenant.accounting.tds-deduction.create');

        $validated = $request->validated();

        DB::beginTransaction();
        try {
            $deduction = TdsDeduction::create($validated);

            // If certificate was used, update consumed amount
            if (!empty($validated['tds_certificate_id'])) {
                $cert = TdsCertificate::find($validated['tds_certificate_id']);
                if ($cert) {
                    $cert->increment('consumed_amount', (float) $validated['taxable_amount']);
                    if ($cert->isExhausted()) {
                        $cert->update(['status' => 'Exhausted']);
                    }
                }
            }

            activityLog($deduction, 'Created', [
                'message'      => 'TDS Deduction recorded: ₹' . number_format((float) $deduction->tds_amount, 2) . ' under Section ' . $deduction->section_code,
                'section_code' => $deduction->section_code,
                'tds_amount'   => $deduction->tds_amount,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
                ->with('success', 'TDS Deduction recorded successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to create TDS Deduction', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->withInput()->with('error', 'Failed to create TDS Deduction: ' . $e->getMessage());
        }
    }
```

**After — store**
```php
    public function store(TdsDeductionRequest $request): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.create');

        $validated = $request->validated();

        DB::transaction(function () use ($validated): void {
            $deduction = TdsDeduction::create($validated);

            $this->adjustCertificateConsumption(
                $validated['tds_certificate_id'] ?? null,
                (float) $validated['taxable_amount']
            );

            activityLog($deduction, 'Created', [
                'message'      => 'TDS Deduction recorded: ₹' . number_format((float) $deduction->tds_amount, 2) . ' under Section ' . $deduction->section_code,
                'section_code' => $deduction->section_code,
                'tds_amount'   => $deduction->tds_amount,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
            ->with('success', 'TDS Deduction recorded successfully.');
    }
```

**Before — update (140-168)**
```php
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction)
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        DB::beginTransaction();
        try {
            $validated = $request->validated();
            $tdsDeduction->update($validated);

            activityLog($tdsDeduction, 'Updated', [
                'message'      => 'TDS Deduction updated: ID #' . $tdsDeduction->id,
                'section_code' => $tdsDeduction->section_code,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
                ->with('success', 'TDS Deduction updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to update TDS Deduction', [
                'id'    => $tdsDeduction->id,
                'error' => $e->getMessage(),
            ]);

            return back()->withInput()->with('error', 'Failed to update TDS Deduction: ' . $e->getMessage());
        }
    }
```

**After — update**
```php
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $validated = $request->validated();

        DB::transaction(function () use ($tdsDeduction, $validated): void {
            $tdsDeduction->update($validated);

            activityLog($tdsDeduction, 'Updated', [
                'message'      => 'TDS Deduction updated: ID #' . $tdsDeduction->id,
                'section_code' => $tdsDeduction->section_code,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
            ->with('success', 'TDS Deduction updated successfully.');
    }
```

**Before — destroy (170-193)**
```php
    public function destroy(TdsDeduction $tdsDeduction)
    {
        Gate::authorize('tenant.accounting.tds-deduction.delete');

        DB::beginTransaction();
        try {
            $tdsDeduction->delete();

            activityLog($tdsDeduction, 'Deleted', [
                'message'      => 'TDS Deduction moved to trash: ID #' . $tdsDeduction->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
                ->with('success', 'TDS Deduction moved to trash.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to delete TDS Deduction', ['id' => $tdsDeduction->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete TDS Deduction: ' . $e->getMessage());
        }
    }
```

**After — destroy**
```php
    public function destroy(TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.delete');

        DB::transaction(function () use ($tdsDeduction): void {
            $tdsDeduction->delete();

            activityLog($tdsDeduction, 'Deleted', [
                'message'      => 'TDS Deduction moved to trash: ID #' . $tdsDeduction->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
            ->with('success', 'TDS Deduction moved to trash.');
    }
```

**Before — toggleStatus (195-220)**
```php
    public function toggleStatus(Request $request, TdsDeduction $tdsDeduction)
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::beginTransaction();
        try {
            $tdsDeduction->is_active = $request->input('is_active');
            $tdsDeduction->save();

            activityLog($tdsDeduction, 'Toggled', [
                'message'      => 'TDS Deduction active status toggled: ID #' . $tdsDeduction->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return response()->json(['success' => true, 'is_active' => $tdsDeduction->is_active, 'message' => 'Status updated.']);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to toggle TDS Deduction status', ['id' => $tdsDeduction->id, 'error' => $e->getMessage()]);

            return response()->json(['success' => false, 'message' => 'Failed to update status: ' . $e->getMessage()], 500);
        }
    }
```

**After — toggleStatus**
```php
    public function toggleStatus(Request $request, TdsDeduction $tdsDeduction): \Illuminate\Http\JsonResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $request->validate(['is_active' => 'required|boolean']);

        DB::transaction(function () use ($request, $tdsDeduction): void {
            $tdsDeduction->is_active = $request->boolean('is_active');
            $tdsDeduction->save();

            activityLog($tdsDeduction, 'Toggled', [
                'message'      => 'TDS Deduction active status toggled: ID #' . $tdsDeduction->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return response()->json(['success' => true, 'is_active' => $tdsDeduction->is_active, 'message' => 'Status updated.']);
    }
```

**Before — changeStatus (222-248)**
```php
    public function changeStatus(Request $request, TdsDeduction $tdsDeduction)
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $request->validate(['status' => 'required|in:Deducted,Partly_Paid,Paid,Reversed']);

        DB::beginTransaction();
        try {
            $tdsDeduction->status = $request->input('status');
            $tdsDeduction->save();

            activityLog($tdsDeduction, 'StatusChanged', [
                'message'      => 'TDS Deduction status changed to ' . $tdsDeduction->status,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
                ->with('success', 'Status updated successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to change TDS Deduction status', ['id' => $tdsDeduction->id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to update status: ' . $e->getMessage());
        }
    }
```

**After — changeStatus**
```php
    public function changeStatus(Request $request, TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $request->validate(['status' => 'required|in:Deducted,Partly_Paid,Paid,Reversed']);

        DB::transaction(function () use ($request, $tdsDeduction): void {
            $tdsDeduction->status = $request->input('status');
            $tdsDeduction->save();

            activityLog($tdsDeduction, 'StatusChanged', [
                'message'      => 'TDS Deduction status changed to ' . $tdsDeduction->status,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
            ->with('success', 'Status updated successfully.');
    }
```

**Before — restore (259-283)**
```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.restore');

        DB::beginTransaction();
        try {
            $model = TdsDeduction::onlyTrashed()->findOrFail($id);
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'TDS Deduction restored: ID #' . $model->id,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.tds-deduction.trashed')->with('success', 'TDS Deduction restored successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to restore TDS Deduction', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to restore TDS Deduction: ' . $e->getMessage());
        }
    }
```

**After — restore**
```php
    public function restore($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.restore');

        $model = TdsDeduction::onlyTrashed()->findOrFail($id);

        DB::transaction(function () use ($model): void {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
                'message'      => 'TDS Deduction restored: ID #' . $model->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.tds-deduction.trashed')->with('success', 'TDS Deduction restored successfully.');
    }
```

**Before — forceDelete (285-309)**
```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.forceDelete');

        DB::beginTransaction();
        try {
            $model = TdsDeduction::withTrashed()->findOrFail($id);
            $idVal = $model->id;
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'TDS Deduction permanently deleted: ID #' . $idVal,
                'performed_by' => auth()->id(),
            ]);

            DB::commit();

            return redirect()->route('accounting.tds-deduction.trashed')->with('success', 'TDS Deduction permanently deleted.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Failed to force delete TDS Deduction', ['id' => $id, 'error' => $e->getMessage()]);

            return back()->with('error', 'Failed to delete TDS Deduction: ' . $e->getMessage());
        }
    }
```

**After — forceDelete**
```php
    public function forceDelete($id): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.forceDelete');

        $model = TdsDeduction::withTrashed()->findOrFail($id);

        DB::transaction(function () use ($model): void {
            $model->forceDelete();

            activityLog($model, 'Deleted', [
                'message'      => 'TDS Deduction permanently deleted: ID #' . $model->id,
                'performed_by' => auth()->id(),
            ]);
        });

        return redirect()->route('accounting.tds-deduction.trashed')->with('success', 'TDS Deduction permanently deleted.');
    }
```

**Add after `forceDelete` (before the class closing brace)** — used by `store` now, and by TDSD-02 later:
```php
    private function adjustCertificateConsumption(int|string|null $certificateId, float $delta): void
    {
        if (! $certificateId) {
            return;
        }

        $cert = TdsCertificate::whereKey((int) $certificateId)->lockForUpdate()->first();
        if (! $cert) {
            return;
        }

        $cert->consumed_amount = max(0, (float) $cert->consumed_amount + $delta);

        if ($cert->status === 'Exhausted' && ! $cert->isExhausted()) {
            $cert->status = 'Active';
        } elseif ($cert->status === 'Active' && $cert->isExhausted()) {
            $cert->status = 'Exhausted';
        }

        $cert->save();
    }
```
The `Log` import becomes unused — remove it now (or let Pint do it in TDSD-14):
```php
use Illuminate\Support\Facades\Log;   // delete this line
```

**Verify** — force a duplicate create (after TDSD-06 it is a 422, so instead force a DB error by temporarily breaking a column, or call `restore` with a missing id): a missing id must return **404**, not a flash. A successful create/update/delete must still write one `sys_activity_log` row.

---

### TDSD-09 · High · `create()` renders a missing view (`CTL-10`)

| Field | Value |
|---|---|
| **Finding** | `view('accounting::tds-deduction.create')` has no file |
| **File:line** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php:30-45` |
| **Change** | Redirect to the hub tab; creation is the modal. Drops 7 unused loader queries. |
| **Touches** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` |
| **Expect** | `GET /accounting/tds-deduction/create` → **302** to the hub; no `View [accounting::tds-deduction.create] not found`. |
| **Effort** | S |

**Before**
```php
    public function create()
    {
        Gate::authorize('tenant.accounting.tds-deduction.create');

        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $tdsLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
        $periods = AccountingPeriod::where('is_active', true)->orderBy('period_no')->get();
        $taxRules = TaxRule::where('is_active', true)->get();
        $certificates = TdsCertificate::where('status', 'Active')->get();
        $vouchers = Voucher::orderByDesc('voucher_date')->limit(50)->get();

        return view('accounting::tds-deduction.create', compact(
            'partyLedgers', 'tdsLedgers', 'financialYears', 'periods', 'taxRules', 'certificates', 'vouchers'
        ));
    }
```

**After**
```php
    public function create(): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.create');

        return redirect()
            ->route('accounting.menu.tds', ['tab' => 'tds-deductions'])
            ->with('info', 'Use the "Record TDS Deduction" button on the TDS Deductions tab.');
    }
```

**Verify** — Super Admin visits `/accounting/tds-deduction/create` → 302 to `/accounting/tds?tab=tds-deductions`, no 500.

---

## 2. Fixes that arm a latent defect (sequenced)

None separately. The only armed pairing (`TDSD-06` → `TDSD-01`) is sequenced inside §1: TDSD-06 is item 1, TDSD-01 item 2.

---

## 3. Errors & transactions (F1/F2)

### TDSD-02 · High · Certificate consumption reconciliation (`TXN-06`)

| Field | Value |
|---|---|
| **Finding** | `consumed_amount` is locked on create only after TDSD-01; update/destroy/restore/forceDelete never reverse/re-apply it |
| **File:line** | `TdsDeductionController.php:140-168` (update), `170-193` (destroy), `259-283` (restore), `285-309` (forceDelete) |
| **Change** | Call `adjustCertificateConsumption()` (added in TDSD-01) with the correct signed delta. `forceDelete` only reverses when the row is **not already trashed** (soft delete already reversed it). |
| **Touches** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` |
| **Expect** | Edit 120000→10000 → cert `10000`; trash → `0`; restore → `10000`; trash+force → `0`; live force → decremented once. |
| **Effort** | M |

**Before — update (post-TDSD-01)**
```php
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $validated = $request->validated();

        DB::transaction(function () use ($tdsDeduction, $validated): void {
            $tdsDeduction->update($validated);

            activityLog($tdsDeduction, 'Updated', [
```

**After — update**
```php
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $validated = $request->validated();
        $oldCertificateId = $tdsDeduction->tds_certificate_id;
        $oldTaxable = (float) $tdsDeduction->taxable_amount;

        DB::transaction(function () use ($tdsDeduction, $validated, $oldCertificateId, $oldTaxable): void {
            $tdsDeduction->update($validated);

            $this->adjustCertificateConsumption($oldCertificateId, -$oldTaxable);
            $this->adjustCertificateConsumption(
                $validated['tds_certificate_id'] ?? null,
                (float) $validated['taxable_amount']
            );

            activityLog($tdsDeduction, 'Updated', [
```

**Before — destroy (post-TDSD-01)**
```php
        DB::transaction(function () use ($tdsDeduction): void {
            $tdsDeduction->delete();
```

**After — destroy**
```php
        DB::transaction(function () use ($tdsDeduction): void {
            $this->adjustCertificateConsumption(
                $tdsDeduction->tds_certificate_id,
                -(float) $tdsDeduction->taxable_amount
            );

            $tdsDeduction->delete();
```

**Before — restore (post-TDSD-01)**
```php
        DB::transaction(function () use ($model): void {
            $model->restore();
            $model->update(['is_active' => true]);

            activityLog($model, 'Restored', [
```

**After — restore**
```php
        DB::transaction(function () use ($model): void {
            $model->restore();
            $model->update(['is_active' => true]);

            $this->adjustCertificateConsumption(
                $model->tds_certificate_id,
                (float) $model->taxable_amount
            );

            activityLog($model, 'Restored', [
```

**Before — forceDelete (post-TDSD-01)**
```php
        DB::transaction(function () use ($model): void {
            $model->forceDelete();
```

**After — forceDelete**
```php
        DB::transaction(function () use ($model): void {
            if (! $model->trashed()) {
                $this->adjustCertificateConsumption(
                    $model->tds_certificate_id,
                    -(float) $model->taxable_amount
                );
            }

            $model->forceDelete();
```

**Verify** — the live certificate starts **already drifted**: `consumed_amount=0.00`, `limit_amount=NULL`, linked to a `120000.00` deduction. The helper clamps at 0, so the first edit behaves like a set-to-new-taxable:
1. Edit taxable `120000 → 10000` → `consumed_amount` = `10000`.
2. Soft-delete → `0`; restore → `10000`.
3. Soft-delete then force-delete → stays `0` (no double subtraction).
4. Create a live row with a cert, force-delete it directly → decremented once.
Because `limit_amount=NULL`, `isExhausted()` stays false for this certificate; that is the model's rule (`limit_amount > 0`), not a bug in this controller.
No trashed deductions exist today (`trashed_deductions=0`), so no backfill is needed. The pre-existing `consumed=0` on certificate #1 is seed drift; decide separately whether to backfill it to `120000`.

---

## 4. Authorization (F3)

### TDSD-04 · Medium · ⚠ SHARED — gate drift in the hub partial (`AUTH-06`)

| Field | Value |
|---|---|
| **Finding** | The table/modal gate on `dashboard.view`; the controller gates on `tds-deduction.*`; the search bar already asks for the (missing) TDS base key |
| **File:line** | `_tds-deductions.blade.php:89` (table), `:265` (modal); `edit.blade.php:50`, `trash.blade.php:40` (no `@can`) |
| **Change** | **Stop and ask the owner (`AccDashboardController`)** before editing the shared partial. Then align the two gates and add `@can` around the record actions. |
| **Touches** | `_tds-deductions.blade.php` (⚠ SHARED), `edit.blade.php`, `trash.blade.php` |
| **Expect** | Line 89 = `...viewAny`, line 265 = `...create`; no `dashboard.view` remains in the TDS partial. |
| **Effort** | S |

**Before**
```blade
'permission' => 'tenant.accounting.dashboard.view',
permission="tenant.accounting.dashboard.view">
```

**After**
```blade
'permission' => 'tenant.accounting.tds-deduction.viewAny',
permission="tenant.accounting.tds-deduction.create">
```
`app/View/Components/Backend/Tab/Modal.php:133` does `Gate::check($permission)`, so the modal prop must be a **full** ability (`.create`); the table config follows the same full-ability convention (`nav-tab.blade.php:72`).

For the controller-owned blades, gate the submit/restore only (`@can('tenant.accounting.tds-deduction.update')` around the edit submit button, `@can('...restore')` around the trash link). Do **not** edit the shared partial without the owner's sign-off.

**Verify** — grant `dashboard.view` without any TDS permission: the TDS table renders, the Create trigger is absent, and a crafted POST is 403. Grant `tds-deduction.*`: the tab, Create and Edit work.

---

### TDSD-05 · Low · Remove the duplicate authorization (`AUTH-04`)

| Field | Value |
|---|---|
| **Finding** | FormRequest `authorize()` and controller `Gate::authorize()` both check the same ability on store/update |
| **File:line** | `TdsDeductionController.php:49`, `:142` (after TDSD-01) |
| **Change** | Keep the FormRequest; delete the two controller `Gate::authorize()` lines. |
| **Touches** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` |
| **Expect** | `Select-String -Pattern "Gate::authorize" | Measure-Object` → 10 (was 12); store/update still 403 for a user without the verb. |
| **Effort** | S |

**Before**
```php
    public function store(TdsDeductionRequest $request): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.create');

        $validated = $request->validated();
```
and
```php
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        Gate::authorize('tenant.accounting.tds-deduction.update');

        $validated = $request->validated();
```

**After**
```php
    public function store(TdsDeductionRequest $request): \Illuminate\Http\RedirectResponse
    {
        $validated = $request->validated();
```
and
```php
    public function update(TdsDeductionRequest $request, TdsDeduction $tdsDeduction): \Illuminate\Http\RedirectResponse
    {
        $validated = $request->validated();
```

**Verify** — an Account Staff user with `tds-deduction.create`/`update` can still submit both forms; a user without the verb is still 403 (from the FormRequest).

---

## 5. Validation, routes, models (F4/F5/F7)

### TDSD-11 · Medium · Cast `is_active` (`MDL-02`)

| Field | Value |
|---|---|
| **Finding** | `is_active` returns integer `1`, not `true` |
| **File:line** | `Modules/Accounting/app/Models/TdsDeduction.php:42-54` |
| **Change** | Add the boolean cast. |
| **Touches** | `Modules/Accounting/app/Models/TdsDeduction.php` |
| **Expect** | `TdsDeduction::first()->is_active` → `true` (bool); JSON returns `true`. |
| **Effort** | S |

**Before**
```php
        'is_higher_rate_no_pan'  => 'boolean',
        'paid_amount'            => 'decimal:2',
        'certificate_issued_at'  => 'datetime',
```

**After**
```php
        'is_higher_rate_no_pan'  => 'boolean',
        'is_active'              => 'boolean',
        'paid_amount'            => 'decimal:2',
        'certificate_issued_at'  => 'datetime',
```

**Verify** — in the tenant context, `TdsDeduction::first()->is_active` → `true` (boolean), and `toggleStatus` returns `"is_active": true` in JSON, not `1`.

---

## 6. Queries & performance (F9)

### TDSD-12 · Medium · Remove the duplicate ledger query (`QRY-12`)

| Field | Value |
|---|---|
| **Finding** | `$partyLedgers` and `$tdsLedgers` run the same query; all six loaders fetch `*` |
| **File:line** | `TdsDeductionController.php:115-121` (`edit` only; `create` is now a redirect) |
| **Change** | Reuse one ledger collection; select only the columns the view reads. |
| **Touches** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` |
| **Expect** | One `Ledger` query in the log for the edit page (was two); the party/TDS dropdowns still populate. |
| **Effort** | S |

**Before**
```php
        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $tdsLedgers = Ledger::where('is_active', true)->orderBy('name')->get();
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get();
        $periods = AccountingPeriod::where('is_active', true)->orderBy('period_no')->get();
        $taxRules = TaxRule::where('is_active', true)->get();
        $certificates = TdsCertificate::where('status', 'Active')->get();
        $vouchers = Voucher::with(['partyLedger'])->orderByDesc('voucher_date')->limit(100)->get();
```

**After**
```php
        $partyLedgers = Ledger::where('is_active', true)->orderBy('name')->get(['id', 'name', 'code']);
        $tdsLedgers = $partyLedgers;
        $financialYears = FinancialYear::where('is_active', true)->orderByDesc('start_date')->get(['id', 'name']);
        $periods = AccountingPeriod::where('is_active', true)->orderBy('period_no')->get(['id', 'name', 'period_no']);
        $taxRules = TaxRule::where('is_active', true)->get(['id', 'name', 'rate']);
        $certificates = TdsCertificate::where('status', 'Active')->get(['id', 'certificate_no', 'certified_rate', 'party_ledger_id']);
        $vouchers = Voucher::with(['partyLedger'])->orderByDesc('voucher_date')->limit(100)->get();
```
`$vouchers` keeps `*` because the edit view reads `formatted_number`, `voucher_display_no`, `voucher_date`, `total_amount`. `$periods`/`$taxRules` are currently passed but unused by `edit.blade.php`; leave them (behaviour-neutral) or remove them **and** their `compact()` entries.

**Verify** — open Edit: exactly one `Ledger` query in the log (was two); the three dropdowns still populate, and the certificate option still shows its party name.

---

## 7. Views (F10)

### TDSD-13 · Low · Remove the `?? 1` fallback (`SEC-03`)

| Field | Value |
|---|---|
| **Finding** | `$tdsDeduction->voucher_item_id ?? 1` can silently target voucher item 1 |
| **File:line** | `Modules/Accounting/resources/views/tds-deduction/edit.blade.php:55` |
| **Change** | Drop the fallback. |
| **Touches** | `Modules/Accounting/resources/views/tds-deduction/edit.blade.php` |
| **Expect** | `Select-String -Pattern "\?\? 1"` → no output; the seeded row still submits `voucher_item_id=1` from the model. |
| **Effort** | S |

**Before**
```blade
<input type="hidden" name="voucher_item_id" value="{{ old('voucher_item_id', $tdsDeduction->voucher_item_id ?? 1) }}">
```

**After**
```blade
<input type="hidden" name="voucher_item_id" value="{{ old('voucher_item_id', $tdsDeduction->voucher_item_id) }}">
```

**Verify** — the edit form still submits the seeded row's `voucher_item_id=1` from the model (not the fallback); a row without the column (not possible today) would submit empty and fail TDSD-06's `required` rule instead of corrupting line 1.

---

## 8. Style (F12) — one item per file

### TDSD-14 · Low · Controller Pint (`STY-02`)

| Field | Value |
|---|---|
| **Finding** | `fully_qualified_strict_types`, `concat_space`, `not_operator_with_successor_space`, `ordered_imports`, `binary_operator_spaces` fail |
| **File:line** | `TdsDeductionController.php` (whole file) |
| **Change** | Run Pint; no manual edit beyond removing the now-unused `Log` import (TDSD-01). |
| **Touches** | `Modules/Accounting/app/Http/Controllers/TdsDeductionController.php` |
| **Expect** | `pint --test` → no `fail`. |
| **Effort** | S |

**Before**
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Modules\Accounting\Http\Requests\TdsDeductionRequest;
use Modules\Accounting\Models\TdsDeduction;
use Modules\Accounting\Models\Ledger;
use Modules\Accounting\Models\FinancialYear;
use Modules\Accounting\Models\AccountingPeriod;
use Modules\Accounting\Models\TaxRule;
use Modules\Accounting\Models\TdsCertificate;
use Modules\Accounting\Models\Voucher;
```

**After**
```php
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;
use Modules\Accounting\Http\Requests\TdsDeductionRequest;
use Modules\Accounting\Models\AccountingPeriod;
use Modules\Accounting\Models\FinancialYear;
use Modules\Accounting\Models\Ledger;
use Modules\Accounting\Models\TaxRule;
use Modules\Accounting\Models\TdsCertificate;
use Modules\Accounting\Models\TdsDeduction;
use Modules\Accounting\Models\Voucher;
```
Pint will shorten the inline `\Illuminate\Http\…` signatures to `RedirectResponse`/`JsonResponse` and add `View` for the still-untyped `show`/`edit` once you add those types (TDSD-10, optional).

**Verify**
```
vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TdsDeductionController.php
```
→ no `fail`.

---

### TDSD-15 · Low · Model Pint (`STY-02`)

| Field | Value |
|---|---|
| **Finding** | Unused `BaseModel`, missing blank line, operator alignment |
| **File:line** | `TdsDeduction.php:7-9`, `:50` |
| **Change** | Remove the unused import; run Pint. |
| **Touches** | `Modules/Accounting/app/Models/TdsDeduction.php` |
| **Expect** | `pint --test` → no `fail`; no `use App\Models\BaseModel;`. |
| **Effort** | S |

**Before**
```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class TdsDeduction extends BaseAccountingModel
```

**After**
```php
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TdsDeduction extends BaseAccountingModel
```

**Verify**
```
vendor\bin\pint --test Modules\Accounting\app\Models\TdsDeduction.php
```
→ pass.

---

### TDSD-16 · Low · Request Pint (`STY-02`)

| Field | Value |
|---|---|
| **Finding** | Import order, inline FQCNs, operator alignment |
| **File:line** | `TdsDeductionRequest.php:7-9`, `:93`, `:96` |
| **Change** | Run Pint after TDSD-06 (it imports `VoucherItem` and uses `$id`). |
| **Touches** | `Modules/Accounting/app/Http/Requests/TdsDeductionRequest.php` |
| **Expect** | `pint --test` → no `fail`; `VoucherItem` is imported, not inline FQCN. |
| **Effort** | S |

**Before**
```php
use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Validation\Rule;
```

**After**
```php
use App\Traits\AuthorizesTenantFeature;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Accounting\Models\VoucherItem;
```
(and `\Modules\Accounting\Models\VoucherItem::…` becomes `VoucherItem::…`).

**Verify**
```
vendor\bin\pint --test Modules\Accounting\app\Http\Requests\TdsDeductionRequest.php
```
→ pass.

---

### TDSD-17 · Low · `TaxRule` Pint (`STY-02`)

| Field | Value |
|---|---|
| **Finding** | Unused `BaseModel`, import order, method-chain indentation, operator alignment |
| **File:line** | `TaxRule.php:7-9` (and the chained query) |
| **Change** | Remove the unused import; run Pint. |
| **Touches** | `Modules/Accounting/app/Models/TaxRule.php` |
| **Expect** | `pint --test` → no `fail`; no `use App\Models\BaseModel;`. |
| **Effort** | S |

**Before**
```php
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
```

**After**
```php
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
```

**Verify**
```
vendor\bin\pint --test Modules\Accounting\app\Models\TaxRule.php
```
→ pass.

---

## 9. Deferred / decisions

### TDSD-03 · Blocker · DECISION (⚠ SHARED) — add the permission key

| Field | Value |
|---|---|
| **Finding** | No `accounting.tds-deduction` key, so `sys_permissions` has no names and every non-super-admin is denied |
| **File:line** | `config/permissionslist.php:644` (anchor), `TdsDeductionController.php:25,32,49,92,111,142,172,197,224,252,261,287` |
| **Options** | **(a) Recommended:** add `'accounting.tds-deduction' => $crud` (all 7 verbs cover the 12 gates); run the tenant permission seeder (`TenantRolePermissionSeeder`) and confirm the four roles receive the names. **(b)** Add `accounting.tds-payment` and `accounting.tds-certificate` in the same commit (same gap). **(c)** Insert the `sys_permissions` rows by hand — rejected: the config is the producer, and the next seeder run would drop them. |
| **Why a decision** | The config is shared by every module; a new key and role grants are a policy change, not a controller fix. |
| **Choice** | ____ (a / b / c) |

**After (option a)**
```php
        'accounting.event-posting' => array_merge($crud, ['process']),
        'accounting.tds-deduction' => $crud,
```

**Verify** — after the seeder runs in the tenant context:
```
SELECT name FROM sys_permissions WHERE name LIKE 'tenant.accounting.tds-deduction.%';
-- 7 rows: create, view, viewAny, update, delete, restore, forceDelete
```
Then a School Admin can open the modal and submit; a user without the key is 403.

---

### TDSD-08 · High · DECISION (⚠ SHARED) — restore must not be GET

| Field | Value |
|---|---|
| **Finding** | `GET .../{id}/restore` mutates state |
| **File:line** | `routes/web.php:465`; `trash.blade.php:40` |
| **Options** | **(a) Recommended:** `Route::delete(...)` + a `@method('DELETE')` form with `@csrf`; update any JS that calls the link. **(b)** `POST` + form (equally valid). **(c)** Keep `GET` and accept the prefetch risk. |
| **Why a decision** | The route file is shared; changing a verb is a route re-scope (§9.3) and may break links outside this module. |
| **Choice** | ____ (a / b / c) |

**After (option a) — route**
```php
Route::delete('/tds-deduction/{id}/restore', [TdsDeductionController::class, 'restore'])->name('tds-deduction.restore');
```

**After (option a) — `trash.blade.php`**
```blade
<form action="{{ route('accounting.tds-deduction.restore', $ded->id) }}" method="POST" class="d-inline">
    @csrf
    @method('DELETE')
    <button type="submit" class="btn btn-sm btn-outline-success">
        <i class="fa-solid fa-rotate-left me-1"></i> Restore
    </button>
</form>
```

**Verify** — `php artisan route:list --path=accounting/tds-deduction` shows `DELETE .../restore`; the trash page restores via the form; a direct `GET .../restore` is 405.

---

## 10. Findings with no plan item

| Finding | Severity | Why no item |
|---|---|---|
| `TDSD-07` | Medium | Needs a business decision: the TDS tolerance (`abs(tds_amount - taxable*rate/100)`) and whether `Paid` requires `paid_amount >= tds_amount`. Auto-fixing could reject legitimate rounding or block a valid workflow. |
| `TDSD-10` | Low | Missing return types are folded into TDSD-01 (store/update/destroy/toggle/change/restore/force) and TDSD-09 (create); add `: View` to `show`/`edit` and `: RedirectResponse` to `index` during the TDSD-14 pass. No separate item. |

---

### Apply checklist

Tick `[ ]` → `[x]` for each item to apply. **⚠ SHARED** and **DECISION** items need their own explicit tick — "tick all" does not cover them. On a ticked DECISION, write the choice on its `Choice:` line.

- [ ] `TDSD-06` · H · `VAL-04` — validation mirrors schema
- [ ] `TDSD-01` · B · `ERR-01` — transaction/exception rewrite
- [ ] `TDSD-09` · H · `CTL-10` — `create()` redirect
- [ ] `TDSD-02` · H · `TXN-06` — certificate reconciliation
- [ ] `TDSD-05` · L · `AUTH-04` — duplicate authorization
- [ ] `TDSD-11` · M · `MDL-02` — boolean cast
- [ ] `TDSD-12` · M · `QRY-12` — duplicate ledger query
- [ ] `TDSD-13` · L · `SEC-03` — `?? 1` fallback
- [ ] `TDSD-14` · L · `STY-02` — controller Pint
- [ ] `TDSD-15` · L · `STY-02` — model Pint
- [ ] `TDSD-16` · L · `STY-02` — request Pint
- [ ] `TDSD-17` · L · `STY-02` — TaxRule Pint
- [ ] ⚠ SHARED `TDSD-04` · M · `AUTH-06` — partial gate hand-off
- [ ] ⚠ SHARED DECISION `TDSD-03` · B · `AUTH-01` — permission key
- [ ] ⚠ SHARED DECISION `TDSD-08` · H · `RTE-01` — restore verb

**Apply order:** `TDSD-06` → `TDSD-01` → `TDSD-09` → `TDSD-02` → `TDSD-05` → `TDSD-11` → `TDSD-12` → `TDSD-13` → `TDSD-14..17` → decisions (`TDSD-03`, `TDSD-08`), then `TDSD-04` with the owner.
`TDSD-06` arms `TDSD-01` (a NOT NULL/duplicate failure becomes a raw 500 only because of the leak), so it is sequenced **before** it.

---

### Verification run

Run after all ticked items:

```powershell
cd C:\laragon\www\PG\prime_ai
php -l Modules\Accounting\app\Http\Controllers\TdsDeductionController.php
php -l Modules\Accounting\app\Http\Requests\TdsDeductionRequest.php
php -l Modules\Accounting\app\Models\TdsDeduction.php
php -l Modules\Accounting\app\Models\TaxRule.php
# edit.blade.php is a Blade template: compile it with the Blade compiler, do NOT run php -l on it.
vendor\bin\pint --test Modules\Accounting\app\Http\Controllers\TdsDeductionController.php Modules\Accounting\app\Http\Requests\TdsDeductionRequest.php Modules\Accounting\app\Models\TdsDeduction.php Modules\Accounting\app\Models\TaxRule.php
php artisan route:list --path=accounting/tds-deduction
```

Manual scenarios:
1. Super Admin: edit the seeded deduction, change taxable, save; the certificate `consumed_amount` matches the new taxable.
2. Duplicate create (same voucher line + section) → 422, not `SQLSTATE`.
3. Missing `voucher_item_id` → 422, not NOT NULL.
4. Restore a missing id → 404.
5. Trash page restore (after TDSD-08, if accepted) → form works, GET is 405.
6. As School Admin (after TDSD-03) → the tab, modal, edit and restore all work.
7. `TdsDeduction::first()->is_active` → `true` (bool).
